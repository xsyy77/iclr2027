# Frozen review revision v4 — 2026-11-11

This package matches the revised 10-page main paper and the eleven reviewer-response questions. It preserves the original three-stage method. No new fitting, parameter selection or TEST experiment was performed for this release.

Download ALL published v4 ZIP volumes and extract them into the same directory; the files are disjoint parts of one checksummed release. Do not run verification after extracting only one volume.

## Inspect and verify

From this extracted directory, install the original package requirements and run:

```
pip install -r package/iclr2027_review_package/requirements.txt
python verify_release.py
python audit_output/verify_stage2_original_greedy.py
python audit_output/verify_matched_path_scorer.py
python audit_output/verify_reconciled_gate_statistics.py
```

The first check reads checksums and current reported statistics without training or graph search. The later commands independently replay previously frozen records; they are not model-selection procedures. See audit_output/reproduction_environment_lock.txt for the version used with serialized checkpoints.

## Exact scopes

- Main Table1 is supplied reference-aligned Clean retrieval, conditional on candidate access. Its small Full-minus-Semantic+Fixed increment combines confidence weighting and control; it is not evidence for greedy filtering or gate-only superiority.
- Automatic proposal is separate: 14,029 candidates/248 queries; useful availability100/248 to152/248. Fixed automatic Top3 PS/ER35.08/38.73 versus GraphOnly27.02/33.97.
- Revised Table4 tests the documented empty-start reconstructed Gain on oversized automatic pools:239/248 pools>K and101 selections differ from confidence-only. TypeBonus has positive pointwise ablation intervals; complete-greedy and Red independent advantages remain unestablished.
- Revised Table5 and Figure4 use EXACTLY Table1 Full: PS39.52/ER59.46,mean gate.36035. Constants/shuffles fix candidates, confidences, graph and budget. The gate-minus-mean utility interval spans zero. Historical files called revised_table4.csv now refer to revised manuscript Table5; the original ER38.05/mean gate.10917 summary is retained only as a correction record.
- Figure3 uses the normalized14,029 pool. The earlier14,041 raw-endpoint condition remains a distinct historical artifact.
- One compact numeric learned-path baseline matches supervision source and inference budget, not query/path label granularity. Its Clean comparison does not establish superiority over all path-scoring families or an isolated gate benefit.
- Split separation is by mechanism record, not strictly endpoint pairs. Nine overlapping test queries are excluded only in a post-hoc sensitivity, not a new independent holdout.
- No historical writer/code identity is fabricated. Executable reconstruction is complete operational evidence with explicit definitions.
- development_not_adopted/ preserves rejected optimization outcomes; their alternative objectives/features are not the released main method.

## Navigation

manuscript/paper_REVISED.pdf: latest compiled paper (main10/total18).
rebuttal/REBUTTAL.md: scientific reviewer responses without private author notes.
package/iclr2027_review_package/: unchanged original code/data/checkpoints.
audit_output/: automatic construction, complete selector, matched path scorer, main-configuration gate controls, splits and order robustness with generators and verifiers.
The checksum manifest identifies exact bytes; comments in original artifacts are retained as historical context rather than current claims.
