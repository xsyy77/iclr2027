from pathlib import Path
import json,hashlib,zipfile
import pandas as pd,numpy as np
P=Path(__file__).resolve().parent;m=json.loads((P/'FILE_MANIFEST.json').read_text())
for x in m['files']:
 b=(P/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
g=pd.read_csv(P/'audit_output/reconciled_gate_controls/revised_table4.csv');s=pd.read_csv(P/'audit_output/stage2_original_greedy_repair/summary.csv');r=(P/'rebuttal/REBUTTAL.md').read_text(encoding='utf-8')
assert r.count('### Q')==11 and 'stable independent gate advantage' in r
for term in ['39.52','59.46','0.36035','35.08','38.73','33.06','41.77']:
 assert term in r
for n in ['matched_path_scorer','reconciled_gate_controls','stage2_original_greedy_repair']:
 assert json.loads((P/'audit_output'/n/'independent_verification.json').read_text())['passed']
assert 'Full' in g.method.values
row=g[g.method=='Full'].iloc[0];assert abs(row.ER*100-59.46)<.01 and abs(row.PS*100-39.52)<.01
print(json.dumps(dict(passed=True,checksummed_files=len(m['files']),review_questions=11,new_fits=0,new_TEST_searches=0),indent=2))
