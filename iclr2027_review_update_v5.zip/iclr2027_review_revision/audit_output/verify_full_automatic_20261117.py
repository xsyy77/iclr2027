from pathlib import Path
from types import SimpleNamespace
import sys,json,hashlib
import numpy as np,pandas as pd,joblib
from scipy.sparse import hstack,csr_matrix
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';O=ROOT/'audit_output/full_automatic_followup_20261117';sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
src=R/'code/original_recovered/current_dmdb/step_semantic_gate_diagnostics.py';s=src.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')));ns={};exec(compile(s,str(src),'exec'),ns)
inp=pd.read_csv(O/'query_inputs_predictions.csv');m=joblib.load(ROOT/'audit_output/experiment1_recovered_proposer/gate_model.joblib');man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)}
for x in inp.itertuples(index=False):
    ns['sets'][x.task,x.rid,x.split,'Followup']=json.loads(x.selected_nodes);text,num=ns['feats'](SimpleNamespace(task=x.task,rid=x.rid,split=x.split,condition='Followup'));assert text==x.text;assert np.allclose(num,json.loads(x.numeric),rtol=0,atol=1e-14)
X=hstack([m['word'].transform(inp.text),m['char'].transform(inp.text),csr_matrix(m['sc'].transform(np.array([json.loads(n) for n in inp.numeric],np.float32)))],format='csr');assert np.allclose(m['clf'].predict_proba(X)[:,1],inp.p,rtol=0,atol=1e-14)
conf={(x.split,x.task,x.rid):json.loads(x.confidences) for x in inp.itertuples(index=False)};d=pd.read_csv(O/'per_query.csv');v=pd.read_csv(O/'validation_constant_paths.csv');replays=0
for x in pd.concat([d[d.method.isin(['Full','GreedyFixed','ValidationBestConstant'])],v]).itertuples(index=False):
    q=man[x.task,x.rid];z=r.search(q.source,q.target,conf[x.split,x.task,x.rid],x.gate);gd=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gd)/max(1,len(gd));assert abs(ps-x.PS)<1e-14 and abs(er-x.ER)<1e-14;assert z['nodes']==json.loads(x.nodes);assert z['edges']==[tuple(e) for e in json.loads(x.edges)];replays+=1
grid=v.groupby('gate').utility.mean().round(12);best=float(grid[grid==grid.max()].index.min());assert best==json.loads((O/'frozen_configuration.json').read_text())['best_constant']
intervals=pd.read_csv(O/'paired_cluster_CI.csv')
for x in intervals.itertuples(index=False):
    dd=d[d.split==x.split];p=dd[dd.method=='Full'].set_index(['task','rid']);o=dd[dd.method==x.comparison.removeprefix('Full - ')].set_index(['task','rid']).reindex(p.index);delta=p[x.metric]-o[x.metric];cl=delta.groupby(level='rid').agg(['sum','size']).sort_index();rng=np.random.default_rng(20260914);draw=rng.integers(0,len(cl),(5000,len(cl)));bs=cl['sum'].to_numpy()[draw].sum(1)/cl['size'].to_numpy()[draw].sum(1);assert np.allclose([delta.mean(),*np.quantile(bs,[.025,.975])],[x.delta,x.low,x.high],rtol=0,atol=1e-14)
proto=json.loads((O/'protocol.json').read_text());assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in proto['input_hashes'].items())
(O/'verification.json').write_text(json.dumps(dict(passed=True,original_source_feature_checks=len(inp),probabilities_checked=len(inp),paths_replayed=replays,intervals_recomputed=len(intervals),validation_only_constant_verified=True,input_hashes_unchanged=True),indent=2));print('VERIFIED',replays,'paths',len(intervals),'intervals')
