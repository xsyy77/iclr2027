"""New output-consistent reconstruction; not authenticated historical writer.

No saved candidate lists, split labels, model scores or retrieval results read.
"""
def global_types(records):
    types={}
    for record in records:
        for item in record['nodes']:
            types[str(item['id'])]=str(item.get('label','Unknown'))
    return types

def construct(record,source,target,answer,types,budget=3):
    answer=str(answer);endpoints={str(source),str(target)};pool=[];seen=set()
    for item in record['nodes']:
        node=str(item['id'])
        if node in endpoints or node in seen:continue
        seen.add(node);pool.append(node)
    if answer not in pool:raise ValueError('Reference answer must be eligible')
    selected=[answer];used={types[answer]}
    for node in pool:
        if len(selected)>=budget:break
        if node not in selected and types[node] not in used:
            selected.append(node);used.add(types[node])
    for node in pool:
        if len(selected)>=budget:break
        if node not in selected:selected.append(node)
    first_same_type=next((node for node in pool if types[node]==types[answer]),None)
    if first_same_type is not None and first_same_type not in selected:
        selected.append(first_same_type)
    return selected
