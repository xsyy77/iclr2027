"""kKLG follow-up W2/W3: frozen Table4 selection plus original frozen gate."""
from pathlib import Path
from collections import Counter
import sys,json,math,hashlib
import numpy as np,pandas as pd,joblib
from scipy.sparse import csr_matrix,hstack
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'audit_output';R=ROOT/'package/iclr2027_review_package';S=A/'stage2_original_greedy_repair';O=A/'full_automatic_followup_20261117'
O.mkdir(exist_ok=True);assert not (O/'completion.json').exists()
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
files=[S/'selections.csv',S/'test_scores.csv',S/'val_scores_C0.1.csv',S/'validation_controls.csv',S/'test_per_query.csv',S/'selected_configuration.json',A/'experiment1_recovered_proposer/gate_model.joblib',R/'methods/dmdb_retrievers.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={str(p.relative_to(ROOT)):sha(p) for p in files}
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
save('protocol.json',dict(review='kKLG latest W2/W3',status='new matched evaluation on previously inspected TEST, not fresh independent confirmation',selection='exact saved Table4 automatic pools / original-feature C.1 scores / greedy mu.5 beta.1 K3',gate='frozen existing original gate checkpoint; recompute original features on actual greedy-selected nodes; g=.5*sqrt(p); no refit or gate hyperparameter search',constant='VAL only grid 0:.05:.5, maximize .7PS+.3ER; round12 ties smaller gate',comparisons=['Full vs ProposalEqual','Full vs ConfidenceOnly','Full vs GreedyFixed','Full vs ValidationBestConstant'],statistics='5000 paired mechanism-record cluster bootstrap seed20260914; pointwise95CI, no multiplicity claim',search='unchanged original graph/order/beam2 hops8 nodes14 edges20',input_hashes=hashes))
model=joblib.load(files[6]);sel=pd.read_csv(files[0]);scores=pd.concat([pd.read_csv(files[1]).assign(split='test'),pd.read_csv(files[2]).assign(split='val')]);sc={k:dict(zip(g.node,g.confidence)) for k,g in scores.groupby(['split','task','rid'])};selected={(x.split,x.task,x.rid):json.loads(x.selected_nodes) for x in sel[sel.method=='Greedy'].itertuples(index=False)}
meta={}
for rec in r.paths:
    for n in rec.get('nodes',[]):meta.setdefault(str(n['id']),dict(name=str(n.get('name','')),type=str(n.get('label','Unknown'))))
qs=list(r.manifest[r.manifest.split.isin(['val','test'])].itertuples(index=False));inputs=[];confs={}
for q in qs:
    k=(q.split,q.task,q.rid);nodes=selected[k];conf={n:sc.get(k,{})[n] for n in nodes};confs[k]=conf;ty=[meta.get(n,{}).get('type','Unknown') for n in nodes];tc=Counter(ty)
    text=f'task {q.task} question {q.question} candidates '+' ; '.join(f'{t} {meta.get(n,{}).get("name",n)}' for t,n in zip(ty,nodes))
    num=[len(nodes)/10.,math.log1p(r.G.out_degree(q.source)),math.log1p(r.G.in_degree(q.target))]+[tc[t]/max(1,len(nodes)) for t in model['types']]+[float(np.mean([r.G.has_edge(q.source,n) for n in nodes])) if nodes else 0.,float(np.mean([math.log1p(r.G.in_degree(n)+r.G.out_degree(n)) for n in nodes])) if nodes else 0.]
    inputs.append(dict(split=q.split,task=q.task,rid=q.rid,text=text,numeric=json.dumps(num),selected_nodes=json.dumps(nodes),confidences=json.dumps(conf)))
inp=pd.DataFrame(inputs);X=hstack([model['word'].transform(inp.text),model['char'].transform(inp.text),csr_matrix(model['sc'].transform(np.asarray([json.loads(x) for x in inp.numeric],np.float32)))],format='csr');inp['p']=model['clf'].predict_proba(X)[:,1];inp['gate']=.5*np.sqrt(inp.p);inp.to_csv(O/'query_inputs_predictions.csv',index=False);gates={(x.split,x.task,x.rid):x.gate for x in inp.itertuples(index=False)}
def run(q,g,method):
    k=(q.split,q.task,q.rid);z=r.search(q.source,q.target,confs[k],float(g));gold=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gold)/max(1,len(gold))
    return dict(split=q.split,task=q.task,rid=q.rid,method=method,gate=float(g),PS=ps,ER=er,AH=float(str(q.answer) in z['nodes']),utility=.7*ps+.3*er,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges'])
v=[]
for a in np.arange(11)/20:
    v.extend(run(q,a,'ConstantGrid') for q in qs if q.split=='val')
v=pd.DataFrame(v);v.to_csv(O/'validation_constant_paths.csv',index=False);grid=v.groupby('gate')[['PS','ER','utility']].mean().reset_index();grid['tie']=grid.utility.round(12);grid=grid.sort_values(['tie','gate'],ascending=[False,True]);grid.to_csv(O/'validation_constant_grid.csv',index=False);best=float(grid.iloc[0].gate)
save('frozen_configuration.json',dict(best_constant=best,gate_checkpoint_hash=hashes[str(files[6].relative_to(ROOT))],gmax=.5,gamma=.5,no_fits=True,no_test_selection=True))
rows=[]
for q in qs:
    k=(q.split,q.task,q.rid)
    rows.extend([run(q,gates[k],'Full'),run(q,best,'ValidationBestConstant'),run(q,.3,'GreedyFixed')])
d=pd.DataFrame(rows)
for split,path in [('val',files[3]),('test',files[4])]:
    old=pd.read_csv(path);old=old[old.split==split]
    for method,weight,new in [('Proposal','Equal','ProposalEqual'),('ConfidenceOnly','Learned','ConfidenceOnly')]:
        zz=old[(old.method==method)&(old.weighting==weight)].copy();zz['method']=new;zz['gate']=.3;d=pd.concat([d,zz],ignore_index=True)
    oldg=old[(old.method=='Greedy')&(old.weighting=='Learned')].set_index(['task','rid']).sort_index();newg=d[(d.split==split)&(d.method=='GreedyFixed')].set_index(['task','rid']).sort_index()
    for m in ['PS','ER','AH','utility']:assert np.allclose(oldg[m],newg[m],rtol=0,atol=1e-14)
    assert all(json.loads(a)==json.loads(b) for a,b in zip(oldg.nodes,newg.nodes))
d.to_csv(O/'per_query.csv',index=False);summary=d.groupby(['split','method'])[['PS','ER','AH','utility','gate']].mean();summary.to_csv(O/'summary.csv');ci=[]
for split in ['val','test']:
    p=d[(d.split==split)&(d.method=='Full')].set_index(['task','rid']);ids=sorted(p.index.get_level_values('rid').unique());ix=np.random.default_rng(20260914).integers(0,len(ids),size=(5000,len(ids)))
    for method in ['ProposalEqual','ConfidenceOnly','GreedyFixed','ValidationBestConstant']:
        other=d[(d.split==split)&(d.method==method)].set_index(['task','rid']).reindex(p.index)
        for m in ['PS','ER','AH','utility']:
            delta=p[m]-other[m];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(ids);b=cl['sum'].to_numpy()[ix].sum(1)/cl['size'].to_numpy()[ix].sum(1);lo,hi=np.quantile(b,[.025,.975]);ci.append(dict(split=split,comparison='Full - '+method,metric=m,delta=delta.mean(),low=lo,high=hi))
pd.DataFrame(ci).to_csv(O/'paired_cluster_CI.csv',index=False);assert all(sha(ROOT/n)==h for n,h in hashes.items());save('completion.json',dict(complete=True,new_model_fits=0,validation_queries=239,reused_test_queries=248,constant_selected_only_on_val=best,original_Table4_fixed_greedy_reproduced=True,inputs_unchanged=True,independent_verification_pending=True));print(summary.to_string(),flush=True)
