from pathlib import Path
import json,hashlib
import pandas as pd
from clean_fixture_constructor_exact_20261117 import global_types,construct
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'package/iclr2027_review_package/data';O=ROOT/'audit_output/clean_rule_reconstruction_20261117'
paths=[D/'raw/drugmechdb/indication_paths.json',D/'processed/drugmechdb/benchmark_manifest.csv',D/'processed/drugmechdb/bridge_marginal_training_samples.csv',D/'processed/drugmechdb/semantic_bridge_predictions.csv']
raw=json.loads(paths[0].read_text());records={str(x['graph']['_id']):x for x in raw};types=global_types(raw);m=pd.read_csv(paths[1]);sample=pd.read_csv(paths[2]);pred=pd.read_csv(paths[3]);out=[]
for table in [sample,pred]:
    saved={k:g.node.tolist() for k,g in table[table.condition=='Clean'].groupby(['task','rid','split'],sort=False)}
    for q in m.itertuples(index=False):
        generated=construct(records[q.rid],q.source,q.target,q.answer,types);old=saved[q.task,q.rid,q.split];assert generated==old,(q.task,q.rid,generated,old)
        out.append(dict(table='samples' if table is sample else 'predictions',split=q.split,task=q.task,rid=q.rid,source=q.source,target=q.target,answer=q.answer,nodes=json.dumps(generated),count=len(generated),ordered_equal=True))
d=pd.DataFrame(out);d.to_csv(O/'exact_reconstruction_all_queries.csv',index=False);s=d[d.table=='predictions'];counts={split:dict(queries=len(g),exact_matches=int(g.ordered_equal.sum()),size_distribution={str(k):int(v) for k,v in g['count'].value_counts().sort_index().items()}) for split,g in s.groupby('split')}
report=dict(passed=True,total_queries=len(m),tables_checked=['bridge_marginal_training_samples.csv','semantic_bridge_predictions.csv'],candidate_lists_checked=len(d),counts=counts,constructor_inputs='raw reference mechanisms, manifest endpoints and reference answer, global last-write entity types; no saved candidate access',historical_identity_authenticated=False,development='rule inferred after inspecting saved lists including TEST; not independent validation or unique-rule proof',inputs={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},constructor_sha256=hashlib.sha256((ROOT/'audit_output/clean_fixture_constructor_exact_20261117.py').read_bytes()).hexdigest())
(O/'exact_verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
