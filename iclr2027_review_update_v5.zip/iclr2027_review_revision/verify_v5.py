from pathlib import Path
import hashlib,json,csv
P=Path(__file__).resolve().parent
m=json.loads((P/'V5_MANIFEST.json').read_text())
for x in m['files']:
 b=(P/x['path']).read_bytes(); assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
with (P/'audit_output/clean_rule_reconstruction_20261117/exact_reconstruction_all_queries.csv').open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
assert len(rows)==3682 and all(x['ordered_equal']=='True' for x in rows)
with (P/'audit_output/full_automatic_followup_20261117/per_query.csv').open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
test=[x for x in rows if x['split']=='test']; by={(x['task'],x['rid'],x['method']):x for x in test}
full=[x for x in test if x['method']=='Full']; assert len(full)==248
for x in full:
 y=by[x['task'],x['rid'],'ValidationBestConstant']
 for key in ['PS','ER','utility']:assert abs(float(x[key])-float(y[key]))<1e-14
for name in ['full_automatic_followup_20261117/verification.json','clean_rule_reconstruction_20261117/exact_verification.json']:
 assert json.loads((P/'audit_output'/name).read_text())['passed']
print(json.dumps(dict(passed=True,manifest_files=len(m['files']),exact_Clean_lists=3682,matched_constant_queries=248,new_fits=0),indent=2))
