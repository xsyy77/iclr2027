"""Check the exact scope in which archived Bridge selection preserves sets."""

from collections import Counter, defaultdict
from pathlib import Path
import csv

from archived_bridge_selection import select_archived_set


root = Path(__file__).resolve().parents[1]
path = root / 'data/processed/drugmechdb/semantic_bridge_predictions.csv'
groups = defaultdict(dict)
with path.open(newline='') as stream:
    for row in csv.DictReader(stream):
        key = tuple(row[column] for column in ('task', 'rid', 'split', 'condition'))
        if key[2] in ('val', 'test'):
            node = row['node']
            score = float(row['pred_semantic_conf'])
            groups[key][node] = max(score, groups[key].get(node, float('-inf')))

assert groups, 'No archived validation/test groups found'
for key, confidences in groups.items():
    selected = select_archived_set(confidences)
    assert selected == confidences, key

for split in ('val', 'test'):
    counts = Counter(len(values) for key, values in groups.items() if key[2] == split)
    print(f'{split}: {sum(counts.values())} groups; candidates/group {dict(sorted(counts.items()))}')
print('PASS: every archived validation/test Bridge and saved confidence is retained.')
