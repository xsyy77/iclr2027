"""Selection adapter for the archived DrugMechDB validation/test candidate sets.

The original implementation of the manuscript's Red(h, H), mu, and full
Gain(h | H) rule has not been recovered. This module therefore makes only
the set-preserving claim that is testable on the archived splits: when the
number of distinct candidates is no greater than the reported budget, every
candidate is retained with its saved reliability score. Larger pools fail
closed instead of silently substituting an invented selection rule.
"""

BRIDGE_BUDGET = 3


def select_archived_set(confidence_by_node, budget=BRIDGE_BUDGET):
    if budget != BRIDGE_BUDGET:
        raise ValueError(f"Archived selection is verified only for budget={BRIDGE_BUDGET}")
    if len(confidence_by_node) > budget:
        raise ValueError(
            f"{len(confidence_by_node)} distinct Bridges exceed budget {budget}; "
            "the original redundancy-aware selector is unavailable"
        )
    return dict(confidence_by_node)
