#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ours-TA on ComplexWebQuestions (CWQ), using the NSM/GraftNet-style preprocessed
question-specific graphs.

Protocol:
- official train split, optionally deterministically sampled for feasible local training
- full official dev split
- full official test split
- seeds: 17, 29, 43
- target-agnostic inference
- dev-only hyperparameter selection
- test metrics: Hit@1, Hits@5, Hits@10, MRR
- paired bootstrap vs Graph Only / Semantic Only / Fixed Bridge

This script DOES NOT retrain any external baseline.
"""

from __future__ import annotations
import argparse, csv, gzip, hashlib, json, math, platform, re, sys, time
from collections import defaultdict, deque
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

TOKEN_RE = re.compile(r"[A-Za-z0-9]+")
SEEDS = [17, 29, 43]

def norm(s):
    s = str(s).replace("_", " ").replace(".", " ").replace("/", " ").replace("-", " ").lower()
    return " ".join(TOKEN_RE.findall(s))

def toks(s):
    return set(norm(s).split())

def sim(a, b):
    A, B = toks(a), toks(b)
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)

def load_lines(p):
    with p.open("r", encoding="utf-8") as f:
        return [x.rstrip("\n") for x in f]

def ent_id(x, ent2id):
    if isinstance(x, int):
        return x
    if isinstance(x, str):
        if x in ent2id:
            return ent2id[x]
        try:
            return int(x)
        except Exception:
            return None
    if isinstance(x, dict):
        for k in ("kb_id","id","text"):
            v=x.get(k)
            if isinstance(v,int):
                return v
            if isinstance(v,str) and v in ent2id:
                return ent2id[v]
    return None

def parse(line, ent2id):
    x=json.loads(line)
    qid=str(x.get("id",""))
    q=str(x.get("question",""))

    src=[]
    for e in x.get("entities",[]):
        z=ent_id(e,ent2id)
        if z is not None:
            src.append(int(z))
    src=list(dict.fromkeys(src))

    ans=[]
    for a in x.get("answers",[]):
        z=ent_id(a,ent2id)
        if z is None and isinstance(a,dict):
            t=a.get("text")
            if isinstance(t,str) and t in ent2id:
                z=ent2id[t]
        if z is not None:
            ans.append(int(z))
    ans=list(dict.fromkeys(ans))

    triples=[]
    for t in (x.get("subgraph") or {}).get("tuples",[]):
        if not isinstance(t,(list,tuple)) or len(t)!=3:
            continue
        h,r,o=t
        h=ent_id(h,ent2id) if not isinstance(h,int) else h
        o=ent_id(o,ent2id) if not isinstance(o,int) else o
        if isinstance(r,dict):
            r=r.get("id",r.get("text"))
        try:
            triples.append((int(h),int(r),int(o)))
        except Exception:
            pass

    if not qid:
        qid=hashlib.md5(q.encode("utf-8",errors="ignore")).hexdigest()

    return {"qid":qid,"question":q,"sources":src,"answers":ans,"triples":triples}

def read_records(p, ent2id, max_records=0, sample_seed=0):
    """
    Read JSONL records.
    If max_records > 0, use deterministic hash-priority sampling while streaming,
    so the full ~2.6 GB CWQ train file does not need to be held in memory.
    """
    import heapq
    if max_records and max_records > 0:
        heap=[]
        with p.open("r",encoding="utf-8") as f:
            for line_no,line in enumerate(f,1):
                if not line.strip():
                    continue
                r=parse(line,ent2id)
                if not (r["sources"] and r["answers"] and r["triples"]):
                    continue
                key=int(hashlib.md5((str(sample_seed)+"|"+r["qid"]).encode()).hexdigest(),16)
                item=(-key, line_no, r)
                if len(heap)<max_records:
                    heapq.heappush(heap,item)
                elif item > heap[0]:
                    heapq.heapreplace(heap,item)
        out=[x[2] for x in heap]
        out.sort(key=lambda r:r["qid"])
        return out
    else:
        out=[]
        with p.open("r",encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                r=parse(line,ent2id)
                if r["sources"] and r["answers"] and r["triples"]:
                    out.append(r)
        return out

def graph(rec):
    adj=defaultdict(list)
    deg=defaultdict(int)
    for h,r,t in rec["triples"]:
        adj[h].append((r,t,0))
        adj[t].append((r,h,1))
        deg[h]+=1; deg[t]+=1
    return adj,deg

def relname(r,inv,id2rel):
    x=id2rel[r] if 0 <= r < len(id2rel) else str(r)
    return ("inverse "+x) if inv else x

def rel_semantic(q,r,inv,id2rel):
    rn=relname(r,inv,id2rel)
    s=sim(q,rn)
    nq=norm(q); nr=norm(rn)
    # Small lexical boosts for common question cues; still query-only.
    cues=[
        ("where",("location","place","country","city","state","contained")),
        ("when",("date","time","year")),
        ("who",("person","people","actor","author","director","spouse","parent")),
        ("what",()),
        ("which",()),
    ]
    for cue,words in cues:
        if cue in nq.split() and any(w in nr.split() for w in words):
            s += 0.12
    return min(1.0,s)

def shortest_dist_to_answers(rec):
    """TRAIN/DEV supervision helper only. Never called by test-time scorer."""
    adj,_=graph(rec)
    ans=set(rec["answers"])
    q=deque()
    dist={}
    for s in rec["sources"]:
        dist[s]=0; q.append(s)
    found={}
    while q:
        u=q.popleft()
        d=dist[u]
        if d>=4: continue
        for _,v,_ in adj.get(u,[]):
            if v not in dist:
                dist[v]=d+1; q.append(v)
            if v in ans:
                found[v]=min(found.get(v,99),d+1)
    return dist,found

def node_bridge_features(rec,node,adj,deg,id2rel):
    q=rec["question"]
    rs=[rel_semantic(q,r,inv,id2rel) for r,_,inv in adj.get(node,[])[:80]]
    near_src=0
    src=set(rec["sources"])
    for _,v,_ in adj.get(node,[])[:80]:
        if v in src: near_src=1; break
    return np.array([
        max(rs) if rs else 0.0,
        float(np.mean(rs)) if rs else 0.0,
        math.log1p(deg.get(node,0)),
        1.0/(1.0+deg.get(node,0)),
        near_src,
        len(adj.get(node,[]))/100.0,
        len(toks(q))/20.0,
    ],dtype=float)

class Const:
    def __init__(self,p): self.p=float(p)
    def predict_proba(self,X):
        p=np.full(len(X),self.p)
        return np.c_[1-p,p]

def fit_logit(X,y,seed):
    if not X:
        return Const(0.0)
    y=np.asarray(y,dtype=int)
    if len(np.unique(y))<2:
        return Const(float(y.mean()))
    m=make_pipeline(StandardScaler(),
                    LogisticRegression(max_iter=600,class_weight="balanced",
                                       solver="liblinear",random_state=seed))
    m.fit(np.vstack(X),y)
    return m

def bridge_candidates(rec,id2rel,max_cand=24):
    adj,deg=graph(rec)
    src=set(rec["sources"])
    cand=set()
    for s in src:
        for _,v,_ in adj.get(s,[]):
            if v not in src:
                cand.add(v)
    feats={n:node_bridge_features(rec,n,adj,deg,id2rel) for n in cand}
    # pre-ranking uses no answer info
    scored=[]
    for n,f in feats.items():
        cheap=.55*f[0]+.20*f[1]+.15*f[3]+.10*f[4]
        scored.append((cheap,-n,n))
    scored.sort(reverse=True)
    cand=[n for _,_,n in scored[:max_cand]]
    return cand,feats,adj,deg

def train_bridge_model(train,id2rel,seed,args):
    X=[]; y=[]
    for i,rec in enumerate(train,1):
        cand,feats,adj,deg=bridge_candidates(rec,id2rel,args.bridge_pool)
        # Positive if candidate lies on any short source->answer route.
        # Used only as training supervision.
        ans=set(rec["answers"])
        # reverse distance from answers
        radj=defaultdict(list)
        for u,outs in adj.items():
            for r,v,inv in outs:
                radj[v].append(u)
        d_to_ans={}
        qq=deque()
        for a in ans:
            d_to_ans[a]=0; qq.append(a)
        while qq:
            u=qq.popleft()
            if d_to_ans[u]>=3: continue
            for v in radj.get(u,[]):
                if v not in d_to_ans:
                    d_to_ans[v]=d_to_ans[u]+1; qq.append(v)
        for n in cand:
            lab=int(n in d_to_ans and d_to_ans[n] <= 2)
            X.append(feats[n]); y.append(lab)
        if i%500==0:
            print(f"  train bridge {i}/{len(train)}",flush=True)
    return fit_logit(X,y,seed), {"n":len(y),"positive_rate":float(np.mean(y)) if y else 0.0}

def select_bridges(rec,model,id2rel,args):
    cand,feats,adj,deg=bridge_candidates(rec,id2rel,args.bridge_pool)
    if not cand:
        return [],adj,deg
    P=model.predict_proba(np.vstack([feats[n] for n in cand]))[:,1]
    ix=np.argsort(-P)
    sel=[(cand[j],float(P[j])) for j in ix[:args.bridge_k]]
    return sel,adj,deg

def bridge_influence(v,selected,adj):
    if not selected: return 0.0
    C=dict(selected)
    if v in C: return C[v]
    b=0.0
    for _,n,_ in adj.get(v,[])[:100]:
        if n in C:
            b=max(b,.45*C[n])
    return b

def rank_nodes(rec,id2rel,selected=(),gate=0.0,semantic_weight=0.55,max_steps=3):
    """
    FULL question-specific graph dynamic search.
    No gold answer is used here.
    """
    adj,deg=graph(rec)
    src=set(rec["sources"])

    current={s:0.0 for s in src}
    best={}
    for depth in range(1,max_steps+1):
        nxt={}
        for u,us in current.items():
            for r,v,inv in adj.get(u,[]):
                rs=rel_semantic(rec["question"],r,inv,id2rel)
                gp=1.0/(1.0+math.log1p(max(0,deg.get(v,0))))
                graph_score=.65*gp + .35*(1.0/depth)
                semantic_score=.75*rs + .25*gp
                bridge=bridge_influence(v,selected,adj)
                # gate affects semantic mechanism guidance, not graph connectivity
                step=(1-gate)*((1-semantic_weight)*graph_score + semantic_weight*semantic_score) \
                     + gate*(.55*semantic_score + .45*bridge) - .025*depth
                ns=us+step
                if ns>nxt.get(v,-1e18):
                    nxt[v]=ns
                if v not in src and ns>best.get(v,-1e18):
                    best[v]=ns
        current=nxt
        if not current: break

    ranked=[n for n,_ in sorted(best.items(),key=lambda x:(-x[1],x[0]))]
    return ranked

def metrics(ranked,answers):
    A=set(answers); rank=None
    for i,n in enumerate(ranked,1):
        if n in A:
            rank=i; break
    return {
        "hits1":float(rank==1),
        "hits5":float(rank is not None and rank<=5),
        "hits10":float(rank is not None and rank<=10),
        "mrr":0.0 if rank is None else 1.0/rank
    }

def query_features(rec,selected,deg):
    c=[x for _,x in selected] or [0.0]
    sd=[deg.get(s,0) for s in rec["sources"]] or [0]
    return np.array([
        max(c),float(np.mean(c)),float(np.std(c)),
        len(selected)/5.0,
        math.log1p(float(np.mean(sd))),
        len(toks(rec["question"]))/20.0,
        math.log1p(len(rec["triples"]))/10.0
    ],dtype=float)

def train_gate(train,bm,id2rel,seed,args):
    X=[]; y=[]
    for i,rec in enumerate(train,1):
        sel,adj,deg=select_bridges(rec,bm,id2rel,args)
        base=metrics(rank_nodes(rec,id2rel,(),0.0,args.semantic_weight,args.max_steps),rec["answers"])["hits1"]
        guided=metrics(rank_nodes(rec,id2rel,sel,args.gate_train,args.semantic_weight,args.max_steps),rec["answers"])["hits1"]
        X.append(query_features(rec,sel,deg))
        y.append(int(guided>base))
        if i%500==0:
            print(f"  train gate   {i}/{len(train)}",flush=True)
    return fit_logit(X,y,seed), {"n":len(y),"positive_rate":float(np.mean(y)) if y else 0.0}

def gate_for(rec,sel,deg,gm,gmax,gamma):
    qf=query_features(rec,sel,deg)
    p=float(gm.predict_proba(qf.reshape(1,-1))[0,1])
    return gmax*(p**gamma),p

def tune(dev,bm,gm,id2rel,args):
    # Fixed Bridge gate, selected on dev
    bestf=(-1,None)
    for fg in args.fixed_grid:
        vals=[]
        for rec in dev:
            sel,adj,deg=select_bridges(rec,bm,id2rel,args)
            vals.append(metrics(rank_nodes(rec,id2rel,sel,fg,args.semantic_weight,args.max_steps),
                                rec["answers"])["hits1"])
        h=float(np.mean(vals))
        if h>bestf[0]: bestf=(h,fg)

    best=(-1,None,None)
    for gx in args.gmax_grid:
        for ga in args.gamma_grid:
            vals=[]
            for rec in dev:
                sel,adj,deg=select_bridges(rec,bm,id2rel,args)
                g,_=gate_for(rec,sel,deg,gm,gx,ga)
                vals.append(metrics(rank_nodes(rec,id2rel,sel,g,args.semantic_weight,args.max_steps),
                                    rec["answers"])["hits1"])
            h=float(np.mean(vals))
            if h>best[0]: best=(h,gx,ga)
    return bestf[1],best[1],best[2],bestf[0],best[0]

def bootstrap(a,b,B,seed):
    d=np.asarray(a)-np.asarray(b)
    rng=np.random.default_rng(seed)
    z=np.empty(B)
    n=len(d)
    for i in range(B):
        ix=rng.integers(0,n,n)
        z[i]=d[ix].mean()
    lo,hi=np.quantile(z,[.025,.975])
    return float(d.mean()),float(lo),float(hi)

def write_csv(path,rows):
    if not rows:
        path.write_text("",encoding="utf-8"); return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

def locate(root):
    for name in ("webqsp","CWQ","ComplexWebQuestions"):
        p=root/name
        if p.exists(): return p
    if (root/"train_simple.json").exists():
        return root
    raise FileNotFoundError("Cannot find webqsp/ under the supplied root")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--out",default="cwq_ours_results")
    ap.add_argument("--seeds",nargs="+",type=int,default=SEEDS)
    ap.add_argument("--bridge-pool",type=int,default=24)
    ap.add_argument("--bridge-k",type=int,default=3)
    ap.add_argument("--gate-train",type=float,default=.35)
    ap.add_argument("--semantic-weight",type=float,default=.55)
    ap.add_argument("--max-steps",type=int,default=3)
    ap.add_argument("--fixed-grid",nargs="+",type=float,default=[.15,.30,.45,.60])
    ap.add_argument("--gmax-grid",nargs="+",type=float,default=[.25,.40,.55,.70])
    ap.add_argument("--gamma-grid",nargs="+",type=float,default=[.5,1.0,2.0])
    ap.add_argument("--bootstrap",type=int,default=10000)
    ap.add_argument("--train-sample",type=int,default=5000,
                    help="Number of deterministic train examples per seed; use 0 for full train")
    ap.add_argument("--dev-sample",type=int,default=1000,
                    help="Number of deterministic dev examples for tuning; use 0 for full dev")
    args=ap.parse_args()

    root=Path(args.root).expanduser().resolve()
    data=locate(root)
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    req=["train_simple.json","dev_simple.json","test_simple.json","entities.txt","relations.txt"]
    for x in req:
        if not (data/x).exists():
            raise FileNotFoundError(data/x)

    id2ent=load_lines(data/"entities.txt")
    ent2id={x:i for i,x in enumerate(id2ent)}
    id2rel=load_lines(data/"relations.txt")

    print("Loading full official dev/test...",flush=True)
    dev_full=read_records(data/"dev_simple.json",ent2id)
    test=read_records(data/"test_simple.json",ent2id)
    print(f"Loaded dev={len(dev_full)}, test={len(test)}",flush=True)

    allsum=[]; allboot=[]; trainstats=[]
    for seed in args.seeds:
        print(f"\n===== CWQ seed={seed} =====",flush=True)
        print("  streaming train subset...",flush=True)
        train=read_records(data/"train_simple.json",ent2id,args.train_sample,seed)
        dev=dev_full if args.dev_sample==0 else read_records(
            data/"dev_simple.json",ent2id,args.dev_sample,777
        )
        print(f"  using train={len(train)}, dev={len(dev)}, test={len(test)}",flush=True)
        t0=time.time()
        bm,bs=train_bridge_model(train,id2rel,seed,args)
        gm,gs=train_gate(train,bm,id2rel,seed,args)
        fg,gx,ga,dev_fixed,dev_ours=tune(dev,bm,gm,id2rel,args)
        print(f"  frozen on dev: fixed={fg}, gmax={gx}, gamma={ga}",flush=True)

        per=[]
        for i,rec in enumerate(test,1):
            sel,adj,deg=select_bridges(rec,bm,id2rel,args)
            g,p=gate_for(rec,sel,deg,gm,gx,ga)

            methods=[
                ("Graph Only",(),0.0,0.0),
                ("Semantic Only",(),0.0,args.semantic_weight),
                ("Fixed Bridge",sel,fg,args.semantic_weight),
                ("Ours-TA",sel,g,args.semantic_weight),
            ]
            for name,s,gval,sw in methods:
                r=rank_nodes(rec,id2rel,s,gval,sw,args.max_steps)
                m=metrics(r,rec["answers"])
                per.append({"qid":rec["qid"],"method":name,**m,
                            "gate":gval,"p_rel":p})
            if i%250==0:
                print(f"  test {i}/{len(test)}",flush=True)

        with gzip.open(out/f"per_query_seed{seed}.csv.gz","wt",encoding="utf-8",newline="") as f:
            keys=list(per[0].keys()); w=csv.DictWriter(f,fieldnames=keys)
            w.writeheader();w.writerows(per)

        by=defaultdict(list)
        for r in per: by[r["method"]].append(r)
        for m,rr in by.items():
            allsum.append({
                "seed":seed,"method":m,"n":len(rr),
                "hits1":float(np.mean([x["hits1"] for x in rr])),
                "hits5":float(np.mean([x["hits5"] for x in rr])),
                "hits10":float(np.mean([x["hits10"] for x in rr])),
                "mrr":float(np.mean([x["mrr"] for x in rr])),
                "seconds_seed":time.time()-t0
            })

        lookup={(r["qid"],r["method"]):r["hits1"] for r in per}
        qids=sorted(set(r["qid"] for r in per))
        oa=[lookup[(q,"Ours-TA")] for q in qids]
        for bname in ("Graph Only","Semantic Only","Fixed Bridge"):
            bb=[lookup[(q,bname)] for q in qids]
            d,lo,hi=bootstrap(oa,bb,args.bootstrap,seed+1000)
            allboot.append({"seed":seed,"comparison":f"Ours-TA - {bname}",
                            "metric":"Hits@1","mean_diff":d,
                            "ci95_low":lo,"ci95_high":hi,"B":args.bootstrap})

        trainstats.append({"seed":seed,
                           "bridge_n":bs["n"],"bridge_positive_rate":bs["positive_rate"],
                           "gate_n":gs["n"],"gate_positive_rate":gs["positive_rate"],
                           "dev_fixed_hits1":dev_fixed,"dev_ours_hits1":dev_ours,
                           "fixed_gate":fg,"gmax":gx,"gamma":ga})

    write_csv(out/"summary_by_seed.csv",allsum)
    write_csv(out/"bootstrap_by_seed.csv",allboot)
    write_csv(out/"training_and_dev.csv",trainstats)

    agg=[]
    for m in sorted(set(x["method"] for x in allsum)):
        rr=[x for x in allsum if x["method"]==m]
        row={"method":m,"seeds":len(rr)}
        for metric in ("hits1","hits5","hits10","mrr"):
            a=np.array([x[metric] for x in rr],float)
            row[metric+"_mean"]=float(a.mean())
            row[metric+"_std"]=float(a.std(ddof=1)) if len(a)>1 else 0.0
        agg.append(row)
    write_csv(out/"WEBQSP_FINAL_RESULTS.csv",agg)

    cfg=vars(args).copy()
    cfg.update({"data":str(data),
                "task":"ComplexWebQuestions target-agnostic transfer",
                "train_sample_per_seed":args.train_sample,
                "dev_tuning_records":len(dev),
                "dev_available_records":len(dev_full),
                "test_full":len(test),
                "external_baselines":"not retrained"})
    (out/"config.json").write_text(json.dumps(cfg,indent=2),encoding="utf-8")

    print("\nDONE")
    print("Results:",out)

if __name__=="__main__":
    main()
