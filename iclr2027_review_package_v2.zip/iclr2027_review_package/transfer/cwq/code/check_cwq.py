#!/usr/bin/env python3
from pathlib import Path
import argparse, json

def locate(root):
    for p in [root, root/"CWQ", root/"cwq", root/"cwq"/"CWQ"]:
        if (p/"train_simple.json").exists():
            return p
    raise FileNotFoundError("Could not find CWQ folder")

ap=argparse.ArgumentParser()
ap.add_argument("root")
a=ap.parse_args()
root=Path(a.root).expanduser().resolve()
d=locate(root)

req=["train_simple.json","dev_simple.json","test_simple.json","entities.txt","relations.txt"]
print("CWQ folder:", d)
for x in req:
    p=d/x
    if not p.exists():
        raise FileNotFoundError(p)
    print(f"OK  {x:20s}  {p.stat().st_size/1024/1024:.1f} MB")

for x in ["train_simple.json","dev_simple.json","test_simple.json"]:
    p=d/x
    with p.open("r",encoding="utf-8") as f:
        line=f.readline()
        obj=json.loads(line)
        assert "question" in obj and "subgraph" in obj
print("ALL CHECKS PASSED")
