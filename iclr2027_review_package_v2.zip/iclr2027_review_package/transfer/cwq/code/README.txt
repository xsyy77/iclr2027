CWQ Ours-TA runner

Recommended publication run:
python3 run_cwq_ours.py ~/Downloads/cwq/CWQ \
  --out ~/Downloads/cwq_ours_results \
  --seeds 17 29 43 \
  --train-sample 5000 \
  --dev-sample 1000 \
  --bootstrap 10000

For a full-train confirmatory run, replace:
  --train-sample 5000
with:
  --train-sample 0

The test split is always evaluated in full.
