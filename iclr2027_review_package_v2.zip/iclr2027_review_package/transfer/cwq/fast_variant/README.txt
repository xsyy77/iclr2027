FAST CWQ Ours-TA runner

1) Stop the old process with Ctrl+C.
2) Run:

cd ~/Downloads/cwq_ours_runner_fast
source ~/Downloads/.venv-metaqa/bin/activate

caffeinate -dimsu python3 run_cwq_ours_fast.py ~/Downloads/CWQ \
  --out ~/Downloads/cwq_ours_results \
  --seeds 17 29 43 \
  --train-sample 5000 \
  --dev-sample 1000 \
  --bootstrap 10000

The key fix is that train sampling no longer JSON-parses all ~27,639 huge rows before choosing 5,000.
