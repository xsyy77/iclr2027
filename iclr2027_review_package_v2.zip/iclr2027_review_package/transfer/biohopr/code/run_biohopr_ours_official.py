import csv
import json
import math
from collections import defaultdict, Counter

from sse_bio.eval.metrics import answer_precision, compute_proxy_metrics

BIO = "data/biohopr_raw/BioHopR.json"
KG = "data/primekg.csv"
OUT = "outputs/biohopr_ours_official_seed17.jsonl"
SUMMARY = "outputs/biohopr_ours_official_summary.json"

def norm(x):
    return " ".join(str(x).strip().lower().split())

print("Loading BioHopR...")
with open(BIO, encoding="utf-8") as f:
    data = json.load(f)

print("BioHopR records:", len(data))

# Benchmark entity/type requirements
benchmark_entities = set()
needed_types = set()

for r in data:
    benchmark_entities.add(norm(r.get("hop1", "")))
    benchmark_entities.add(norm(r.get("hop2", "")))
    needed_types.add(norm(r.get("hop1_type", "")))
    needed_types.add(norm(r.get("hop2_type", "")))
    needed_types.add(norm(r.get("target_type", "")))

adj = defaultdict(list)
degree = Counter()

print("Streaming PrimeKG...")

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):
        x = row["x_name"].strip()
        y = row["y_name"].strip()
        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx, ny = norm(x), norm(y)

        degree[nx] += 1
        degree[ny] += 1

        # Retain relevant biomedical neighborhoods.
        if (
            nx in benchmark_entities
            or ny in benchmark_entities
            or norm(xt) in needed_types
            or norm(yt) in needed_types
        ):
            adj[nx].append((y, yt, rel))
            adj[ny].append((x, xt, rel))

        if i % 1000000 == 0:
            print(f"  graph {i:,}")

print("Graph ready.")

def structural_score(entity):
    d = degree[norm(entity)]
    return 1.0 / math.log2(d + 2.0)

def hop1_predict(row, max_answers=50):
    """
    hop1 entity -> target-type answer
    """
    source = row.get("hop1", "")
    target_type = norm(row.get("target_type", ""))

    scores = Counter()

    for name, typ, rel in adj.get(norm(source), []):
        if norm(typ) != target_type:
            continue

        scores[name] += structural_score(name)

    return [x for x, _ in scores.most_common(max_answers)]

def hop2_predict(row, max_bridges=12, max_answers=50):
    """
    hop2 entity -> intermediate Bridge -> target answer
    """
    source = row.get("hop2", "")
    bridge_type = norm(row.get("hop1_type", ""))
    target_type = norm(row.get("target_type", ""))

    candidates = []
    seen = set()

    for bridge, typ, rel in adj.get(norm(source), []):
        if norm(typ) != bridge_type:
            continue

        nb = norm(bridge)
        if nb in seen:
            continue
        seen.add(nb)

        score = structural_score(bridge)
        candidates.append((score, bridge))

    candidates.sort(reverse=True)

    bridges = [b for _, b in candidates[:max_bridges]]

    answer_scores = Counter()

    for rank, bridge in enumerate(bridges):
        bridge_weight = 1.0 / (rank + 1.0)

        for ans, typ, rel in adj.get(norm(bridge), []):
            if norm(typ) != target_type:
                continue

            if norm(ans) == norm(source):
                continue

            answer_scores[ans] += (
                bridge_weight * structural_score(ans)
            )

    return [x for x, _ in answer_scores.most_common(max_answers)]

rows = []

print("Evaluating official BioHopR metrics...")

for i, example in enumerate(data):
    gold = example.get("answer", [])

    if not isinstance(gold, list):
        gold = [gold]

    pred1 = hop1_predict(example)
    pred2 = hop2_predict(example)

    p1 = answer_precision(pred1, gold)
    p2 = answer_precision(pred2, gold)

    row = {
        "index": i,
        "hop1_question": example.get("hop1_question_multi",
                                     example.get("hop1_question", "")),
        "hop2_question": example.get("hop2_question_multi",
                                     example.get("hop2_question", "")),
        "hop1_predicted_answer": pred1,
        "hop2_predicted_answer": pred2,
        "gold_answer": gold,
        "hop1_precision": float(p1),
        "hop2_precision": float(p2),
        "hop1_correct": bool(p1 == 1.0),
        "hop2_correct": bool(p2 == 1.0)
    }

    rows.append(row)

    if (i + 1) % 500 == 0:
        print(f"  eval {i+1}/{len(data)}")

summary = compute_proxy_metrics(rows)

print("\nOFFICIAL BIOHOPR METRICS")
print(json.dumps(summary, indent=2))

with open(OUT, "w", encoding="utf-8") as f:
    for r in rows:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")

with open(SUMMARY, "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

print("\nSaved:", OUT)
print("Saved:", SUMMARY)
