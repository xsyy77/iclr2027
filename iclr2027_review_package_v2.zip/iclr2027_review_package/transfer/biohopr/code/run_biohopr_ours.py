import argparse
import csv
import json
import math
import random
import re
from collections import defaultdict, Counter

def norm(s):
    return re.sub(r"\s+", " ", str(s).strip().lower())

def f1(pred, gold):
    p = {norm(x) for x in pred if norm(x)}
    g = {norm(x) for x in gold if norm(x)}
    if not p and not g:
        return 1.0, 1.0, 1.0
    if not p:
        return 0.0, 0.0, 0.0
    inter = len(p & g)
    precision = inter / len(p)
    recall = inter / len(g) if g else 0.0
    score = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return precision, recall, score

parser = argparse.ArgumentParser()
parser.add_argument("--biohopr", default="data/biohopr_raw/BioHopR.json")
parser.add_argument("--primekg", default="data/primekg.csv")
parser.add_argument("--out", default="outputs/biohopr_ours_seed17.json")
parser.add_argument("--seed", type=int, default=17)
parser.add_argument("--max-bridges", type=int, default=12)
parser.add_argument("--max-answers", type=int, default=50)
args = parser.parse_args()

random.seed(args.seed)

print("Loading BioHopR...")
with open(args.biohopr, encoding="utf-8") as f:
    data = json.load(f)

print("BioHopR records:", len(data))

# ---------------------------------------------------------
# Build only the PrimeKG adjacency needed by BioHopR.
# This avoids loading the entire 8M-edge JSONL into memory.
# ---------------------------------------------------------

source_names = {norm(x.get("hop2", "")) for x in data}
source_names |= {norm(x.get("hop1", "")) for x in data}

needed_middle_types = {norm(x.get("hop1_type", "")) for x in data}
needed_target_types = {norm(x.get("target_type", "")) for x in data}

adj = defaultdict(list)
degree = Counter()

print("Streaming PrimeKG...")

with open(args.primekg, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):
        x = row["x_name"].strip()
        y = row["y_name"].strip()
        xt = row["x_type"].strip()
        yt = row["y_type"].strip()
        rel = (row.get("display_relation") or row.get("relation") or "").strip()

        nx, ny = norm(x), norm(y)

        degree[nx] += 1
        degree[ny] += 1

        # Keep neighborhoods around benchmark entities and typed
        # biomedical candidates.
        if (
            nx in source_names or ny in source_names
            or norm(xt) in needed_middle_types
            or norm(yt) in needed_middle_types
        ):
            adj[nx].append((y, yt, rel))
            adj[ny].append((x, xt, rel))

        if i % 1000000 == 0:
            print(f"  graph {i:,} edges")

print("Graph loaded.")

def bridge_score(source, bridge, bridge_type):
    """
    Target-agnostic bridge score.
    Uses only graph structure/type information available at inference.
    No gold answer and no gold hop1 identity are used.
    """
    d = degree[norm(bridge)]
    type_bonus = 1.0 if norm(bridge_type) else 0.0
    # Prefer informative but not extremely generic hubs.
    structural = 1.0 / math.log2(d + 2.0)
    return 0.65 * type_bonus + 0.35 * structural

def retrieve(row, adaptive=True):
    source = row.get("hop2", "")
    middle_type = norm(row.get("hop1_type", ""))
    target_type = norm(row.get("target_type", ""))

    # Candidate intermediate biomedical Bridges.
    candidates = []
    seen = set()

    for name, typ, rel in adj.get(norm(source), []):
        if norm(typ) != middle_type:
            continue

        key = norm(name)
        if key in seen:
            continue

        seen.add(key)
        score = bridge_score(source, name, typ)
        candidates.append((score, name))

    candidates.sort(reverse=True)

    # Reliability-adaptive bridge budget.
    if adaptive:
        if len(candidates) <= 3:
            k = len(candidates)
        elif len(candidates) <= 10:
            k = min(6, len(candidates))
        else:
            k = min(args.max_bridges, len(candidates))
    else:
        k = min(args.max_bridges, len(candidates))

    bridges = [b for _, b in candidates[:k]]

    target_scores = Counter()

    for rank, bridge in enumerate(bridges):
        bridge_weight = 1.0 / (1.0 + rank)

        for name, typ, rel in adj.get(norm(bridge), []):
            if norm(typ) != target_type:
                continue
            if norm(name) == norm(source):
                continue

            # Bridge-guided graph-valid two-hop retrieval.
            target_scores[name] += bridge_weight

    ranked = [x for x, _ in target_scores.most_common(args.max_answers)]
    return ranked, bridges

results = []

print("Evaluating BioHopR 2-hop multi-answer task...")

for i, row in enumerate(data, 1):
    gold = row.get("answer", [])
    if not isinstance(gold, list):
        gold = [gold]

    pred, bridges = retrieve(row, adaptive=True)
    precision, recall, score = f1(pred, gold)

    results.append({
        "id": i - 1,
        "question": row.get("hop2_question_multi", row.get("hop2_question", "")),
        "source": row.get("hop2", ""),
        "source_type": row.get("hop2_type", ""),
        "bridge_type": row.get("hop1_type", ""),
        "target_type": row.get("target_type", ""),
        "n_gold": len(gold),
        "n_pred": len(pred),
        "precision": precision,
        "recall": recall,
        "f1": score,
        "bridges": bridges,
        "prediction": pred,
    })

    if i % 500 == 0:
        print(f"  eval {i}/{len(data)}")

mean_p = sum(x["precision"] for x in results) / len(results)
mean_r = sum(x["recall"] for x in results) / len(results)
mean_f = sum(x["f1"] for x in results) / len(results)
hit = sum(x["recall"] > 0 for x in results) / len(results)

summary = {
    "dataset": "BioHopR",
    "task": "2-hop multi-answer biomedical KG reasoning",
    "method": "Ours-TA quick transfer",
    "seed": args.seed,
    "n": len(results),
    "precision": mean_p,
    "recall": mean_r,
    "f1": mean_f,
    "answer_hit": hit,
    "target_agnostic": True,
    "gold_bridge_used_at_inference": False
}

import os
os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)

with open(args.out, "w", encoding="utf-8") as f:
    json.dump({"summary": summary, "per_query": results}, f,
              ensure_ascii=False, indent=2)

print("\nDONE")
print(json.dumps(summary, indent=2))
print("Saved:", args.out)
