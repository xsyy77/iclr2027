import json
import re

FILE = "outputs/biohopr_ours_official_fast_seed17.jsonl"

def norm(x):
    text = str(x or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[\"'.,;:!?()\[\]{}]", "", text)
    return text

def rank_metrics(preds, golds):
    gold = {norm(x) for x in golds if norm(x)}
    preds = [norm(x) for x in preds if norm(x)]

    first_rank = None

    for i, p in enumerate(preds, 1):
        if p in gold:
            first_rank = i
            break

    h1 = float(first_rank is not None and first_rank <= 1)
    h5 = float(first_rank is not None and first_rank <= 5)
    rr = 0.0 if first_rank is None else 1.0 / first_rank

    return h1, h5, rr


rows = []

with open(FILE, encoding="utf-8") as f:
    for line in f:
        rows.append(json.loads(line))

h1 = 0.0
h5 = 0.0
mrr = 0.0

for r in rows:

    # 5.2 使用最终 two-hop retrieval output
    preds = r["hop2_predicted_answer"]
    gold = r["gold_answer"]

    a, b, c = rank_metrics(preds, gold)

    h1 += a
    h5 += b
    mrr += c

n = len(rows)

result = {
    "dataset": "BioHopR",
    "count": n,
    "Hits@1": 100.0 * h1 / n,
    "Hits@5": 100.0 * h5 / n,
    "MRR": 100.0 * mrr / n,
}

print(json.dumps(result, indent=2))
