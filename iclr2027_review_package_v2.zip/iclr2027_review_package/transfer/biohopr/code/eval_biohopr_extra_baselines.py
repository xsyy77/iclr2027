import csv
import json
import math
import re
from collections import defaultdict, Counter

import numpy as np
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression


BIO = "data/biohopr_raw/BioHopR.json"
KG = "data/primekg.csv"

SEED = 17
MAX_ANSWERS = 50


def norm(x):
    text = str(x or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[\"'.,;:!?()\[\]{}]", "", text)
    return text


def relation_quality(rel):
    s = str(rel or "").lower().replace("_", " ")

    if any(k in s for k in [
        "causes", "prevents", "treats", "therapeutic"
    ]):
        return 1.00

    if any(k in s for k in [
        "regulates", "activity", "abundance",
        "inhibits", "stimulates", "affects"
    ]):
        return 0.88

    if any(k in s for k in [
        "participates", "produces", "has output",
        "capable of", "precedes"
    ]):
        return 0.72

    if any(k in s for k in [
        "occurs in", "located in", "location of",
        "correlated", "associated"
    ]):
        return 0.52

    return 0.62


def first_rank(preds, gold):
    gold = {norm(x) for x in gold if norm(x)}

    for i, p in enumerate(preds, 1):
        if norm(p) in gold:
            return i

    return None


def evaluate(rows):
    h1 = h5 = mrr = 0.0

    for r in rows:
        rank = first_rank(
            r["predictions"],
            r["gold"]
        )

        if rank is not None:
            h1 += rank <= 1
            h5 += rank <= 5
            mrr += 1.0 / rank

    n = len(rows)

    return {
        "Hits@1": 100.0 * h1 / n,
        "Hits@5": 100.0 * h5 / n,
        "MRR": 100.0 * mrr / n,
        "count": n
    }


print("Loading BioHopR...")

with open(BIO, encoding="utf-8") as f:
    data = json.load(f)

print("records:", len(data))


# ------------------------------------------------------------
# EXACT SAME deterministic split as Full Ours
# ------------------------------------------------------------

rng = np.random.default_rng(SEED)

idx = np.arange(len(data))
rng.shuffle(idx)

n = len(data)
n_train = int(0.70 * n)
n_val = int(0.15 * n)

split = np.empty(n, dtype=object)

split[idx[:n_train]] = "train"
split[idx[n_train:n_train+n_val]] = "val"
split[idx[n_train+n_val:]] = "test"

for i, r in enumerate(data):
    r["_split"] = split[i]

print("split:", Counter(split))


# ------------------------------------------------------------
# PASS 1: source -> type-compatible Bridges
# ------------------------------------------------------------

sources = {
    norm(r.get("hop2", ""))
    for r in data
}

source_adj = defaultdict(list)
source_degree = Counter()

print("PrimeKG pass 1...")

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):

        x = row["x_name"].strip()
        y = row["y_name"].strip()

        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx = norm(x)
        ny = norm(y)

        if nx in sources:
            source_degree[nx] += 1
            source_adj[nx].append(
                (y, yt, rel)
            )

        if ny in sources:
            source_degree[ny] += 1
            source_adj[ny].append(
                (x, xt, rel)
            )

        if i % 1_000_000 == 0:
            print(" pass1", i)


query_bridges = []
all_bridges = set()

for r in data:

    source = norm(r.get("hop2", ""))
    bridge_type = norm(r.get("hop1_type", ""))

    seen = set()
    current = []

    for name, typ, rel in source_adj.get(source, []):

        if norm(typ) != bridge_type:
            continue

        bn = norm(name)

        if not bn or bn in seen:
            continue

        seen.add(bn)

        current.append({
            "name": name,
            "norm": bn,
            "type": typ,
            "rel1": rel
        })

        all_bridges.add(bn)

    query_bridges.append(current)

print("unique bridges:", len(all_bridges))


# ------------------------------------------------------------
# PASS 2: Bridge -> answers
# ------------------------------------------------------------

bridge_adj = defaultdict(list)
degree = Counter()

print("PrimeKG pass 2...")

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):

        x = row["x_name"].strip()
        y = row["y_name"].strip()

        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx = norm(x)
        ny = norm(y)

        if nx in all_bridges:
            degree[nx] += 1
            degree[ny] += 1
            bridge_adj[nx].append(
                (y, yt, rel)
            )

        if ny in all_bridges:
            degree[ny] += 1
            degree[nx] += 1
            bridge_adj[ny].append(
                (x, xt, rel)
            )

        if i % 1_000_000 == 0:
            print(" pass2", i)


MAXLOG = max(
    [math.log1p(v) for v in degree.values()]
    + [1.0]
)


def structural_score(name, rel):
    d = math.log1p(
        degree.get(norm(name), 0)
    ) / MAXLOG

    return (
        0.82 * relation_quality(rel)
        + 0.18 * (1.0 - d)
    )


# ------------------------------------------------------------
# Train Stage-II semantic Bridge scorer
#
# Important:
# gold is used ONLY for TRAIN labels.
# Test inference never sees gold.
# ------------------------------------------------------------

print("Building semantic baseline training data...")

cand = []

for qi, r in enumerate(data):

    question = (
        r.get("hop2_question_multi")
        or r.get("hop2_question")
        or r.get("prompt")
        or ""
    )

    source = norm(r.get("hop2", ""))
    target_type = norm(r.get("target_type", ""))

    gold = {
        norm(x)
        for x in r.get("answer", [])
        if norm(x)
    }

    for b in query_bridges[qi]:

        possible_answers = []

        for ans, typ, rel2 in bridge_adj.get(
            b["norm"], []
        ):
            if norm(typ) != target_type:
                continue

            if norm(ans) == source:
                continue

            possible_answers.append(
                (ans, rel2)
            )

        beneficial = int(
            any(
                norm(ans) in gold
                for ans, _ in possible_answers
            )
        )

        text = (
            f"question {question} "
            f"bridge_type {b['type']} "
            f"bridge {b['name']} "
            f"relation {b['rel1']}"
        )

        nums = [
            math.log1p(
                source_degree.get(source, 0)
            ),
            math.log1p(
                degree.get(b["norm"], 0)
            ),
            relation_quality(b["rel1"]),
            len(possible_answers) / 50.0,
        ]

        cand.append({
            "qi": qi,
            "split": r["_split"],
            "bridge": b["norm"],
            "text": text,
            "nums": nums,
            "label": beneficial
        })


texts = np.asarray(
    [x["text"] for x in cand],
    dtype=object
)

nums = np.asarray(
    [x["nums"] for x in cand],
    dtype=np.float32
)

labels = np.asarray(
    [x["label"] for x in cand],
    dtype=int
)

splits = np.asarray(
    [x["split"] for x in cand]
)

tr = splits == "train"


word = TfidfVectorizer(
    lowercase=True,
    ngram_range=(1, 2),
    min_df=2,
    max_features=40000,
    sublinear_tf=True
)

char = TfidfVectorizer(
    lowercase=True,
    analyzer="char_wb",
    ngram_range=(3, 5),
    min_df=3,
    max_features=40000,
    sublinear_tf=True
)

word.fit(texts[tr])
char.fit(texts[tr])

sc = StandardScaler().fit(
    nums[tr]
)

X = hstack([
    word.transform(texts),
    char.transform(texts),
    csr_matrix(
        sc.transform(nums)
    )
], format="csr")


clf = LogisticRegression(
    max_iter=1200,
    C=1.0,
    class_weight="balanced",
    solver="liblinear",
    random_state=20260827
)

clf.fit(
    X[tr],
    labels[tr]
)

semantic_conf = clf.predict_proba(X)[:, 1]


CONF = defaultdict(dict)

for row, p in zip(cand, semantic_conf):

    qi = row["qi"]
    b = row["bridge"]

    CONF[qi][b] = max(
        CONF[qi].get(b, 0.0),
        float(p)
    )


# ------------------------------------------------------------
# Run Structural and Semantic
# ------------------------------------------------------------

def rank_structural(qi):

    r = data[qi]

    source = norm(r.get("hop2", ""))
    target_type = norm(r.get("target_type", ""))

    scores = {}

    for b in query_bridges[qi]:

        s1 = structural_score(
            b["name"],
            b["rel1"]
        )

        for ans, typ, rel2 in bridge_adj.get(
            b["norm"], []
        ):

            if norm(typ) != target_type:
                continue

            if norm(ans) == source:
                continue

            s2 = structural_score(
                ans,
                rel2
            )

            score = (s1 + s2) / 2.0

            key = norm(ans)

            if (
                key not in scores
                or score > scores[key]
            ):
                scores[key] = score

    return [
        x[0]
        for x in sorted(
            scores.items(),
            key=lambda x: x[1],
            reverse=True
        )[:MAX_ANSWERS]
    ]


def rank_semantic(qi):

    r = data[qi]

    source = norm(r.get("hop2", ""))
    target_type = norm(r.get("target_type", ""))

    conf = CONF.get(qi, {})

    scores = {}

    for b in query_bridges[qi]:

        bscore = conf.get(
            b["norm"],
            0.0
        )

        for ans, typ, rel2 in bridge_adj.get(
            b["norm"], []
        ):

            if norm(typ) != target_type:
                continue

            if norm(ans) == source:
                continue

            key = norm(ans)

            # semantic baseline:
            # ranking only by learned query-Bridge confidence
            score = bscore

            if (
                key not in scores
                or score > scores[key]
            ):
                scores[key] = score

    return [
        x[0]
        for x in sorted(
            scores.items(),
            key=lambda x: x[1],
            reverse=True
        )[:MAX_ANSWERS]
    ]


struct_rows = []
semantic_rows = []

for qi, r in enumerate(data):

    if r["_split"] != "test":
        continue

    gold = r.get("answer", [])

    struct_rows.append({
        "predictions": rank_structural(qi),
        "gold": gold
    })

    semantic_rows.append({
        "predictions": rank_semantic(qi),
        "gold": gold
    })


result = {
    "dataset": "BioHopR",
    "seed": SEED,
    "test_count": len(struct_rows),
    "Structural": evaluate(struct_rows),
    "Semantic": evaluate(semantic_rows)
}


print("\n===================================")
print("BIOHOPR EXTRA BASELINES")
print("===================================")

print(
    json.dumps(
        result,
        indent=2
    )
)


with open(
    "outputs/biohopr_extra_baselines_seed17.json",
    "w"
) as f:
    json.dump(
        result,
        f,
        indent=2
    )
