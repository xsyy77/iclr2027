import csv
import json
import math
import re
from collections import defaultdict, Counter

import torch
from transformers import AutoModel, AutoTokenizer

BIO = "data/biohopr_raw/BioHopR.json"
KG = "data/primekg.csv"

OUT = "outputs/biohopr_ours_official_fast_seed17.jsonl"
SUMMARY = "outputs/biohopr_ours_official_fast_summary.json"

MODEL_NAME = "dmis-lab/biobert-base-cased-v1.1"
THRESHOLD = 0.85
BATCH = 128

def norm(x):
    if isinstance(x, list):
        x = ", ".join(str(i) for i in x)
    text = str(x or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[\"'.,;:!?()\[\]{}]", "", text)
    return text


print("Loading BioHopR...")
with open(BIO, encoding="utf-8") as f:
    data = json.load(f)

print("BioHopR records:", len(data))


# --------------------------------------------------
# Build graph
# --------------------------------------------------

benchmark_entities = set()
needed_types = set()

for r in data:
    benchmark_entities.add(norm(r.get("hop1", "")))
    benchmark_entities.add(norm(r.get("hop2", "")))
    needed_types.add(norm(r.get("hop1_type", "")))
    needed_types.add(norm(r.get("hop2_type", "")))
    needed_types.add(norm(r.get("target_type", "")))

adj = defaultdict(list)
degree = Counter()

print("Streaming PrimeKG...")

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):
        x = row["x_name"].strip()
        y = row["y_name"].strip()
        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx = norm(x)
        ny = norm(y)

        degree[nx] += 1
        degree[ny] += 1

        if (
            nx in benchmark_entities
            or ny in benchmark_entities
            or norm(xt) in needed_types
            or norm(yt) in needed_types
        ):
            adj[nx].append((y, yt, rel))
            adj[ny].append((x, xt, rel))

        if i % 1_000_000 == 0:
            print(f"  graph {i:,}")

print("Graph ready.")


def structural_score(entity):
    d = degree[norm(entity)]
    return 1.0 / math.log2(d + 2.0)


def hop1_predict(row, max_answers=50):
    source = row.get("hop1", "")
    target_type = norm(row.get("target_type", ""))

    scores = Counter()

    for name, typ, rel in adj.get(norm(source), []):
        if norm(typ) == target_type:
            scores[name] += structural_score(name)

    return [x for x, _ in scores.most_common(max_answers)]


def hop2_predict(row, max_bridges=12, max_answers=50):
    source = row.get("hop2", "")
    bridge_type = norm(row.get("hop1_type", ""))
    target_type = norm(row.get("target_type", ""))

    candidates = []
    seen = set()

    for bridge, typ, rel in adj.get(norm(source), []):
        if norm(typ) != bridge_type:
            continue

        nb = norm(bridge)

        if nb in seen:
            continue

        seen.add(nb)

        candidates.append(
            (structural_score(bridge), bridge)
        )

    candidates.sort(reverse=True)

    bridges = [
        bridge
        for _, bridge in candidates[:max_bridges]
    ]

    scores = Counter()

    for rank, bridge in enumerate(bridges):
        bw = 1.0 / (rank + 1.0)

        for ans, typ, rel in adj.get(norm(bridge), []):
            if norm(typ) != target_type:
                continue

            if norm(ans) == norm(source):
                continue

            scores[ans] += bw * structural_score(ans)

    return [x for x, _ in scores.most_common(max_answers)]


# --------------------------------------------------
# Generate predictions FIRST
# --------------------------------------------------

print("Generating predictions...")

rows = []

for i, ex in enumerate(data):
    gold = ex.get("answer", [])

    if not isinstance(gold, list):
        gold = [gold]

    p1 = hop1_predict(ex)
    p2 = hop2_predict(ex)

    rows.append({
        "index": i,
        "hop1_prediction": p1,
        "hop2_prediction": p2,
        "gold": gold
    })

    if (i + 1) % 500 == 0:
        print(f"  retrieval {i+1}/{len(data)}")


# --------------------------------------------------
# Collect unique strings requiring embeddings
# --------------------------------------------------

print("Collecting unique biomedical entities...")

unique = set()

for r in rows:
    gold_norm = [norm(x) for x in r["gold"] if norm(x)]

    for x in gold_norm:
        unique.add(x)

    for p in r["hop1_prediction"]:
        np = norm(p)

        if np and np not in gold_norm:
            unique.add(np)

    for p in r["hop2_prediction"]:
        np = norm(p)

        if np and np not in gold_norm:
            unique.add(np)

texts = sorted(unique)

print("Unique strings to embed:", len(texts))


# --------------------------------------------------
# Batch BioBERT encoding
# --------------------------------------------------

print("Loading BioBERT...")

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME)
model.eval()

device = (
    "mps"
    if torch.backends.mps.is_available()
    else "cpu"
)

print("Embedding device:", device)

model.to(device)

emb_cache = {}

print("Batch embedding...")

with torch.no_grad():

    for start in range(0, len(texts), BATCH):
        batch = texts[start:start+BATCH]

        encoded = tokenizer(
            batch,
            padding=True,
            truncation=True,
            return_tensors="pt"
        )

        encoded = {
            k: v.to(device)
            for k, v in encoded.items()
        }

        outputs = model(**encoded)

        mask = encoded["attention_mask"].unsqueeze(-1)

        hidden = outputs.last_hidden_state * mask

        pooled = (
            hidden.sum(dim=1)
            / mask.sum(dim=1).clamp(min=1)
        )

        pooled = torch.nn.functional.normalize(
            pooled,
            dim=1
        )

        pooled = pooled.cpu()

        for t, e in zip(batch, pooled):
            emb_cache[t] = e

        done = min(start+BATCH, len(texts))

        if done % 5000 < BATCH:
            print(f"  embedded {done}/{len(texts)}")


# --------------------------------------------------
# Official-equivalent precision
# --------------------------------------------------

def fast_answer_precision(predicted, gold):
    predicted = [str(x).strip() for x in predicted if str(x).strip()]
    gold = [norm(x) for x in gold if norm(x)]

    if not predicted or not gold:
        return 0.0

    gold_set = set(gold)

    gold_emb = torch.stack([
        emb_cache[g]
        for g in gold
    ])

    matched = 0

    for candidate in predicted:

        c = norm(candidate)

        if not c:
            continue

        if c in gold_set:
            matched += 1
            continue

        ce = emb_cache[c]

        sims = torch.mv(
            gold_emb,
            ce
        )

        if float(sims.max()) >= THRESHOLD:
            matched += 1

    return matched / max(len(predicted), 1)


print("Computing official metrics...")

final_rows = []

for i, r in enumerate(rows):

    p1 = fast_answer_precision(
        r["hop1_prediction"],
        r["gold"]
    )

    p2 = fast_answer_precision(
        r["hop2_prediction"],
        r["gold"]
    )

    final_rows.append({
        "index": r["index"],
        "hop1_predicted_answer": r["hop1_prediction"],
        "hop2_predicted_answer": r["hop2_prediction"],
        "gold_answer": r["gold"],
        "hop1_precision": float(p1),
        "hop2_precision": float(p2),
        "hop1_correct": bool(p1 == 1.0),
        "hop2_correct": bool(p2 == 1.0)
    })

    if (i + 1) % 1000 == 0:
        print(f"  metric {i+1}/{len(rows)}")


n = len(final_rows)

prec1 = 100.0 * sum(
    r["hop1_precision"] for r in final_rows
) / n

prec2 = 100.0 * sum(
    r["hop2_precision"] for r in final_rows
) / n

both_corr = 100.0 * sum(
    r["hop1_correct"] and r["hop2_correct"]
    for r in final_rows
) / n

both_wr = 100.0 * sum(
    (not r["hop1_correct"]) and
    (not r["hop2_correct"])
    for r in final_rows
) / n

summary = {
    "prec_hop1": prec1,
    "prec_hop2": prec2,
    "both_corr": both_corr,
    "both_wr": both_wr,
    "count": n,
    "metric": "BioHopR official-equivalent batched BioBERT",
    "threshold": THRESHOLD
}

print("\nOFFICIAL BIOHOPR METRICS")
print(json.dumps(summary, indent=2))

with open(OUT, "w", encoding="utf-8") as f:
    for r in final_rows:
        f.write(
            json.dumps(r, ensure_ascii=False)
            + "\n"
        )

with open(SUMMARY, "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2)

print("\nDONE")
print("Saved:", OUT)
print("Saved:", SUMMARY)
