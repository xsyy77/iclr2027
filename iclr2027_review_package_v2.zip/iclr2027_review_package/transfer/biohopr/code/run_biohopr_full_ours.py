import csv
import json
import math
import re
from collections import defaultdict, Counter

import numpy as np

from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score


# ============================================================
# CONFIG
# ============================================================

BIO = "data/biohopr_raw/BioHopR.json"
KG = "data/primekg.csv"

SEED = 17

MAX_BRIDGES = 24
MAX_ANSWERS = 50

FIXED_G = 0.30

GMAX_GRID = [0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50]
GAMMA_GRID = [0.50, 0.75, 1.00, 1.25, 1.50, 2.00]

OUT = "outputs/biohopr_full_ours_seed17.json"
DETAIL = "outputs/biohopr_full_ours_seed17_predictions.jsonl"


# ============================================================
# BASIC HELPERS
# ============================================================

def norm(x):
    text = str(x or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[\"'.,;:!?()\[\]{}]", "", text)
    return text


def relation_quality(rel):
    s = str(rel or "").lower().replace("_", " ")

    if any(k in s for k in [
        "causes", "prevents", "treats", "therapeutic"
    ]):
        return 1.00

    if any(k in s for k in [
        "regulates", "activity", "abundance",
        "inhibits", "stimulates", "affects"
    ]):
        return 0.88

    if any(k in s for k in [
        "participates", "produces", "has output",
        "capable of", "precedes"
    ]):
        return 0.72

    if any(k in s for k in [
        "occurs in", "located in", "location of",
        "correlated", "associated"
    ]):
        return 0.52

    return 0.62


def first_rank(preds, gold):
    gold = {norm(x) for x in gold if norm(x)}

    for i, p in enumerate(preds, 1):
        if norm(p) in gold:
            return i

    return None


def metrics_from_predictions(rows):
    h1 = 0.0
    h5 = 0.0
    rr = 0.0

    for r in rows:
        rank = first_rank(r["predictions"], r["gold"])

        if rank is not None:
            h1 += float(rank <= 1)
            h5 += float(rank <= 5)
            rr += 1.0 / rank

    n = max(len(rows), 1)

    return {
        "Hits@1": 100.0 * h1 / n,
        "Hits@5": 100.0 * h5 / n,
        "MRR": 100.0 * rr / n,
        "count": len(rows)
    }


# ============================================================
# LOAD BIOHOPR
# ============================================================

print("Loading BioHopR...")

with open(BIO, encoding="utf-8") as f:
    data = json.load(f)

print("BioHopR records:", len(data))


# ============================================================
# SPLIT
#
# If benchmark provides a split, use it.
# Otherwise deterministic held-out split:
# 70 train / 15 val / 15 test.
# ============================================================

has_split = all(
    str(r.get("split", "")).lower() in {"train", "val", "test"}
    for r in data
)

if has_split:
    split = np.array([
        str(r["split"]).lower()
        for r in data
    ])

    print("Using dataset-provided split.")

else:
    print("No explicit split field found.")
    print("Using deterministic 70/15/15 held-out split, seed=17.")

    rng = np.random.default_rng(SEED)
    idx = np.arange(len(data))
    rng.shuffle(idx)

    n = len(data)

    n_train = int(0.70 * n)
    n_val = int(0.15 * n)

    split = np.empty(n, dtype=object)

    split[idx[:n_train]] = "train"
    split[idx[n_train:n_train+n_val]] = "val"
    split[idx[n_train+n_val:]] = "test"


for i, r in enumerate(data):
    r["_split"] = split[i]


print(
    "Split:",
    Counter(r["_split"] for r in data)
)


# ============================================================
# QUERY INPUT
#
# BioHopR 2-hop:
# hop2 = query source
# hop1_type = intermediate / bridge type
# target_type = answer type
#
# Gold answer is NEVER used in candidate construction at test.
# ============================================================

sources = set()

for r in data:
    sources.add(norm(r.get("hop2", "")))


# ============================================================
# PRIMEKG PASS 1
#
# Find type-compatible candidate Bridges adjacent to query source.
# ============================================================

print("\nPrimeKG pass 1: source -> candidate Bridges...")

source_candidates = defaultdict(list)
source_degree = Counter()

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):

        x = row["x_name"].strip()
        y = row["y_name"].strip()

        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx = norm(x)
        ny = norm(y)

        if nx in sources:
            source_degree[nx] += 1
            source_candidates[nx].append(
                (y, yt, rel)
            )

        if ny in sources:
            source_degree[ny] += 1
            source_candidates[ny].append(
                (x, xt, rel)
            )

        if i % 1_000_000 == 0:
            print(f"  pass1 {i:,}")


# ============================================================
# COLLECT ACTUAL BRIDGE CANDIDATES PER QUERY
# ============================================================

query_bridges = []
all_bridge_names = set()

for r in data:

    source = norm(r.get("hop2", ""))
    bridge_type = norm(r.get("hop1_type", ""))

    seen = set()
    bridges = []

    for name, typ, rel in source_candidates.get(source, []):

        if norm(typ) != bridge_type:
            continue

        nname = norm(name)

        if not nname or nname in seen:
            continue

        seen.add(nname)

        bridges.append({
            "name": name,
            "norm": nname,
            "type": typ,
            "rel_source": rel
        })

    query_bridges.append(bridges)

    for b in bridges:
        all_bridge_names.add(b["norm"])


print("Unique candidate Bridges:", len(all_bridge_names))


# ============================================================
# PRIMEKG PASS 2
#
# Candidate Bridge -> candidate answers.
# Also collect bridge / answer degree.
# ============================================================

print("\nPrimeKG pass 2: Bridge -> answer candidates...")

bridge_adj = defaultdict(list)
degree = Counter()

with open(KG, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for i, row in enumerate(reader, 1):

        x = row["x_name"].strip()
        y = row["y_name"].strip()

        xt = row["x_type"].strip()
        yt = row["y_type"].strip()

        rel = (
            row.get("display_relation")
            or row.get("relation")
            or ""
        ).strip()

        nx = norm(x)
        ny = norm(y)

        if nx in all_bridge_names:
            degree[nx] += 1
            degree[ny] += 1

            bridge_adj[nx].append(
                (y, yt, rel)
            )

        if ny in all_bridge_names:
            degree[ny] += 1
            degree[nx] += 1

            bridge_adj[ny].append(
                (x, xt, rel)
            )

        if i % 1_000_000 == 0:
            print(f"  pass2 {i:,}")


max_log_degree = max(
    [math.log1p(v) for v in degree.values()] + [1.0]
)


def local_graph_score(node_name, rel):
    d = (
        math.log1p(degree.get(norm(node_name), 0))
        / max_log_degree
    )

    return (
        0.82 * relation_quality(rel)
        + 0.18 * (1.0 - d)
    )


# ============================================================
# STAGE II TRAINING DATA
#
# Training-only beneficial label:
#
# candidate Bridge is useful iff it connects to at least one
# gold answer through a graph-valid edge.
#
# Gold is used ONLY to construct TRAIN labels.
# ============================================================

print("\nBuilding Stage-II candidate training data...")

candidate_rows = []

for qi, r in enumerate(data):

    question = (
        r.get("hop2_question_multi")
        or r.get("hop2_question")
        or r.get("prompt")
        or ""
    )

    source = norm(r.get("hop2", ""))
    target_type = norm(r.get("target_type", ""))

    gold = {
        norm(x)
        for x in r.get("answer", [])
        if norm(x)
    }

    bridges = query_bridges[qi]

    for b in bridges:

        answers = []

        for ans, typ, rel2 in bridge_adj.get(b["norm"], []):

            if norm(typ) != target_type:
                continue

            if norm(ans) == source:
                continue

            answers.append((ans, rel2))

        beneficial = int(
            any(norm(ans) in gold for ans, _ in answers)
        )

        text = (
            f"question {question} "
            f"bridge_type {b['type']} "
            f"bridge {b['name']} "
            f"source_relation {b['rel_source']}"
        )

        nums = [
            math.log1p(source_degree.get(source, 0)),
            math.log1p(degree.get(b["norm"], 0)),
            relation_quality(b["rel_source"]),
            len(answers) / 50.0,
        ]

        candidate_rows.append({
            "query": qi,
            "split": r["_split"],
            "bridge": b["norm"],
            "text": text,
            "nums": nums,
            "label": beneficial
        })


print("Candidate rows:", len(candidate_rows))

train_candidate_rows = [
    x for x in candidate_rows
    if x["split"] == "train"
]

if not train_candidate_rows:
    raise RuntimeError("No Stage-II training candidates.")


# ============================================================
# STAGE II:
# word TF-IDF + char TF-IDF + structural features
# LogisticRegression
# ============================================================

print("\nTraining Stage II Bridge confidence...")

texts = np.array(
    [x["text"] for x in candidate_rows],
    dtype=object
)

Xnum = np.asarray(
    [x["nums"] for x in candidate_rows],
    dtype=np.float32
)

y_bridge = np.asarray(
    [x["label"] for x in candidate_rows],
    dtype=int
)

split_bridge = np.asarray(
    [x["split"] for x in candidate_rows]
)

tr = split_bridge == "train"
va = split_bridge == "val"
te = split_bridge == "test"


word = TfidfVectorizer(
    lowercase=True,
    ngram_range=(1, 2),
    min_df=2,
    max_features=40000,
    sublinear_tf=True
)

char = TfidfVectorizer(
    lowercase=True,
    analyzer="char_wb",
    ngram_range=(3, 5),
    min_df=3,
    max_features=40000,
    sublinear_tf=True
)

Xw_train = word.fit_transform(texts[tr])
Xc_train = char.fit_transform(texts[tr])

Xw = word.transform(texts)
Xc = char.transform(texts)

sc_bridge = StandardScaler().fit(Xnum[tr])

X = hstack([
    Xw,
    Xc,
    csr_matrix(sc_bridge.transform(Xnum))
], format="csr")


bridge_clf = LogisticRegression(
    max_iter=1200,
    C=1.0,
    class_weight="balanced",
    solver="liblinear",
    random_state=20260827
)

bridge_clf.fit(
    X[tr],
    y_bridge[tr]
)

bridge_p = bridge_clf.predict_proba(X)[:, 1]


if len(np.unique(y_bridge[va])) == 2:

    print(
        "Stage II val AUROC:",
        roc_auc_score(
            y_bridge[va],
            bridge_p[va]
        )
    )

    print(
        "Stage II val AUPRC:",
        average_precision_score(
            y_bridge[va],
            bridge_p[va]
        )
    )


# ============================================================
# CSETS
# ============================================================

CSETS = defaultdict(dict)

for row, p in zip(candidate_rows, bridge_p):

    qi = row["query"]
    b = row["bridge"]

    old = CSETS[qi].get(b, 0.0)

    CSETS[qi][b] = max(
        old,
        float(p)
    )


# ============================================================
# BRIDGE STATE SCORE
#
# Adapted directly from DMDB Full Ours scoring logic.
# ============================================================

def bridge_state_score(conf, bridge_norm):

    if not conf:
        return 0.0

    if bridge_norm not in conf:
        return 0.0

    uniq = [bridge_norm]

    cov = len(uniq) / max(1, len(conf))

    mean_c = float(np.mean([
        conf[n]
        for n in uniq
    ]))

    cur = conf.get(bridge_norm, 0.0)

    # For a two-hop source->bridge->answer path,
    # bridge occurs among the final two nodes.
    recent = 0.5

    sat = 0.65

    return min(
        1.0,
        max(
            0.0,
            (
                0.45 * cov
                + 0.25 * mean_c
                + 0.15 * cur
                + 0.15 * recent
            ) * sat
        )
    )


# ============================================================
# RANK ANSWERS GIVEN GATE g
#
# No gold target is used here.
# ============================================================

def rank_query(qi, g):

    r = data[qi]

    source = norm(r.get("hop2", ""))
    target_type = norm(r.get("target_type", ""))

    conf = CSETS.get(qi, {})

    paths = []

    for b in query_bridges[qi]:

        bnorm = b["norm"]

        if bnorm not in conf:
            continue

        bscore = bridge_state_score(
            conf,
            bnorm
        )

        graph1 = local_graph_score(
            b["name"],
            b["rel_source"]
        )

        for ans, typ, rel2 in bridge_adj.get(bnorm, []):

            if norm(typ) != target_type:
                continue

            if norm(ans) == source:
                continue

            graph2 = local_graph_score(
                ans,
                rel2
            )

            graph_score = (
                graph1 + graph2
            ) / 2.0

            score = (
                (1.0 - g) * graph_score
                + g * bscore
                - 0.012 * 2
            )

            paths.append(
                (
                    score,
                    ans,
                    b["name"]
                )
            )

    # One answer may be reached through multiple Bridges.
    answer_score = {}

    answer_bridge = {}

    for score, ans, bridge in paths:

        key = norm(ans)

        if (
            key not in answer_score
            or score > answer_score[key]
        ):
            answer_score[key] = score
            answer_bridge[key] = bridge

    ranked = sorted(
        answer_score.items(),
        key=lambda x: x[1],
        reverse=True
    )

    predictions = [
        ans
        for ans, _ in ranked[:MAX_ANSWERS]
    ]

    return predictions, answer_score, answer_bridge


# ============================================================
# STAGE III TRAINING LABEL
#
# z = 1 when positive semantic guidance improves retrieval
# relative to graph-only.
#
# TRAIN ONLY.
# ============================================================

print("\nConstructing Stage-III query labels...")

query_z = np.zeros(
    len(data),
    dtype=int
)

query_texts = []
query_nums = []


for qi, r in enumerate(data):

    question = (
        r.get("hop2_question_multi")
        or r.get("hop2_question")
        or r.get("prompt")
        or ""
    )

    conf = CSETS.get(qi, {})

    top_bridges = sorted(
        conf.items(),
        key=lambda x: x[1],
        reverse=True
    )[:MAX_BRIDGES]

    bridge_names = [
        b
        for b, _ in top_bridges
    ]

    bridge_types = []

    for b in query_bridges[qi]:

        if b["norm"] in set(bridge_names):
            bridge_types.append(
                norm(b["type"])
            )

    text = (
        f"question {question} candidates "
        + " ; ".join(
            bridge_names
        )
    )

    source = norm(r.get("hop2", ""))

    conf_values = [
        p for _, p in top_bridges
    ]

    nums = [
        len(top_bridges) / max(1, MAX_BRIDGES),

        math.log1p(
            source_degree.get(source, 0)
        ),

        float(np.mean(conf_values))
        if conf_values else 0.0,

        float(np.max(conf_values))
        if conf_values else 0.0,

        float(np.std(conf_values))
        if conf_values else 0.0,

        len(set(bridge_types))
        / max(1, len(bridge_types))
        if bridge_types else 0.0,
    ]

    query_texts.append(text)
    query_nums.append(nums)

    # Training label construction only.
    if r["_split"] == "train":

        gold = r.get("answer", [])

        pred0, _, _ = rank_query(
            qi,
            0.0
        )

        predf, _, _ = rank_query(
            qi,
            FIXED_G
        )

        rank0 = first_rank(
            pred0,
            gold
        )

        rankf = first_rank(
            predf,
            gold
        )

        rr0 = (
            0.0
            if rank0 is None
            else 1.0 / rank0
        )

        rrf = (
            0.0
            if rankf is None
            else 1.0 / rankf
        )

        query_z[qi] = int(
            rrf > rr0
        )


print(
    "Stage III positive train rate:",
    query_z[
        np.array([r["_split"] == "train" for r in data])
    ].mean()
)


# ============================================================
# STAGE III:
# query + Bridge-set TF-IDF + structural/confidence features
# LogisticRegression
# ============================================================

print("\nTraining Stage III query reliability...")

qtexts = np.asarray(
    query_texts,
    dtype=object
)

Qnum = np.asarray(
    query_nums,
    dtype=np.float32
)

qsplit = np.asarray([
    r["_split"]
    for r in data
])

qtr = qsplit == "train"
qva = qsplit == "val"
qte = qsplit == "test"


qword = TfidfVectorizer(
    lowercase=True,
    ngram_range=(1, 2),
    min_df=2,
    max_features=50000,
    sublinear_tf=True
)

qchar = TfidfVectorizer(
    lowercase=True,
    analyzer="char_wb",
    ngram_range=(3, 5),
    min_df=3,
    max_features=50000,
    sublinear_tf=True
)

qword.fit(qtexts[qtr])
qchar.fit(qtexts[qtr])

sc_gate = StandardScaler().fit(
    Qnum[qtr]
)

QX = hstack([
    qword.transform(qtexts),
    qchar.transform(qtexts),
    csr_matrix(
        sc_gate.transform(Qnum)
    )
], format="csr")


# Guard against pathological all-zero/all-one z.
if len(np.unique(query_z[qtr])) < 2:

    print(
        "WARNING: Stage-III train labels contain one class only."
    )

    p_gate = np.full(
        len(data),
        FIXED_G,
        dtype=float
    )

else:

    gate_clf = LogisticRegression(
        max_iter=1200,
        C=0.5,
        class_weight="balanced",
        solver="liblinear",
        random_state=20260827
    )

    gate_clf.fit(
        QX[qtr],
        query_z[qtr]
    )

    p_gate = gate_clf.predict_proba(
        QX
    )[:, 1]

    if len(np.unique(query_z[qva])) == 2:

        print(
            "Stage III val AUROC:",
            roc_auc_score(
                query_z[qva],
                p_gate[qva]
            )
        )

        print(
            "Stage III val AUPRC:",
            average_precision_score(
                query_z[qva],
                p_gate[qva]
            )
        )


# ============================================================
# VALIDATION-ONLY gmax / gamma SELECTION
#
# Main criterion = MRR
# tie-break Hits@1 then Hits@5.
# ============================================================

print("\nSelecting gmax/gamma on validation only...")

best = None

for gmax in GMAX_GRID:

    for gamma in GAMMA_GRID:

        val_rows = []

        for qi, r in enumerate(data):

            if r["_split"] != "val":
                continue

            p = float(p_gate[qi])

            g = gmax * (
                max(0.0, min(1.0, p))
                ** gamma
            )

            preds, _, _ = rank_query(
                qi,
                g
            )

            val_rows.append({
                "predictions": preds,
                "gold": r.get("answer", [])
            })

        m = metrics_from_predictions(
            val_rows
        )

        key = (
            m["MRR"],
            m["Hits@1"],
            m["Hits@5"]
        )

        print(
            f"  gmax={gmax:.2f} "
            f"gamma={gamma:.2f} "
            f"H1={m['Hits@1']:.3f} "
            f"H5={m['Hits@5']:.3f} "
            f"MRR={m['MRR']:.3f}"
        )

        if best is None or key > best[0]:

            best = (
                key,
                gmax,
                gamma,
                m
            )


_, gmax, gamma, val_metrics = best

print("\nSELECTED")
print("gmax =", gmax)
print("gamma =", gamma)
print("validation =", val_metrics)


# ============================================================
# FINAL HELD-OUT TEST
# ============================================================

print("\nEvaluating held-out test...")

full_rows = []
graph_rows = []

details = []


for qi, r in enumerate(data):

    if r["_split"] != "test":
        continue

    p = float(p_gate[qi])

    g = gmax * (
        max(0.0, min(1.0, p))
        ** gamma
    )

    full_pred, _, _ = rank_query(
        qi,
        g
    )

    graph_pred, _, _ = rank_query(
        qi,
        0.0
    )

    gold = r.get("answer", [])

    full_rows.append({
        "predictions": full_pred,
        "gold": gold
    })

    graph_rows.append({
        "predictions": graph_pred,
        "gold": gold
    })

    details.append({
        "index": qi,
        "split": "test",
        "question": (
            r.get("hop2_question_multi")
            or r.get("hop2_question")
            or r.get("prompt")
            or ""
        ),
        "source": r.get("hop2"),
        "gold": gold,
        "p_semantic_gate": p,
        "gate": g,
        "graph_only_predictions": graph_pred,
        "full_ours_predictions": full_pred
    })


graph_metrics = metrics_from_predictions(
    graph_rows
)

full_metrics = metrics_from_predictions(
    full_rows
)


result = {
    "dataset": "BioHopR",
    "protocol": (
        "target-agnostic held-out entity ranking; "
        "no test-time gold target, gold bridge, "
        "gold path, or target-dependent features"
    ),
    "seed": SEED,
    "selected_gate": {
        "gmax": gmax,
        "gamma": gamma
    },
    "validation": val_metrics,
    "Graph Only": graph_metrics,
    "Full Ours": full_metrics
}


print("\n======================================")
print("BIOHOPR UNIFIED 5.2 RESULTS")
print("======================================")

print(json.dumps(
    result,
    indent=2
))


with open(
    DETAIL,
    "w",
    encoding="utf-8"
) as f:

    for row in details:

        f.write(
            json.dumps(
                row,
                ensure_ascii=False
            )
            + "\n"
        )


with open(
    OUT,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        result,
        f,
        indent=2
    )


print("\nSaved:", OUT)
print("Saved:", DETAIL)
print("DONE")
