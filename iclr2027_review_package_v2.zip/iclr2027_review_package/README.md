# Confidence-Gated Mechanistic Bridge Retrieval — traced reproducibility bundle

This package consolidates the code, result tables, figure-generation scripts, current TeX, and current PDF that could be traced from the uploaded project artifacts.

## What is fully verifiable in this package

Run:

```bash
python verify_bundle.py
```

It checks the current DrugMechDB Table-1 values, Stage-II retrieval-aware AUROC/AUPRC, Stage-II utility-weight robustness, Stage-III control values, and shuffled-gate statistics.

The package also contains a regenerated Figure 4 under `figures/figure4_stage3_reproduced.*`.

## Directory layout

- `manuscript/` — current TeX and current compiled PDF.
- `code/` — DrugMechDB Stage I/II/III code, EpiKG code, CWQ transfer code, Figure 3/4 generation code.
- `data/` — result/prediction files currently available and used for numerical verification.
- `figures/` — traceable reference/reproduced figure assets.
- `docs/REPRODUCIBILITY_AUDIT.md` — claim-by-claim status.
- `docs/MISSING_INPUTS.md` — files that still need to be restored for true clean-room reproduction.
- `MANIFEST.csv` / `SHA256SUMS.txt` — file inventory and hashes.

## Recommended execution order

The intended method pipeline is:

1. Stage I / controlled Stage-I rerun: `rerun_stage12_fixed.py`
2. Stage II Bridge reliability: `step_semantic_bridge_diagnostics.py`
3. Stage III query reliability: `step_semantic_gate_diagnostics.py`
4. Final constrained retrieval: `final_continuous_realgraph.py`
5. Stage-I figure: `figure3_stage1_reconstructed.py`
6. Stage-III Figure 4: `figure4_stage3_shuffled_gate.py`
7. External EpiKG validation: `epikg_fixed_manifest_rerun.py`
8. Optional CWQ transfer: the recovered source is `run_cwq_same_pipeline.partial.txt` and is truncated; restore the original full script before running.

`run_order.sh` records this order, but the first four scripts require upstream raw DrugMechDB files that are not currently inside the bundle.

## Core implementation frozen by uploaded code

DrugMechDB search uses beam width 2, max 8 hops, 14 visited-node budget, 20 expanded-edge budget, and fixed semantic gate 0.30 for fixed-guidance controls. The local structural path score combines a frozen relation-quality prior and anti-hub degree term; the Bridge state score combines Bridge coverage, reached-Bridge mean confidence, current-node confidence, recent Bridge hits, and a saturation factor. The final path score is `(1-g)*S_graph + g*S_bridge - 0.012*path_length`.

## Important limitations

This is an **audited traced bundle**, not a claim that every current manuscript result can already be rerun from raw public inputs. See `docs/MISSING_INPUTS.md`. The most important unresolved items are the upstream DrugMechDB raw/manifests, the exact source of the Stage-I 40.32% -> 61.29% coverage statement, the executable/raw outputs for the current Section-3 corruption study, EpiKG raw inputs, and OpenBioLink/BioHopR artifacts.
