"""Portable EpiKG Graph Only / Semantic Beam / Bridge-guided retrievers.
Derived from the recovered independent EpiKG experiment implementation.
"""
from __future__ import annotations
import json, re, math, unicodedata
from collections import defaultdict
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; trip=json.load(open(ROOT/'data/raw/epikg/triplets.json'))
OUT=defaultdict(list); IN=defaultdict(list); NAMES=set()
for i,e in enumerate(trip):
 h,t=str(e['head']),str(e['tail']); NAMES|={h,t}; OUT[h].append((t,i,str(e['relation']),float(e.get('confidence',.5)),int(e.get('paper_count',0)))); IN[t].append((h,i,str(e['relation']),float(e.get('confidence',.5)),int(e.get('paper_count',0))))
DEG={n:len(OUT[n])+len(IN[n]) for n in NAMES}; MAXLOG=max(math.log1p(x) for x in DEG.values()) or 1.; MAXPC=max(math.log1p(int(e.get('paper_count',0))) for e in trip) or 1.
def norm(s): return ' '.join(re.sub(r'[^a-z0-9]+',' ',unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()).split())
def jac(a,b):
 A,B=set(norm(a).split()),set(norm(b).split()); return len(A&B)/len(A|B) if A and B else 0.
def edge_base(v,c,pc): return .62*c+.23*(1-math.log1p(DEG.get(v,0))/MAXLOG)+.15*math.log1p(pc)/MAXPC
def semantic_edge(source,target,qrel,v,rel,c,pc): return .58*edge_base(v,c,pc)+.42*(.55*jac(rel,qrel)+.30*jac(v,target)+.15*jac(v,source))
def bridge_state(nodes,conf):
 if not conf:return 0.
 r=list(dict.fromkeys(n for n in nodes if n in conf))
 if not r:return 0.
 return min(1.,.42*len(r)/len(conf)+.28*np.mean([conf[n] for n in r])+.16*conf.get(nodes[-1],0)+.14*sum(n in conf for n in nodes[-2:])/2)
def search(source,target,qrel,mode='graph',bridge_conf=None,gate=0.,beam=2,max_hops=8,node_budget=14,edge_budget=20):
 bridge_conf=bridge_conf or {}; states=[(0.,(source,),())]; gen={source}; expanded=0; best=None
 for _ in range(max_hops):
  nxt=[]
  for _,pn,rels in states:
   cand=[]
   for v,idx,r,c,pc in OUT.get(pn[-1],[]):
    if pn[-1]==source and v==target:continue
    if v in pn:continue
    gs=semantic_edge(source,target,qrel,v,r,c,pc) if mode=='semantic' else edge_base(v,c,pc); cand.append((gs,v,r))
   cand.sort(reverse=True,key=lambda x:x[0])
   for gs,v,r in cand:
    if expanded>=edge_budget:break
    expanded+=1
    if v not in gen and len(gen)>=node_budget:continue
    gen.add(v); nn=pn+(v,); rr=rels+(r,); score=(1-gate)*gs+gate*bridge_state(nn,bridge_conf)-.012*len(rr); st=(score,nn,rr); nxt.append(st)
    if v==target and (best is None or score>best[0]):best=st
   if expanded>=edge_budget:break
  if best is not None:break
  if not nxt:break
  nxt.sort(reverse=True,key=lambda x:x[0]); states=nxt[:beam]
 z=best if best is not None else (max(states,key=lambda x:x[0]) if states else (0,(source,),()))
 return {'found':z[1][-1]==target,'nodes':list(z[1]),'relations':list(z[2]),'visited_nodes':len(gen),'expanded_edges':expanded}
def graph_only(s,t,r): return search(s,t,r,'graph')
def semantic_beam(s,t,r): return search(s,t,r,'semantic')
def fixed_bridge(s,t,r,b,a=.3): return search(s,t,r,'graph',b,a)
def ours(s,t,r,b,p,gmax=.45,gamma=1.): return search(s,t,r,'graph',b,gmax*(float(p)**gamma))
