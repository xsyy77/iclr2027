"""Portable DrugMechDB retrieval implementations used to expose Graph Only, Fixed Bridge and Ours.
Derived from the recovered final_continuous_realgraph.py; paths are repository-relative here.
"""
from __future__ import annotations
import json, math
from collections import defaultdict
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw/drugmechdb/indication_paths.json'; BASE=ROOT/'data/processed/drugmechdb'
paths=json.load(open(RAW)); manifest=pd.read_csv(BASE/'benchmark_manifest.csv')
G=nx.MultiDiGraph(); gold={}
for rec in paths:
 rid=str(rec.get('graph',{}).get('_id','')); links=[]
 for n in rec.get('nodes',[]):
  nid=str(n['id']); G.add_node(nid,name=str(n.get('name','')),type=str(n.get('label','Unknown')))
 for e in rec.get('links',[]):
  u,v,r=str(e['source']),str(e['target']),str(e.get('key','unknown')); G.add_edge(u,v,relation=r); links.append((u,v,r))
 if rid: gold[rid]=links
OUT=defaultdict(list)
for u,v,d in G.edges(data=True):
 t=(v,str(d.get('relation','unknown')))
 if t not in OUT[u]: OUT[u].append(t)
MAXLOG=max(math.log1p(G.in_degree(n)+G.out_degree(n)) for n in G.nodes) or 1

def rel_quality(rel):
 s=rel.lower().replace('_',' ')
 if any(k in s for k in ['causes','prevents','treats','therapeutic']): return 1.0
 if any(k in s for k in ['regulates','activity','abundance','inhibits','stimulates','affects']): return .88
 if any(k in s for k in ['participates','produces','has output','capable of','precedes']): return .72
 if any(k in s for k in ['occurs in','located in','location of','correlated','associated']): return .52
 return .62

def graph_score(v,r): return .82*rel_quality(r)+.18*(1-math.log1p(G.in_degree(v)+G.out_degree(v))/MAXLOG)
def bridge_score(nodes,conf):
 if not conf:return 0.
 reached=list(dict.fromkeys(n for n in nodes if n in conf))
 if not reached:return 0.
 cov=len(reached)/len(conf); mc=np.mean([conf[n] for n in reached]); cur=conf.get(nodes[-1],0.); recent=sum(n in conf for n in nodes[-2:])/2
 sat=.65 if len(reached)<=1 else (.85 if len(reached)==2 else 1.)
 return min(1.,(.45*cov+.25*mc+.15*cur+.15*recent)*sat)
def search(source,target,bridge_conf=None,gate=0.,beam=2,max_hops=8,node_budget=14,edge_budget=20):
 bridge_conf=bridge_conf or {}; states=[(0.,(source,),(),())]; generated={source}; expanded=0; best=None
 for _ in range(max_hops):
  nxt=[]
  for _,pn,pr,pg in states:
   for v,r in OUT.get(pn[-1],[]):
    if expanded>=edge_budget:break
    expanded+=1
    if v in pn:continue
    if v not in generated and len(generated)>=node_budget:continue
    generated.add(v); nn=pn+(v,); rr=pr+(r,); gg=pg+(graph_score(v,r),)
    gs=float(np.mean(gg)); bs=bridge_score(nn,bridge_conf); score=(1-gate)*gs+gate*bs-.012*len(rr); st=(score,nn,rr,gg); nxt.append(st)
    if v==target and (best is None or score>best[0]):best=st
   if expanded>=edge_budget:break
  if best is not None:break
  if not nxt:break
  nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True); states=nxt[:beam]
 z=best if best is not None else (max(states,key=lambda x:x[0]) if states else (0,(source,),(),()))
 return {'found':z[1][-1]==target,'nodes':list(z[1]),'edges':[(z[1][i],z[1][i+1],z[2][i]) for i in range(len(z[2]))],'visited_nodes':len(generated),'expanded_edges':expanded}

def graph_only(source,target): return search(source,target,{},0.)
def fixed_bridge(source,target,bridges,alpha=.30): return search(source,target,bridges,alpha)
def ours(source,target,bridges,p_reliable,gmax=.45,gamma=1.0): return search(source,target,bridges,gmax*(float(p_reliable)**gamma))
