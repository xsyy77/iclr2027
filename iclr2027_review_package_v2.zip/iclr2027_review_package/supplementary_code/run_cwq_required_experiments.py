#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CWQ Stage I / Stage II / Stage III diagnostics that extend the existing
run_cwq_ours_samplefiles.py pipeline without adding a new experimental section.

This companion script keeps the same CWQ parser, candidate generator, bridge
model, query-level gate, dynamic graph search, dev-only tuning, and official
held-out test protocol from run_cwq_ours_samplefiles.py, then adds:

Stage I  (paper Sec. 5.3): complementary candidate-view ablation
  - Relation-semantic only
  - Neighborhood-semantic only
  - Structural only
  - Multi-view

Stage II (paper Sec. 5.4): reliability quality + downstream selection intervention
  - AUROC / AUPRC / Brier against held-out downstream-beneficial labels
  - Random / lexical-semantic / graph-structural / ours / oracle K=1 selection

Stage III (paper Sec. 5.5): adaptive guidance control
  - Graph Only
  - Fixed Guidance
  - Hard Gate
  - Continuous Gate
  - Oracle Gate upper bound

CWQ has no biomedical molecular/cellular/system ontology, so Stage I uses a
transparent dataset-specific realization of the SAME complementarity question:
relation-semantic, neighborhood-semantic, and structural candidate views.  No
biomedical labels are fabricated for Freebase entities.

Expected layout: put this file beside run_cwq_ours_samplefiles.py.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

import run_cwq_ours_samplefiles as cwq


def write_csv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def metric_utility(m):
    """CWQ analogue of downstream retrieval utility: prioritize exact top answer, then rank quality."""
    return 0.70*float(m["hits1"]) + 0.30*float(m["mrr"])


def eval_selected(rec, id2rel, selected, gate, args):
    ranked=cwq.rank_nodes(rec, id2rel, selected, float(gate), args.semantic_weight, args.max_steps)
    return cwq.metrics(ranked, rec["answers"])


def candidate_table(rec, bm, id2rel, args, fixed_gate):
    """Held-out candidate diagnostics. Gold answers are used ONLY to define evaluation labels/delta."""
    cand, feats, adj, deg = cwq.bridge_candidates(rec, id2rel, args.bridge_pool)
    if not cand:
        return [], adj, deg
    probs=bm.predict_proba(np.vstack([feats[n] for n in cand]))[:,1]

    base_m=eval_selected(rec, id2rel, (), 0.0, args)
    base_u=metric_utility(base_m)
    rows=[]
    for n,p in zip(cand,probs):
        one=[(n,1.0)]
        mm=eval_selected(rec, id2rel, one, fixed_gate, args)
        du=metric_utility(mm)-base_u
        f=feats[n]
        rows.append({
            "node":int(n),
            "p_bridge":float(p),
            "score_relation_sem":float(f[0]),
            "score_neighborhood_sem":float(f[1]),
            "score_structural":float(0.70*f[3] + 0.30*f[4]),
            "delta_utility":float(du),
            "beneficial":int(du>1e-12),
        })
    return rows, adj, deg


def choose_top(rows, key, k=1):
    if not rows:
        return []
    z=sorted(rows, key=lambda r:(-float(r[key]), int(r["node"])))[:k]
    return [int(x["node"]) for x in z]


def multi_view_nodes(rows, k):
    """Round-robin union across three non-gold candidate views; equal confidence later isolates representation."""
    if not rows:
        return []
    orders=[
        choose_top(rows,"score_relation_sem",len(rows)),
        choose_top(rows,"score_neighborhood_sem",len(rows)),
        choose_top(rows,"score_structural",len(rows)),
    ]
    out=[]
    for depth in range(max(map(len,orders))):
        for order in orders:
            if depth < len(order) and order[depth] not in out:
                out.append(order[depth])
                if len(out)>=k:
                    return out
    return out[:k]


def stage1(test, bm, id2rel, fixed_gate, seed, args, out):
    rows=[]
    for i,rec in enumerate(test,1):
        cr,_,_=candidate_table(rec,bm,id2rel,args,fixed_gate)
        variants={
            "Relation-semantic only": choose_top(cr,"score_relation_sem",args.bridge_k),
            "Neighborhood-semantic only": choose_top(cr,"score_neighborhood_sem",args.bridge_k),
            "Structural only": choose_top(cr,"score_structural",args.bridge_k),
            "Multi-view": multi_view_nodes(cr,args.bridge_k),
        }
        for name,nodes in variants.items():
            selected=[(n,1.0) for n in nodes]
            m=eval_selected(rec,id2rel,selected,fixed_gate,args)
            rows.append({"seed":seed,"qid":rec["qid"],"variant":name,
                         "n_bridges":len(nodes),"has_bridge":int(bool(nodes)),**m})
        if i%250==0:
            print(f"  Stage I {i}/{len(test)}",flush=True)

    write_csv(out/f"stage1_multiview_detailed_seed{seed}.csv",rows)
    summary=[]
    for name in sorted(set(r["variant"] for r in rows)):
        rr=[r for r in rows if r["variant"]==name]
        summary.append({"seed":seed,"variant":name,"n":len(rr),
                        "bridge_availability":float(np.mean([x["has_bridge"] for x in rr])),
                        "mean_bridges":float(np.mean([x["n_bridges"] for x in rr])),
                        "hits1":float(np.mean([x["hits1"] for x in rr])),
                        "hits5":float(np.mean([x["hits5"] for x in rr])),
                        "hits10":float(np.mean([x["hits10"] for x in rr])),
                        "mrr":float(np.mean([x["mrr"] for x in rr]))})
    write_csv(out/f"stage1_multiview_summary_seed{seed}.csv",summary)

    # Same post-hoc diagnostic as the biomedical experiment: Multi-view vs per-query best single view.
    singles=["Relation-semantic only","Neighborhood-semantic only","Structural only"]
    boot=[]; rng=np.random.default_rng(seed+51001); B=args.bootstrap
    byq=defaultdict(dict)
    for r in rows: byq[r["qid"]][r["variant"]]=r
    for metric in ("hits1","hits5","hits10","mrr"):
        dif=[]
        for q,d in byq.items():
            if "Multi-view" not in d or any(s not in d for s in singles):
                continue
            best=max(float(d[s][metric]) for s in singles)
            dif.append(float(d["Multi-view"][metric])-best)
        if dif:
            a=np.asarray(dif,float); ix=rng.integers(0,len(a),(B,len(a))); z=a[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
            boot.append({"seed":seed,"comparison":"Multi-view - per-query best single view","metric":metric,
                         "mean_diff":float(a.mean()),"ci95_low":float(lo),"ci95_high":float(hi),"B":B})
    write_csv(out/f"stage1_multiview_bootstrap_seed{seed}.csv",boot)
    return summary,boot


def stage2(test,bm,id2rel,fixed_gate,seed,args,out):
    cand_all=[]; inter=[]
    rng=np.random.default_rng(seed+52001)
    for i,rec in enumerate(test,1):
        cr,_,_=candidate_table(rec,bm,id2rel,args,fixed_gate)
        for r in cr:
            cand_all.append({"seed":seed,"qid":rec["qid"],**r})
        if not cr:
            continue

        choices={
            "Lexical-Semantic Selection": choose_top(cr,"score_relation_sem",1)[0],
            "Graph-Structural Selection": choose_top(cr,"score_structural",1)[0],
            "Ours Reliability Selection": choose_top(cr,"p_bridge",1)[0],
            "Oracle Selection": choose_top(cr,"delta_utility",1)[0],
        }
        for name,n in choices.items():
            m=eval_selected(rec,id2rel,[(n,1.0)],fixed_gate,args)
            inter.append({"seed":seed,"qid":rec["qid"],"method":name,"rep":0,**m})
        nodes=[int(x["node"]) for x in cr]
        for rep in range(args.random_reps):
            n=nodes[int(rng.integers(0,len(nodes)))]
            m=eval_selected(rec,id2rel,[(n,1.0)],fixed_gate,args)
            inter.append({"seed":seed,"qid":rec["qid"],"method":"Random Selection","rep":rep,**m})
        if i%250==0:
            print(f"  Stage II {i}/{len(test)}",flush=True)

    write_csv(out/f"stage2_candidate_diagnostics_seed{seed}.csv",cand_all)
    write_csv(out/f"stage2_selection_intervention_detailed_seed{seed}.csv",inter)

    # reliability quality against actual held-out downstream utility labels
    rank=[]
    if cand_all:
        y=np.array([x["beneficial"] for x in cand_all],int)
        for name,col in [
            ("Lexical similarity","score_relation_sem"),
            ("Graph heuristic","score_structural"),
            ("Ours","p_bridge"),
            ("Oracle utility","delta_utility"),
        ]:
            sc=np.array([x[col] for x in cand_all],float)
            auroc=roc_auc_score(y,sc) if len(np.unique(y))>1 else np.nan
            auprc=average_precision_score(y,sc) if len(np.unique(y))>1 else np.nan
            # Brier only meaningful for probability-like score; clip baselines to [0,1] for a descriptive calibration diagnostic.
            brier=brier_score_loss(y,np.clip(sc,0,1)) if len(y) else np.nan
            rank.append({"seed":seed,"method":name,"n":len(y),"positive_rate":float(y.mean()),
                         "auroc":float(auroc) if np.isfinite(auroc) else np.nan,
                         "auprc":float(auprc) if np.isfinite(auprc) else np.nan,
                         "brier":float(brier) if np.isfinite(brier) else np.nan})
    write_csv(out/f"stage2_ranking_metrics_seed{seed}.csv",rank)

    # Average random repetitions per query before aggregation.
    qagg=[]
    groups=defaultdict(list)
    for r in inter: groups[(r["qid"],r["method"])].append(r)
    for (qid,method),rr in groups.items():
        qagg.append({"seed":seed,"qid":qid,"method":method,
                     **{m:float(np.mean([x[m] for x in rr])) for m in ("hits1","hits5","hits10","mrr")}})
    write_csv(out/f"stage2_selection_intervention_per_query_seed{seed}.csv",qagg)

    summary=[]
    for method in sorted(set(x["method"] for x in qagg)):
        rr=[x for x in qagg if x["method"]==method]
        summary.append({"seed":seed,"method":method,"n":len(rr),
                        **{m:float(np.mean([x[m] for x in rr])) for m in ("hits1","hits5","hits10","mrr")}})
    write_csv(out/f"stage2_selection_intervention_summary_seed{seed}.csv",summary)

    boot=[]; B=args.bootstrap; brng=np.random.default_rng(seed+52002)
    ours={x["qid"]:x for x in qagg if x["method"]=="Ours Reliability Selection"}
    for base in ["Random Selection","Lexical-Semantic Selection","Graph-Structural Selection"]:
        bb={x["qid"]:x for x in qagg if x["method"]==base}; common=sorted(set(ours)&set(bb))
        for metric in ("hits1","hits5","hits10","mrr"):
            d=np.array([ours[q][metric]-bb[q][metric] for q in common],float)
            if not len(d): continue
            ix=brng.integers(0,len(d),(B,len(d))); z=d[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
            boot.append({"seed":seed,"comparison":f"Ours - {base}","metric":metric,
                         "mean_diff":float(d.mean()),"ci95_low":float(lo),"ci95_high":float(hi),"B":B})
    write_csv(out/f"stage2_selection_bootstrap_seed{seed}.csv",boot)
    return rank,summary,boot


def gate_probability(rec,bm,gm,id2rel,args):
    sel,adj,deg=cwq.select_bridges(rec,bm,id2rel,args)
    qf=cwq.query_features(rec,sel,deg)
    p=float(gm.predict_proba(qf.reshape(1,-1))[0,1])
    return sel,p


def tune_hard_gate(dev,bm,gm,id2rel,args,out,seed):
    rows=[]
    cached=[]
    for rec in dev:
        sel,p=gate_probability(rec,bm,gm,id2rel,args)
        cached.append((rec,sel,p))
    for gon in args.hard_on_grid:
        for tau in args.hard_tau_grid:
            vals=[]
            for rec,sel,p in cached:
                g=float(gon if p>=tau else 0.0)
                vals.append(eval_selected(rec,id2rel,sel,g,args))
            row={"seed":seed,"g_on":float(gon),"threshold":float(tau)}
            for met in ("hits1","hits5","hits10","mrr"):
                row[met]=float(np.mean([x[met] for x in vals]))
            row["utility"]=0.70*row["hits1"]+0.30*row["mrr"]
            rows.append(row)
    rows.sort(key=lambda r:(r["utility"],r["hits1"],r["mrr"]),reverse=True)
    write_csv(out/f"stage3_hard_gate_validation_grid_seed{seed}.csv",rows)
    best=rows[0]
    return float(best["g_on"]),float(best["threshold"])


def stage3(dev,test,bm,gm,id2rel,fixed_gate,gmax,gamma,seed,args,out):
    gon,tau=tune_hard_gate(dev,bm,gm,id2rel,args,out,seed)
    rows=[]
    agrid=args.oracle_grid
    for i,rec in enumerate(test,1):
        sel,p=gate_probability(rec,bm,gm,id2rel,args)
        cont=float(gmax*(p**gamma))
        hard=float(gon if p>=tau else 0.0)

        # Oracle is a held-out per-query upper bound only; it is never used by the learned controller.
        best=None
        for a in agrid:
            m=eval_selected(rec,id2rel,sel,float(a),args)
            u=metric_utility(m)
            if best is None or (u,m["hits1"],m["mrr"],-float(a)) > (best[0],best[2]["hits1"],best[2]["mrr"],-best[1]):
                best=(u,float(a),m)
        methods={
            "Graph Only": ((),0.0),
            "Fixed Guidance": (sel,float(fixed_gate)),
            "Hard Gate": (sel,hard),
            "Continuous Gate": (sel,cont),
            "Oracle Gate": (sel,float(best[1])),
        }
        for name,(ss,g) in methods.items():
            m=eval_selected(rec,id2rel,ss,g,args)
            rows.append({"seed":seed,"qid":rec["qid"],"method":name,"p_reliable":p,"gate":g,**m})
        if i%250==0:
            print(f"  Stage III {i}/{len(test)}",flush=True)

    write_csv(out/f"stage3_gate_comparison_detailed_seed{seed}.csv",rows)
    summary=[]
    for method in sorted(set(r["method"] for r in rows)):
        rr=[r for r in rows if r["method"]==method]
        summary.append({"seed":seed,"method":method,"n":len(rr),
                        "mean_gate":float(np.mean([x["gate"] for x in rr])),
                        **{m:float(np.mean([x[m] for x in rr])) for m in ("hits1","hits5","hits10","mrr")}})
    write_csv(out/f"stage3_gate_comparison_overall_seed{seed}.csv",summary)

    boot=[]; B=args.bootstrap; brng=np.random.default_rng(seed+53001)
    cont={r["qid"]:r for r in rows if r["method"]=="Continuous Gate"}
    for base in ("Fixed Guidance","Hard Gate"):
        bb={r["qid"]:r for r in rows if r["method"]==base}; common=sorted(set(cont)&set(bb))
        for metric in ("hits1","hits5","hits10","mrr"):
            d=np.array([cont[q][metric]-bb[q][metric] for q in common],float)
            ix=brng.integers(0,len(d),(B,len(d))); z=d[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
            boot.append({"seed":seed,"comparison":f"Continuous - {base}","metric":metric,
                         "mean_diff":float(d.mean()),"ci95_low":float(lo),"ci95_high":float(hi),"B":B})
    write_csv(out/f"stage3_gate_bootstrap_seed{seed}.csv",boot)
    return {"g_on":gon,"threshold":tau,"gmax":float(gmax),"gamma":float(gamma)},summary,boot


def aggregate_seed_summaries(rows,group_key,metrics):
    out=[]
    for key in sorted(set(r[group_key] for r in rows)):
        rr=[r for r in rows if r[group_key]==key]
        z={group_key:key,"seeds":len(set(r["seed"] for r in rr))}
        for metric in metrics:
            a=np.array([r[metric] for r in rr],float)
            z[metric+"_mean"]=float(a.mean())
            z[metric+"_std"]=float(a.std(ddof=1)) if len(a)>1 else 0.0
        out.append(z)
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--out",default="cwq_required_experiments")
    ap.add_argument("--seeds",nargs="+",type=int,default=[17,29,43])
    ap.add_argument("--train-files",nargs="*",default=None)
    ap.add_argument("--train-sample",type=int,default=5000)
    ap.add_argument("--dev-sample",type=int,default=1000)
    ap.add_argument("--bridge-pool",type=int,default=24)
    ap.add_argument("--bridge-k",type=int,default=3)
    ap.add_argument("--gate-train",type=float,default=.35)
    ap.add_argument("--semantic-weight",type=float,default=.55)
    ap.add_argument("--max-steps",type=int,default=3)
    ap.add_argument("--fixed-grid",nargs="+",type=float,default=[.15,.30,.45,.60])
    ap.add_argument("--gmax-grid",nargs="+",type=float,default=[.25,.40,.55,.70])
    ap.add_argument("--gamma-grid",nargs="+",type=float,default=[.5,1.0,2.0])
    ap.add_argument("--hard-on-grid",nargs="+",type=float,default=[.15,.30,.45,.60])
    ap.add_argument("--hard-tau-grid",nargs="+",type=float,default=[.10,.20,.30,.40,.50,.60,.70,.80,.90])
    ap.add_argument("--oracle-grid",nargs="+",type=float,default=[0,.05,.10,.15,.20,.25,.30,.35,.40,.45,.50,.55,.60,.65,.70])
    ap.add_argument("--random-reps",type=int,default=20)
    ap.add_argument("--bootstrap",type=int,default=3000)
    args=ap.parse_args()

    root=Path(args.root).expanduser().resolve(); data=cwq.locate(root)
    out=Path(args.out).expanduser().resolve(); out.mkdir(parents=True,exist_ok=True)
    if args.train_files is not None and len(args.train_files) not in (0,len(args.seeds)):
        raise ValueError("--train-files must provide exactly one file per seed")

    id2ent=cwq.load_lines(data/"entities.txt"); ent2id={x:i for i,x in enumerate(id2ent)}
    id2rel=cwq.load_lines(data/"relations.txt")
    print("Loading official dev/test...",flush=True)
    dev_full=cwq.read_records(data/"dev_simple.json",ent2id)
    test=cwq.read_records(data/"test_simple.json",ent2id)
    dev=dev_full if args.dev_sample==0 else dev_full[:min(args.dev_sample,len(dev_full))]
    print(f"Loaded dev={len(dev_full)}, test={len(test)}; tuning dev={len(dev)}",flush=True)

    s1all=[]; s2rankall=[]; s2sumall=[]; s3sumall=[]; params=[]
    for si,seed in enumerate(args.seeds):
        print(f"\n===== CWQ complete diagnostics seed={seed} =====",flush=True)
        if args.train_files:
            tf=Path(args.train_files[si]).expanduser().resolve()
            train=cwq.read_records(tf,ent2id)
        else:
            train=cwq.read_records(data/"train_simple.json",ent2id,args.train_sample,seed)
        print(f"  using train={len(train)}, dev={len(dev)}, test={len(test)}",flush=True)
        t0=time.time()
        bm,bs=cwq.train_bridge_model(train,id2rel,seed,args)
        gm,gs=cwq.train_gate(train,bm,id2rel,seed,args)
        fg,gx,ga,dev_fixed,dev_cont=cwq.tune(dev,bm,gm,id2rel,args)
        print(f"  frozen on dev: fixed={fg}, gmax={gx}, gamma={ga}",flush=True)

        s1,_=stage1(test,bm,id2rel,fg,seed,args,out); s1all.extend(s1)
        s2r,s2s,_=stage2(test,bm,id2rel,fg,seed,args,out); s2rankall.extend(s2r); s2sumall.extend(s2s)
        p,s3,_=stage3(dev,test,bm,gm,id2rel,fg,gx,ga,seed,args,out); s3sumall.extend(s3)
        params.append({"seed":seed,"train_n":len(train),"bridge_positive_rate":bs["positive_rate"],
                       "gate_positive_rate":gs["positive_rate"],"fixed_gate":fg,"gmax":gx,"gamma":ga,
                       "hard_g_on":p["g_on"],"hard_threshold":p["threshold"],
                       "dev_fixed_hits1":dev_fixed,"dev_continuous_hits1":dev_cont,"seconds":time.time()-t0})

    write_csv(out/"stage1_multiview_summary_all_seeds.csv",s1all)
    write_csv(out/"stage2_ranking_metrics_all_seeds.csv",s2rankall)
    write_csv(out/"stage2_selection_summary_all_seeds.csv",s2sumall)
    write_csv(out/"stage3_gate_summary_all_seeds.csv",s3sumall)
    write_csv(out/"selected_parameters_by_seed.csv",params)

    write_csv(out/"STAGE1_FINAL.csv",aggregate_seed_summaries(s1all,"variant",["hits1","hits5","hits10","mrr"]))
    write_csv(out/"STAGE2_SELECTION_FINAL.csv",aggregate_seed_summaries(s2sumall,"method",["hits1","hits5","hits10","mrr"]))
    write_csv(out/"STAGE3_FINAL.csv",aggregate_seed_summaries(s3sumall,"method",["hits1","hits5","hits10","mrr"]))

    cfg=vars(args).copy(); cfg.update({"data":str(data),"dev_available":len(dev_full),"dev_used":len(dev),"test":len(test),
        "stage1_views":["relation-semantic","neighborhood-semantic","structural","multi-view"],
        "note":"CWQ uses dataset-appropriate complementary graph/semantic views; no biomedical entity-type labels are fabricated."})
    (out/"config.json").write_text(json.dumps(cfg,indent=2),encoding="utf-8")
    print("\nDONE",flush=True); print("Results:",out,flush=True)


if __name__=="__main__":
    main()
