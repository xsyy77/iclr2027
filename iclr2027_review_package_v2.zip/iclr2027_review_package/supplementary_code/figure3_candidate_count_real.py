import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

RAW = {'Gene': {'Cellular': [3, 0, 0, 0, 1, 7, 6, 12, 0, 9, 8, 9, 8, 2, 0, 9, 0, 7, 7, 7, 0, 3, 11, 1, 2, 1, 1, 1, 1, 2, 0, 0, 1, 1, 2, 6, 7, 1, 1, 1, 4, 4, 3, 3, 0, 11, 1, 1, 1, 1, 1, 7, 7, 5, 7, 0, 6, 2, 19, 2, 20, 20, 0, 2, 2, 2, 0, 6, 3, 8, 3, 0, 1, 8, 2, 5, 5, 5, 0, 0, 0, 1, 6, 6, 1, 4, 6, 0, 1, 1, 0, 1, 0, 0, 2, 1, 8, 4, 3, 0, 5, 0, 0, 1, 2, 0, 4, 6, 0, 6, 0, 0, 3, 3, 3, 3, 2, 7, 2, 0, 18, 14, 14], 'Molecular': [20, 4, 2, 10, 8, 18, 45, 12, 3, 127, 100, 114, 100, 25, 1, 26, 1, 12, 12, 12, 2, 8, 56, 21, 20, 21, 21, 22, 21, 20, 3, 5, 6, 3, 5, 58, 62, 13, 22, 18, 8, 8, 7, 6, 3, 9, 3, 24, 24, 24, 23, 55, 54, 29, 54, 8, 56, 13, 257, 6, 285, 285, 3, 29, 26, 10, 2, 23, 25, 119, 12, 2, 8, 71, 14, 10, 10, 10, 6, 6, 1, 10, 33, 30, 6, 9, 10, 0, 5, 12, 1, 1, 2, 1, 6, 16, 42, 42, 26, 1, 67, 3, 8, 10, 35, 1, 36, 62, 6, 13, 3, 2, 14, 14, 2, 2, 1, 68, 13, 2, 72, 24, 24], 'System': [25, 7, 1, 8, 6, 68, 47, 41, 5, 64, 51, 66, 51, 30, 4, 45, 10, 39, 39, 39, 14, 11, 74, 33, 30, 30, 30, 32, 32, 30, 4, 8, 15, 10, 11, 71, 78, 15, 16, 16, 6, 6, 7, 6, 1, 25, 3, 19, 19, 19, 16, 49, 49, 34, 50, 14, 70, 18, 123, 17, 137, 137, 5, 22, 32, 11, 14, 34, 28, 58, 17, 16, 9, 85, 16, 19, 19, 19, 6, 6, 9, 11, 43, 39, 13, 12, 17, 3, 8, 12, 1, 0, 3, 10, 9, 13, 55, 42, 32, 6, 81, 0, 15, 12, 22, 4, 36, 73, 3, 37, 3, 2, 20, 21, 12, 12, 7, 90, 25, 3, 87, 33, 33], 'Multi-view': [48, 11, 3, 18, 15, 93, 98, 65, 8, 200, 159, 189, 159, 57, 5, 80, 11, 58, 58, 58, 16, 22, 141, 55, 52, 52, 52, 55, 54, 52, 7, 13, 22, 14, 18, 135, 147, 29, 39, 35, 18, 18, 17, 15, 4, 45, 7, 44, 44, 44, 40, 111, 110, 68, 111, 22, 132, 33, 399, 25, 442, 442, 8, 53, 60, 23, 16, 63, 56, 185, 32, 18, 18, 164, 32, 34, 34, 34, 12, 12, 10, 22, 82, 75, 20, 25, 33, 3, 14, 25, 2, 2, 5, 11, 17, 30, 105, 88, 61, 7, 153, 3, 23, 23, 59, 5, 76, 141, 9, 56, 6, 4, 37, 38, 17, 17, 10, 165, 40, 5, 177, 71, 71]}, 'Metabolite': {'Cellular': [6, 1, 4, 6, 3, 1, 1, 3, 4, 6, 1, 2, 0, 3, 2, 0, 0, 1, 1, 1, 0], 'Molecular': [8, 21, 6, 87, 4, 26, 16, 22, 23, 31, 24, 2, 1, 14, 14, 2, 3, 21, 8, 1, 3], 'System': [24, 30, 20, 87, 9, 16, 13, 43, 40, 40, 19, 6, 2, 20, 16, 5, 10, 30, 6, 6, 4], 'Multi-view': [38, 52, 30, 180, 16, 43, 30, 68, 67, 77, 44, 10, 3, 37, 32, 7, 13, 52, 15, 8, 7]}, 'Process': {'Cellular': [2, 1, 9, 6, 7, 1, 6, 0, 0, 4, 14, 11, 0, 2, 0, 1, 8, 0, 1, 3, 1, 13, 1, 0, 6, 0, 9, 0, 7, 4, 20, 2, 0, 0, 1, 2, 7, 6, 13, 12, 1, 1, 1, 16, 0, 0, 7, 0, 4, 0, 0, 7, 0, 0, 0, 5, 0, 2, 0, 6, 12, 15, 4, 2, 2, 0, 13, 0, 4, 0, 1, 14, 6, 1, 4, 5, 0, 5, 6, 1, 1, 5, 9, 18, 2, 2, 2, 6, 0, 3, 8, 2, 2, 14, 0, 4, 4, 0, 6, 0, 1, 1, 0, 6], 'Molecular': [6, 3, 93, 6, 14, 18, 45, 10, 4, 4, 26, 56, 4, 32, 1, 5, 101, 6, 10, 12, 13, 70, 1, 1, 54, 1, 43, 2, 168, 11, 285, 4, 19, 1, 24, 35, 12, 26, 13, 25, 24, 8, 24, 27, 2, 2, 57, 2, 48, 1, 6, 57, 0, 2, 2, 5, 2, 3, 6, 5, 62, 63, 8, 25, 21, 1, 91, 3, 9, 1, 21, 89, 18, 2, 2, 3, 2, 4, 5, 1, 5, 8, 114, 179, 7, 7, 7, 12, 3, 2, 56, 1, 6, 61, 27, 30, 28, 27, 32, 27, 28, 1, 2, 4], 'System': [1, 8, 101, 34, 39, 16, 47, 8, 7, 18, 41, 74, 12, 37, 1, 15, 51, 3, 12, 45, 16, 93, 9, 4, 63, 6, 46, 2, 21, 24, 137, 10, 19, 6, 19, 22, 39, 44, 50, 52, 19, 17, 19, 44, 2, 2, 74, 7, 40, 6, 5, 72, 3, 5, 3, 27, 2, 14, 12, 27, 103, 100, 6, 30, 24, 4, 97, 0, 12, 9, 13, 100, 23, 6, 20, 15, 7, 15, 26, 6, 15, 26, 66, 109, 9, 3, 5, 20, 12, 9, 73, 3, 5, 99, 2, 17, 18, 2, 34, 2, 5, 8, 8, 30], 'Multi-view': [9, 12, 203, 46, 60, 35, 98, 18, 11, 26, 81, 141, 16, 71, 2, 21, 160, 9, 23, 60, 30, 176, 11, 5, 123, 7, 98, 4, 196, 39, 442, 16, 38, 7, 44, 59, 58, 76, 76, 89, 44, 26, 44, 87, 4, 4, 138, 9, 92, 7, 11, 136, 3, 7, 5, 37, 4, 19, 18, 38, 177, 178, 18, 57, 47, 5, 201, 3, 25, 10, 35, 203, 47, 9, 26, 23, 9, 24, 37, 8, 21, 39, 189, 306, 18, 12, 14, 38, 15, 14, 137, 6, 13, 174, 29, 51, 50, 29, 72, 29, 34, 10, 10, 40]}}
COLORS = {'Multi-view': '#078B8C', 'System': '#1477C9', 'Molecular': '#C85A0A', 'Cellular': '#D82268'}
ORDER = ['Multi-view', 'System', 'Molecular', 'Cellular']

plt.rcParams.update({
    "font.family":"serif",
    "font.serif":["Times New Roman","Times","DejaVu Serif"],
    "font.size":11,"axes.titlesize":18,"axes.labelsize":14,
    "xtick.labelsize":10.5,"ytick.labelsize":10.5,
    "axes.linewidth":0.8,"pdf.fonttype":42,"ps.fonttype":42,
})

xmin,xmax=0.0,np.log10(443)
bins=np.linspace(xmin,xmax,25)
binw=bins[1]-bins[0]
xgrid=np.linspace(xmin,xmax,600)

maxy=0
for task in RAW:
    for method in ORDER:
        z=np.log10(np.asarray(RAW[task][method],float)+1.0)
        counts,_=np.histogram(z,bins=bins)
        maxy=max(maxy,counts.max())
        if len(np.unique(z))>1:
            y=gaussian_kde(z)(xgrid)*len(z)*binw
            maxy=max(maxy,y.max())
ylim=int(np.ceil(maxy/5)*5)

fig,axes=plt.subplots(1,3,figsize=(15.8,5.7),sharey=True)
for ax,task in zip(axes,["Gene","Metabolite","Process"]):
    for method in ["Cellular","Molecular","System","Multi-view"]:
        raw=np.asarray(RAW[task][method],float)
        z=np.log10(raw+1.0)
        c=COLORS[method]
        ax.hist(z,bins=bins,histtype="bar",facecolor="none",
                edgecolor=c,linewidth=0.8,alpha=0.28)
        if len(np.unique(z))>1:
            kde=gaussian_kde(z,bw_method=0.33)
            y=kde(xgrid)*len(z)*binw
            ax.plot(xgrid,y,color=c,linewidth=2.25)
    y0=ylim-0.9
    dy=ylim*0.087
    for i,method in enumerate(ORDER):
        raw=np.asarray(RAW[task][method],float)
        mean=raw.mean()
        avail=(raw>=3).mean()*100
        ax.text(0.04,y0-i*dy,f"{method}  {mean:.1f}  ({avail:.1f}% ≥3)",
                color=COLORS[method],fontsize=11.6,va="top")
    ax.set_title(task,pad=7)
    ax.set_xlim(xmin,xmax); ax.set_ylim(0,ylim)
    ax.set_xlabel("Candidate count per query"); ax.set_ylabel("Frequency")
    raw_ticks=[0,1,3,10,30,100,300]
    ax.set_xticks([np.log10(v+1) for v in raw_ticks])
    ax.set_xticklabels([str(v) for v in raw_ticks])
    ax.tick_params(axis="both",which="both",direction="in",top=True,right=True,length=4)
    ax.minorticks_on(); ax.tick_params(which="minor",length=2)
    ax.text(0.98,0.98,f"n={len(RAW[task]['Multi-view'])}",
            transform=ax.transAxes,ha="right",va="top",fontsize=9.3,color="#555555")

fig.subplots_adjust(left=0.06,right=0.99,top=0.90,bottom=0.15,wspace=0.16)
plt.savefig("figure3_candidate_count_real.png",dpi=300,bbox_inches="tight",facecolor="white")
plt.savefig("figure3_candidate_count_real.pdf",bbox_inches="tight",facecolor="white")
plt.show()
