import csv, json, math
from collections import defaultdict
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'data/processed/drugmechdb'
OUT=Path(__file__).resolve().parent
records=json.loads((ROOT/'data/raw/drugmechdb/indication_paths.json').read_text())
out=defaultdict(list); grouped_out=defaultdict(dict); edges_seen=defaultdict(set); indeg=defaultdict(int); outdeg=defaultdict(int); gold={}
for rec in records:
 rid=str(rec.get('graph',{}).get('_id',''))
 links=[]
 for e in rec.get('links',[]):
  u,v,r=str(e['source']),str(e['target']),str(e.get('key','unknown'))
  if (v,r) not in edges_seen[u]:
   grouped_out[u].setdefault(v,[]).append(r);edges_seen[u].add((v,r))
  indeg[v]+=1;outdeg[u]+=1;links.append((u,v,r))
 if rid:gold[rid]=set(links)
for u,neighbors in grouped_out.items():
 for v,rels in neighbors.items():
  out[u].extend((v,r) for r in rels)
maxlog=max(math.log1p(indeg[n]+outdeg[n]) for n in set(indeg)|set(outdeg))

def rq(rel):
 s=rel.lower().replace('_',' ')
 for words,val in [(['causes','prevents','treats','therapeutic'],1.),(['regulates','activity','abundance','inhibits','stimulates','affects'],.88),(['participates','produces','has output','capable of','precedes'],.72),(['occurs in','located in','location of','correlated','associated'],.52)]:
  if any(k in s for k in words):return val
 return .62

def search(row,conf,gate,p):
 beam=[(0.,(row.source,),(),())];generated={row.source};expanded=0;best=None
 for hop in range(8):
  nxt=[]
  for _,pn,pr,pg in beam:
   for v,rel in out.get(pn[-1],[]):
    if expanded>=20:break
    expanded+=1
    if v in pn:continue
    if v not in generated and len(generated)>=14:continue
    generated.add(v);nn=pn+(v,);rr=pr+(rel,)
    deg=math.log1p(indeg[v]+outdeg[v])/maxlog
    gg=pg+(p['a']*rq(rel)+(1-p['a'])*(1-deg),)
    gs=sum(gg)/len(gg)
    bs=0.
    if conf:
     reached=[n for n in nn if n in conf]
     if reached:
      uniq=list(dict.fromkeys(reached));cov=len(uniq)/len(conf)
      mean=sum(conf[n] for n in uniq)/len(uniq)
      cur=conf.get(nn[-1],0.)
      recent=sum(n in conf for n in nn[-2:])/2
      sat=(p['sat1'] if len(uniq)<=1 else p['sat2'] if len(uniq)==2 else 1.)
      bs=min(1.,max(0.,sum(w*x for w,x in zip(p['w'],(cov,mean,cur,recent)))*sat))
    score=(1-gate)*gs+gate*bs-p['length']*len(rr)
    st=(score,nn,rr,gg);nxt.append(st)
    if v==row.target and (best is None or score>best[0]):best=st
   if expanded>=20:break
  if best is not None or not nxt:break
  nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True);beam=nxt[:2]
 if best is None:best=max(beam,key=lambda x:x[0]) if beam else (0.,(row.source,),(),())
 _,pn,rr,_=best
 retrieved={(pn[i],pn[i+1],rr[i]) for i in range(len(rr))}
 ge=gold[row.rid]
 return int(pn[-1]==row.target),len(ge&retrieved)/max(1,len(ge)),int(str(row.answer) in pn), tuple(zip(pn[:-1],pn[1:],rr))

manifest=pd.read_csv(DATA/'benchmark_manifest.csv');man={(r.task,r.rid):r for r in manifest.itertuples(index=False)}
cand=pd.read_csv(DATA/'semantic_bridge_predictions.csv');cand=cand[(cand.split.isin(['val','test']))&(cand.condition=='Clean')]
gates=pd.read_csv(DATA/'semantic_gate_predictions.csv');gates=gates[(gates.split.isin(['val','test']))&(gates.condition=='Clean')]
gate_map={(r.task,r.rid,r.split):float(r.p_semantic_gate) for r in gates.itertuples(index=False)}
items=[]
for (task,rid,split,condition),d in cand.groupby(['task','rid','split','condition'],sort=False):
 row=man[(task,rid)];conf={str(k):float(v) for k,v in d.groupby('node').pred_semantic_conf.max().items()}
 gate=.5*gate_map[(task,rid,split)]**.5
 items.append((split,row,conf,gate))
base=dict(a=.82,w=[.45,.25,.15,.15],sat1=.65,sat2=.85,length=.012)

from collections import Counter
import time
start= time.time()
configs=[('baseline',base)]
for a in [0.,.4,.6,.7,.8,.819,.81,.83,.9,1.]:
 configs.append((f'relation={a:g}',{**base,'a':a}))
for k in [0.,.025,.05,.1,.2]:
 configs.append((f'length={k:g}',{**base,'length':k}))
for x in [0.,.25,.5,.85,1.]:
 configs.append((f'saturation1={x:g}',{**base,'sat1':x}))
for x in [0.,.25,.5,.65,1.]:
 configs.append((f'saturation2={x:g}',{**base,'sat2':x}))
for j,label in enumerate(['coverage','mean','current','recent']):
 ww=[0.]*4;ww[j]=1.
 configs.append((f'{label}-only',{**base,'w':ww}))
 ww=base['w'][:];v=ww[j];ww[j]=0.;ww=[z/(1-v) for z in ww]
 configs.append((f'{label}-removed',{**base,'w':ww}))
rows=[]
for split in ['val','test']:
 data=[(row,conf,gate) for sp,row,conf,gate in items if sp==split]
 baseline=[search(row,conf,gate,base) for row,conf,gate in data]
 for label,p in configs:
  vals=[search(row,conf,gate,p) for row,conf,gate in data]
  n=len(vals)
  ps=sum(x[0] for x in vals)/n
  er=sum(x[1] for x in vals)/n
  path_changed=sum(x[3]!=b[3] for x,b in zip(vals,baseline))
  ps_changed=sum(x[0]!=b[0] for x,b in zip(vals,baseline))
  er_changed=sum(abs(x[1]-b[1])>1e-12 for x,b in zip(vals,baseline))
  rows.append(dict(split=split,configuration=label,n=n,path_success=ps,edge_recall=er,path_changed=path_changed,ps_changed=ps_changed,er_changed=er_changed))
  print(split,label,round(ps*100,3),round(er*100,3),path_changed,ps_changed,er_changed,flush=True)
with (OUT/'dmdb_parameter_stress_test.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print('elapsed',time.time()-start)
