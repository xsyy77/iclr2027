from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score

ROOT = Path(__file__).resolve().parent
D = ROOT / 'data'

def close(a,b,tol=5e-5):
    return abs(float(a)-float(b)) <= tol

def check(label, got, exp, tol=5e-5):
    ok = close(got, exp, tol)
    print(f"{'PASS' if ok else 'FAIL'}  {label}: got={float(got):.8f}, expected={float(exp):.8f}")
    return ok

oks=[]

# Table 1 / DrugMechDB Clean condition
m = pd.read_csv(D/'main_results_current.csv')
d = m[(m.dataset=='DrugMechDB') & (m.setting=='Clean')].set_index('Method')
expected = {
    'Graph Only': (0.2701612903,0.3396867505,0.7056451613),
    'Fixed Bridge': (0.3911290323,0.5855875714,0.9153225806),
    'Confidence + Fixed': (0.3951612903,0.5894182165,0.9112903226),
    'Ours': (0.3951612903,0.5945929477,0.9193548387),
}
for method,(ps,er,ah) in expected.items():
    oks += [check(f'Table1 {method} PS', d.loc[method,'PathSuccess'], ps),
            check(f'Table1 {method} ER', d.loc[method,'EdgeRecall'], er),
            check(f'Table1 {method} AH', d.loc[method,'AnswerHit'], ah)]

# Stage-II retrieval-aware reliability metrics
p = pd.read_csv(D/'semantic_bridge_predictions.csv')
for label,mask,exp_roc,exp_pr in [
    ('StageII all test', p['split'].eq('test'), 0.7950107329593756, 0.3931014791600214),
    ('StageII clean test', p['split'].eq('test') & p['condition'].eq('Clean'), 0.8151618299002233, 0.6546809430883751),
]:
    ss=p.loc[mask]
    y=ss['beneficial'].astype(int).to_numpy()
    q=ss['pred_semantic_conf'].astype(float).to_numpy()
    oks += [check(label+' AUROC',roc_auc_score(y,q),exp_roc),check(label+' AUPRC',average_precision_score(y,q),exp_pr)]

# Stage-III table values
s3=pd.read_csv(D/'stage3_controls_summary.csv').set_index('method')
for method,er,u,g in [
    ('Graph Only',0.3396867504783464,0.2910189283693103,0.0),
    ('Best Global alpha',0.3635320583962349,0.3151080046156446,0.05),
    ('Mean-matched Constant alpha',0.3728734562456973,0.3179104239704833,0.1140266187987371),
    ('Full',0.3805347465682779,0.3286765530027414,0.1091746267403836),
]:
    oks += [check(f'StageIII {method} ER',s3.loc[method,'edge_recall'],er),
            check(f'StageIII {method} utility',s3.loc[method,'utility'],u),
            check(f'StageIII {method} gate',s3.loc[method,'mean_gate'],g)]

sh=pd.read_csv(D/'stage3_full_vs_shuffled.csv').set_index('metric')
oks += [check('StageIII shuffled ER mean',sh.loc['edge_recall','shuffled_mean'],0.3717763870603615),
        check('StageIII Full>shuffle ER fraction',sh.loc['edge_recall','fraction_full_gt_shuffle'],0.976),
        check('StageIII shuffled utility mean',sh.loc['utility','shuffled_mean'],0.3198224323676117),
        check('StageIII Full>shuffle utility fraction',sh.loc['utility','fraction_full_gt_shuffle'],0.96)]

# Stage-II utility-weight robustness: every row should retain same AUROC/AUPRC within subset
sens=pd.read_csv(D/'stage2_utility_weight_sensitivity.csv')
for subset,grp in sens.groupby('Subset'):
    oks.append(grp['AUROC'].nunique()==1 and grp['AUPRC'].nunique()==1 and grp['Positive rate (%)'].nunique()==1)
    print(f"{'PASS' if oks[-1] else 'FAIL'}  StageII utility-weight stability: {subset}")

print('\nSUMMARY:',sum(oks),'/',len(oks),'checks passed')
if not all(oks):
    raise SystemExit(1)
