"""Verify that adding the reconstructed selector cannot change reported DMDB eval pools.

Usage:
  python paper_checks/verify_bridge_selection.py /path/to/semantic_bridge_predictions.csv

The submitted paper describes a finite Bridge budget. The recovered evaluation
artifact contains at most three unique grounded Bridges per validation/test
query-condition. Therefore, with the recovered K=3 convention used in the
Stage-I matched-budget diagnostics and EpiKG selector, selection is set-preserving
for every reported DrugMechDB validation/test evaluation instance.
"""
from __future__ import annotations

import sys
from pathlib import Path
import pandas as pd

BUDGET = 3
KEYS = ["task", "rid", "split", "condition"]


def main(path: str) -> None:
    df = pd.read_csv(path)
    missing = [c for c in KEYS + ["node"] if c not in df.columns]
    if missing:
        raise SystemExit(f"Missing required columns: {missing}")

    counts = df.groupby(KEYS)["node"].nunique().rename("n_unique")
    ev = counts[counts.index.get_level_values("split").isin(["val", "test"])]
    offenders = ev[ev > BUDGET]

    print(f"Validation/test groups: {len(ev)}")
    print(f"Max unique Bridges: {int(ev.max())}")
    print("Count distribution:")
    print(ev.value_counts().sort_index().to_string())

    if len(offenders):
        print("\nFAIL: reconstructed K=3 selector would truncate reported evaluation pools:")
        print(offenders.to_string())
        raise SystemExit(1)

    train = counts[counts.index.get_level_values("split") == "train"]
    train_over = train[train > BUDGET]
    print(f"\nTrain-only groups above K=3: {len(train_over)}")
    if len(train_over):
        print("NOTE: these are training-only and this verification does NOT claim that the\n"
              "reconstructed selector is the historical source used to create archived\n"
              "query-gate training artifacts. Keep the reconstructed file provenance-labeled.")

    print("\nPASS: K=3 selection is set-preserving for every archived validation/test group.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_bridge_selection.py semantic_bridge_predictions.csv")
    main(sys.argv[1])
