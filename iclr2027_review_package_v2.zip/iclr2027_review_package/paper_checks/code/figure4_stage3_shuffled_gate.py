from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from matplotlib.lines import Line2D
from matplotlib.patches import Patch


# =========================================================
# 0. STYLE
# =========================================================
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 7,
    "axes.labelsize": 8,
    "xtick.labelsize": 7,
    "ytick.labelsize": 7,
    "legend.fontsize": 5.4,
})


# =========================================================
# 1. PATH
# =========================================================
BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "stage3_shuffled_gate_repetitions.csv"


# =========================================================
# 2. READ CSV
# =========================================================
df = pd.read_csv(CSV_PATH)

if "edge_recall" not in df.columns or "utility" not in df.columns:
    print("Current CSV columns:", list(df.columns))
    raise ValueError(
        "CSV must contain columns named 'edge_recall' and 'utility'."
    )

edge_vals = df["edge_recall"].dropna().astype(float).values
utility_vals = df["utility"].dropna().astype(float).values


# =========================================================
# 3. VERIFIED FULL MODEL VALUES
# =========================================================
full_edge = 0.3805347465682779
full_utility = 0.3286765530027414

mean_edge = edge_vals.mean()
mean_utility = utility_vals.mean()

diff_edge = full_edge - mean_edge
diff_utility = full_utility - mean_utility


# =========================================================
# 4. KDE
# =========================================================
xmin = min(
    edge_vals.min(),
    utility_vals.min(),
    full_edge,
    full_utility
) - 0.008

xmax = max(
    edge_vals.max(),
    utility_vals.max(),
    full_edge,
    full_utility
) + 0.008

x = np.linspace(xmin, xmax, 800)

edge_kde = gaussian_kde(edge_vals)
utility_kde = gaussian_kde(utility_vals)

edge_density = edge_kde(x)
utility_density = utility_kde(x)

# normalize independently
edge_density = edge_density / edge_density.max()
utility_density = utility_density / utility_density.max()


# =========================================================
# 5. COLORS
# =========================================================
# fills
ER_FILL = "#DDE6F2"
UT_FILL = "#EEDFE7"

# density outlines
ER_CURVE = "#8298B6"
UT_CURVE = "#B58CA2"

# four distinct reference-line colors
ER_MEAN = "#A7B9D3"
ER_FULL = "#536F9C"

UT_MEAN = "#D2AABD"
UT_FULL = "#A7607B"


# =========================================================
# 6. FIGURE
# =========================================================
fig, ax = plt.subplots(
    figsize=(3.35, 2.70),
    dpi=300
)


# =========================================================
# 7. DISTRIBUTIONS ON SAME X AXIS
# =========================================================
# Edge Recall
ax.fill_between(
    x,
    0,
    edge_density,
    color=ER_FILL,
    alpha=0.72,
    linewidth=0,
    zorder=1
)

ax.plot(
    x,
    edge_density,
    color=ER_CURVE,
    linewidth=1.2,
    zorder=3
)

# Utility
ax.fill_between(
    x,
    0,
    utility_density,
    color=UT_FILL,
    alpha=0.70,
    linewidth=0,
    zorder=1
)

ax.plot(
    x,
    utility_density,
    color=UT_CURVE,
    linewidth=1.2,
    zorder=3
)


# =========================================================
# 8. FOUR REFERENCE LINES
# =========================================================
# ER mean
ax.axvline(
    mean_edge,
    color=ER_MEAN,
    linestyle=(0, (4, 3)),
    linewidth=1.2,
    zorder=5
)

# ER full
ax.axvline(
    full_edge,
    color=ER_FULL,
    linestyle="-",
    linewidth=1.55,
    zorder=5
)

# Utility mean
ax.axvline(
    mean_utility,
    color=UT_MEAN,
    linestyle=(0, (4, 3)),
    linewidth=1.2,
    zorder=5
)

# Utility full
ax.axvline(
    full_utility,
    color=UT_FULL,
    linestyle="-",
    linewidth=1.55,
    zorder=5
)


# =========================================================
# 9. TWO-LINE LABELS
# =========================================================
# ---------------- ER ----------------
ax.text(
    mean_edge - 0.0020,
    1.00,
    f"ER mean\n{mean_edge:.4f}",
    color=ER_MEAN,
    ha="right",
    va="bottom",
    fontsize=5.2,
    linespacing=0.90
)

ax.text(
    full_edge + 0.0016,
    1.10,
    f"ER full\n{full_edge:.4f}",
    color=ER_FULL,
    ha="left",
    va="bottom",
    fontsize=5.2,
    fontweight="bold",
    linespacing=0.90
)

# ER diff
ax.text(
    (mean_edge + full_edge) / 2,
    1.17,
    f"+{diff_edge:.4f}",
    color=ER_CURVE,
    ha="center",
    va="bottom",
    fontsize=5.0
)


# ---------------- Utility ----------------
ax.text(
    mean_utility - 0.0020,
    0.72,
    f"Utility mean\n{mean_utility:.4f}",
    color=UT_MEAN,
    ha="right",
    va="bottom",
    fontsize=5.2,
    linespacing=0.90
)

ax.text(
    full_utility + 0.0016,
    0.84,
    f"Utility full\n{full_utility:.4f}",
    color=UT_FULL,
    ha="left",
    va="bottom",
    fontsize=5.2,
    fontweight="bold",
    linespacing=0.90
)

# Utility diff
ax.text(
    (mean_utility + full_utility) / 2,
    0.93,
    f"+{diff_utility:.4f}",
    color=UT_CURVE,
    ha="center",
    va="bottom",
    fontsize=5.0
)


# =========================================================
# 10. AXES
# =========================================================
ax.set_xlim(0.285, 0.395)
ax.set_ylim(0, 1.32)

ax.set_xlabel("Score")
ax.set_ylabel("Normalized density")

ax.set_yticks([0, 0.5, 1.0])
ax.set_yticklabels(["0", "0.5", "1.0"])

for spine in ["top", "right"]:
    ax.spines[spine].set_visible(False)

ax.spines["left"].set_linewidth(0.85)
ax.spines["bottom"].set_linewidth(0.85)

ax.tick_params(
    axis="x",
    width=0.8,
    length=3
)

ax.tick_params(
    axis="y",
    width=0.8,
    length=3
)


# =========================================================
# 11. SMALL LEGEND
# =========================================================
legend_handles = [
    Patch(
        facecolor=ER_FILL,
        edgecolor=ER_CURVE,
        linewidth=0.4,
        label="ER shuffled dist."
    ),

    Patch(
        facecolor=UT_FILL,
        edgecolor=UT_CURVE,
        linewidth=0.4,
        label="Utility shuffled dist."
    ),

    Line2D(
        [0], [0],
        color=ER_MEAN,
        lw=1.2,
        ls=(0, (4, 3)),
        label="ER shuffled mean"
    ),

    Line2D(
        [0], [0],
        color=UT_MEAN,
        lw=1.2,
        ls=(0, (4, 3)),
        label="Utility shuffled mean"
    ),

    Line2D(
        [0], [0],
        color=ER_FULL,
        lw=1.55,
        ls="-",
        label="ER full"
    ),

    Line2D(
        [0], [0],
        color=UT_FULL,
        lw=1.55,
        ls="-",
        label="Utility full"
    ),
]

ax.legend(
    handles=legend_handles,
    ncol=2,
    loc="lower center",
    bbox_to_anchor=(0.5, 1.01),
    frameon=False,
    columnspacing=0.75,
    handlelength=1.5,
    handletextpad=0.35,
    borderpad=0.1,
    labelspacing=0.25
)


# =========================================================
# 12. SAVE
# =========================================================
plt.tight_layout()

plt.savefig(
    BASE_DIR / "figure5_stage3_final.pdf",
    bbox_inches="tight"
)

plt.savefig(
    BASE_DIR / "figure5_stage3_final.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()