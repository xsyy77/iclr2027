import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D

# ============================================================
# Figure 3: Complementarity and coverage of multi-view
# mechanistic Bridges
#
# Reconstructed from the confirmed Stage-I results used in
# Section 5.3 of the current paper.
# ============================================================

# -----------------------------
# 1. Confirmed experimental data
# -----------------------------
# We keep only Molecular / System / Multi-view in the radar
# plots because the controlled Cellular values were not part of
# the confirmed controlled-result set used for the figure.

methods = ["Molecular", "System", "Multi-view"]

# Panel (a): Candidate coverage / controlled retrieval
# Order: K=3 Availability, Controlled PS, Controlled ER
panel_a = {
    "Molecular":  [81.05, 31.05, 43.53],
    "System":     [93.15, 34.68, 47.27],
    "Multi-view": [98.79, 39.11, 58.64],
}

# Panel (b): matched-budget + controlled retrieval
# Order: Matched ER, Matched PS, Controlled PS, Controlled ER
panel_b = {
    "Molecular":  [32.95, 26.17, 31.05, 43.53],
    "System":     [34.16, 29.91, 34.68, 47.27],
    "Multi-view": [34.87, 28.97, 39.11, 58.64],
}

# Panel (c): task-level matched-budget Edge Recall
# Columns: Cellular, Molecular, System, Multi-view
# Rows:    Gene, Metabolite, Process
task_er = np.array([
    [0.318, 0.325, 0.329, 0.325],  # Gene
    [0.145, 0.174, 0.180, 0.192],  # Metabolite
    [0.346, 0.363, 0.385, 0.406],  # Process
])

task_names = ["Gene", "Metabolite", "Process"]
view_names = ["Cellular", "Molecular", "System", "Multi-view"]

# -----------------------------
# 2. Paper style
# -----------------------------
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 8.5,
    "axes.titlesize": 8.5,
    "axes.labelsize": 8.0,
    "xtick.labelsize": 7.0,
    "ytick.labelsize": 7.0,
    "legend.fontsize": 7.3,
    "axes.linewidth": 0.65,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# Same pastel family used in the earlier Stage-I figure
COLORS = {
    "Molecular":  "#F1B9C8",
    "System":     "#F2BD9B",
    "Multi-view": "#C95E7D",
}

# -----------------------------
# 3. Helpers
# -----------------------------
def close_loop(values):
    values = list(values)
    return values + values[:1]

def setup_radar(ax, labels):
    n = len(labels)
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)

    # Start at top and go clockwise, matching the paper figure
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)

    ax.set_xticks(angles)
    ax.set_xticklabels(labels)

    ax.set_ylim(0, 100)
    ax.set_yticks([25, 50, 75, 100])
    ax.set_yticklabels(["25", "50", "75", "100"],
                       fontsize=6.3, color="#6A6A6A")
    ax.set_rlabel_position(0)

    ax.grid(color="#D9DFE8", linewidth=0.55, alpha=0.90)
    ax.spines["polar"].set_color("#D9DFE8")
    ax.spines["polar"].set_linewidth(0.6)

    return angles

# -----------------------------
# 4. Figure layout
# -----------------------------
fig = plt.figure(figsize=(10.6, 3.25))
gs = fig.add_gridspec(
    1, 3,
    width_ratios=[1.0, 1.0, 1.22],
    wspace=0.46
)

ax_a = fig.add_subplot(gs[0, 0], projection="polar")
ax_b = fig.add_subplot(gs[0, 1], projection="polar")
ax_c = fig.add_subplot(gs[0, 2])

# -----------------------------
# 5. Panel (a): radar
# -----------------------------
labels_a = ["K=3 Availability", "Controlled PS", "Controlled ER"]
angles_a = setup_radar(ax_a, labels_a)

for method in methods:
    vals = panel_a[method]
    ang = close_loop(angles_a)
    dat = close_loop(vals)

    ax_a.plot(
        ang, dat,
        color=COLORS[method],
        linewidth=1.7,
        marker="o",
        markersize=2.8,
        zorder=3,
    )
    ax_a.fill(
        ang, dat,
        color=COLORS[method],
        alpha=0.10,
        zorder=2,
    )

# -----------------------------
# 6. Panel (b): radar
# -----------------------------
labels_b = ["Matched ER", "Matched PS", "Controlled PS", "Controlled ER"]
angles_b = setup_radar(ax_b, labels_b)

for method in methods:
    vals = panel_b[method]
    ang = close_loop(angles_b)
    dat = close_loop(vals)

    ax_b.plot(
        ang, dat,
        color=COLORS[method],
        linewidth=1.7,
        marker="o",
        markersize=2.8,
        zorder=3,
    )
    ax_b.fill(
        ang, dat,
        color=COLORS[method],
        alpha=0.10,
        zorder=2,
    )

# -----------------------------
# 7. Panel (c): heatmap
# -----------------------------
cmap = LinearSegmentedColormap.from_list(
    "stage1_heatmap",
    ["#F2F5F1", "#DDE7E3", "#C9CEE1", "#B49CC9"],
)

im = ax_c.imshow(
    task_er,
    cmap=cmap,
    vmin=0.14,
    vmax=0.41,
    aspect="auto",
    interpolation="nearest",
)

ax_c.set_xticks(np.arange(len(view_names)))
ax_c.set_xticklabels(view_names)
ax_c.set_yticks(np.arange(len(task_names)))
ax_c.set_yticklabels(task_names)

ax_c.tick_params(axis="both", length=0, pad=5)

# white cell boundaries
ax_c.set_xticks(np.arange(-0.5, len(view_names), 1), minor=True)
ax_c.set_yticks(np.arange(-0.5, len(task_names), 1), minor=True)
ax_c.grid(which="minor", color="white", linewidth=1.0)
ax_c.tick_params(which="minor", bottom=False, left=False)

for spine in ax_c.spines.values():
    spine.set_visible(False)

# cell values
for i in range(task_er.shape[0]):
    for j in range(task_er.shape[1]):
        v = task_er[i, j]
        text_color = "white" if v >= 0.395 else "#26364A"
        ax_c.text(
            j, i, f"{v:.3f}",
            ha="center", va="center",
            fontsize=7.6,
            color=text_color,
        )

# compact horizontal colorbar
cbar = fig.colorbar(
    im,
    ax=ax_c,
    orientation="horizontal",
    fraction=0.075,
    pad=0.10,
    aspect=30,
)
cbar.set_label("Matched-budget Edge Recall", fontsize=7.0, labelpad=3)
cbar.set_ticks([0.15, 0.20, 0.25, 0.30, 0.35, 0.40])
cbar.ax.tick_params(labelsize=6.2, length=2)
cbar.outline.set_linewidth(0.5)
cbar.outline.set_edgecolor("#CFCFCF")

# -----------------------------
# 8. Shared legend at top
# -----------------------------
legend_handles = [
    Line2D(
        [0], [0],
        color=COLORS[m],
        marker="o",
        markersize=3.3,
        linewidth=1.7,
        label=m,
    )
    for m in methods
]

fig.legend(
    handles=legend_handles,
    loc="upper center",
    bbox_to_anchor=(0.43, 0.985),
    ncol=3,
    frameon=False,
    handlelength=1.5,
    handletextpad=0.4,
    columnspacing=1.5,
)

# -----------------------------
# 9. Panel labels / subtitles
# -----------------------------
# Put these below the plots, as in the current paper figure.
ax_a.text(
    0.50, -0.19,
    r"$\bf{a}$  Candidate coverage",
    transform=ax_a.transAxes,
    ha="center", va="top",
    fontsize=8.5,
    color="#344A68",
)

ax_b.text(
    0.50, -0.19,
    r"$\bf{b}$  Retrieval performance",
    transform=ax_b.transAxes,
    ha="center", va="top",
    fontsize=8.5,
    color="#344A68",
)

ax_c.text(
    0.50, -0.24,
    r"$\bf{c}$  View complementarity across tasks",
    transform=ax_c.transAxes,
    ha="center", va="top",
    fontsize=8.5,
    color="#344A68",
)

# -----------------------------
# 10. Final spacing / export
# -----------------------------
fig.subplots_adjust(
    left=0.035,
    right=0.985,
    top=0.79,
    bottom=0.27,
)

plt.savefig(
    "figure3_stage1_reconstructed.pdf",
    bbox_inches="tight",
    dpi=600,
)
plt.savefig(
    "figure3_stage1_reconstructed.png",
    bbox_inches="tight",
    dpi=600,
)

plt.show()
