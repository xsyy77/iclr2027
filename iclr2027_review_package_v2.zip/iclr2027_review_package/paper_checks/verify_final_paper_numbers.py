"""Numerically verify final-paper values that are supported by recovered artifacts."""
from pathlib import Path
import sys
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score

ROOT = Path(__file__).resolve().parents[1]
# Allow running after copying these two files into the existing review package.
DATA = ROOT / "data"


def chk(name, got, exp, tol=5e-5):
    ok = abs(float(got)-float(exp)) <= tol
    print(f"{'PASS' if ok else 'FAIL'} {name}: {float(got):.8f} vs {float(exp):.8f}")
    return ok

oks=[]
# Stage-II matched K=1 intervention (Table 2): all-condition rows, as in final paper.
s2 = pd.read_csv(DATA / "stage2_selection_intervention_summary.csv")
s2 = s2[s2["subset"].eq("All conditions")].set_index("method")
for method, vals in {
    "Lexical Selection": (0.2991935483870968,0.3818588994480335,0.7532258064516129),
    "Graph-Heuristic Selection": (0.2766129032258064,0.3614680702244369,0.7290322580645161),
    "Ours Reliability Selection": (0.2919354838709677,0.3992397936434439,0.7661290322580645),
}.items():
    ps,er,ah=vals
    oks += [chk(method+" PS",s2.loc[method,"path_success"],ps),
            chk(method+" ER",s2.loc[method,"edge_recall"],er),
            chk(method+" AH",s2.loc[method,"answer_hit"],ah)]

# Bootstrap provenance for Stage-II Edge Recall (not all printed in final paper, but verifies source).
b = pd.read_csv(DATA / "stage2_selection_bootstrap.csv")
for base, exp in {
    "Ours - Random Selection": (0.0289955365564448,0.0220908542357237,0.0360260748439096),
    "Ours - Lexical Selection": (0.0173808941954103,0.0093634894451426,0.025451365614672),
    "Ours - Graph-Heuristic Selection": (0.0377717234190069,0.028278030578646,0.0474608825491147),
}.items():
    row=b[(b["subset"]=="All conditions")&(b["comparison"]==base)&(b["metric"]=="edge_recall")].iloc[0]
    md,lo,hi=exp
    oks += [chk(base+" ER diff",row.mean_diff,md),chk(base+" ER CI low",row.ci95_low,lo),chk(base+" ER CI high",row.ci95_high,hi)]

print(f"\nSUMMARY {sum(oks)}/{len(oks)}")
if not all(oks):
    raise SystemExit(1)
