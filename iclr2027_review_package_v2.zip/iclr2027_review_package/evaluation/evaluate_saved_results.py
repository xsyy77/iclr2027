"""Evaluate the saved held-out result tables without rerunning retrieval."""
from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path(__file__).resolve().parents[1]
def summarize(path,method_col='method'):
 d=pd.read_csv(path); found='found' if 'found' in d else 'path_success'; out=[]
 for m,g in d.groupby(method_col):
  row={'method':m,'n':len(g),'path_success':g[found].mean()}
  for c in ['edge_recall','answer_hit','visited_nodes','expanded_edges','gate']:
   if c in g: row[c]=g[c].mean()
  out.append(row)
 return pd.DataFrame(out)
def paired_bootstrap(d,a,b,metric='found',B=5000,seed=20260910):
 keys=[x for x in ['task','rid','condition','qid'] if x in d.columns]
 A=d[d.method==a][keys+[metric]].rename(columns={metric:'a'}); C=d[d.method==b][keys+[metric]].rename(columns={metric:'b'}); m=A.merge(C,on=keys); diff=(m.a-m.b).to_numpy(float); rng=np.random.default_rng(seed); z=diff[rng.integers(0,len(diff),(B,len(diff)))].mean(1); return {'mean_diff':diff.mean(),'ci95_low':np.quantile(z,.025),'ci95_high':np.quantile(z,.975)}
if __name__=='__main__':
 dm=ROOT/'results/dmdb/final_continuous_test_detailed.csv'; ep=ROOT/'results/epikg/epikg_test_detailed.csv'
 print('DrugMechDB\n',summarize(dm).to_string(index=False)); print('\nEpiKG\n',summarize(ep).to_string(index=False))
