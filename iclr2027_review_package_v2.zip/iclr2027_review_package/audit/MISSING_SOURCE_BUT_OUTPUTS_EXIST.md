# Missing source, surviving evidence

These items were cross-checked separately. Their outputs / references survive, but the exact original Python source was not found in the available saved Library. They are therefore not reconstructed.

## Legacy dependencies

- `step1_build_graph.py` — imported by `step7_guided_search.py`.
- `step12_batch_experiment.py` — imported by `step15_bridge_noise_ablation.py`, `step16_bridge_alpha_sensitivity.py`, and `step17_difficulty_alpha_grid.py`.
- `step6_selected_bridges.json` — run-time input referenced by the legacy `step7` main; not a source file.

## Historical experiment steps with surviving outputs

### Step 23 — multi-seed study
Surviving outputs:
- `step23_multiseed_detailed_results.csv`
- `step23_multiseed_summary.csv`
- `step23_per_seed_summary.csv`
- `step23_paired_bootstrap_comparisons.csv`
- `step23_multiseed_report.json`

### Step 24 — alpha sensitivity
Surviving outputs:
- `step24_alpha_sensitivity_summary.csv`
- `step24_alpha_sensitivity_report.json`

### Step 25 — mixed difficulty
Surviving outputs:
- `step25_mixed_difficulty_detailed.csv`
- `step25_mixed_difficulty_summary.csv`
- `step25_mixed_difficulty_breakdown.csv`
- `step25_mixed_difficulty_bootstrap.csv`
- `step25_mixed_difficulty_report.json`

### Step 26 — global fixed alpha vs per-query oracle
Surviving outputs:
- `step26_global_vs_oracle_alpha_detailed.csv`
- `step26_validation_alpha_selection.csv`
- `step26_fixed_alpha_test_results.csv`
- `step26_oracle_alpha_test_results.csv`
- `step26_fixed_vs_oracle_paired.csv`
- `step26_condition_comparison.csv`
- `step26_difficulty_comparison.csv`
- `step26_oracle_alpha_distribution.csv`
- `step26_global_vs_oracle_alpha_report.json`

### Historical controller training (Step 27 / 28 lineage)
Surviving artifacts include controller/confidence training CSVs and trained model files referenced by `step30_train_continuous_gate.py`, but the exact source generator scripts were not recovered.

## Superseding current sources

The current paper's final controlled component experiments are available as exact source in `05_section5_rq2_rq3_rq4/new_required_experiments.py`, the DrugMechDB real-graph continuous controller in `04_current_dmdb_realgraph/final_continuous_realgraph.py`, and the independent EpiKG evaluation in `06_epikg_independent/epikg_independent_experiment_run.py`.
