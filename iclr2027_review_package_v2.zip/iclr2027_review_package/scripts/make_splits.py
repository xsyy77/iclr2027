from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
for name,path in [('dmdb',ROOT/'data/processed/drugmechdb/benchmark_manifest.csv'),('epikg',ROOT/'data/processed/epikg/epikg_benchmark_manifest.csv')]:
 d=pd.read_csv(path)
 for split,g in d.groupby('split'): g.to_csv(ROOT/f'data/splits/{name}_{split}.csv',index=False)
 print(name,d.groupby('split').size().to_dict())
