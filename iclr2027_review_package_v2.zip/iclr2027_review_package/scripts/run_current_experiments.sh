#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python scripts/check_project.py
python evaluation/evaluate_saved_results.py
# Current experiment source files are preserved under code/original_recovered.
# They contain the exact historical /mnt/data paths. For byte-identical provenance we leave them unchanged.
# Use the portable method implementations under methods/ for new runs, or edit BASE/RAW in the preserved scripts.
