from pathlib import Path
import importlib.util, json, pandas as pd
ROOT=Path(__file__).resolve().parents[1]
req=['data/raw/drugmechdb/indication_paths.json','data/raw/epikg/triplets.json','data/raw/epikg/t1_clinical_decision_accuracy_mcq.json','data/processed/drugmechdb/benchmark_manifest.csv','data/processed/epikg/epikg_benchmark_manifest.csv','checkpoints/bridge_confidence_realgraph.pt','checkpoints/gate_realgraph.pt']
missing=[x for x in req if not (ROOT/x).exists()]
print(json.dumps({'root':str(ROOT),'missing':missing,'ok':not missing},indent=2))
