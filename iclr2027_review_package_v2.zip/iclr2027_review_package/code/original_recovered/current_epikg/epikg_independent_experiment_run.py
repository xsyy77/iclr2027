import json, re, math, unicodedata, os
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

SEED=20260903
rng=np.random.default_rng(SEED)
BASE=Path('/mnt/data/epikg_independent_experiment'); BASE.mkdir(exist_ok=True)
trip=json.load(open('/mnt/data/triplets.json'))
mcq=json.load(open('/mnt/data/t1_clinical_decision_accuracy_mcq.json'))

# ---------- graph ----------
OUT=defaultdict(list); IN=defaultdict(list); LAYER={}; NAME=set()
for idx,e in enumerate(trip):
    h,t=e['head'],e['tail']; NAME.update([h,t])
    LAYER[h]=e.get('head_layer','L_unknown'); LAYER[t]=e.get('tail_layer','L_unknown')
    rec=(t,idx,e['relation'],float(e.get('confidence',0.5)),int(e.get('paper_count',0)))
    OUT[h].append(rec)
    IN[t].append((h,idx,e['relation'],float(e.get('confidence',0.5)),int(e.get('paper_count',0))))
DEG={n:len(OUT.get(n,[]))+len(IN.get(n,[])) for n in NAME}
MAXLOG=max(math.log1p(x) for x in DEG.values()) or 1.0
MAXPCLOG=max(math.log1p(int(e.get('paper_count',0))) for e in trip) or 1.0

def norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return ' '.join(s.split())

def toks(s): return set(norm(s).split())
def jac(a,b):
    A,B=toks(a),toks(b)
    return len(A&B)/len(A|B) if A and B else 0.0

def common_bridges(h,t):
    return ({v for v,*_ in OUT.get(h,[]) if v!=t} & {u for u,*_ in IN.get(t,[]) if u!=h})

def edge_base(v,conf,pc):
    anti=1-math.log1p(DEG.get(v,0))/MAXLOG
    pcs=math.log1p(pc)/MAXPCLOG
    return 0.62*conf+0.23*anti+0.15*pcs

def query_edge_sem(source,target,qrel,v,rel,conf,pc):
    # target-aware source-target retrieval, but direct source->target edge is always masked
    sem=0.55*jac(rel,qrel)+0.30*jac(v,target)+0.15*jac(v,source)
    return 0.58*edge_base(v,conf,pc)+0.42*sem

def bridge_state(path_nodes, bridge_conf):
    if not bridge_conf: return 0.0
    reached=[n for n in path_nodes if n in bridge_conf]
    if not reached: return 0.0
    uniq=list(dict.fromkeys(reached)); cov=len(uniq)/max(1,len(bridge_conf))
    mc=float(np.mean([bridge_conf[n] for n in uniq])); cur=bridge_conf.get(path_nodes[-1],0.0)
    recent=sum(1 for n in path_nodes[-2:] if n in bridge_conf)/2.0
    return min(1.0,0.42*cov+0.28*mc+0.16*cur+0.14*recent)

def run_search(source,target,qrel,bridge_conf=None,g=0.0,mode='graph',beam=2,max_hops=8,node_budget=14,edge_budget=20):
    bridge_conf=bridge_conf or {}
    states=[(0.0,(source,),())]; generated={source}; expanded=0; best_target=None
    for _ in range(max_hops):
        nxt=[]
        for _,pn,rels in states:
            u=pn[-1]
            cand=[]
            for v,idx,rel,conf,pc in OUT.get(u,[]):
                if u==source and v==target: # mask direct answer edge(s)
                    continue
                if v in pn: continue
                if mode=='semantic': gs=query_edge_sem(source,target,qrel,v,rel,conf,pc)
                else: gs=edge_base(v,conf,pc)
                # rank before budget accounting, as a real retriever would prioritize expansions
                cand.append((gs,v,rel))
            cand.sort(key=lambda x:x[0],reverse=True)
            for gs,v,rel in cand:
                if expanded>=edge_budget: break
                expanded+=1
                if v not in generated and len(generated)>=node_budget: continue
                generated.add(v)
                nn=pn+(v,); rr=rels+(rel,)
                # mean structural/semantic edge quality for path
                # recompute mean approximately from current transition score + previous path score proxy
                bs=bridge_state(nn,bridge_conf)
                score=(1-g)*gs+g*bs-0.012*len(rr)
                st=(score,nn,rr); nxt.append(st)
                if v==target and (best_target is None or score>best_target[0]): best_target=st
            if expanded>=edge_budget: break
        if best_target is not None: break
        if not nxt: break
        nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True); states=nxt[:beam]
    best=best_target if best_target is not None else (max(states,key=lambda x:x[0]) if states else (0.0,(source,),()))
    _,pn,rr=best
    found=bool(pn and pn[-1]==target)
    plen=len(rr) if found else max_hops+1
    utility=(0.85 if found else 0.0)+(0.15*(1.0/max(1,plen)) if found else 0.0)
    return {'found':float(found),'path_len':plen,'utility':utility,'nodes':list(pn),'relations':list(rr)}

# ---------- benchmark construction ----------
elig=[]; seen=set()
for i,e in enumerate(trip):
    if not e.get('cross_layer',False): continue
    h,t,r=e['head'],e['tail'],e['relation']; key=(h,t,r)
    if key in seen or h==t: continue
    seen.add(key)
    cbs=common_bridges(h,t)
    if len(cbs)>=3:
        elig.append({'edge_idx':i,'source':h,'target':t,'relation':r,'source_layer':e.get('head_layer',''),
                     'target_layer':e.get('tail_layer',''),'n_common_bridges':len(cbs)})
edf=pd.DataFrame(elig)
# restrict to relation types with enough examples for meaningful train/val/test
vc=edf.relation.value_counts(); keep=list(vc[vc>=30].index)
edf=edf[edf.relation.isin(keep)].copy()
# sample 2000 proportionally
parts=[]; TARGET=2000
for rel,gp in edf.groupby('relation'):
    n=max(15,round(TARGET*len(gp)/len(edf))); n=min(n,len(gp)); parts.append(gp.sample(n=n,random_state=SEED+abs(hash(rel))%10000))
bench=pd.concat(parts).drop_duplicates(['source','target','relation'])
if len(bench)>TARGET: bench=bench.sample(n=TARGET,random_state=SEED)
bench=bench.reset_index(drop=True)
# per-relation deterministic 70/15/15
bench['split']=''
for rel,idxs in bench.groupby('relation').groups.items():
    idxs=np.array(list(idxs)); rr=np.random.default_rng(SEED+abs(hash(rel))%100000); rr.shuffle(idxs)
    n=len(idxs); ntr=max(1,int(round(.70*n))); nv=max(1,int(round(.15*n)))
    if ntr+nv>=n: nv=max(1,n-ntr-1)
    bench.loc[idxs[:ntr],'split']='train'; bench.loc[idxs[ntr:ntr+nv],'split']='val'; bench.loc[idxs[ntr+nv:],'split']='test'
bench.to_csv(BASE/'epikg_benchmark_manifest.csv',index=False)

# ---------- candidate features / retrieval-derived labels ----------
def edge_pair_stats(h,b,t):
    hb=[x for x in OUT.get(h,[]) if x[0]==b]
    bt=[x for x in OUT.get(b,[]) if x[0]==t]
    c1=max([x[3] for x in hb],default=0); c2=max([x[3] for x in bt],default=0)
    p1=max([x[4] for x in hb],default=0); p2=max([x[4] for x in bt],default=0)
    r1=max(hb,key=lambda x:x[3])[2] if hb else ''
    r2=max(bt,key=lambda x:x[3])[2] if bt else ''
    return c1,c2,p1,p2,r1,r2

def cand_features(row,b):
    h,t,r=row.source,row.target,row.relation
    c1,c2,p1,p2,r1,r2=edge_pair_stats(h,b,t)
    return {
      'sem_bridge_query': (jac(b,h)+jac(b,t)+jac(LAYER.get(b,''),r))/3,
      'rel_compat': (jac(r1,r)+jac(r2,r))/2,
      'edge_conf_mean': (c1+c2)/2,
      'edge_conf_min': min(c1,c2),
      'paper_support': (math.log1p(p1)+math.log1p(p2))/(2*MAXPCLOG),
      'anti_hub': 1-math.log1p(DEG.get(b,0))/MAXLOG,
      'cross_view': float(LAYER.get(b,'') not in {row.source_layer,row.target_layer}),
    }

candrows=[]
for qi,row in bench.iterrows():
    base=run_search(row.source,row.target,row.relation,{},0.0,'graph')
    cbs=list(common_bridges(row.source,row.target))
    # rank candidate pool by local edge confidence / anti-hub, no gold utility used
    tmp=[]
    for b in cbs:
        f=cand_features(row,b); prescore=.45*f['edge_conf_mean']+.25*f['paper_support']+.20*f['anti_hub']+.10*f['cross_view']
        tmp.append((prescore,b,f))
    tmp.sort(reverse=True,key=lambda x:x[0]); tmp=tmp[:12]
    for prescore,b,f in tmp:
        ev=run_search(row.source,row.target,row.relation,{b:1.0},0.30,'graph')
        delta=ev['utility']-base['utility']
        candrows.append({'qid':qi,'split':row.split,'source':row.source,'target':row.target,'relation':row.relation,'bridge':b,
                         'bridge_layer':LAYER.get(b,'L_unknown'),'base_utility':base['utility'],'bridge_utility':ev['utility'],'delta':delta,
                         'beneficial':int(delta>1e-12),**f})
cand=pd.DataFrame(candrows); cand.to_csv(BASE/'epikg_bridge_training_samples.csv',index=False)
FEATURES=['sem_bridge_query','rel_compat','edge_conf_mean','edge_conf_min','paper_support','anti_hub','cross_view']
train=cand[cand.split=='train']; val=cand[cand.split=='val']; testc=cand[cand.split=='test']
clf=LogisticRegression(max_iter=1000,class_weight='balanced',random_state=SEED)
clf.fit(train[FEATURES],train.beneficial)
for dd in [cand]: dd['p_bridge']=clf.predict_proba(dd[FEATURES])[:,1]
# scorer metrics
metrics=[]
for spl in ['train','val','test']:
    ss=cand[cand.split==spl]; y=ss.beneficial.to_numpy(); p=ss.p_bridge.to_numpy()
    metrics.append({'split':spl,'n':len(ss),'positive_rate':y.mean(),'auroc':roc_auc_score(y,p),'auprc':average_precision_score(y,p),'brier':brier_score_loss(y,p)})
pd.DataFrame(metrics).to_csv(BASE/'epikg_reliability_metrics.csv',index=False)

# ---------- select bridges with layer diversity ----------
def select_bridges(dd,k=3):
    dd=dd.sort_values('p_bridge',ascending=False).copy(); selected=[]; used=set()
    # first pass encourage distinct known layers
    for _,r in dd.iterrows():
        layer=r.bridge_layer
        bonus=0.08 if layer not in used and layer!='L_unknown' else 0
        score=float(r.p_bridge)+bonus
        selected.append((score,str(r.bridge),float(r.p_bridge),layer))
    selected.sort(reverse=True)
    out=[]; used_nodes=set(); used_layers=set()
    # greedy re-score diversity
    remaining=dd.to_dict('records')
    while remaining and len(out)<k:
        best=None
        for r in remaining:
            div=0.08 if r['bridge_layer'] not in used_layers and r['bridge_layer']!='L_unknown' else 0.0
            s=float(r['p_bridge'])+div
            if best is None or s>best[0]: best=(s,r)
        r=best[1]; out.append(r); used_layers.add(r['bridge_layer']); remaining=[x for x in remaining if x['bridge']!=r['bridge']]
    return out

# query-level training features and label based on whether selected fixed guidance improves graph only
qrows=[]
for qi,row in bench.iterrows():
    dd=cand[cand.qid==qi]; sel=select_bridges(dd,3); conf={x['bridge']:float(x['p_bridge']) for x in sel}
    base=run_search(row.source,row.target,row.relation,{},0.0,'graph')
    fixed=run_search(row.source,row.target,row.relation,conf,0.30,'graph')
    ps=np.array([x['p_bridge'] for x in sel],float)
    qrows.append({'qid':qi,'split':row.split,'relation':row.relation,'n_candidates':len(dd),'p_mean':ps.mean() if len(ps) else 0,
                  'p_max':ps.max() if len(ps) else 0,'p_min':ps.min() if len(ps) else 0,'p_std':ps.std() if len(ps) else 0,
                  'source_deg':math.log1p(DEG.get(row.source,0))/MAXLOG,'target_deg':math.log1p(DEG.get(row.target,0))/MAXLOG,
                  'base_utility':base['utility'],'fixed_utility':fixed['utility'],'gate_label':int(fixed['utility']>base['utility']+1e-12)})
qdf=pd.DataFrame(qrows)
QF=['n_candidates','p_mean','p_max','p_min','p_std','source_deg','target_deg']
gclf=LogisticRegression(max_iter=1000,class_weight='balanced',random_state=SEED+1)
gclf.fit(qdf[qdf.split=='train'][QF],qdf[qdf.split=='train'].gate_label)
qdf['p_reliable']=gclf.predict_proba(qdf[QF])[:,1]
qdf.to_csv(BASE/'epikg_gate_training_samples.csv',index=False)
qm=[]
for spl in ['train','val','test']:
    ss=qdf[qdf.split==spl]; y=ss.gate_label; p=ss.p_reliable
    qm.append({'split':spl,'n':len(ss),'positive_rate':y.mean(),'auroc':roc_auc_score(y,p) if y.nunique()>1 else np.nan,
               'auprc':average_precision_score(y,p) if y.nunique()>1 else np.nan,'brier':brier_score_loss(y,p)})
pd.DataFrame(qm).to_csv(BASE/'epikg_gate_metrics.csv',index=False)

# validation gate hyperparameters
vg=[]
for gmax in [0.30,0.40,0.50,0.60]:
  for gamma in [0.5,1.0,2.0]:
    vals=[]
    for qi,row in bench[bench.split=='val'].iterrows():
        dd=cand[cand.qid==qi]; sel=select_bridges(dd,3); conf={x['bridge']:float(x['p_bridge']) for x in sel}
        p=float(qdf.loc[qdf.qid==qi,'p_reliable'].iloc[0]); g=gmax*(p**gamma)
        ev=run_search(row.source,row.target,row.relation,conf,g,'graph'); vals.append(ev['utility'])
    vg.append({'gmax':gmax,'gamma':gamma,'mean_utility':float(np.mean(vals))})
vg=pd.DataFrame(vg).sort_values('mean_utility',ascending=False); vg.to_csv(BASE/'epikg_gate_validation_grid.csv',index=False)
GMAX=float(vg.iloc[0].gmax); GAM=float(vg.iloc[0].gamma)
# hard threshold validation with on-strength .30
hrows=[]
for tau in np.arange(.1,.91,.05):
    vals=[]
    for qi,row in bench[bench.split=='val'].iterrows():
        dd=cand[cand.qid==qi]; sel=select_bridges(dd,3); conf={x['bridge']:float(x['p_bridge']) for x in sel}
        p=float(qdf.loc[qdf.qid==qi,'p_reliable'].iloc[0]); g=.30 if p>=tau else 0.0
        vals.append(run_search(row.source,row.target,row.relation,conf,g,'graph')['utility'])
    hrows.append({'threshold':tau,'mean_utility':np.mean(vals)})
hg=pd.DataFrame(hrows).sort_values('mean_utility',ascending=False); hg.to_csv(BASE/'epikg_hard_gate_validation.csv',index=False); HT=float(hg.iloc[0].threshold)

# ---------- test comparison ----------
results=[]
for qi,row in bench[bench.split=='test'].iterrows():
    dd=cand[cand.qid==qi]; sel=select_bridges(dd,3); conf={x['bridge']:float(x['p_bridge']) for x in sel}
    p=float(qdf.loc[qdf.qid==qi,'p_reliable'].iloc[0])
    methods={
      'Graph Only': ('graph',{},0.0),
      'Semantic Beam': ('semantic',{},0.0),
      'Fixed Bridge': ('graph',conf,0.30),
      'Hard Gate': ('graph',conf,0.30 if p>=HT else 0.0),
      'Full Continuous Gate': ('graph',conf,GMAX*(p**GAM)),
    }
    # oracle gate upper bound over alpha grid
    best=None
    for a in np.arange(0,0.61,.05):
        ev=run_search(row.source,row.target,row.relation,conf,float(a),'graph')
        if best is None or ev['utility']>best[0]: best=(ev['utility'],float(a),ev)
    methods['Oracle Gate']=('graph',conf,best[1])
    for name,(mode,bc,g) in methods.items():
        ev=run_search(row.source,row.target,row.relation,bc,g,mode)
        results.append({'qid':qi,'source':row.source,'target':row.target,'relation':row.relation,'method':name,'p_reliable':p,'gate':g,
                        'path_success':ev['found'],'path_len':ev['path_len'],'utility':ev['utility']})
res=pd.DataFrame(results); res.to_csv(BASE/'epikg_test_detailed.csv',index=False)
summary=res.groupby('method').agg(n=('qid','size'),path_success=('path_success','mean'),mean_path_len_success=('path_len',lambda x: x[res.loc[x.index,'path_success']==1].mean() if (res.loc[x.index,'path_success']==1).any() else np.nan),utility=('utility','mean'),mean_gate=('gate','mean')).reset_index()
summary.to_csv(BASE/'epikg_main_results.csv',index=False)
byrel=res.groupby(['method','relation']).agg(n=('qid','size'),path_success=('path_success','mean'),utility=('utility','mean')).reset_index(); byrel.to_csv(BASE/'epikg_main_by_relation.csv',index=False)
# paired bootstrap Full vs baselines
boot=[]; B=3000; rr=np.random.default_rng(SEED+8)
full=res[res.method=='Full Continuous Gate'][['qid','path_success','utility']]
for base in ['Graph Only','Semantic Beam','Fixed Bridge','Hard Gate']:
    bb=res[res.method==base][['qid','path_success','utility']]; mm=full.merge(bb,on='qid',suffixes=('_f','_b'))
    for met in ['path_success','utility']:
        d=(mm[f'{met}_f']-mm[f'{met}_b']).to_numpy(float); ix=rr.integers(0,len(d),(B,len(d))); z=d[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
        boot.append({'comparison':f'Full - {base}','metric':met,'mean_diff':d.mean(),'ci95_low':lo,'ci95_high':hi})
pd.DataFrame(boot).to_csv(BASE/'epikg_bootstrap.csv',index=False)

# ---------- EpiBench audit: graph-groundable answer options ----------
# exact normalized node mapping; this is an audit, not a claimed full MCQ result
normmap=defaultdict(list)
for n in NAME: normmap[norm(n)].append(n)
audit=[]
for q in mcq:
    mapped={L:(norm(q[f'option_{L}']) in normmap) for L in 'ABCD'}
    audit.append({'mcq_id':q['mcq_id'],'type':q['type'],'correct_answer':q['correct_answer'],'correct_option_mapped':int(mapped[q['correct_answer']]),
                  'n_options_mapped':sum(mapped.values()),'all_options_mapped':int(all(mapped.values()))})
aud=pd.DataFrame(audit); aud.to_csv(BASE/'epibench_graph_groundability_audit.csv',index=False)
audsum=pd.DataFrame([{'n_mcq':len(aud),'correct_option_mapped':aud.correct_option_mapped.mean(),'all_four_options_mapped':aud.all_options_mapped.mean(),
                     'any_option_mapped':(aud.n_options_mapped>0).mean(),'mean_options_mapped':aud.n_options_mapped.mean()}])
audsum.to_csv(BASE/'epibench_graph_groundability_summary.csv',index=False)

# report json
report={
 'epikg_file_edges':len(trip),'epikg_unique_nodes':len(NAME),'benchmark_n':len(bench),'splits':bench.split.value_counts().to_dict(),
 'relations':bench.relation.value_counts().to_dict(),'selected_gate':{'gmax':GMAX,'gamma':GAM,'hard_threshold':HT},
 'reliability_metrics':metrics,'gate_metrics':qm,
 'main_results':summary.to_dict('records'),'epibench_audit':audsum.iloc[0].to_dict()
}
json.dump(report,open(BASE/'epikg_report.json','w'),indent=2)
print(json.dumps(report,indent=2))
