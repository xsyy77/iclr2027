import csv
import json
import random

from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean

import step7_guided_search as search_module

from step12_batch_experiment import (
    BenchmarkCase,
    build_batch_graph,
    build_benchmark_cases,
)

from step15_bridge_noise_ablation import (
    ConditionMetrics,
    build_clean_bridges,
    build_noisy_bridges,
    build_random_bridges,
    evaluate_condition,
)


# ============================================================
# 1. 实验参数
# ============================================================

ALPHA_VALUES = [
    0.10,
    0.20,
    0.30,
    0.40,
    0.50,
]

RANDOM_SEED = 42

OUTPUT_JSON = "step16_bridge_alpha_sensitivity.json"
OUTPUT_CSV = "step16_bridge_alpha_sensitivity.csv"


# ============================================================
# 2. 单个 Alpha 下的总体结果
# ============================================================

@dataclass
class AlphaAggregate:
    bridge_alpha: float
    condition_name: str

    number_of_cases: int

    success_rate: float
    exact_match_rate: float

    mean_node_recall: float
    mean_edge_recall: float

    mean_visited_nodes: float
    mean_generated_nodes: float
    mean_generated_states: float
    mean_expanded_edges: float

    mean_path_score: float


# ============================================================
# 3. 单个案例、条件和 Alpha 的详细结果
# ============================================================

@dataclass
class AlphaCaseResult:
    bridge_alpha: float

    case_id: str
    condition_name: str

    found: bool
    exact_path_match: bool

    node_recall: float
    edge_recall: float

    visited_nodes: int
    generated_nodes: int
    generated_states: int
    expanded_edges: int

    path_score: float
    terminated_reason: str

    supplied_bridges: dict[str, float]
    reached_bridges: list[str]

    path_nodes: list[str]
    path_relations: list[str]


# ============================================================
# 4. 单次运行
# ============================================================

def run_single_condition(
    graph,
    case: BenchmarkCase,
    condition_name: str,
    supplied_bridges: dict[str, float],
) -> ConditionMetrics:
    use_bridge_guidance = (
        condition_name != "Baseline"
    )

    search_result = (
        search_module.run_beam_search(
            graph=graph,

            source_node=case.source_node,

            target_node=case.target_node,

            bridge_utilities=(
                supplied_bridges
            ),

            use_bridge_guidance=(
                use_bridge_guidance
            ),

            method_name=(
                f"{condition_name} "
                f"(alpha={search_module.BRIDGE_ALPHA:.2f})"
            ),
        )
    )

    return evaluate_condition(
        case=case,

        condition_name=condition_name,

        supplied_bridges=(
            supplied_bridges
        ),

        search_result=search_result,
    )


# ============================================================
# 5. 为每个 Alpha 构建公平一致的条件
# ============================================================

def build_conditions_for_case(
    graph,
    case: BenchmarkCase,
    random_generator: random.Random,
) -> dict[str, dict[str, float]]:
    """
    对每个 Alpha 使用相同的随机种子和相同的错误 Bridge，
    保证不同 Alpha 之间可公平比较。
    """

    return {
        "Baseline": {},

        "Clean Bridge": (
            build_clean_bridges(
                case
            )
        ),

        "Noisy Bridge": (
            build_noisy_bridges(
                graph,
                case,
            )
        ),

        "Random Bridge": (
            build_random_bridges(
                graph,
                case,
                random_generator,
            )
        ),
    }


# ============================================================
# 6. 运行全部 Alpha
# ============================================================

def run_alpha_sensitivity(
    graph,
    cases: list[BenchmarkCase],
) -> list[AlphaCaseResult]:
    all_results: list[
        AlphaCaseResult
    ] = []

    original_alpha = (
        search_module.BRIDGE_ALPHA
    )

    try:
        for alpha in ALPHA_VALUES:
            search_module.BRIDGE_ALPHA = float(
                alpha
            )

            print("\n" + "=" * 110)
            print(
                f"RUNNING BRIDGE_ALPHA = "
                f"{alpha:.2f}"
            )
            print("=" * 110)

            # 每个 alpha 都重置相同随机种子，
            # 使 Random Bridge 条件保持一致。
            random_generator = random.Random(
                RANDOM_SEED
            )

            for case in cases:
                conditions = (
                    build_conditions_for_case(
                        graph=graph,
                        case=case,
                        random_generator=(
                            random_generator
                        ),
                    )
                )

                for (
                    condition_name,
                    supplied_bridges,
                ) in conditions.items():
                    metrics = (
                        run_single_condition(
                            graph=graph,
                            case=case,
                            condition_name=(
                                condition_name
                            ),
                            supplied_bridges=(
                                supplied_bridges
                            ),
                        )
                    )

                    all_results.append(
                        AlphaCaseResult(
                            bridge_alpha=round(
                                alpha,
                                2,
                            ),

                            case_id=(
                                case.case_id
                            ),

                            condition_name=(
                                condition_name
                            ),

                            found=metrics.found,

                            exact_path_match=(
                                metrics
                                .exact_path_match
                            ),

                            node_recall=(
                                metrics.node_recall
                            ),

                            edge_recall=(
                                metrics.edge_recall
                            ),

                            visited_nodes=(
                                metrics.visited_nodes
                            ),

                            generated_nodes=(
                                metrics.generated_nodes
                            ),

                            generated_states=(
                                metrics.generated_states
                            ),

                            expanded_edges=(
                                metrics.expanded_edges
                            ),

                            path_score=(
                                metrics.path_score
                            ),

                            terminated_reason=(
                                metrics
                                .terminated_reason
                            ),

                            supplied_bridges=(
                                metrics
                                .supplied_bridges
                            ),

                            reached_bridges=(
                                metrics
                                .reached_bridges
                            ),

                            path_nodes=(
                                metrics.path_nodes
                            ),

                            path_relations=(
                                metrics
                                .path_relations
                            ),
                        )
                    )

                    print(
                        f"{case.case_id:<10} "
                        f"{condition_name:<15} "
                        f"found={str(metrics.found):<5} "
                        f"exact="
                        f"{str(metrics.exact_path_match):<5} "
                        f"edge_recall="
                        f"{metrics.edge_recall:.4f} "
                        f"visited="
                        f"{metrics.visited_nodes} "
                        f"expanded="
                        f"{metrics.expanded_edges}"
                    )

    finally:
        # 无论程序是否正常结束，都恢复原参数。
        search_module.BRIDGE_ALPHA = (
            original_alpha
        )

    return all_results


# ============================================================
# 7. 汇总每个 Alpha 和条件
# ============================================================

def aggregate_results(
    results: list[AlphaCaseResult],
) -> list[AlphaAggregate]:
    aggregates: list[
        AlphaAggregate
    ] = []

    condition_names = [
        "Baseline",
        "Clean Bridge",
        "Noisy Bridge",
        "Random Bridge",
    ]

    for alpha in ALPHA_VALUES:
        for condition_name in (
            condition_names
        ):
            subset = [
                result
                for result in results
                if (
                    result.bridge_alpha
                    == round(alpha, 2)
                    and result.condition_name
                    == condition_name
                )
            ]

            if not subset:
                continue

            aggregates.append(
                AlphaAggregate(
                    bridge_alpha=round(
                        alpha,
                        2,
                    ),

                    condition_name=(
                        condition_name
                    ),

                    number_of_cases=len(
                        subset
                    ),

                    success_rate=round(
                        mean(
                            int(result.found)
                            for result in subset
                        ),
                        4,
                    ),

                    exact_match_rate=round(
                        mean(
                            int(
                                result
                                .exact_path_match
                            )
                            for result in subset
                        ),
                        4,
                    ),

                    mean_node_recall=round(
                        mean(
                            result.node_recall
                            for result in subset
                        ),
                        4,
                    ),

                    mean_edge_recall=round(
                        mean(
                            result.edge_recall
                            for result in subset
                        ),
                        4,
                    ),

                    mean_visited_nodes=round(
                        mean(
                            result.visited_nodes
                            for result in subset
                        ),
                        4,
                    ),

                    mean_generated_nodes=round(
                        mean(
                            result.generated_nodes
                            for result in subset
                        ),
                        4,
                    ),

                    mean_generated_states=round(
                        mean(
                            result.generated_states
                            for result in subset
                        ),
                        4,
                    ),

                    mean_expanded_edges=round(
                        mean(
                            result.expanded_edges
                            for result in subset
                        ),
                        4,
                    ),

                    mean_path_score=round(
                        mean(
                            result.path_score
                            for result in subset
                        ),
                        4,
                    ),
                )
            )

    return aggregates


# ============================================================
# 8. 打印汇总表
# ============================================================

def print_summary(
    aggregates: list[AlphaAggregate],
) -> None:
    print("\n" + "=" * 130)
    print("BRIDGE ALPHA SENSITIVITY SUMMARY")
    print("=" * 130)

    print(
        f"{'Alpha':<10}"
        f"{'Condition':<18}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Node Recall':<15}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    print("-" * 130)

    for aggregate in aggregates:
        print(
            f"{aggregate.bridge_alpha:<10.2f}"
            f"{aggregate.condition_name:<18}"
            f"{aggregate.success_rate:<12.2%}"
            f"{aggregate.exact_match_rate:<12.2%}"
            f"{aggregate.mean_node_recall:<15.4f}"
            f"{aggregate.mean_edge_recall:<15.4f}"
            f"{aggregate.mean_visited_nodes:<12.4f}"
            f"{aggregate.mean_expanded_edges:<12.4f}"
        )


# ============================================================
# 9. 选择推荐 Alpha
# ============================================================

def select_recommended_alpha(
    aggregates: list[AlphaAggregate],
) -> float:
    """
    推荐规则：

    1. Clean Bridge 成功率必须为 100%；
    2. 优先最大化 Noisy Bridge 成功率；
    3. 再最大化 Random Bridge 成功率；
    4. 再选择更小的 Alpha，降低错误 Bridge 风险。
    """

    by_alpha: dict[
        float,
        dict[str, AlphaAggregate],
    ] = {}

    for aggregate in aggregates:
        by_alpha.setdefault(
            aggregate.bridge_alpha,
            {},
        )

        by_alpha[
            aggregate.bridge_alpha
        ][
            aggregate.condition_name
        ] = aggregate

    candidates = []

    for alpha, condition_map in (
        by_alpha.items()
    ):
        clean = condition_map.get(
            "Clean Bridge"
        )

        noisy = condition_map.get(
            "Noisy Bridge"
        )

        random_condition = condition_map.get(
            "Random Bridge"
        )

        if (
            clean is None
            or noisy is None
            or random_condition is None
        ):
            continue

        if clean.success_rate < 1.0:
            continue

        candidates.append(
            (
                noisy.success_rate,
                random_condition.success_rate,
                noisy.mean_edge_recall,
                random_condition.mean_edge_recall,
                -alpha,
                alpha,
            )
        )

    if not candidates:
        return min(
            ALPHA_VALUES
        )

    candidates.sort(
        reverse=True
    )

    return candidates[0][-1]


# ============================================================
# 10. 保存 JSON
# ============================================================

def save_json_results(
    detailed_results: list[
        AlphaCaseResult
    ],
    aggregates: list[
        AlphaAggregate
    ],
    recommended_alpha: float,
) -> None:
    output_data = {
        "experiment_name":
            "bridge_alpha_sensitivity",

        "alpha_values":
            ALPHA_VALUES,

        "random_seed":
            RANDOM_SEED,

        "search_parameters": {
            "beam_width":
                search_module.BEAM_WIDTH,

            "maximum_hops":
                search_module.MAX_HOPS,

            "maximum_generated_nodes":
                search_module
                .MAX_VISITED_NODES,

            "maximum_expanded_edges":
                search_module
                .MAX_EXPANDED_EDGES,
        },

        "recommended_alpha":
            recommended_alpha,

        "detailed_results": [
            asdict(result)
            for result in detailed_results
        ],

        "aggregate_results": [
            asdict(aggregate)
            for aggregate in aggregates
        ],
    }

    output_path = Path(
        OUTPUT_JSON
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print(
        f"\nJSON saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 11. 保存 CSV
# ============================================================

def save_csv_results(
    aggregates: list[
        AlphaAggregate
    ],
) -> None:
    output_path = Path(
        OUTPUT_CSV
    )

    fieldnames = [
        "bridge_alpha",
        "condition_name",
        "number_of_cases",

        "success_rate",
        "exact_match_rate",

        "mean_node_recall",
        "mean_edge_recall",

        "mean_visited_nodes",
        "mean_generated_nodes",
        "mean_generated_states",
        "mean_expanded_edges",

        "mean_path_score",
    ]

    with output_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for aggregate in aggregates:
            writer.writerow(
                asdict(
                    aggregate
                )
            )

    print(
        f"CSV saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 12. 主程序
# ============================================================

def main() -> None:
    print(
        "Building batch benchmark graph..."
    )

    graph = build_batch_graph()

    print(
        f"Graph loaded: "
        f"{graph.number_of_nodes()} nodes, "
        f"{graph.number_of_edges()} edges"
    )

    cases = build_benchmark_cases()

    print(
        f"Benchmark cases: "
        f"{len(cases)}"
    )

    detailed_results = (
        run_alpha_sensitivity(
            graph=graph,
            cases=cases,
        )
    )

    aggregates = aggregate_results(
        detailed_results
    )

    print_summary(
        aggregates
    )

    recommended_alpha = (
        select_recommended_alpha(
            aggregates
        )
    )

    print(
        "\nRecommended BRIDGE_ALPHA: "
        f"{recommended_alpha:.2f}"
    )

    save_json_results(
        detailed_results=(
            detailed_results
        ),

        aggregates=aggregates,

        recommended_alpha=(
            recommended_alpha
        ),
    )

    save_csv_results(
        aggregates
    )

    print("\n" + "=" * 80)
    print("STEP 16 COMPLETED")
    print("=" * 80)

    print(
        "Bridge alpha sensitivity "
        "experiment completed successfully."
    )


if __name__ == "__main__":
    main()
