import csv
import json
import random
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean

import networkx as nx

import step7_guided_search as search_module

from step12_batch_experiment import (
    BenchmarkCase,
    build_batch_graph,
    build_benchmark_cases,
)

from step15_bridge_noise_ablation import (
    build_clean_bridges,
    build_noisy_bridges,
    build_random_bridges,
    calculate_prf,
    build_edge_set,
)


# ============================================================
# 1. 实验参数
# ============================================================

DIFFICULTY_LEVELS = [
    "easy",
    "medium",
    "hard",
]

ALPHA_VALUES = [
    0.10,
    0.20,
    0.30,
]

BEAM_WIDTH_VALUES = [
    1,
    2,
]

CONDITIONS = [
    "Baseline",
    "Clean Bridge",
    "Noisy Bridge",
    "Random Bridge",
]

RANDOM_SEED = 42

OUTPUT_JSON = "step17_difficulty_alpha_grid.json"
OUTPUT_CSV = "step17_difficulty_alpha_grid.csv"


# ============================================================
# 2. 单次实验结果
# ============================================================

@dataclass
class GridResult:
    difficulty: str
    bridge_alpha: float
    beam_width: int

    case_id: str
    condition_name: str

    found: bool
    exact_path_match: bool

    node_recall: float
    edge_recall: float

    visited_nodes: int
    generated_nodes: int
    generated_states: int
    expanded_edges: int

    path_score: float
    termination: str

    supplied_bridges: dict[str, float]
    reached_bridges: list[str]

    path_nodes: list[str]
    path_relations: list[str]


# ============================================================
# 3. 汇总结果
# ============================================================

@dataclass
class GridAggregate:
    difficulty: str
    bridge_alpha: float
    beam_width: int
    condition_name: str

    number_of_cases: int

    success_rate: float
    exact_match_rate: float

    mean_node_recall: float
    mean_edge_recall: float

    mean_visited_nodes: float
    mean_generated_nodes: float
    mean_generated_states: float
    mean_expanded_edges: float


# ============================================================
# 4. 添加干扰链
# ============================================================

def add_distractor_chain(
    graph: nx.MultiDiGraph,
    source_node: str,
    prefix: str,
    chain_index: int,
    length: int,
    confidence: float,
) -> None:
    """
    从 source 添加一条无法到达目标的高置信度干扰链。
    """

    previous_node = source_node

    relation_cycle = [
        "causes",
        "promotes",
        "regulates",
        "supports",
    ]

    for step in range(1, length + 1):
        node_id = (
            f"{prefix}_DISTRACTOR_"
            f"{chain_index}_{step}"
        )

        graph.add_node(
            node_id,
            name=(
                f"{prefix.lower()} distractor "
                f"{chain_index}-{step}"
            ),
            entity_type="BiologicalProcess",
            description=(
                "Synthetic distractor node used only "
                "for controlled search stress testing."
            ),
        )

        relation = relation_cycle[
            (step - 1) % len(relation_cycle)
        ]

        graph.add_edge(
            previous_node,
            node_id,
            relation=relation,
            confidence=confidence,
            evidence=(
                "Synthetic high-confidence distractor "
                "evidence for stress testing."
            ),
        )

        previous_node = node_id


# ============================================================
# 5. 根据难度构建图
# ============================================================

def build_difficulty_graph(
    difficulty: str,
    cases: list[BenchmarkCase],
) -> nx.MultiDiGraph:
    """
    easy:
        使用 Step 12 原图。

    medium:
        每个 source 增加 2 条、长度 3 的高置信度干扰链。

    hard:
        每个 source 增加 4 条、长度 4 的高置信度干扰链。
    """

    graph = deepcopy(
        build_batch_graph()
    )

    if difficulty == "easy":
        return graph

    if difficulty == "medium":
        chain_count = 2
        chain_length = 3
        confidence = 0.985

    elif difficulty == "hard":
        chain_count = 4
        chain_length = 4
        confidence = 0.995

    else:
        raise ValueError(
            f"Unknown difficulty: {difficulty}"
        )

    for case in cases:
        for chain_index in range(
            1,
            chain_count + 1,
        ):
            add_distractor_chain(
                graph=graph,
                source_node=case.source_node,
                prefix=case.case_id,
                chain_index=chain_index,
                length=chain_length,
                confidence=confidence,
            )

    return graph


# ============================================================
# 6. 构建实验条件
# ============================================================

def build_conditions(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
    random_generator: random.Random,
) -> dict[str, dict[str, float]]:
    return {
        "Baseline": {},

        "Clean Bridge": (
            build_clean_bridges(
                case
            )
        ),

        "Noisy Bridge": (
            build_noisy_bridges(
                graph,
                case,
            )
        ),

        "Random Bridge": (
            build_random_bridges(
                graph,
                case,
                random_generator,
            )
        ),
    }


# ============================================================
# 7. 评价一次搜索
# ============================================================

def evaluate_search_result(
    difficulty: str,
    alpha: float,
    beam_width: int,
    case: BenchmarkCase,
    condition_name: str,
    supplied_bridges: dict[str, float],
    search_result,
) -> GridResult:
    predicted_nodes = list(
        search_result.path_nodes
    )

    predicted_relations = list(
        search_result.path_relations
    )

    _, node_recall, _ = calculate_prf(
        predicted_items=set(
            predicted_nodes
        ),
        gold_items=set(
            case.gold_path_nodes
        ),
    )

    predicted_edges = build_edge_set(
        predicted_nodes,
        predicted_relations,
    )

    gold_edges = build_edge_set(
        case.gold_path_nodes,
        case.gold_path_relations,
    )

    _, edge_recall, _ = calculate_prf(
        predicted_items=predicted_edges,
        gold_items=gold_edges,
    )

    exact_path_match = (
        predicted_nodes
        == case.gold_path_nodes
        and predicted_relations
        == case.gold_path_relations
    )

    return GridResult(
        difficulty=difficulty,

        bridge_alpha=round(
            alpha,
            2,
        ),

        beam_width=beam_width,

        case_id=case.case_id,

        condition_name=(
            condition_name
        ),

        found=bool(
            search_result.found
        ),

        exact_path_match=(
            exact_path_match
        ),

        node_recall=node_recall,

        edge_recall=edge_recall,

        visited_nodes=int(
            search_result.visited_nodes
        ),

        generated_nodes=int(
            getattr(
                search_result,
                "generated_nodes",
                0,
            )
        ),

        generated_states=int(
            getattr(
                search_result,
                "generated_states",
                0,
            )
        ),

        expanded_edges=int(
            search_result.expanded_edges
        ),

        path_score=round(
            float(
                search_result.path_score
            ),
            4,
        ),

        termination=(
            search_result
            .terminated_reason
        ),

        supplied_bridges=dict(
            supplied_bridges
        ),

        reached_bridges=list(
            search_result.reached_bridges
        ),

        path_nodes=predicted_nodes,

        path_relations=(
            predicted_relations
        ),
    )


# ============================================================
# 8. 运行网格实验
# ============================================================

def run_grid_experiment(
    cases: list[BenchmarkCase],
) -> list[GridResult]:
    all_results: list[
        GridResult
    ] = []

    original_alpha = (
        search_module.BRIDGE_ALPHA
    )

    original_beam_width = (
        search_module.BEAM_WIDTH
    )

    try:
        for difficulty in (
            DIFFICULTY_LEVELS
        ):
            graph = build_difficulty_graph(
                difficulty=difficulty,
                cases=cases,
            )

            print("\n" + "=" * 120)
            print(
                f"DIFFICULTY: "
                f"{difficulty.upper()}"
            )
            print(
                f"Graph: "
                f"{graph.number_of_nodes()} nodes, "
                f"{graph.number_of_edges()} edges"
            )
            print("=" * 120)

            for beam_width in (
                BEAM_WIDTH_VALUES
            ):
                search_module.BEAM_WIDTH = (
                    beam_width
                )

                for alpha in ALPHA_VALUES:
                    search_module.BRIDGE_ALPHA = (
                        float(alpha)
                    )

                    print(
                        "\n"
                        f"beam={beam_width}, "
                        f"alpha={alpha:.2f}"
                    )

                    # 每组参数重置相同随机种子，
                    # 确保 Random Bridge 可公平比较。
                    random_generator = (
                        random.Random(
                            RANDOM_SEED
                        )
                    )

                    for case in cases:
                        conditions = (
                            build_conditions(
                                graph=graph,
                                case=case,
                                random_generator=(
                                    random_generator
                                ),
                            )
                        )

                        for (
                            condition_name,
                            supplied_bridges,
                        ) in conditions.items():
                            use_bridge_guidance = (
                                condition_name
                                != "Baseline"
                            )

                            search_result = (
                                search_module
                                .run_beam_search(
                                    graph=graph,

                                    source_node=(
                                        case
                                        .source_node
                                    ),

                                    target_node=(
                                        case
                                        .target_node
                                    ),

                                    bridge_utilities=(
                                        supplied_bridges
                                    ),

                                    use_bridge_guidance=(
                                        use_bridge_guidance
                                    ),

                                    method_name=(
                                        condition_name
                                    ),
                                )
                            )

                            result = (
                                evaluate_search_result(
                                    difficulty=(
                                        difficulty
                                    ),

                                    alpha=alpha,

                                    beam_width=(
                                        beam_width
                                    ),

                                    case=case,

                                    condition_name=(
                                        condition_name
                                    ),

                                    supplied_bridges=(
                                        supplied_bridges
                                    ),

                                    search_result=(
                                        search_result
                                    ),
                                )
                            )

                            all_results.append(
                                result
                            )

                            print(
                                f"{case.case_id:<10} "
                                f"{condition_name:<15} "
                                f"found="
                                f"{str(result.found):<5} "
                                f"edge_recall="
                                f"{result.edge_recall:.4f}"
                            )

    finally:
        search_module.BRIDGE_ALPHA = (
            original_alpha
        )

        search_module.BEAM_WIDTH = (
            original_beam_width
        )

    return all_results


# ============================================================
# 9. 汇总结果
# ============================================================

def aggregate_results(
    results: list[GridResult],
) -> list[GridAggregate]:
    aggregates: list[
        GridAggregate
    ] = []

    for difficulty in (
        DIFFICULTY_LEVELS
    ):
        for beam_width in (
            BEAM_WIDTH_VALUES
        ):
            for alpha in ALPHA_VALUES:
                for condition_name in (
                    CONDITIONS
                ):
                    subset = [
                        result
                        for result in results
                        if (
                            result.difficulty
                            == difficulty
                            and result.beam_width
                            == beam_width
                            and result.bridge_alpha
                            == round(alpha, 2)
                            and result.condition_name
                            == condition_name
                        )
                    ]

                    if not subset:
                        continue

                    aggregates.append(
                        GridAggregate(
                            difficulty=(
                                difficulty
                            ),

                            bridge_alpha=round(
                                alpha,
                                2,
                            ),

                            beam_width=(
                                beam_width
                            ),

                            condition_name=(
                                condition_name
                            ),

                            number_of_cases=len(
                                subset
                            ),

                            success_rate=round(
                                mean(
                                    int(
                                        result.found
                                    )
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            exact_match_rate=round(
                                mean(
                                    int(
                                        result
                                        .exact_path_match
                                    )
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_node_recall=round(
                                mean(
                                    result.node_recall
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_edge_recall=round(
                                mean(
                                    result.edge_recall
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_visited_nodes=round(
                                mean(
                                    result
                                    .visited_nodes
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_generated_nodes=round(
                                mean(
                                    result
                                    .generated_nodes
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_generated_states=round(
                                mean(
                                    result
                                    .generated_states
                                    for result
                                    in subset
                                ),
                                4,
                            ),

                            mean_expanded_edges=round(
                                mean(
                                    result
                                    .expanded_edges
                                    for result
                                    in subset
                                ),
                                4,
                            ),
                        )
                    )

    return aggregates


# ============================================================
# 10. 打印汇总
# ============================================================

def print_summary(
    aggregates: list[GridAggregate],
) -> None:
    print("\n" + "=" * 145)
    print("DIFFICULTY × ALPHA × BEAM SUMMARY")
    print("=" * 145)

    print(
        f"{'Difficulty':<12}"
        f"{'Beam':<8}"
        f"{'Alpha':<8}"
        f"{'Condition':<18}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    print("-" * 145)

    for aggregate in aggregates:
        print(
            f"{aggregate.difficulty:<12}"
            f"{aggregate.beam_width:<8}"
            f"{aggregate.bridge_alpha:<8.2f}"
            f"{aggregate.condition_name:<18}"
            f"{aggregate.success_rate:<12.2%}"
            f"{aggregate.exact_match_rate:<12.2%}"
            f"{aggregate.mean_edge_recall:<15.4f}"
            f"{aggregate.mean_visited_nodes:<12.4f}"
            f"{aggregate.mean_expanded_edges:<12.4f}"
        )


# ============================================================
# 11. 推荐参数
# ============================================================

def select_recommended_setting(
    aggregates: list[GridAggregate],
) -> dict:
    """
    推荐规则：

    1. Clean Bridge 在 medium/hard 上成功率尽可能高；
    2. Noisy Bridge 成功率尽可能高；
    3. Random Bridge 成功率不作为奖励；
    4. Clean 相对 Baseline 的成功率提升越大越好；
    5. 同分时优先更小 alpha 和更小 beam。
    """

    candidates = []

    for beam_width in (
        BEAM_WIDTH_VALUES
    ):
        for alpha in ALPHA_VALUES:
            score = 0.0
            clean_success = []
            noisy_success = []
            baseline_success = []
            random_success = []

            valid = True

            for difficulty in [
                "medium",
                "hard",
            ]:
                condition_map = {
                    aggregate.condition_name:
                        aggregate
                    for aggregate in aggregates
                    if (
                        aggregate.difficulty
                        == difficulty
                        and aggregate.beam_width
                        == beam_width
                        and aggregate.bridge_alpha
                        == round(alpha, 2)
                    )
                }

                required = {
                    "Baseline",
                    "Clean Bridge",
                    "Noisy Bridge",
                    "Random Bridge",
                }

                if not required.issubset(
                    condition_map
                ):
                    valid = False
                    break

                baseline = condition_map[
                    "Baseline"
                ].success_rate

                clean = condition_map[
                    "Clean Bridge"
                ].success_rate

                noisy = condition_map[
                    "Noisy Bridge"
                ].success_rate

                random_condition = condition_map[
                    "Random Bridge"
                ].success_rate

                baseline_success.append(
                    baseline
                )

                clean_success.append(
                    clean
                )

                noisy_success.append(
                    noisy
                )

                random_success.append(
                    random_condition
                )

            if not valid:
                continue

            mean_clean = mean(
                clean_success
            )

            mean_noisy = mean(
                noisy_success
            )

            mean_baseline = mean(
                baseline_success
            )

            mean_random = mean(
                random_success
            )

            clean_gain = (
                mean_clean
                - mean_baseline
            )

            score = (
                3.0 * mean_clean
                + 2.0 * mean_noisy
                + 2.0 * clean_gain
                - 0.5 * mean_random
                - 0.1 * alpha
                - 0.02 * beam_width
            )

            candidates.append(
                {
                    "score": round(
                        score,
                        6,
                    ),

                    "beam_width":
                        beam_width,

                    "bridge_alpha":
                        round(alpha, 2),

                    "medium_hard_clean_success":
                        round(mean_clean, 4),

                    "medium_hard_noisy_success":
                        round(mean_noisy, 4),

                    "medium_hard_baseline_success":
                        round(mean_baseline, 4),

                    "medium_hard_random_success":
                        round(mean_random, 4),

                    "clean_gain_over_baseline":
                        round(clean_gain, 4),
                }
            )

    if not candidates:
        return {
            "beam_width": 1,
            "bridge_alpha": 0.10,
            "score": 0.0,
        }

    candidates.sort(
        key=lambda item: (
            -item["score"],
            item["bridge_alpha"],
            item["beam_width"],
        )
    )

    return candidates[0]


# ============================================================
# 12. 保存 JSON
# ============================================================

def save_json_results(
    detailed_results: list[GridResult],
    aggregates: list[GridAggregate],
    recommendation: dict,
) -> None:
    output_data = {
        "experiment_name":
            "difficulty_alpha_beam_grid",

        "difficulty_levels":
            DIFFICULTY_LEVELS,

        "alpha_values":
            ALPHA_VALUES,

        "beam_width_values":
            BEAM_WIDTH_VALUES,

        "random_seed":
            RANDOM_SEED,

        "recommendation":
            recommendation,

        "detailed_results": [
            asdict(result)
            for result in detailed_results
        ],

        "aggregate_results": [
            asdict(aggregate)
            for aggregate in aggregates
        ],
    }

    output_path = Path(
        OUTPUT_JSON
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print(
        f"\nJSON saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 13. 保存 CSV
# ============================================================

def save_csv_results(
    aggregates: list[GridAggregate],
) -> None:
    output_path = Path(
        OUTPUT_CSV
    )

    fieldnames = [
        "difficulty",
        "beam_width",
        "bridge_alpha",
        "condition_name",
        "number_of_cases",

        "success_rate",
        "exact_match_rate",

        "mean_node_recall",
        "mean_edge_recall",

        "mean_visited_nodes",
        "mean_generated_nodes",
        "mean_generated_states",
        "mean_expanded_edges",
    ]

    with output_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for aggregate in aggregates:
            writer.writerow(
                asdict(
                    aggregate
                )
            )

    print(
        f"CSV saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 14. 主程序
# ============================================================

def main() -> None:
    cases = build_benchmark_cases()

    print(
        f"Benchmark cases: "
        f"{len(cases)}"
    )

    detailed_results = (
        run_grid_experiment(
            cases=cases
        )
    )

    aggregates = aggregate_results(
        detailed_results
    )

    print_summary(
        aggregates
    )

    recommendation = (
        select_recommended_setting(
            aggregates
        )
    )

    print(
        "\nRecommended setting:"
    )

    print(
        f"  BEAM_WIDTH = "
        f"{recommendation['beam_width']}"
    )

    print(
        f"  BRIDGE_ALPHA = "
        f"{recommendation['bridge_alpha']:.2f}"
    )

    print(
        f"  Score = "
        f"{recommendation['score']:.6f}"
    )

    save_json_results(
        detailed_results=(
            detailed_results
        ),

        aggregates=aggregates,

        recommendation=(
            recommendation
        ),
    )

    save_csv_results(
        aggregates
    )

    print("\n" + "=" * 80)
    print("STEP 17 COMPLETED")
    print("=" * 80)

    print(
        "Difficulty, alpha and beam-width "
        "grid experiment completed successfully."
    )


if __name__ == "__main__":
    main()
