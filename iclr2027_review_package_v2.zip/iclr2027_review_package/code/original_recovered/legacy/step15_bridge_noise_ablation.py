import csv
import json
import random

from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean

import networkx as nx

from step7_guided_search import run_beam_search
from step12_batch_experiment import (
    BenchmarkCase,
    build_batch_graph,
    build_benchmark_cases,
)


# ============================================================
# 1. 实验参数
# ============================================================

RANDOM_SEED = 42

OUTPUT_JSON = "step15_bridge_noise_ablation.json"
OUTPUT_CSV = "step15_bridge_noise_ablation.csv"


# ============================================================
# 2. 单个实验条件结果
# ============================================================

@dataclass
class ConditionMetrics:
    case_id: str
    condition_name: str

    found: bool
    exact_path_match: bool

    node_precision: float
    node_recall: float
    node_f1: float

    edge_precision: float
    edge_recall: float
    edge_f1: float

    visited_nodes: int
    generated_nodes: int
    generated_states: int
    expanded_edges: int

    search_rounds: int
    path_length: int
    path_score: float

    terminated_reason: str

    path_nodes: list[str]
    path_relations: list[str]

    reached_bridges: list[str]
    supplied_bridges: dict[str, float]


# ============================================================
# 3. 总体条件统计
# ============================================================

@dataclass
class ConditionAggregate:
    condition_name: str

    number_of_cases: int

    success_rate: float
    exact_match_rate: float

    mean_node_precision: float
    mean_node_recall: float
    mean_node_f1: float

    mean_edge_precision: float
    mean_edge_recall: float
    mean_edge_f1: float

    mean_visited_nodes: float
    mean_generated_nodes: float
    mean_generated_states: float
    mean_expanded_edges: float

    mean_path_length: float
    mean_path_score: float


# ============================================================
# 4. 完整实验结果
# ============================================================

@dataclass
class AblationSummary:
    number_of_cases: int

    condition_aggregates: list[ConditionAggregate]

    clean_success_over_baseline_count: int
    noisy_success_over_baseline_count: int
    random_success_over_baseline_count: int

    clean_failure_when_baseline_success_count: int
    noisy_failure_when_clean_success_count: int
    random_failure_when_clean_success_count: int

    noisy_edge_recall_degradation_count: int
    random_edge_recall_degradation_count: int


# ============================================================
# 5. 安全除法
# ============================================================

def safe_divide(
    numerator: float,
    denominator: float,
) -> float:
    if denominator == 0:
        return 0.0

    return numerator / denominator


# ============================================================
# 6. Precision / Recall / F1
# ============================================================

def calculate_prf(
    predicted_items: set,
    gold_items: set,
) -> tuple[float, float, float]:
    true_positive_count = len(
        predicted_items.intersection(
            gold_items
        )
    )

    precision = safe_divide(
        true_positive_count,
        len(predicted_items),
    )

    recall = safe_divide(
        true_positive_count,
        len(gold_items),
    )

    if precision + recall == 0:
        f1 = 0.0
    else:
        f1 = (
            2.0
            * precision
            * recall
            / (precision + recall)
        )

    return (
        round(precision, 4),
        round(recall, 4),
        round(f1, 4),
    )


# ============================================================
# 7. 路径转成边集合
# ============================================================

def build_edge_set(
    nodes: list[str],
    relations: list[str],
) -> set[tuple[str, str, str]]:
    if len(relations) != len(nodes) - 1:
        return set()

    edge_set = set()

    for index, relation in enumerate(
        relations
    ):
        edge_set.add(
            (
                nodes[index],
                relation,
                nodes[index + 1],
            )
        )

    return edge_set


# ============================================================
# 8. 获取当前案例的干扰节点
# ============================================================

def get_distractor_nodes(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
) -> list[str]:
    """
    排除 source、target 和 Gold path 节点。
    剩余节点均可作为错误 Bridge 候选。
    """

    excluded_nodes = set(
        case.gold_path_nodes
    )

    distractor_nodes = [
        node_id
        for node_id in graph.nodes
        if node_id not in excluded_nodes
    ]

    return sorted(
        distractor_nodes
    )


# ============================================================
# 9. Clean Bridge 条件
# ============================================================

def build_clean_bridges(
    case: BenchmarkCase,
) -> dict[str, float]:
    """
    仅使用 Step 12 中预设的正确 Bridge。
    """

    return dict(
        case.predicted_bridge_utilities
    )


# ============================================================
# 10. 选择与 source 最相关的错误节点
# ============================================================

def select_strong_distractor(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
) -> str | None:
    """
    优先从 source 的直接错误出邻居中选择最高置信度节点。
    若不存在，则从其他干扰节点中选择第一个。
    """

    gold_nodes = set(
        case.gold_path_nodes
    )

    direct_distractors = []

    for _, target_node, _, edge_data in (
        graph.out_edges(
            case.source_node,
            keys=True,
            data=True,
        )
    ):
        if target_node in gold_nodes:
            continue

        confidence = float(
            edge_data.get(
                "confidence",
                0.0,
            )
        )

        direct_distractors.append(
            (
                confidence,
                target_node,
            )
        )

    if direct_distractors:
        direct_distractors.sort(
            key=lambda item: (
                -item[0],
                item[1],
            )
        )

        return direct_distractors[0][1]

    distractor_nodes = get_distractor_nodes(
        graph,
        case,
    )

    if distractor_nodes:
        return distractor_nodes[0]

    return None


# ============================================================
# 11. 强噪声 Bridge 条件
# ============================================================

def build_noisy_bridges(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
) -> dict[str, float]:
    """
    强噪声条件：

    1. 保留正确 Bridge，但统一降低 utility；
    2. 加入 source 的高置信度错误直接分支；
    3. 错误 Bridge utility 高于正确 Bridge。
    """

    noisy_bridges = {
        node_id: 0.65
        for node_id
        in case.predicted_bridge_utilities
    }

    distractor_node = select_strong_distractor(
        graph,
        case,
    )

    if distractor_node is not None:
        noisy_bridges[
            distractor_node
        ] = 1.00

    return noisy_bridges


# ============================================================
# 12. 强随机错误 Bridge 条件
# ============================================================

def build_random_bridges(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
    random_generator: random.Random,
) -> dict[str, float]:
    """
    只使用错误 Bridge：

    1. 优先加入 source 的错误直接邻居；
    2. 再随机补充其他错误节点；
    3. 第一个错误 Bridge utility 设为 1.00。
    """

    distractor_nodes = get_distractor_nodes(
        graph,
        case,
    )

    selected_nodes = []

    strong_distractor = select_strong_distractor(
        graph,
        case,
    )

    if strong_distractor is not None:
        selected_nodes.append(
            strong_distractor
        )

    remaining_nodes = [
        node_id
        for node_id in distractor_nodes
        if node_id not in selected_nodes
    ]

    requested_count = max(
        1,
        len(
            case.predicted_bridge_utilities
        ),
    )

    remaining_count = min(
        requested_count
        - len(selected_nodes),
        len(remaining_nodes),
    )

    if remaining_count > 0:
        selected_nodes.extend(
            random_generator.sample(
                remaining_nodes,
                remaining_count,
            )
        )

    random_bridges = {}

    for index, node_id in enumerate(
        selected_nodes
    ):
        if index == 0:
            utility = 1.00
        else:
            utility = max(
                0.80,
                0.95 - 0.05 * index,
            )

        random_bridges[node_id] = round(
            utility,
            4,
        )

    return random_bridges


# ============================================================
# 13. 构建四种实验条件
# ============================================================

def build_condition_bridges(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
    random_generator: random.Random,
) -> dict[str, dict[str, float]]:
    return {
        "Baseline": {},

        "Clean Bridge": build_clean_bridges(
            case
        ),

        "Noisy Bridge": build_noisy_bridges(
            graph,
            case,
        ),

        "Random Bridge": build_random_bridges(
            graph,
            case,
            random_generator,
        ),
    }


# ============================================================
# 14. 评价单次搜索
# ============================================================

def evaluate_condition(
    case: BenchmarkCase,
    condition_name: str,
    supplied_bridges: dict[str, float],
    search_result,
) -> ConditionMetrics:
    predicted_nodes = list(
        search_result.path_nodes
    )

    predicted_relations = list(
        search_result.path_relations
    )

    (
        node_precision,
        node_recall,
        node_f1,
    ) = calculate_prf(
        predicted_items=set(
            predicted_nodes
        ),
        gold_items=set(
            case.gold_path_nodes
        ),
    )

    predicted_edges = build_edge_set(
        predicted_nodes,
        predicted_relations,
    )

    gold_edges = build_edge_set(
        case.gold_path_nodes,
        case.gold_path_relations,
    )

    (
        edge_precision,
        edge_recall,
        edge_f1,
    ) = calculate_prf(
        predicted_items=predicted_edges,
        gold_items=gold_edges,
    )

    exact_path_match = (
        predicted_nodes
        == case.gold_path_nodes
        and predicted_relations
        == case.gold_path_relations
    )

    return ConditionMetrics(
        case_id=case.case_id,

        condition_name=condition_name,

        found=bool(
            search_result.found
        ),

        exact_path_match=(
            exact_path_match
        ),

        node_precision=(
            node_precision
        ),

        node_recall=node_recall,

        node_f1=node_f1,

        edge_precision=(
            edge_precision
        ),

        edge_recall=edge_recall,

        edge_f1=edge_f1,

        visited_nodes=int(
            search_result.visited_nodes
        ),

        generated_nodes=int(
            getattr(
                search_result,
                "generated_nodes",
                0,
            )
        ),

        generated_states=int(
            getattr(
                search_result,
                "generated_states",
                0,
            )
        ),

        expanded_edges=int(
            search_result.expanded_edges
        ),

        search_rounds=int(
            search_result.search_rounds
        ),

        path_length=len(
            predicted_relations
        ),

        path_score=round(
            float(
                search_result.path_score
            ),
            4,
        ),

        terminated_reason=(
            search_result.terminated_reason
        ),

        path_nodes=predicted_nodes,

        path_relations=(
            predicted_relations
        ),

        reached_bridges=list(
            search_result.reached_bridges
        ),

        supplied_bridges=dict(
            supplied_bridges
        ),
    )


# ============================================================
# 15. 运行一个条件
# ============================================================

def run_condition(
    graph: nx.MultiDiGraph,
    case: BenchmarkCase,
    condition_name: str,
    supplied_bridges: dict[str, float],
) -> ConditionMetrics:
    use_bridge_guidance = (
        condition_name != "Baseline"
    )

    search_result = run_beam_search(
        graph=graph,

        source_node=case.source_node,

        target_node=case.target_node,

        bridge_utilities=(
            supplied_bridges
        ),

        use_bridge_guidance=(
            use_bridge_guidance
        ),

        method_name=condition_name,
    )

    return evaluate_condition(
        case=case,

        condition_name=condition_name,

        supplied_bridges=(
            supplied_bridges
        ),

        search_result=search_result,
    )


# ============================================================
# 16. 打印单个条件结果
# ============================================================

def print_condition_result(
    metrics: ConditionMetrics,
) -> None:
    print("\n" + "-" * 100)

    print(
        f"Condition: "
        f"{metrics.condition_name}"
    )

    print(
        f"Found complete path: "
        f"{metrics.found}"
    )

    print(
        f"Exact gold path: "
        f"{metrics.exact_path_match}"
    )

    print(
        f"Node recall: "
        f"{metrics.node_recall:.4f}"
    )

    print(
        f"Edge recall: "
        f"{metrics.edge_recall:.4f}"
    )

    print(
        f"Path score: "
        f"{metrics.path_score:.4f}"
    )

    print(
        f"Termination: "
        f"{metrics.terminated_reason}"
    )

    print(
        f"Visited nodes: "
        f"{metrics.visited_nodes}"
    )

    print(
        f"Generated nodes: "
        f"{metrics.generated_nodes}"
    )

    print(
        f"Generated states: "
        f"{metrics.generated_states}"
    )

    print(
        f"Expanded edges: "
        f"{metrics.expanded_edges}"
    )

    print(
        f"Supplied bridges: "
        f"{metrics.supplied_bridges}"
    )

    print(
        f"Reached bridges: "
        f"{metrics.reached_bridges}"
    )

    print("Path:")

    if metrics.path_nodes:
        print(
            " -> ".join(
                metrics.path_nodes
            )
        )
    else:
        print("None")

    print("Relations:")

    if metrics.path_relations:
        print(
            " -> ".join(
                metrics.path_relations
            )
        )
    else:
        print("None")


# ============================================================
# 17. 批量运行全部案例
# ============================================================

def run_ablation_experiment(
    graph: nx.MultiDiGraph,
    cases: list[BenchmarkCase],
) -> list[ConditionMetrics]:
    random_generator = random.Random(
        RANDOM_SEED
    )

    all_results = []

    for case in cases:
        print("\n" + "=" * 100)
        print(
            f"Running {case.case_id}"
        )
        print("=" * 100)

        print(
            f"Question: {case.question}"
        )

        print(
            "Gold path:"
        )

        print(
            " -> ".join(
                case.gold_path_nodes
            )
        )

        condition_bridges = (
            build_condition_bridges(
                graph,
                case,
                random_generator,
            )
        )

        for (
            condition_name,
            supplied_bridges,
        ) in condition_bridges.items():
            metrics = run_condition(
                graph=graph,

                case=case,

                condition_name=(
                    condition_name
                ),

                supplied_bridges=(
                    supplied_bridges
                ),
            )

            all_results.append(
                metrics
            )

            print_condition_result(
                metrics
            )

    return all_results


# ============================================================
# 18. 按条件汇总
# ============================================================

def aggregate_condition(
    condition_name: str,
    results: list[ConditionMetrics],
) -> ConditionAggregate:
    condition_results = [
        result
        for result in results
        if result.condition_name
        == condition_name
    ]

    if not condition_results:
        raise ValueError(
            f"No results for condition: "
            f"{condition_name}"
        )

    return ConditionAggregate(
        condition_name=condition_name,

        number_of_cases=len(
            condition_results
        ),

        success_rate=round(
            mean(
                int(result.found)
                for result in condition_results
            ),
            4,
        ),

        exact_match_rate=round(
            mean(
                int(
                    result.exact_path_match
                )
                for result
                in condition_results
            ),
            4,
        ),

        mean_node_precision=round(
            mean(
                result.node_precision
                for result
                in condition_results
            ),
            4,
        ),

        mean_node_recall=round(
            mean(
                result.node_recall
                for result
                in condition_results
            ),
            4,
        ),

        mean_node_f1=round(
            mean(
                result.node_f1
                for result
                in condition_results
            ),
            4,
        ),

        mean_edge_precision=round(
            mean(
                result.edge_precision
                for result
                in condition_results
            ),
            4,
        ),

        mean_edge_recall=round(
            mean(
                result.edge_recall
                for result
                in condition_results
            ),
            4,
        ),

        mean_edge_f1=round(
            mean(
                result.edge_f1
                for result
                in condition_results
            ),
            4,
        ),

        mean_visited_nodes=round(
            mean(
                result.visited_nodes
                for result
                in condition_results
            ),
            4,
        ),

        mean_generated_nodes=round(
            mean(
                result.generated_nodes
                for result
                in condition_results
            ),
            4,
        ),

        mean_generated_states=round(
            mean(
                result.generated_states
                for result
                in condition_results
            ),
            4,
        ),

        mean_expanded_edges=round(
            mean(
                result.expanded_edges
                for result
                in condition_results
            ),
            4,
        ),

        mean_path_length=round(
            mean(
                result.path_length
                for result
                in condition_results
            ),
            4,
        ),

        mean_path_score=round(
            mean(
                result.path_score
                for result
                in condition_results
            ),
            4,
        ),
    )


# ============================================================
# 19. 按案例构建索引
# ============================================================

def index_results_by_case(
    results: list[ConditionMetrics],
) -> dict[
    str,
    dict[str, ConditionMetrics],
]:
    indexed_results = {}

    for result in results:
        indexed_results.setdefault(
            result.case_id,
            {},
        )

        indexed_results[
            result.case_id
        ][
            result.condition_name
        ] = result

    return indexed_results


# ============================================================
# 20. 建立总体总结
# ============================================================

def build_ablation_summary(
    cases: list[BenchmarkCase],
    results: list[ConditionMetrics],
) -> AblationSummary:
    condition_names = [
        "Baseline",
        "Clean Bridge",
        "Noisy Bridge",
        "Random Bridge",
    ]

    aggregates = [
        aggregate_condition(
            condition_name,
            results,
        )
        for condition_name
        in condition_names
    ]

    indexed_results = index_results_by_case(
        results
    )

    clean_success_over_baseline_count = 0
    noisy_success_over_baseline_count = 0
    random_success_over_baseline_count = 0

    clean_failure_when_baseline_success_count = 0
    noisy_failure_when_clean_success_count = 0
    random_failure_when_clean_success_count = 0

    noisy_edge_recall_degradation_count = 0
    random_edge_recall_degradation_count = 0

    for case in cases:
        case_results = indexed_results[
            case.case_id
        ]

        baseline_result = case_results[
            "Baseline"
        ]

        clean_result = case_results[
            "Clean Bridge"
        ]

        noisy_result = case_results[
            "Noisy Bridge"
        ]

        random_result = case_results[
            "Random Bridge"
        ]

        if (
            clean_result.found
            and not baseline_result.found
        ):
            clean_success_over_baseline_count += 1

        if (
            noisy_result.found
            and not baseline_result.found
        ):
            noisy_success_over_baseline_count += 1

        if (
            random_result.found
            and not baseline_result.found
        ):
            random_success_over_baseline_count += 1

        if (
            baseline_result.found
            and not clean_result.found
        ):
            clean_failure_when_baseline_success_count += 1

        if (
            clean_result.found
            and not noisy_result.found
        ):
            noisy_failure_when_clean_success_count += 1

        if (
            clean_result.found
            and not random_result.found
        ):
            random_failure_when_clean_success_count += 1

        if (
            noisy_result.edge_recall
            < clean_result.edge_recall
        ):
            noisy_edge_recall_degradation_count += 1

        if (
            random_result.edge_recall
            < clean_result.edge_recall
        ):
            random_edge_recall_degradation_count += 1

    return AblationSummary(
        number_of_cases=len(cases),

        condition_aggregates=aggregates,

        clean_success_over_baseline_count=(
            clean_success_over_baseline_count
        ),

        noisy_success_over_baseline_count=(
            noisy_success_over_baseline_count
        ),

        random_success_over_baseline_count=(
            random_success_over_baseline_count
        ),

        clean_failure_when_baseline_success_count=(
            clean_failure_when_baseline_success_count
        ),

        noisy_failure_when_clean_success_count=(
            noisy_failure_when_clean_success_count
        ),

        random_failure_when_clean_success_count=(
            random_failure_when_clean_success_count
        ),

        noisy_edge_recall_degradation_count=(
            noisy_edge_recall_degradation_count
        ),

        random_edge_recall_degradation_count=(
            random_edge_recall_degradation_count
        ),
    )


# ============================================================
# 21. 打印总体结果
# ============================================================

def print_ablation_summary(
    summary: AblationSummary,
) -> None:
    print("\n" + "=" * 120)
    print("BRIDGE NOISE ABLATION SUMMARY")
    print("=" * 120)

    print(
        f"Number of cases: "
        f"{summary.number_of_cases}"
    )

    print("\nCondition comparison:")

    print(
        f"{'Condition':<22}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Node Recall':<15}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    print("-" * 120)

    for aggregate in (
        summary.condition_aggregates
    ):
        print(
            f"{aggregate.condition_name:<22}"
            f"{aggregate.success_rate:<12.2%}"
            f"{aggregate.exact_match_rate:<12.2%}"
            f"{aggregate.mean_node_recall:<15.4f}"
            f"{aggregate.mean_edge_recall:<15.4f}"
            f"{aggregate.mean_visited_nodes:<12.4f}"
            f"{aggregate.mean_expanded_edges:<12.4f}"
        )

    print("\nSuccess comparisons:")

    print(
        "Clean succeeded while Baseline failed: "
        f"{summary.clean_success_over_baseline_count}"
    )

    print(
        "Noisy succeeded while Baseline failed: "
        f"{summary.noisy_success_over_baseline_count}"
    )

    print(
        "Random succeeded while Baseline failed: "
        f"{summary.random_success_over_baseline_count}"
    )

    print("\nFailure comparisons:")

    print(
        "Clean failed while Baseline succeeded: "
        f"{summary.clean_failure_when_baseline_success_count}"
    )

    print(
        "Noisy failed while Clean succeeded: "
        f"{summary.noisy_failure_when_clean_success_count}"
    )

    print(
        "Random failed while Clean succeeded: "
        f"{summary.random_failure_when_clean_success_count}"
    )

    print("\nRecall degradation:")

    print(
        "Noisy edge-recall degradation cases: "
        f"{summary.noisy_edge_recall_degradation_count}"
    )

    print(
        "Random edge-recall degradation cases: "
        f"{summary.random_edge_recall_degradation_count}"
    )


# ============================================================
# 22. 保存 JSON
# ============================================================

def save_json_results(
    cases: list[BenchmarkCase],
    results: list[ConditionMetrics],
    summary: AblationSummary,
) -> None:
    output_data = {
        "experiment_name":
            "bridge_noise_ablation",

        "random_seed":
            RANDOM_SEED,

        "experiment_note": (
            "Synthetic benchmark comparing baseline, "
            "clean bridge guidance, strong noisy bridge "
            "guidance and strong random bridge guidance."
        ),

        "cases": [
            asdict(case)
            for case in cases
        ],

        "condition_results": [
            asdict(result)
            for result in results
        ],

        "summary": asdict(
            summary
        ),
    }

    output_path = Path(
        OUTPUT_JSON
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print(
        f"\nJSON saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 23. 保存 CSV
# ============================================================

def save_csv_results(
    results: list[ConditionMetrics],
) -> None:
    output_path = Path(
        OUTPUT_CSV
    )

    fieldnames = [
        "case_id",
        "condition_name",

        "found",
        "exact_path_match",

        "node_precision",
        "node_recall",
        "node_f1",

        "edge_precision",
        "edge_recall",
        "edge_f1",

        "visited_nodes",
        "generated_nodes",
        "generated_states",
        "expanded_edges",

        "search_rounds",
        "path_length",
        "path_score",

        "terminated_reason",

        "supplied_bridges",
        "reached_bridges",

        "path_nodes",
        "path_relations",
    ]

    with output_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for result in results:
            writer.writerow(
                {
                    "case_id":
                        result.case_id,

                    "condition_name":
                        result.condition_name,

                    "found":
                        result.found,

                    "exact_path_match":
                        result.exact_path_match,

                    "node_precision":
                        result.node_precision,

                    "node_recall":
                        result.node_recall,

                    "node_f1":
                        result.node_f1,

                    "edge_precision":
                        result.edge_precision,

                    "edge_recall":
                        result.edge_recall,

                    "edge_f1":
                        result.edge_f1,

                    "visited_nodes":
                        result.visited_nodes,

                    "generated_nodes":
                        result.generated_nodes,

                    "generated_states":
                        result.generated_states,

                    "expanded_edges":
                        result.expanded_edges,

                    "search_rounds":
                        result.search_rounds,

                    "path_length":
                        result.path_length,

                    "path_score":
                        result.path_score,

                    "terminated_reason":
                        result.terminated_reason,

                    "supplied_bridges":
                        json.dumps(
                            result.supplied_bridges,
                            ensure_ascii=False,
                        ),

                    "reached_bridges":
                        " | ".join(
                            result.reached_bridges
                        ),

                    "path_nodes":
                        " -> ".join(
                            result.path_nodes
                        ),

                    "path_relations":
                        " -> ".join(
                            result.path_relations
                        ),
                }
            )

    print(
        f"CSV saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 24. 主程序
# ============================================================

def main() -> None:
    print(
        "Building batch benchmark graph..."
    )

    graph = build_batch_graph()

    print(
        f"Graph loaded: "
        f"{graph.number_of_nodes()} nodes, "
        f"{graph.number_of_edges()} edges"
    )

    cases = build_benchmark_cases()

    print(
        f"Benchmark cases: "
        f"{len(cases)}"
    )

    results = run_ablation_experiment(
        graph=graph,
        cases=cases,
    )

    summary = build_ablation_summary(
        cases=cases,
        results=results,
    )

    print_ablation_summary(
        summary
    )

    save_json_results(
        cases=cases,
        results=results,
        summary=summary,
    )

    save_csv_results(
        results
    )

    print("\n" + "=" * 80)
    print("STEP 15 COMPLETED")
    print("=" * 80)

    print(
        "Strong bridge-noise ablation "
        "experiment completed successfully."
    )


if __name__ == "__main__":
    main()
