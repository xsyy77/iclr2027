import json
from pathlib import Path
from typing import Any


# ============================================================
# 1. 输入与输出文件
# ============================================================

STEP17_JSON = "step17_difficulty_alpha_grid.json"
STEP18_JSON = "step18_independent_test_results.json"
STEP19_JSON = "step19_combined_experiment_summary.json"

OUTPUT_REPORT = "step21_final_experiment_report.txt"
OUTPUT_MARKDOWN = "step21_final_experiment_report.md"


# ============================================================
# 2. JSON 读取
# ============================================================

def load_json(
    file_name: str,
) -> dict[str, Any]:
    path = Path(file_name)

    if not path.exists():
        raise FileNotFoundError(
            f"Cannot find required file: "
            f"{path.resolve()}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


# ============================================================
# 3. 查找条件结果
# ============================================================

def find_condition(
    aggregates: list[dict[str, Any]],
    condition_name: str,
) -> dict[str, Any]:
    for item in aggregates:
        if (
            item.get("condition_name")
            == condition_name
        ):
            return item

    raise ValueError(
        f"Condition not found: "
        f"{condition_name}"
    )


# ============================================================
# 4. 百分比格式
# ============================================================

def format_percent(
    value: Any,
) -> str:
    return (
        f"{float(value) * 100:.0f}%"
    )


# ============================================================
# 5. 构建英文报告
# ============================================================

def build_report(
    step17: dict[str, Any],
    step18: dict[str, Any],
    step19: dict[str, Any],
) -> str:
    recommendation = step17.get(
        "recommendation",
        {},
    )

    fixed_parameters = step18.get(
        "fixed_parameters",
        {},
    )

    aggregates = step18.get(
        "aggregate_results",
        [],
    )

    baseline = find_condition(
        aggregates,
        "Baseline",
    )

    clean = find_condition(
        aggregates,
        "Clean Bridge",
    )

    noisy = find_condition(
        aggregates,
        "Noisy Bridge",
    )

    random_bridge = find_condition(
        aggregates,
        "Random Bridge",
    )

    beam_width = fixed_parameters.get(
        "beam_width",
        recommendation.get(
            "beam_width",
            2,
        ),
    )

    bridge_alpha = fixed_parameters.get(
        "bridge_alpha",
        recommendation.get(
            "bridge_alpha",
            0.30,
        ),
    )

    lines = []

    lines.append(
        "FINAL EXPERIMENT REPORT"
    )

    lines.append(
        "=" * 80
    )

    lines.append("")

    lines.append(
        "1. Experimental Objective"
    )

    lines.append(
        ""
    )

    lines.append(
        "The experiments evaluate whether predicted bridge entities can "
        "improve constrained multi-hop graph retrieval. The bridge entities "
        "are treated as soft intermediate guidance rather than hard path "
        "constraints. The evaluation compares standard beam search with "
        "clean, noisy, and random bridge-guided search under identical "
        "search budgets."
    )

    lines.append("")

    lines.append(
        "2. Search Configuration"
    )

    lines.append("")

    lines.append(
        f"The final search configuration uses BEAM_WIDTH = {beam_width} "
        f"and BRIDGE_ALPHA = {float(bridge_alpha):.2f}. The maximum path "
        "length is eight hops, the generated-node budget is fourteen, and "
        "the expanded-edge budget is twenty. Target shortest-path distance "
        "is not used during ranking, which prevents oracle leakage from the "
        "gold target path."
    )

    lines.append("")

    lines.append(
        "Bridge utilities are calibrated before use. Extreme utility values "
        "are capped relative to the median bridge utility, and the resulting "
        "bridge score is mixed with the baseline graph score using a bounded "
        "weight. This design prevents a single high-confidence but incorrect "
        "bridge entity from completely controlling the beam."
    )

    lines.append("")

    lines.append(
        "3. Parameter Selection"
    )

    lines.append("")

    lines.append(
        "A joint grid experiment varied graph difficulty, beam width, and "
        "bridge mixing weight. The tested graph difficulty levels were easy, "
        "medium, and hard; beam widths were one and two; and bridge alpha "
        "values were 0.10, 0.20, and 0.30. The selected setting was "
        f"BEAM_WIDTH = {recommendation.get('beam_width', beam_width)} and "
        f"BRIDGE_ALPHA = "
        f"{float(recommendation.get('bridge_alpha', bridge_alpha)):.2f}."
    )

    lines.append("")

    lines.append(
        "The selected configuration provided the strongest balance between "
        "clean-bridge retrieval performance and robustness to noisy bridge "
        "predictions on the tuning cases. After this selection, the search "
        "weights were frozen before the independent evaluation."
    )

    lines.append("")

    lines.append(
        "4. Independent Test Results"
    )

    lines.append("")

    lines.append(
        "The independent test set contains four hard multi-hop cases that "
        "were not used for parameter selection. Each source node includes "
        "multiple high-confidence distractor chains, creating a setting in "
        "which local edge confidence alone is insufficient."
    )

    lines.append("")

    lines.append(
        f"Baseline beam search achieved a success rate of "
        f"{format_percent(baseline['success_rate'])} and an exact-path "
        f"match rate of {format_percent(baseline['exact_match_rate'])}. "
        f"Its mean edge recall was "
        f"{float(baseline['mean_edge_recall']):.4f}."
    )

    lines.append("")

    lines.append(
        f"Clean bridge guidance achieved a success rate of "
        f"{format_percent(clean['success_rate'])}, an exact-path match rate "
        f"of {format_percent(clean['exact_match_rate'])}, and a mean edge "
        f"recall of {float(clean['mean_edge_recall']):.4f}."
    )

    lines.append("")

    lines.append(
        f"Noisy bridge guidance retained a success rate of "
        f"{format_percent(noisy['success_rate'])} and a mean edge recall of "
        f"{float(noisy['mean_edge_recall']):.4f}. This condition contained "
        "the correct bridge set together with a high-confidence incorrect "
        "bridge, providing a direct robustness test."
    )

    lines.append("")

    lines.append(
        f"Random bridge guidance achieved a success rate of "
        f"{format_percent(random_bridge['success_rate'])} and a mean edge "
        f"recall of {float(random_bridge['mean_edge_recall']):.4f}. The "
        "failure of random bridge guidance indicates that the improvement "
        "does not result from adding arbitrary intermediate entities."
    )

    lines.append("")

    lines.append(
        "5. Search Cost"
    )

    lines.append("")

    lines.append(
        f"The baseline visited an average of "
        f"{float(baseline['mean_visited_nodes']):.4f} nodes and expanded "
        f"{float(baseline['mean_expanded_edges']):.4f} edges. Clean bridge "
        f"guidance visited an average of "
        f"{float(clean['mean_visited_nodes']):.4f} nodes and expanded "
        f"{float(clean['mean_expanded_edges']):.4f} edges. The clean guided "
        "method therefore achieved substantially higher retrieval accuracy "
        "with only a small increase in edge expansion."
    )

    lines.append("")

    lines.append(
        "6. Main Findings"
    )

    lines.append("")

    lines.append(
        "First, clean bridge guidance recovered all independent gold paths, "
        "whereas the baseline recovered none. Second, noisy bridge guidance "
        "recovered three of four independent paths, demonstrating partial "
        "robustness to high-confidence bridge noise. Third, random bridge "
        "guidance failed on all independent cases, showing that the method "
        "depends on semantically relevant bridge entities rather than merely "
        "on additional scoring terms."
    )

    lines.append("")

    lines.append(
        "7. Limitations"
    )

    lines.append("")

    lines.append(
        "The current evaluation uses synthetic neuroscience-style knowledge "
        "graphs and a small number of independent cases. The bridge entities "
        "in the batch and independent tests are controlled inputs rather than "
        "fully generated by a production LLM pipeline. The current evidence "
        "therefore demonstrates retrieval behavior and algorithmic validity, "
        "but it does not yet establish performance on a large real-world "
        "biomedical knowledge graph."
    )

    lines.append("")

    lines.append(
        "A second limitation is that relation-quality weights are manually "
        "specified. Although the final relation table was frozen before the "
        "reported independent result, future work should learn or calibrate "
        "these weights on a separate validation set."
    )

    lines.append("")

    lines.append(
        "8. Conclusion"
    )

    lines.append("")

    lines.append(
        "The experiments support the use of bridge entities as soft guidance "
        "for constrained graph retrieval. Under the independent hard-test "
        "setting, clean bridge guidance increased success from "
        f"{format_percent(baseline['success_rate'])} to "
        f"{format_percent(clean['success_rate'])}, while noisy bridge "
        f"guidance retained {format_percent(noisy['success_rate'])} success. "
        "The contrast with random bridge guidance indicates that useful "
        "intermediate semantic structure, rather than arbitrary node bias, "
        "drives the improvement."
    )

    return "\n".join(
        lines
    )


# ============================================================
# 6. 构建 Markdown 报告
# ============================================================

def build_markdown_report(
    plain_report: str,
) -> str:
    replacements = {
        "FINAL EXPERIMENT REPORT":
            "# Final Experiment Report",

        "1. Experimental Objective":
            "## 1. Experimental Objective",

        "2. Search Configuration":
            "## 2. Search Configuration",

        "3. Parameter Selection":
            "## 3. Parameter Selection",

        "4. Independent Test Results":
            "## 4. Independent Test Results",

        "5. Search Cost":
            "## 5. Search Cost",

        "6. Main Findings":
            "## 6. Main Findings",

        "7. Limitations":
            "## 7. Limitations",

        "8. Conclusion":
            "## 8. Conclusion",
    }

    markdown = plain_report

    markdown = markdown.replace(
        "=" * 80,
        "",
    )

    for source, target in (
        replacements.items()
    ):
        markdown = markdown.replace(
            source,
            target,
        )

    return markdown.strip() + "\n"


# ============================================================
# 7. 主程序
# ============================================================

def main() -> None:
    print(
        "Loading experiment results..."
    )

    step17 = load_json(
        STEP17_JSON
    )

    step18 = load_json(
        STEP18_JSON
    )

    step19 = load_json(
        STEP19_JSON
    )

    report = build_report(
        step17=step17,
        step18=step18,
        step19=step19,
    )

    markdown_report = (
        build_markdown_report(
            report
        )
    )

    report_path = Path(
        OUTPUT_REPORT
    )

    report_path.write_text(
        report,
        encoding="utf-8",
    )

    markdown_path = Path(
        OUTPUT_MARKDOWN
    )

    markdown_path.write_text(
        markdown_report,
        encoding="utf-8",
    )

    print(
        f"Text report saved to: "
        f"{report_path.resolve()}"
    )

    print(
        f"Markdown report saved to: "
        f"{markdown_path.resolve()}"
    )

    print("\n" + "=" * 80)
    print("STEP 21 COMPLETED")
    print("=" * 80)

    print(
        "The final English experiment report "
        "was generated successfully."
    )


if __name__ == "__main__":
    main()
