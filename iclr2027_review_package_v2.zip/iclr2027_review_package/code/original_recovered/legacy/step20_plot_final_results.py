import json
from pathlib import Path

import matplotlib.pyplot as plt


# ============================================================
# 1. 输入与输出
# ============================================================

INPUT_JSON = "step18_independent_test_results.json"

OUTPUT_DIRECTORY = Path(
    "step20_final_figures"
)

FIGURE_DPI = 300


# ============================================================
# 2. 读取独立测试结果
# ============================================================

def load_independent_results(
    input_file: str,
) -> dict:
    input_path = Path(
        input_file
    )

    if not input_path.exists():
        raise FileNotFoundError(
            f"Cannot find input file: "
            f"{input_path.resolve()}\n"
            "Run step18_independent_test.py first."
        )

    with input_path.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(
            file
        )


# ============================================================
# 3. 提取总体结果
# ============================================================

def extract_aggregate_results(
    data: dict,
) -> list[dict]:
    aggregates = data.get(
        "aggregate_results",
        [],
    )

    if not aggregates:
        raise ValueError(
            "aggregate_results is missing "
            "or empty in Step 18 JSON."
        )

    required_conditions = [
        "Baseline",
        "Clean Bridge",
        "Noisy Bridge",
        "Random Bridge",
    ]

    condition_map = {
        item.get(
            "condition_name"
        ): item
        for item in aggregates
    }

    missing_conditions = [
        condition
        for condition
        in required_conditions
        if condition not in condition_map
    ]

    if missing_conditions:
        raise ValueError(
            "Missing conditions: "
            + ", ".join(
                missing_conditions
            )
        )

    return [
        condition_map[
            condition
        ]
        for condition
        in required_conditions
    ]


# ============================================================
# 4. 保存图像
# ============================================================

def save_figure(
    figure,
    base_name: str,
) -> None:
    OUTPUT_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    png_path = (
        OUTPUT_DIRECTORY
        / f"{base_name}.png"
    )

    pdf_path = (
        OUTPUT_DIRECTORY
        / f"{base_name}.pdf"
    )

    figure.savefig(
        png_path,
        dpi=FIGURE_DPI,
        bbox_inches="tight",
    )

    figure.savefig(
        pdf_path,
        bbox_inches="tight",
    )

    print(
        f"Saved PNG: "
        f"{png_path.resolve()}"
    )

    print(
        f"Saved PDF: "
        f"{pdf_path.resolve()}"
    )

    plt.close(
        figure
    )


# ============================================================
# 5. 添加柱状图数值标签
# ============================================================

def add_bar_labels(
    axis,
    bars,
    value_format: str,
) -> None:
    for bar in bars:
        value = bar.get_height()

        axis.text(
            bar.get_x()
            + bar.get_width() / 2.0,
            value,
            value_format.format(
                value
            ),
            ha="center",
            va="bottom",
            fontsize=10,
        )


# ============================================================
# 6. 图 1：Success Rate
# ============================================================

def plot_success_rate(
    aggregates: list[dict],
) -> None:
    conditions = [
        item[
            "condition_name"
        ]
        for item in aggregates
    ]

    values = [
        float(
            item[
                "success_rate"
            ]
        )
        for item in aggregates
    ]

    figure, axis = plt.subplots(
        figsize=(8, 5)
    )

    bars = axis.bar(
        conditions,
        values,
    )

    axis.set_title(
        "Independent Test Success Rate"
    )

    axis.set_ylabel(
        "Success Rate"
    )

    axis.set_ylim(
        0.0,
        1.10,
    )

    axis.tick_params(
        axis="x",
        rotation=20,
    )

    add_bar_labels(
        axis,
        bars,
        "{:.0%}",
    )

    figure.tight_layout()

    save_figure(
        figure,
        "figure1_success_rate",
    )


# ============================================================
# 7. 图 2：Exact Path Match Rate
# ============================================================

def plot_exact_match_rate(
    aggregates: list[dict],
) -> None:
    conditions = [
        item[
            "condition_name"
        ]
        for item in aggregates
    ]

    values = [
        float(
            item[
                "exact_match_rate"
            ]
        )
        for item in aggregates
    ]

    figure, axis = plt.subplots(
        figsize=(8, 5)
    )

    bars = axis.bar(
        conditions,
        values,
    )

    axis.set_title(
        "Independent Test Exact Path Match Rate"
    )

    axis.set_ylabel(
        "Exact Match Rate"
    )

    axis.set_ylim(
        0.0,
        1.10,
    )

    axis.tick_params(
        axis="x",
        rotation=20,
    )

    add_bar_labels(
        axis,
        bars,
        "{:.0%}",
    )

    figure.tight_layout()

    save_figure(
        figure,
        "figure2_exact_match_rate",
    )


# ============================================================
# 8. 图 3：Mean Edge Recall
# ============================================================

def plot_mean_edge_recall(
    aggregates: list[dict],
) -> None:
    conditions = [
        item[
            "condition_name"
        ]
        for item in aggregates
    ]

    values = [
        float(
            item[
                "mean_edge_recall"
            ]
        )
        for item in aggregates
    ]

    figure, axis = plt.subplots(
        figsize=(8, 5)
    )

    bars = axis.bar(
        conditions,
        values,
    )

    axis.set_title(
        "Independent Test Mean Edge Recall"
    )

    axis.set_ylabel(
        "Mean Edge Recall"
    )

    axis.set_ylim(
        0.0,
        1.10,
    )

    axis.tick_params(
        axis="x",
        rotation=20,
    )

    add_bar_labels(
        axis,
        bars,
        "{:.2f}",
    )

    figure.tight_layout()

    save_figure(
        figure,
        "figure3_mean_edge_recall",
    )


# ============================================================
# 9. 图 4：Search Cost
# ============================================================

def plot_search_cost(
    aggregates: list[dict],
) -> None:
    conditions = [
        item[
            "condition_name"
        ]
        for item in aggregates
    ]

    visited_nodes = [
        float(
            item[
                "mean_visited_nodes"
            ]
        )
        for item in aggregates
    ]

    expanded_edges = [
        float(
            item[
                "mean_expanded_edges"
            ]
        )
        for item in aggregates
    ]

    x_positions = list(
        range(
            len(
                conditions
            )
        )
    )

    bar_width = 0.36

    left_positions = [
        position
        - bar_width / 2.0
        for position
        in x_positions
    ]

    right_positions = [
        position
        + bar_width / 2.0
        for position
        in x_positions
    ]

    figure, axis = plt.subplots(
        figsize=(9, 5)
    )

    visited_bars = axis.bar(
        left_positions,
        visited_nodes,
        width=bar_width,
        label="Visited Nodes",
    )

    expanded_bars = axis.bar(
        right_positions,
        expanded_edges,
        width=bar_width,
        label="Expanded Edges",
    )

    axis.set_title(
        "Independent Test Search Cost"
    )

    axis.set_ylabel(
        "Mean Count"
    )

    axis.set_xticks(
        x_positions
    )

    axis.set_xticklabels(
        conditions,
        rotation=20,
    )

    maximum_value = max(
        visited_nodes
        + expanded_edges
    )

    axis.set_ylim(
        0.0,
        maximum_value * 1.18,
    )

    axis.legend()

    add_bar_labels(
        axis,
        visited_bars,
        "{:.2f}",
    )

    add_bar_labels(
        axis,
        expanded_bars,
        "{:.2f}",
    )

    figure.tight_layout()

    save_figure(
        figure,
        "figure4_search_cost",
    )


# ============================================================
# 10. 保存用于论文的数值表
# ============================================================

def save_table_text(
    aggregates: list[dict],
) -> None:
    OUTPUT_DIRECTORY.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_path = (
        OUTPUT_DIRECTORY
        / "independent_test_table.txt"
    )

    header = (
        f"{'Condition':<18}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Node Recall':<15}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    rows = [
        header,
        "-" * len(
            header
        ),
    ]

    for item in aggregates:
        rows.append(
            f"{item['condition_name']:<18}"
            f"{float(item['success_rate']):<12.2%}"
            f"{float(item['exact_match_rate']):<12.2%}"
            f"{float(item['mean_node_recall']):<15.4f}"
            f"{float(item['mean_edge_recall']):<15.4f}"
            f"{float(item['mean_visited_nodes']):<12.4f}"
            f"{float(item['mean_expanded_edges']):<12.4f}"
        )

    output_path.write_text(
        "\n".join(
            rows
        ),
        encoding="utf-8",
    )

    print(
        f"Saved table: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 11. 主程序
# ============================================================

def main() -> None:
    print(
        "Loading Step 18 independent "
        "test results..."
    )

    data = load_independent_results(
        INPUT_JSON
    )

    aggregates = (
        extract_aggregate_results(
            data
        )
    )

    print(
        f"Loaded "
        f"{len(aggregates)} conditions."
    )

    plot_success_rate(
        aggregates
    )

    plot_exact_match_rate(
        aggregates
    )

    plot_mean_edge_recall(
        aggregates
    )

    plot_search_cost(
        aggregates
    )

    save_table_text(
        aggregates
    )

    print("\n" + "=" * 80)
    print("STEP 20 COMPLETED")
    print("=" * 80)

    print(
        "Four publication-ready figures "
        "were generated successfully."
    )


if __name__ == "__main__":
    main()
