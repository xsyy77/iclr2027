
import csv
import json
import math
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import mean

import networkx as nx
import step7_guided_search as search_module

SEED = 20260826
N_CASES = 200

BEAM_WIDTH = 2
BRIDGE_ALPHA = 0.30

NOISE_LEVELS = [0.25, 0.50, 0.75]

OUT_JSON = "step22_large_exploratory_results.json"
OUT_CSV = "step22_large_exploratory_results.csv"
OUT_SUMMARY = "step22_large_exploratory_summary.csv"

GOLD_RELATIONS = [
    "encodes", "impairs", "dysfunction_causes", "promotes", "causes"
]

DISTRACTOR_RELATIONS = [
    "causes", "promotes", "dysfunction_causes", "impairs"
]

TYPE_SEQUENCE = [
    "Gene", "Protein", "CellType", "BiologicalProcess",
    "NeuralProcess", "Phenotype"
]

@dataclass
class Case:
    case_id: str
    question: str
    source: str
    target: str
    gold_nodes: list[str]
    gold_relations: list[str]
    clean_bridges: dict[str, float]
    graph: nx.MultiDiGraph

def add_node(g, node_id, entity_type):
    g.add_node(
        node_id,
        name=node_id,
        entity_type=entity_type,
        description="Controlled synthetic biomedical-mechanistic node."
    )

def add_edge(g, u, v, relation, confidence):
    g.add_edge(
        u, v,
        relation=relation,
        confidence=float(confidence),
        evidence="Controlled synthetic evidence."
    )

def build_case(case_index: int, rng: random.Random) -> Case:
    g = nx.MultiDiGraph()
    prefix = f"C{case_index:04d}"

    # Gold mechanism length: 4-6 edges, always within MAX_HOPS=8.
    n_edges = rng.choice([4, 5, 6])
    n_nodes = n_edges + 1

    gold_nodes = [f"{prefix}_GOLD_{i}" for i in range(n_nodes)]
    for i, node in enumerate(gold_nodes):
        entity_type = TYPE_SEQUENCE[min(i, len(TYPE_SEQUENCE)-1)]
        add_node(g, node, entity_type)

    gold_relations = []
    for i in range(n_edges):
        # Favor mechanistically strong relations while varying the exact path.
        relation = GOLD_RELATIONS[min(i, len(GOLD_RELATIONS)-1)]
        if i >= len(GOLD_RELATIONS):
            relation = "causes"
        gold_relations.append(relation)

        # Gold path is credible but not always locally dominant.
        conf = rng.uniform(0.885, 0.945)
        add_edge(g, gold_nodes[i], gold_nodes[i+1], relation, conf)

    source = gold_nodes[0]
    target = gold_nodes[-1]

    # Build 4-6 high-confidence distractor chains from the source.
    # These are structurally valid and locally attractive, but never reach target.
    n_chains = rng.choice([4, 5, 6])
    distractor_first_nodes = []
    distractor_nodes_by_type = {}

    for c in range(n_chains):
        prev = source
        chain_len = rng.choice([4, 5])
        for j in range(1, chain_len + 1):
            node = f"{prefix}_D{c}_{j}"
            # Match intermediate type distribution to make noise non-trivial.
            entity_type = TYPE_SEQUENCE[min(j, len(TYPE_SEQUENCE)-2)]
            add_node(g, node, entity_type)
            distractor_nodes_by_type.setdefault(entity_type, []).append(node)
            if j == 1:
                distractor_first_nodes.append(node)

            relation = DISTRACTOR_RELATIONS[(j-1) % len(DISTRACTOR_RELATIONS)]
            # Distractors deliberately look stronger to the baseline.
            conf = rng.uniform(0.965, 0.997)
            add_edge(g, prev, node, relation, conf)
            prev = node

    # Add cross-links among distractors to make the graph less tree-like.
    all_dist = [n for n in g.nodes if "_D" in n]
    for _ in range(rng.randint(3, 8)):
        if len(all_dist) >= 2:
            u, v = rng.sample(all_dist, 2)
            if u != v and not nx.has_path(g, v, u):
                add_edge(
                    g, u, v,
                    rng.choice(["regulates", "supports", "associated_with"]),
                    rng.uniform(0.88, 0.96)
                )

    # Clean bridges: 3-4 intermediate gold entities, excluding source/target.
    intermediate = gold_nodes[1:-1]
    k = min(4, len(intermediate))
    # Spread anchors over the mechanism rather than taking only target-nearest nodes.
    if len(intermediate) <= k:
        selected = list(intermediate)
    else:
        idxs = sorted(set(round(i*(len(intermediate)-1)/(k-1)) for i in range(k)))
        selected = [intermediate[i] for i in idxs]

    clean_bridges = {}
    for i, node in enumerate(selected):
        clean_bridges[node] = round(0.86 + 0.03*i + rng.uniform(-0.01, 0.01), 4)

    return Case(
        case_id=prefix,
        question=f"How can {source} lead to {target}?",
        source=source,
        target=target,
        gold_nodes=gold_nodes,
        gold_relations=gold_relations,
        clean_bridges=clean_bridges,
        graph=g,
    )

def edge_set(nodes, relations):
    return set(zip(nodes[:-1], relations, nodes[1:]))

def recall(predicted, gold):
    return len(predicted & gold) / len(gold) if gold else 0.0

def type_matched_distractor(g, gold_node, rng, excluded):
    typ = g.nodes[gold_node].get("entity_type")
    candidates = [
        n for n, d in g.nodes(data=True)
        if "_D" in n and d.get("entity_type") == typ and n not in excluded
    ]
    if not candidates:
        candidates = [
            n for n in g.nodes
            if "_D" in n and n not in excluded
        ]
    return rng.choice(candidates) if candidates else None

def make_noisy(case, noise_frac, rng):
    clean_items = list(case.clean_bridges.items())
    k_replace = max(1, int(round(len(clean_items) * noise_frac)))
    replace_idxs = set(rng.sample(range(len(clean_items)), k_replace))

    result = {}
    excluded = set(case.gold_nodes)

    for i, (node, util) in enumerate(clean_items):
        if i not in replace_idxs:
            result[node] = util
            continue
        d = type_matched_distractor(case.graph, node, rng, excluded | set(result))
        if d is not None:
            # Give corrupted bridges competitive utility to test true robustness.
            result[d] = round(rng.uniform(0.88, 1.00), 4)
        else:
            result[node] = util
    return result

def make_random(case, rng):
    clean_items = list(case.clean_bridges.items())
    result = {}
    excluded = set(case.gold_nodes)
    for node, _ in clean_items:
        d = type_matched_distractor(case.graph, node, rng, excluded | set(result))
        if d is None:
            candidates = [n for n in case.graph.nodes if "_D" in n and n not in result]
            if not candidates:
                continue
            d = rng.choice(candidates)
        result[d] = round(rng.uniform(0.86, 0.98), 4)
    return result

def run_one(case, condition, bridges):
    guided = condition != "No Bridge"
    res = search_module.run_beam_search(
        graph=case.graph,
        source_node=case.source,
        target_node=case.target,
        bridge_utilities=bridges,
        use_bridge_guidance=guided,
        method_name=condition,
    )
    pred_nodes = list(res.path_nodes)
    pred_rels = list(res.path_relations)
    return {
        "case_id": case.case_id,
        "condition": condition,
        "found": int(bool(res.found)),
        "exact_match": int(pred_nodes == case.gold_nodes and pred_rels == case.gold_relations),
        "node_recall": recall(set(pred_nodes), set(case.gold_nodes)),
        "edge_recall": recall(edge_set(pred_nodes, pred_rels), edge_set(case.gold_nodes, case.gold_relations)),
        "visited_nodes": int(res.visited_nodes),
        "generated_nodes": int(res.generated_nodes),
        "generated_states": int(res.generated_states),
        "expanded_edges": int(res.expanded_edges),
        "termination": res.terminated_reason,
        "bridge_count": len(bridges),
        "reached_bridge_count": len(res.reached_bridges),
    }

def wilson_ci(successes, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = successes/n
    denom = 1 + z*z/n
    center = (p + z*z/(2*n))/denom
    half = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/denom
    return center-half, center+half

def main():
    rng = random.Random(SEED)

    old_beam = search_module.BEAM_WIDTH
    old_alpha = search_module.BRIDGE_ALPHA
    search_module.BEAM_WIDTH = BEAM_WIDTH
    search_module.BRIDGE_ALPHA = BRIDGE_ALPHA

    rows = []
    try:
        cases = [build_case(i+1, rng) for i in range(N_CASES)]
        for case in cases:
            conds = [
                ("No Bridge", {}),
                ("Clean Bridge", dict(case.clean_bridges)),
                ("25% Noise", make_noisy(case, 0.25, rng)),
                ("50% Noise", make_noisy(case, 0.50, rng)),
                ("75% Noise", make_noisy(case, 0.75, rng)),
                ("Random Bridge", make_random(case, rng)),
            ]
            for name, bridges in conds:
                rows.append(run_one(case, name, bridges))
    finally:
        search_module.BEAM_WIDTH = old_beam
        search_module.BRIDGE_ALPHA = old_alpha

    conditions = ["No Bridge","Clean Bridge","25% Noise","50% Noise","75% Noise","Random Bridge"]
    summary = []
    for c in conditions:
        sub = [r for r in rows if r["condition"] == c]
        n = len(sub)
        successes = sum(r["found"] for r in sub)
        lo, hi = wilson_ci(successes, n)
        summary.append({
            "condition": c,
            "n": n,
            "success_rate": successes/n,
            "success_ci95_low": lo,
            "success_ci95_high": hi,
            "exact_match_rate": mean(r["exact_match"] for r in sub),
            "mean_node_recall": mean(r["node_recall"] for r in sub),
            "mean_edge_recall": mean(r["edge_recall"] for r in sub),
            "mean_visited_nodes": mean(r["visited_nodes"] for r in sub),
            "mean_expanded_edges": mean(r["expanded_edges"] for r in sub),
            "mean_reached_bridges": mean(r["reached_bridge_count"] for r in sub),
        })

    Path(OUT_JSON).write_text(
        json.dumps({
            "experiment": "large_controlled_bridge_quality_exploratory_study",
            "seed": SEED,
            "n_cases": N_CASES,
            "fixed_parameters": {
                "beam_width": BEAM_WIDTH,
                "bridge_alpha": BRIDGE_ALPHA,
                "max_hops": search_module.MAX_HOPS,
                "max_generated_nodes": search_module.MAX_VISITED_NODES,
                "max_expanded_edges": search_module.MAX_EXPANDED_EDGES,
                "target_proximity_weight": search_module.TARGET_PROXIMITY_WEIGHT,
            },
            "summary": summary,
            "rows": rows,
        }, indent=2),
        encoding="utf-8",
    )

    with open(OUT_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    with open(OUT_SUMMARY, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)

    print(f"N_CASES = {N_CASES}, total runs = {len(rows)}")
    print(f"Fixed: beam={BEAM_WIDTH}, alpha={BRIDGE_ALPHA}, "
          f"max_hops={search_module.MAX_HOPS}, "
          f"node_budget={search_module.MAX_VISITED_NODES}, "
          f"edge_budget={search_module.MAX_EXPANDED_EDGES}")
    print()
    print(f"{'Condition':<15} {'Success':>9} {'95% CI':>18} {'EdgeRec':>9} {'Visited':>9} {'Expanded':>9}")
    for s in summary:
        print(
            f"{s['condition']:<15} "
            f"{s['success_rate']*100:>8.1f}% "
            f"[{s['success_ci95_low']*100:5.1f},{s['success_ci95_high']*100:5.1f}] "
            f"{s['mean_edge_recall']:>9.3f} "
            f"{s['mean_visited_nodes']:>9.2f} "
            f"{s['mean_expanded_edges']:>9.2f}"
        )

if __name__ == "__main__":
    main()
