import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import networkx as nx

from step1_build_graph import build_neuroscience_graph


# ============================================================
# 1. 搜索参数
# ============================================================

# 压力测试设置：每轮只保留一条路径
BEAM_WIDTH = 1

MAX_HOPS = 8
MAX_VISITED_NODES = 14
MAX_EXPANDED_EDGES = 20

# Baseline 主体权重
EDGE_CONFIDENCE_WEIGHT = 0.40
TARGET_PROXIMITY_WEIGHT = 0.00
RELATION_QUALITY_WEIGHT = 0.25

# Bridge 仅作为有限辅助信号
BRIDGE_GUIDANCE_WEIGHT = 0.30

LENGTH_PENALTY_WEIGHT = 0.05

# Guided 最终混合中 Bridge 所占比例
BRIDGE_ALPHA = 0.30


# ============================================================
# 2. 路径状态
# ============================================================

@dataclass
class SearchState:
    nodes: list[str]
    relations: list[str]
    edge_confidences: list[float]

    path_score: float = 0.0

    edge_score: float = 0.0
    target_score: float = 0.0
    bridge_score: float = 0.0
    relation_score: float = 0.0
    length_penalty: float = 0.0

    reached_bridges: list[str] = field(
        default_factory=list
    )

    @property
    def current_node(self) -> str:
        return self.nodes[-1]

    @property
    def hop_count(self) -> int:
        return len(self.relations)


# ============================================================
# 3. 搜索结果
# ============================================================

@dataclass
class SearchResult:
    method_name: str

    found: bool

    source_node: str
    target_node: str

    path_nodes: list[str]
    path_relations: list[str]

    path_score: float

    reached_bridges: list[str]

    # 真正进入 Beam 并被扩展的不同节点
    visited_nodes: int

    # 所有生成过的不同节点
    generated_nodes: int

    # 所有生成的有效路径状态
    generated_states: int

    # 被读取和检查的出边数
    expanded_edges: int

    search_rounds: int
    terminated_reason: str
    final_beam_size: int

    all_complete_paths: list[dict] = field(
        default_factory=list
    )


# ============================================================
# 4. 读取 Step 6 输出
# ============================================================

def load_step6_results(
    input_file: str,
) -> dict:
    input_path = Path(input_file)

    if not input_path.exists():
        raise FileNotFoundError(
            f"Cannot find: {input_path.resolve()}\n"
            "Run step6_select_bridges.py first."
        )

    with input_path.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


# ============================================================
# 5. 边置信度
# ============================================================

def calculate_edge_score(
    edge_confidences: list[float],
) -> float:
    if not edge_confidences:
        return 0.0

    average_confidence = (
        sum(edge_confidences)
        / len(edge_confidences)
    )

    return max(
        0.0,
        min(1.0, average_confidence),
    )


# ============================================================
# 6. 目标接近度
# ============================================================

def calculate_target_proximity(
    graph: nx.MultiDiGraph,
    current_node: str,
    target_node: str,
) -> float:
    """
    不使用到 target 的真实最短距离。

    当前权重为 0，仅保留输出字段兼容性。
    """

    if current_node == target_node:
        return 1.0

    return 0.0


# ============================================================
# 7. Bridge utility 鲁棒校准
# ============================================================

def calibrate_bridge_utilities(
    bridge_utilities: dict[str, float],
) -> dict[str, float]:
    """
    防止单个异常高分 Bridge 完全主导搜索。

    处理：
    1. utility 截断到 0 至 1；
    2. 计算中位数；
    3. 单个 utility 最多高于中位数 0.15；
    4. 将分数压缩到 0.5 至 1.0。
    """

    if not bridge_utilities:
        return {}

    clipped_values = sorted(
        max(
            0.0,
            min(1.0, float(value)),
        )
        for value in bridge_utilities.values()
    )

    count = len(
        clipped_values
    )

    middle = count // 2

    if count % 2 == 1:
        median_utility = (
            clipped_values[middle]
        )
    else:
        median_utility = (
            clipped_values[middle - 1]
            + clipped_values[middle]
        ) / 2.0

    maximum_allowed = min(
        1.0,
        median_utility + 0.15,
    )

    calibrated = {}

    for node_id, raw_utility in (
        bridge_utilities.items()
    ):
        clipped_utility = max(
            0.0,
            min(1.0, float(raw_utility)),
        )

        capped_utility = min(
            clipped_utility,
            maximum_allowed,
        )

        calibrated_utility = (
            0.5
            + 0.5 * capped_utility
        )

        calibrated[node_id] = round(
            calibrated_utility,
            4,
        )

    return calibrated


# ============================================================
# 8. 鲁棒 Bridge 引导评分
# ============================================================

def calculate_bridge_guidance(
    graph: nx.MultiDiGraph,
    path_nodes: list[str],
    current_node: str,
    bridge_utilities: dict[str, float],
) -> tuple[float, list[str]]:
    """
    鲁棒 Bridge 引导。

    原则：
    1. Bridge 只作为辅助信号；
    2. 奖励覆盖多个不同 Bridge；
    3. 单个错误 Bridge 不产生永久高奖励；
    4. 仅最近两跳中的 Bridge 贡献进展奖励；
    5. 不使用 target 的真实最短距离。
    """

    if not bridge_utilities:
        return 0.0, []

    calibrated_utilities = (
        calibrate_bridge_utilities(
            bridge_utilities
        )
    )

    reached_bridges = [
        node_id
        for node_id in path_nodes
        if node_id in calibrated_utilities
    ]

    # 去重但保留路径出现顺序
    unique_reached = list(
        dict.fromkeys(
            reached_bridges
        )
    )

    total_bridge_count = len(
        calibrated_utilities
    )

    reached_count = len(
        unique_reached
    )

    # 1. Bridge 覆盖率
    coverage_score = (
        reached_count
        / total_bridge_count
        if total_bridge_count > 0
        else 0.0
    )

    # 2. 已覆盖 Bridge 的平均 utility
    if unique_reached:
        reached_utility_score = (
            sum(
                calibrated_utilities[
                    node_id
                ]
                for node_id
                in unique_reached
            )
            / len(unique_reached)
        )
    else:
        reached_utility_score = 0.0

    # 3. 当前节点是 Bridge 的局部奖励
    current_bridge_bonus = (
        calibrated_utilities.get(
            current_node,
            0.0,
        )
    )

    # 4. 最近两跳是否持续推进
    recent_nodes = path_nodes[
        -2:
    ]

    recent_bridge_count = sum(
        1
        for node_id in recent_nodes
        if node_id in calibrated_utilities
    )

    recent_progress_score = min(
        1.0,
        recent_bridge_count / 2.0,
    )

    # 5. 单 Bridge 饱和限制
    if reached_count <= 1:
        saturation_factor = 0.65
    elif reached_count == 2:
        saturation_factor = 0.85
    else:
        saturation_factor = 1.00

    raw_bridge_score = (
        0.45 * coverage_score
        + 0.25 * reached_utility_score
        + 0.15 * current_bridge_bonus
        + 0.15 * recent_progress_score
    )

    bridge_score = (
        raw_bridge_score
        * saturation_factor
    )

    return (
        min(
            1.0,
            max(
                0.0,
                bridge_score,
            ),
        ),
        unique_reached,
    )


# ============================================================
# 9. 关系质量
# ============================================================

def calculate_relation_quality(
    relations: list[str],
) -> float:
    if not relations:
        return 0.0

    relation_weights = {
        "encodes": 0.90,
        "loss_of_function_causes": 1.00,
        "impairs": 0.95,
        "dysfunction_causes": 1.00,
        "promotes": 0.95,
        "causes": 1.00,

        "targets": 0.85,
        "disruption_causes": 0.95,
        "regulates": 0.65,
        "supports": 0.60,
        "contains": 0.55,

        "participates_in": 0.50,
        "involves": 0.45,
        "associated_with": 0.40,
        "metabolized_by": 0.35,

        "occurs_in": 0.30,
        "located_in": 0.20,
    }

    scores = [
        relation_weights.get(
            relation,
            0.40,
        )
        for relation in relations
    ]

    return sum(scores) / len(scores)


# ============================================================
# 10. 路径长度惩罚
# ============================================================

def calculate_length_penalty(
    hop_count: int,
    maximum_hops: int,
) -> float:
    if maximum_hops <= 0:
        return 0.0

    return min(
        1.0,
        hop_count / maximum_hops,
    )


# ============================================================
# 11. 完整路径评分
# ============================================================

def score_search_state(
    graph: nx.MultiDiGraph,
    state: SearchState,
    target_node: str,
    bridge_utilities: dict[str, float],
    use_bridge_guidance: bool,
) -> SearchState:
    edge_score = calculate_edge_score(
        state.edge_confidences
    )

    target_score = calculate_target_proximity(
        graph=graph,
        current_node=state.current_node,
        target_node=target_node,
    )

    if use_bridge_guidance:
        (
            bridge_score,
            reached_bridges,
        ) = calculate_bridge_guidance(
            graph=graph,
            path_nodes=state.nodes,
            current_node=state.current_node,
            bridge_utilities=bridge_utilities,
        )
    else:
        bridge_score = 0.0
        reached_bridges = []

    relation_score = calculate_relation_quality(
        state.relations
    )

    length_penalty = calculate_length_penalty(
        hop_count=state.hop_count,
        maximum_hops=MAX_HOPS,
    )

    # Baseline 主体分数
    baseline_weight_sum = (
        EDGE_CONFIDENCE_WEIGHT
        + TARGET_PROXIMITY_WEIGHT
        + RELATION_QUALITY_WEIGHT
    )

    baseline_positive_score = (
        EDGE_CONFIDENCE_WEIGHT
        * edge_score

        + TARGET_PROXIMITY_WEIGHT
        * target_score

        + RELATION_QUALITY_WEIGHT
        * relation_score
    )

    if baseline_weight_sum > 0:
        baseline_normalized_score = (
            baseline_positive_score
            / baseline_weight_sum
        )
    else:
        baseline_normalized_score = 0.0

    # Guided 只对 Baseline 进行有限修正
    if use_bridge_guidance:
        normalized_positive_score = (
            (1.0 - BRIDGE_ALPHA)
            * baseline_normalized_score

            + BRIDGE_ALPHA
            * bridge_score
        )
    else:
        normalized_positive_score = (
            baseline_normalized_score
        )

    path_score = (
        normalized_positive_score
        - LENGTH_PENALTY_WEIGHT
        * length_penalty
    )

    state.edge_score = round(
        edge_score,
        4,
    )

    state.target_score = round(
        target_score,
        4,
    )

    state.bridge_score = round(
        bridge_score,
        4,
    )

    state.relation_score = round(
        relation_score,
        4,
    )

    state.length_penalty = round(
        length_penalty,
        4,
    )

    state.path_score = round(
        path_score,
        4,
    )

    state.reached_bridges = (
        reached_bridges
    )

    return state


# ============================================================
# 12. 获取所有出边
# ============================================================

def get_outgoing_edges(
    graph: nx.MultiDiGraph,
    node_id: str,
) -> list[tuple[str, str, float]]:
    outgoing_edges = []

    for _, target, _, edge_data in (
        graph.out_edges(
            node_id,
            keys=True,
            data=True,
        )
    ):
        relation = edge_data.get(
            "relation",
            "unknown_relation",
        )

        confidence = float(
            edge_data.get(
                "confidence",
                0.5,
            )
        )

        outgoing_edges.append(
            (
                target,
                relation,
                confidence,
            )
        )

    return outgoing_edges


# ============================================================
# 13. 循环检查
# ============================================================

def can_expand_to_node(
    state: SearchState,
    next_node: str,
) -> bool:
    return next_node not in state.nodes


# ============================================================
# 14. 状态去重
# ============================================================

def deduplicate_states(
    states: list[SearchState],
) -> list[SearchState]:
    state_map: dict[
        tuple[tuple[str, ...], tuple[str, ...]],
        SearchState,
    ] = {}

    for state in states:
        signature = (
            tuple(state.nodes),
            tuple(state.relations),
        )

        previous = state_map.get(
            signature
        )

        if (
            previous is None
            or state.path_score
            > previous.path_score
        ):
            state_map[signature] = state

    return list(
        state_map.values()
    )


# ============================================================
# 15. Beam Search
# ============================================================

def run_beam_search(
    graph: nx.MultiDiGraph,
    source_node: str,
    target_node: str,
    bridge_utilities: dict[str, float],
    use_bridge_guidance: bool,
    method_name: str,
) -> SearchResult:
    initial_state = SearchState(
        nodes=[source_node],
        relations=[],
        edge_confidences=[],
    )

    initial_state = score_search_state(
        graph=graph,
        state=initial_state,
        target_node=target_node,
        bridge_utilities=bridge_utilities,
        use_bridge_guidance=(
            use_bridge_guidance
        ),
    )

    beam = [
        initial_state
    ]

    generated_node_set = {
        source_node
    }

    expanded_node_set: set[str] = set()

    expanded_edges = 0
    generated_states = 0
    search_rounds = 0

    complete_paths: list[
        SearchState
    ] = []

    terminated_reason = (
        "maximum_hops_reached"
    )

    budget_exhausted = False

    for search_round in range(
        1,
        MAX_HOPS + 1,
    ):
        search_rounds = search_round

        next_states: list[
            SearchState
        ] = []

        for state in beam:
            expanded_node_set.add(
                state.current_node
            )

            if state.current_node == target_node:
                complete_paths.append(
                    state
                )
                continue

            outgoing_edges = get_outgoing_edges(
                graph=graph,
                node_id=state.current_node,
            )

            for (
                next_node,
                relation,
                confidence,
            ) in outgoing_edges:
                if (
                    expanded_edges
                    >= MAX_EXPANDED_EDGES
                ):
                    terminated_reason = (
                        "edge_budget_exhausted"
                    )
                    budget_exhausted = True
                    break

                expanded_edges += 1

                if not can_expand_to_node(
                    state=state,
                    next_node=next_node,
                ):
                    continue

                new_state = SearchState(
                    nodes=(
                        state.nodes
                        + [next_node]
                    ),

                    relations=(
                        state.relations
                        + [relation]
                    ),

                    edge_confidences=(
                        state.edge_confidences
                        + [confidence]
                    ),
                )

                new_state = score_search_state(
                    graph=graph,
                    state=new_state,
                    target_node=target_node,
                    bridge_utilities=(
                        bridge_utilities
                    ),
                    use_bridge_guidance=(
                        use_bridge_guidance
                    ),
                )

                generated_states += 1

                generated_node_set.add(
                    next_node
                )

                if next_node == target_node:
                    complete_paths.append(
                        new_state
                    )
                else:
                    next_states.append(
                        new_state
                    )

                if (
                    len(generated_node_set)
                    >= MAX_VISITED_NODES
                ):
                    terminated_reason = (
                        "node_budget_exhausted"
                    )
                    budget_exhausted = True
                    break

            if budget_exhausted:
                break

        if complete_paths:
            terminated_reason = (
                "target_reached"
            )
            break

        if budget_exhausted:
            break

        if not next_states:
            terminated_reason = (
                "no_more_paths"
            )
            break

        next_states = deduplicate_states(
            next_states
        )

        next_states.sort(
            key=lambda candidate: (
                -candidate.path_score,
                candidate.hop_count,
                tuple(candidate.nodes),
            )
        )

        beam = next_states[
            :BEAM_WIDTH
        ]

    # 选择最终状态
    if complete_paths:
        complete_paths = (
            deduplicate_states(
                complete_paths
            )
        )

        complete_paths.sort(
            key=lambda candidate: (
                -candidate.path_score,
                candidate.hop_count,
                tuple(candidate.nodes),
            )
        )

        best_state = complete_paths[0]
        found = True

    else:
        if beam:
            beam.sort(
                key=lambda candidate: (
                    -candidate.path_score,
                    candidate.hop_count,
                    tuple(candidate.nodes),
                )
            )

            best_state = beam[0]
        else:
            best_state = initial_state

        found = False

    all_complete_paths = [
        {
            "nodes": complete_state.nodes,

            "relations":
                complete_state.relations,

            "path_score":
                complete_state.path_score,

            "reached_bridges":
                complete_state.reached_bridges,

            "edge_score":
                complete_state.edge_score,

            "bridge_score":
                complete_state.bridge_score,

            "relation_score":
                complete_state.relation_score,
        }
        for complete_state in complete_paths
    ]

    return SearchResult(
        method_name=method_name,

        found=found,

        source_node=source_node,
        target_node=target_node,

        path_nodes=best_state.nodes,

        path_relations=(
            best_state.relations
        ),

        path_score=(
            best_state.path_score
        ),

        reached_bridges=(
            best_state.reached_bridges
        ),

        visited_nodes=len(
            expanded_node_set
        ),

        generated_nodes=len(
            generated_node_set
        ),

        generated_states=(
            generated_states
        ),

        expanded_edges=(
            expanded_edges
        ),

        search_rounds=(
            search_rounds
        ),

        terminated_reason=(
            terminated_reason
        ),

        final_beam_size=len(
            beam
        ),

        all_complete_paths=(
            all_complete_paths
        ),
    )


# ============================================================
# 16. 打印路径
# ============================================================

def print_path(
    graph: nx.MultiDiGraph,
    path_nodes: list[str],
    path_relations: list[str],
) -> None:
    if not path_nodes:
        print("No path.")
        return

    for index, node_id in enumerate(
        path_nodes
    ):
        node_name = graph.nodes[
            node_id
        ].get(
            "name",
            node_id,
        )

        print(
            f"{index:02d}. "
            f"{node_id} | {node_name}"
        )

        if index < len(
            path_relations
        ):
            print(
                "    "
                f"--[{path_relations[index]}]-->"
            )


# ============================================================
# 17. 打印搜索结果
# ============================================================

def print_search_result(
    graph: nx.MultiDiGraph,
    result: SearchResult,
) -> None:
    print("\n" + "=" * 90)
    print(result.method_name)
    print("=" * 90)

    print(
        f"Found complete path: "
        f"{result.found}"
    )

    print(
        f"Path score: "
        f"{result.path_score:.4f}"
    )

    print(
        f"Visited nodes: "
        f"{result.visited_nodes}"
    )

    print(
        f"Generated nodes: "
        f"{result.generated_nodes}"
    )

    print(
        f"Generated states: "
        f"{result.generated_states}"
    )

    print(
        f"Expanded edges: "
        f"{result.expanded_edges}"
    )

    print(
        f"Search rounds: "
        f"{result.search_rounds}"
    )

    print(
        f"Termination: "
        f"{result.terminated_reason}"
    )

    print(
        "Reached bridges: "
        + (
            ", ".join(
                result.reached_bridges
            )
            if result.reached_bridges
            else "None"
        )
    )

    print("\nBest path:")

    print_path(
        graph=graph,
        path_nodes=result.path_nodes,
        path_relations=(
            result.path_relations
        ),
    )


# ============================================================
# 18. 比较搜索方法
# ============================================================

def print_method_comparison(
    baseline: SearchResult,
    guided: SearchResult,
) -> None:
    print("\n" + "=" * 110)
    print("SEARCH METHOD COMPARISON")
    print("=" * 110)

    print(
        f"{'Metric':<34}"
        f"{'Baseline Beam':<28}"
        f"{'Bridge-Guided Beam':<28}"
    )

    print("-" * 110)

    comparison_rows = [
        (
            "Complete path found",
            baseline.found,
            guided.found,
        ),
        (
            "Path score",
            f"{baseline.path_score:.4f}",
            f"{guided.path_score:.4f}",
        ),
        (
            "Visited nodes",
            baseline.visited_nodes,
            guided.visited_nodes,
        ),
        (
            "Generated nodes",
            baseline.generated_nodes,
            guided.generated_nodes,
        ),
        (
            "Generated states",
            baseline.generated_states,
            guided.generated_states,
        ),
        (
            "Expanded edges",
            baseline.expanded_edges,
            guided.expanded_edges,
        ),
        (
            "Search rounds",
            baseline.search_rounds,
            guided.search_rounds,
        ),
        (
            "Path length",
            len(
                baseline.path_relations
            ),
            len(
                guided.path_relations
            ),
        ),
    ]

    for metric, baseline_value, guided_value in (
        comparison_rows
    ):
        print(
            f"{metric:<34}"
            f"{str(baseline_value):<28}"
            f"{str(guided_value):<28}"
        )


# ============================================================
# 19. 保存结果
# ============================================================

def save_search_results(
    step6_data: dict,
    baseline_result: SearchResult,
    guided_result: SearchResult,
    output_file: str,
) -> None:
    output_data = {
        "question": step6_data.get(
            "question"
        ),

        "source_entity_id": (
            step6_data.get(
                "source_entity_id"
            )
        ),

        "target_entity_id": (
            step6_data.get(
                "target_entity_id"
            )
        ),

        "search_parameters": {
            "beam_width": BEAM_WIDTH,

            "maximum_hops":
                MAX_HOPS,

            "maximum_generated_nodes":
                MAX_VISITED_NODES,

            "maximum_expanded_edges":
                MAX_EXPANDED_EDGES,

            "edge_confidence_weight":
                EDGE_CONFIDENCE_WEIGHT,

            "target_proximity_weight":
                TARGET_PROXIMITY_WEIGHT,

            "relation_quality_weight":
                RELATION_QUALITY_WEIGHT,

            "bridge_guidance_weight":
                BRIDGE_GUIDANCE_WEIGHT,

            "bridge_alpha":
                BRIDGE_ALPHA,

            "length_penalty_weight":
                LENGTH_PENALTY_WEIGHT,
        },

        "metric_definitions": {
            "visited_nodes": (
                "Distinct nodes that entered the beam "
                "and were actually expanded."
            ),

            "generated_nodes": (
                "Distinct nodes generated before "
                "beam pruning."
            ),

            "generated_states": (
                "Valid path states generated before "
                "beam pruning."
            ),

            "expanded_edges": (
                "Outgoing edges read and examined "
                "during search."
            ),
        },

        "baseline_search": asdict(
            baseline_result
        ),

        "bridge_guided_search": asdict(
            guided_result
        ),
    }

    output_path = Path(
        output_file
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print(
        "\nSearch results saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 20. 主程序
# ============================================================

def main() -> None:
    print(
        "Loading neuroscience graph..."
    )

    graph = build_neuroscience_graph()

    print(
        f"Graph loaded: "
        f"{graph.number_of_nodes()} nodes, "
        f"{graph.number_of_edges()} edges"
    )

    print(
        "\nLoading selected bridge entities..."
    )

    step6_data = load_step6_results(
        "step6_selected_bridges.json"
    )

    source_node = step6_data.get(
        "source_entity_id"
    )

    target_node = step6_data.get(
        "target_entity_id"
    )

    if source_node is None:
        raise ValueError(
            "source_entity_id is missing."
        )

    if target_node is None:
        raise ValueError(
            "target_entity_id is missing."
        )

    if source_node not in graph:
        raise ValueError(
            f"Source node not in graph: "
            f"{source_node}"
        )

    if target_node not in graph:
        raise ValueError(
            f"Target node not in graph: "
            f"{target_node}"
        )

    selected_bridges = step6_data.get(
        "selected_bridges",
        [],
    )

    bridge_utilities: dict[
        str,
        float,
    ] = {}

    for bridge in selected_bridges:
        node_id = bridge.get(
            "node_id"
        )

        if node_id is None:
            continue

        if node_id not in graph:
            print(
                f"Skipping bridge not found "
                f"in graph: {node_id}"
            )
            continue

        original_utility = float(
            bridge.get(
                "original_utility",
                0.0,
            )
        )

        selection_gain = float(
            bridge.get(
                "selection_gain",
                0.0,
            )
        )

        bridge_utility = (
            original_utility
            + selection_gain
        ) / 2.0

        bridge_utilities[node_id] = max(
            0.0,
            min(1.0, bridge_utility),
        )

    print(
        f"Source node: {source_node}"
    )

    print(
        f"Target node: {target_node}"
    )

    print(
        f"Selected bridges: "
        f"{list(bridge_utilities.keys())}"
    )

    baseline_result = run_beam_search(
        graph=graph,

        source_node=source_node,

        target_node=target_node,

        bridge_utilities={},

        use_bridge_guidance=False,

        method_name=(
            "Baseline Beam Search"
        ),
    )

    guided_result = run_beam_search(
        graph=graph,

        source_node=source_node,

        target_node=target_node,

        bridge_utilities=(
            bridge_utilities
        ),

        use_bridge_guidance=True,

        method_name=(
            "Bridge-Guided Beam Search"
        ),
    )

    print_search_result(
        graph=graph,
        result=baseline_result,
    )

    print_search_result(
        graph=graph,
        result=guided_result,
    )

    print_method_comparison(
        baseline=baseline_result,
        guided=guided_result,
    )

    save_search_results(
        step6_data=step6_data,

        baseline_result=(
            baseline_result
        ),

        guided_result=(
            guided_result
        ),

        output_file=(
            "step7_search_results.json"
        ),
    )

    print("\n" + "=" * 80)
    print("STEP 7 COMPLETED")
    print("=" * 80)

    print(
        "Robust baseline and bridge-guided "
        "graph searches completed successfully."
    )


if __name__ == "__main__":
    main()
