import csv
import json
import random

from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean

import networkx as nx

import step7_guided_search as search_module


# ============================================================
# 1. 固定主参数
# ============================================================

FIXED_BEAM_WIDTH = 2
FIXED_BRIDGE_ALPHA = 0.30

RANDOM_SEED = 2026

OUTPUT_JSON = "step18_independent_test_results.json"
OUTPUT_CSV = "step18_independent_test_results.csv"


# ============================================================
# 2. 独立测试案例
# ============================================================

@dataclass
class IndependentCase:
    case_id: str
    question: str

    source_node: str
    target_node: str

    gold_path_nodes: list[str]
    gold_path_relations: list[str]

    clean_bridges: dict[str, float]


# ============================================================
# 3. 单次结果
# ============================================================

@dataclass
class TestResult:
    case_id: str
    condition_name: str

    found: bool
    exact_path_match: bool

    node_recall: float
    edge_recall: float

    visited_nodes: int
    generated_nodes: int
    generated_states: int
    expanded_edges: int

    path_score: float
    termination: str

    supplied_bridges: dict[str, float]
    reached_bridges: list[str]

    path_nodes: list[str]
    path_relations: list[str]


# ============================================================
# 4. 汇总结果
# ============================================================

@dataclass
class AggregateResult:
    condition_name: str

    number_of_cases: int

    success_rate: float
    exact_match_rate: float

    mean_node_recall: float
    mean_edge_recall: float

    mean_visited_nodes: float
    mean_generated_nodes: float
    mean_generated_states: float
    mean_expanded_edges: float


# ============================================================
# 5. 添加节点和边
# ============================================================

def add_node(
    graph: nx.MultiDiGraph,
    node_id: str,
    name: str,
    entity_type: str,
) -> None:
    graph.add_node(
        node_id,
        name=name,
        entity_type=entity_type,
        description=(
            "Synthetic independent-test node."
        ),
    )


def add_edge(
    graph: nx.MultiDiGraph,
    source: str,
    target: str,
    relation: str,
    confidence: float,
) -> None:
    graph.add_edge(
        source,
        target,
        relation=relation,
        confidence=confidence,
        evidence=(
            "Synthetic independent-test evidence."
        ),
    )


# ============================================================
# 6. 添加强干扰链
# ============================================================

def add_distractor_chain(
    graph: nx.MultiDiGraph,
    source_node: str,
    prefix: str,
    chain_index: int,
    length: int = 4,
) -> None:
    previous = source_node

    relations = [
        "causes",
        "promotes",
        "regulates",
        "supports",
    ]

    for step in range(
        1,
        length + 1,
    ):
        node_id = (
            f"{prefix}_DISTRACTOR_"
            f"{chain_index}_{step}"
        )

        add_node(
            graph,
            node_id,
            f"{prefix.lower()} distractor "
            f"{chain_index}-{step}",
            "BiologicalProcess",
        )

        add_edge(
            graph,
            previous,
            node_id,
            relations[
                (step - 1)
                % len(relations)
            ],
            0.995,
        )

        previous = node_id


# ============================================================
# 7. 构建独立测试图
# ============================================================

def build_independent_graph() -> nx.MultiDiGraph:
    graph = nx.MultiDiGraph()

    # --------------------------------------------------------
    # TEST 1: Gene E -> Memory impairment
    # --------------------------------------------------------

    for node_id, name, entity_type in [
        ("GENE_E", "Gene E", "Gene"),
        ("PROTEIN_E", "Protein E", "Protein"),
        ("HIPPOCAMPAL_NEURON", "hippocampal neuron", "CellType"),
        ("SYNAPTIC_PLASTICITY_E", "impaired synaptic plasticity", "NeuralProcess"),
        ("MEMORY_NETWORK_E", "memory network dysfunction", "NeuralProcess"),
        ("MEMORY_IMPAIRMENT", "memory impairment", "Phenotype"),
    ]:
        add_node(
            graph,
            node_id,
            name,
            entity_type,
        )

    add_edge(graph, "GENE_E", "PROTEIN_E", "encodes", 0.93)
    add_edge(graph, "PROTEIN_E", "HIPPOCAMPAL_NEURON", "supports", 0.91)
    add_edge(graph, "HIPPOCAMPAL_NEURON", "SYNAPTIC_PLASTICITY_E", "dysfunction_causes", 0.94)
    add_edge(graph, "SYNAPTIC_PLASTICITY_E", "MEMORY_NETWORK_E", "impairs", 0.93)
    add_edge(graph, "MEMORY_NETWORK_E", "MEMORY_IMPAIRMENT", "causes", 0.95)

    # --------------------------------------------------------
    # TEST 2: Drug F -> Reduced tremor
    # --------------------------------------------------------

    for node_id, name, entity_type in [
        ("DRUG_F", "Drug F", "Drug"),
        ("RECEPTOR_F", "Receptor F", "Protein"),
        ("DOPAMINE_SIGNAL_F", "dopamine signaling", "NeuralProcess"),
        ("BASAL_GANGLIA_F", "basal ganglia circuit", "NeuralCircuit"),
        ("MOTOR_STABILITY_F", "motor stability", "NeuralProcess"),
        ("REDUCED_TREMOR", "reduced tremor", "Phenotype"),
    ]:
        add_node(
            graph,
            node_id,
            name,
            entity_type,
        )

    add_edge(graph, "DRUG_F", "RECEPTOR_F", "targets", 0.94)
    add_edge(graph, "RECEPTOR_F", "DOPAMINE_SIGNAL_F", "regulates", 0.92)
    add_edge(graph, "DOPAMINE_SIGNAL_F", "BASAL_GANGLIA_F", "supports", 0.91)
    add_edge(graph, "BASAL_GANGLIA_F", "MOTOR_STABILITY_F", "promotes", 0.94)
    add_edge(graph, "MOTOR_STABILITY_F", "REDUCED_TREMOR", "causes", 0.93)

    # --------------------------------------------------------
    # TEST 3: Region G -> Language deficit
    # --------------------------------------------------------

    for node_id, name, entity_type in [
        ("REGION_G", "Brain Region G", "BrainRegion"),
        ("LOCAL_NETWORK_G", "local language network", "NeuralCircuit"),
        ("WHITE_MATTER_G", "white matter connectivity", "NeuralProcess"),
        ("LANGUAGE_NETWORK_G", "language network dysfunction", "NeuralProcess"),
        ("LANGUAGE_DEFICIT", "language deficit", "Phenotype"),
    ]:
        add_node(
            graph,
            node_id,
            name,
            entity_type,
        )

    add_edge(graph, "REGION_G", "LOCAL_NETWORK_G", "contains", 0.90)
    add_edge(graph, "LOCAL_NETWORK_G", "WHITE_MATTER_G", "supports", 0.91)
    add_edge(graph, "WHITE_MATTER_G", "LANGUAGE_NETWORK_G", "disruption_causes", 0.95)
    add_edge(graph, "LANGUAGE_NETWORK_G", "LANGUAGE_DEFICIT", "causes", 0.96)

    # --------------------------------------------------------
    # TEST 4: Mutation H -> Sensory hypersensitivity
    # --------------------------------------------------------

    for node_id, name, entity_type in [
        ("MUTATION_H", "Mutation H", "Variant"),
        ("CHANNEL_H", "Ion Channel H", "IonChannel"),
        ("SENSORY_NEURON_H", "sensory neuron", "CellType"),
        ("SENSORY_GAIN_H", "increased sensory gain", "NeuralProcess"),
        ("SENSORY_NETWORK_H", "sensory network hyperreactivity", "NeuralProcess"),
        ("SENSORY_HYPERSENSITIVITY", "sensory hypersensitivity", "Phenotype"),
    ]:
        add_node(
            graph,
            node_id,
            name,
            entity_type,
        )

    add_edge(graph, "MUTATION_H", "CHANNEL_H", "affects", 0.92)
    add_edge(graph, "CHANNEL_H", "SENSORY_NEURON_H", "impairs", 0.93)
    add_edge(graph, "SENSORY_NEURON_H", "SENSORY_GAIN_H", "dysfunction_causes", 0.94)
    add_edge(graph, "SENSORY_GAIN_H", "SENSORY_NETWORK_H", "promotes", 0.95)
    add_edge(graph, "SENSORY_NETWORK_H", "SENSORY_HYPERSENSITIVITY", "causes", 0.96)

    # 每个 source 添加 4 条强干扰链
    source_prefix_pairs = [
        ("GENE_E", "TEST1"),
        ("DRUG_F", "TEST2"),
        ("REGION_G", "TEST3"),
        ("MUTATION_H", "TEST4"),
    ]

    for source_node, prefix in (
        source_prefix_pairs
    ):
        for chain_index in range(
            1,
            5,
        ):
            add_distractor_chain(
                graph=graph,
                source_node=source_node,
                prefix=prefix,
                chain_index=chain_index,
                length=4,
            )

    return graph


# ============================================================
# 8. 构建独立测试案例
# ============================================================

def build_independent_cases() -> list[IndependentCase]:
    return [
        IndependentCase(
            case_id="TEST_001",
            question=(
                "How can Gene E dysfunction "
                "lead to memory impairment?"
            ),
            source_node="GENE_E",
            target_node="MEMORY_IMPAIRMENT",
            gold_path_nodes=[
                "GENE_E",
                "PROTEIN_E",
                "HIPPOCAMPAL_NEURON",
                "SYNAPTIC_PLASTICITY_E",
                "MEMORY_NETWORK_E",
                "MEMORY_IMPAIRMENT",
            ],
            gold_path_relations=[
                "encodes",
                "supports",
                "dysfunction_causes",
                "impairs",
                "causes",
            ],
            clean_bridges={
                "PROTEIN_E": 0.88,
                "HIPPOCAMPAL_NEURON": 0.92,
                "SYNAPTIC_PLASTICITY_E": 0.91,
                "MEMORY_NETWORK_E": 0.93,
            },
        ),
        IndependentCase(
            case_id="TEST_002",
            question=(
                "How can Drug F reduce tremor?"
            ),
            source_node="DRUG_F",
            target_node="REDUCED_TREMOR",
            gold_path_nodes=[
                "DRUG_F",
                "RECEPTOR_F",
                "DOPAMINE_SIGNAL_F",
                "BASAL_GANGLIA_F",
                "MOTOR_STABILITY_F",
                "REDUCED_TREMOR",
            ],
            gold_path_relations=[
                "targets",
                "regulates",
                "supports",
                "promotes",
                "causes",
            ],
            clean_bridges={
                "RECEPTOR_F": 0.90,
                "DOPAMINE_SIGNAL_F": 0.92,
                "BASAL_GANGLIA_F": 0.91,
                "MOTOR_STABILITY_F": 0.93,
            },
        ),
        IndependentCase(
            case_id="TEST_003",
            question=(
                "How can dysfunction in Brain Region G "
                "cause language deficit?"
            ),
            source_node="REGION_G",
            target_node="LANGUAGE_DEFICIT",
            gold_path_nodes=[
                "REGION_G",
                "LOCAL_NETWORK_G",
                "WHITE_MATTER_G",
                "LANGUAGE_NETWORK_G",
                "LANGUAGE_DEFICIT",
            ],
            gold_path_relations=[
                "contains",
                "supports",
                "disruption_causes",
                "causes",
            ],
            clean_bridges={
                "LOCAL_NETWORK_G": 0.89,
                "WHITE_MATTER_G": 0.92,
                "LANGUAGE_NETWORK_G": 0.94,
            },
        ),
        IndependentCase(
            case_id="TEST_004",
            question=(
                "How can Mutation H produce "
                "sensory hypersensitivity?"
            ),
            source_node="MUTATION_H",
            target_node="SENSORY_HYPERSENSITIVITY",
            gold_path_nodes=[
                "MUTATION_H",
                "CHANNEL_H",
                "SENSORY_NEURON_H",
                "SENSORY_GAIN_H",
                "SENSORY_NETWORK_H",
                "SENSORY_HYPERSENSITIVITY",
            ],
            gold_path_relations=[
                "affects",
                "impairs",
                "dysfunction_causes",
                "promotes",
                "causes",
            ],
            clean_bridges={
                "CHANNEL_H": 0.89,
                "SENSORY_NEURON_H": 0.92,
                "SENSORY_GAIN_H": 0.91,
                "SENSORY_NETWORK_H": 0.94,
            },
        ),
    ]


# ============================================================
# 9. Precision / Recall
# ============================================================

def safe_divide(
    numerator: float,
    denominator: float,
) -> float:
    if denominator == 0:
        return 0.0

    return numerator / denominator


def calculate_recall(
    predicted: set,
    gold: set,
) -> float:
    return round(
        safe_divide(
            len(
                predicted.intersection(
                    gold
                )
            ),
            len(gold),
        ),
        4,
    )


def build_edge_set(
    nodes: list[str],
    relations: list[str],
) -> set[tuple[str, str, str]]:
    if len(relations) != len(nodes) - 1:
        return set()

    return {
        (
            nodes[index],
            relations[index],
            nodes[index + 1],
        )
        for index in range(
            len(relations)
        )
    }


# ============================================================
# 10. 构建噪声条件
# ============================================================

def get_direct_distractors(
    graph: nx.MultiDiGraph,
    case: IndependentCase,
) -> list[str]:
    gold_nodes = set(
        case.gold_path_nodes
    )

    candidates = []

    for _, target, _, edge_data in (
        graph.out_edges(
            case.source_node,
            keys=True,
            data=True,
        )
    ):
        if target in gold_nodes:
            continue

        candidates.append(
            (
                float(
                    edge_data.get(
                        "confidence",
                        0.0,
                    )
                ),
                target,
            )
        )

    candidates.sort(
        key=lambda item: (
            -item[0],
            item[1],
        )
    )

    return [
        node_id
        for _, node_id in candidates
    ]


def build_noisy_bridges(
    graph: nx.MultiDiGraph,
    case: IndependentCase,
) -> dict[str, float]:
    noisy = {
        node_id: 0.65
        for node_id
        in case.clean_bridges
    }

    direct_distractors = (
        get_direct_distractors(
            graph,
            case,
        )
    )

    if direct_distractors:
        noisy[
            direct_distractors[0]
        ] = 1.00

    return noisy


def build_random_bridges(
    graph: nx.MultiDiGraph,
    case: IndependentCase,
    random_generator: random.Random,
) -> dict[str, float]:
    gold_nodes = set(
        case.gold_path_nodes
    )

    distractors = [
        node_id
        for node_id in graph.nodes
        if node_id not in gold_nodes
    ]

    selected = []

    direct_distractors = (
        get_direct_distractors(
            graph,
            case,
        )
    )

    if direct_distractors:
        selected.append(
            direct_distractors[0]
        )

    remaining = [
        node_id
        for node_id in distractors
        if node_id not in selected
    ]

    requested = max(
        1,
        len(case.clean_bridges),
    )

    additional_count = min(
        requested - len(selected),
        len(remaining),
    )

    if additional_count > 0:
        selected.extend(
            random_generator.sample(
                remaining,
                additional_count,
            )
        )

    result = {}

    for index, node_id in enumerate(
        selected
    ):
        if index == 0:
            utility = 1.00
        else:
            utility = max(
                0.80,
                0.95 - 0.05 * index,
            )

        result[node_id] = round(
            utility,
            4,
        )

    return result


# ============================================================
# 11. 运行单个条件
# ============================================================

def run_condition(
    graph: nx.MultiDiGraph,
    case: IndependentCase,
    condition_name: str,
    supplied_bridges: dict[str, float],
) -> TestResult:
    use_bridge_guidance = (
        condition_name != "Baseline"
    )

    search_result = (
        search_module.run_beam_search(
            graph=graph,

            source_node=case.source_node,

            target_node=case.target_node,

            bridge_utilities=(
                supplied_bridges
            ),

            use_bridge_guidance=(
                use_bridge_guidance
            ),

            method_name=condition_name,
        )
    )

    predicted_nodes = list(
        search_result.path_nodes
    )

    predicted_relations = list(
        search_result.path_relations
    )

    node_recall = calculate_recall(
        predicted=set(
            predicted_nodes
        ),
        gold=set(
            case.gold_path_nodes
        ),
    )

    edge_recall = calculate_recall(
        predicted=build_edge_set(
            predicted_nodes,
            predicted_relations,
        ),
        gold=build_edge_set(
            case.gold_path_nodes,
            case.gold_path_relations,
        ),
    )

    exact_match = (
        predicted_nodes
        == case.gold_path_nodes
        and predicted_relations
        == case.gold_path_relations
    )

    return TestResult(
        case_id=case.case_id,

        condition_name=condition_name,

        found=bool(
            search_result.found
        ),

        exact_path_match=(
            exact_match
        ),

        node_recall=node_recall,

        edge_recall=edge_recall,

        visited_nodes=int(
            search_result.visited_nodes
        ),

        generated_nodes=int(
            search_result.generated_nodes
        ),

        generated_states=int(
            search_result.generated_states
        ),

        expanded_edges=int(
            search_result.expanded_edges
        ),

        path_score=round(
            float(
                search_result.path_score
            ),
            4,
        ),

        termination=(
            search_result
            .terminated_reason
        ),

        supplied_bridges=dict(
            supplied_bridges
        ),

        reached_bridges=list(
            search_result.reached_bridges
        ),

        path_nodes=predicted_nodes,

        path_relations=(
            predicted_relations
        ),
    )


# ============================================================
# 12. 运行独立测试
# ============================================================

def run_independent_test(
    graph: nx.MultiDiGraph,
    cases: list[IndependentCase],
) -> list[TestResult]:
    all_results = []

    original_beam_width = (
        search_module.BEAM_WIDTH
    )

    original_alpha = (
        search_module.BRIDGE_ALPHA
    )

    search_module.BEAM_WIDTH = (
        FIXED_BEAM_WIDTH
    )

    search_module.BRIDGE_ALPHA = (
        FIXED_BRIDGE_ALPHA
    )

    try:
        random_generator = random.Random(
            RANDOM_SEED
        )

        for case in cases:
            conditions = {
                "Baseline": {},

                "Clean Bridge": dict(
                    case.clean_bridges
                ),

                "Noisy Bridge": (
                    build_noisy_bridges(
                        graph,
                        case,
                    )
                ),

                "Random Bridge": (
                    build_random_bridges(
                        graph,
                        case,
                        random_generator,
                    )
                ),
            }

            print("\n" + "=" * 100)
            print(case.case_id)
            print(case.question)
            print("=" * 100)

            for (
                condition_name,
                supplied_bridges,
            ) in conditions.items():
                result = run_condition(
                    graph=graph,
                    case=case,
                    condition_name=(
                        condition_name
                    ),
                    supplied_bridges=(
                        supplied_bridges
                    ),
                )

                all_results.append(
                    result
                )

                print(
                    f"{condition_name:<15} "
                    f"found={str(result.found):<5} "
                    f"exact="
                    f"{str(result.exact_path_match):<5} "
                    f"edge_recall="
                    f"{result.edge_recall:.4f} "
                    f"visited="
                    f"{result.visited_nodes} "
                    f"expanded="
                    f"{result.expanded_edges}"
                )

    finally:
        search_module.BEAM_WIDTH = (
            original_beam_width
        )

        search_module.BRIDGE_ALPHA = (
            original_alpha
        )

    return all_results


# ============================================================
# 13. 汇总
# ============================================================

def aggregate_results(
    results: list[TestResult],
) -> list[AggregateResult]:
    condition_names = [
        "Baseline",
        "Clean Bridge",
        "Noisy Bridge",
        "Random Bridge",
    ]

    aggregates = []

    for condition_name in (
        condition_names
    ):
        subset = [
            result
            for result in results
            if result.condition_name
            == condition_name
        ]

        aggregates.append(
            AggregateResult(
                condition_name=(
                    condition_name
                ),

                number_of_cases=len(
                    subset
                ),

                success_rate=round(
                    mean(
                        int(result.found)
                        for result in subset
                    ),
                    4,
                ),

                exact_match_rate=round(
                    mean(
                        int(
                            result
                            .exact_path_match
                        )
                        for result in subset
                    ),
                    4,
                ),

                mean_node_recall=round(
                    mean(
                        result.node_recall
                        for result in subset
                    ),
                    4,
                ),

                mean_edge_recall=round(
                    mean(
                        result.edge_recall
                        for result in subset
                    ),
                    4,
                ),

                mean_visited_nodes=round(
                    mean(
                        result.visited_nodes
                        for result in subset
                    ),
                    4,
                ),

                mean_generated_nodes=round(
                    mean(
                        result.generated_nodes
                        for result in subset
                    ),
                    4,
                ),

                mean_generated_states=round(
                    mean(
                        result.generated_states
                        for result in subset
                    ),
                    4,
                ),

                mean_expanded_edges=round(
                    mean(
                        result.expanded_edges
                        for result in subset
                    ),
                    4,
                ),
            )
        )

    return aggregates


# ============================================================
# 14. 打印汇总
# ============================================================

def print_summary(
    aggregates: list[AggregateResult],
) -> None:
    print("\n" + "=" * 120)
    print("INDEPENDENT TEST SUMMARY")
    print("=" * 120)

    print(
        f"Fixed BEAM_WIDTH: "
        f"{FIXED_BEAM_WIDTH}"
    )

    print(
        f"Fixed BRIDGE_ALPHA: "
        f"{FIXED_BRIDGE_ALPHA:.2f}"
    )

    print(
        f"\n{'Condition':<18}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Node Recall':<15}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    print("-" * 120)

    for aggregate in aggregates:
        print(
            f"{aggregate.condition_name:<18}"
            f"{aggregate.success_rate:<12.2%}"
            f"{aggregate.exact_match_rate:<12.2%}"
            f"{aggregate.mean_node_recall:<15.4f}"
            f"{aggregate.mean_edge_recall:<15.4f}"
            f"{aggregate.mean_visited_nodes:<12.4f}"
            f"{aggregate.mean_expanded_edges:<12.4f}"
        )


# ============================================================
# 15. 保存结果
# ============================================================

def save_results(
    detailed_results: list[TestResult],
    aggregates: list[AggregateResult],
) -> None:
    output_data = {
        "experiment_name":
            "independent_generalization_test",

        "fixed_parameters": {
            "beam_width":
                FIXED_BEAM_WIDTH,

            "bridge_alpha":
                FIXED_BRIDGE_ALPHA,

            "maximum_hops":
                search_module.MAX_HOPS,

            "maximum_generated_nodes":
                search_module
                .MAX_VISITED_NODES,

            "maximum_expanded_edges":
                search_module
                .MAX_EXPANDED_EDGES,
        },

        "detailed_results": [
            asdict(result)
            for result in detailed_results
        ],

        "aggregate_results": [
            asdict(aggregate)
            for aggregate in aggregates
        ],
    }

    json_path = Path(
        OUTPUT_JSON
    )

    with json_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    csv_path = Path(
        OUTPUT_CSV
    )

    fieldnames = [
        "case_id",
        "condition_name",

        "found",
        "exact_path_match",

        "node_recall",
        "edge_recall",

        "visited_nodes",
        "generated_nodes",
        "generated_states",
        "expanded_edges",

        "path_score",
        "termination",

        "supplied_bridges",
        "reached_bridges",

        "path_nodes",
        "path_relations",
    ]

    with csv_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for result in detailed_results:
            writer.writerow(
                {
                    "case_id":
                        result.case_id,

                    "condition_name":
                        result.condition_name,

                    "found":
                        result.found,

                    "exact_path_match":
                        result
                        .exact_path_match,

                    "node_recall":
                        result.node_recall,

                    "edge_recall":
                        result.edge_recall,

                    "visited_nodes":
                        result.visited_nodes,

                    "generated_nodes":
                        result.generated_nodes,

                    "generated_states":
                        result.generated_states,

                    "expanded_edges":
                        result.expanded_edges,

                    "path_score":
                        result.path_score,

                    "termination":
                        result.termination,

                    "supplied_bridges":
                        json.dumps(
                            result
                            .supplied_bridges,
                            ensure_ascii=False,
                        ),

                    "reached_bridges":
                        " | ".join(
                            result
                            .reached_bridges
                        ),

                    "path_nodes":
                        " -> ".join(
                            result.path_nodes
                        ),

                    "path_relations":
                        " -> ".join(
                            result
                            .path_relations
                        ),
                }
            )

    print(
        f"\nJSON saved to: "
        f"{json_path.resolve()}"
    )

    print(
        f"CSV saved to: "
        f"{csv_path.resolve()}"
    )


# ============================================================
# 16. 主程序
# ============================================================

def main() -> None:
    graph = build_independent_graph()

    cases = build_independent_cases()

    print(
        f"Independent graph: "
        f"{graph.number_of_nodes()} nodes, "
        f"{graph.number_of_edges()} edges"
    )

    print(
        f"Independent cases: "
        f"{len(cases)}"
    )

    detailed_results = (
        run_independent_test(
            graph=graph,
            cases=cases,
        )
    )

    aggregates = aggregate_results(
        detailed_results
    )

    print_summary(
        aggregates
    )

    save_results(
        detailed_results=(
            detailed_results
        ),
        aggregates=aggregates,
    )

    print("\n" + "=" * 80)
    print("STEP 18 COMPLETED")
    print("=" * 80)

    print(
        "Independent generalization test "
        "completed successfully."
    )


if __name__ == "__main__":
    main()
