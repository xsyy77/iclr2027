
import math, random, json
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd, torch, torch.nn as nn
import step22_large_exploratory_study as exp

search_module=exp.search_module
gate_df=pd.read_csv('step27_gate_training_samples.csv')
cand_df=pd.read_csv('step27_confidence_training_samples.csv')
SEEDS=[20260826,20260827,20260828,20260829,20260830,20260831,20260832]
TRAIN=SEEDS[:4]; VAL=[SEEDS[4]]; TEST=SEEDS[5:]
N=200; EASY=.40
REL=['encodes','impairs','dysfunction_causes','promotes','causes','regulates','supports','associated_with']
TYPES=exp.TYPE_SEQUENCE

def build(i,rng):
    c=exp.build_case(i,rng); easy=rng.random()<EASY
    if easy:
        gp=set(zip(c.gold_nodes[:-1],c.gold_nodes[1:]))
        for u,v,k,d in c.graph.edges(keys=True,data=True):
            if (u,v) in gp:d['confidence']=rng.uniform(.94,.98)
            elif '_D' in u or '_D' in v:d['confidence']=rng.uniform(.80,.88)
    return c,easy

def bsets(c,rng):
    return {'Clean Bridge':dict(c.clean_bridges),'25% Noise':exp.make_noisy(c,.25,rng),'50% Noise':exp.make_noisy(c,.5,rng),'75% Noise':exp.make_noisy(c,.75,rng),'Random Bridge':exp.make_random(c,rng)}

def nf(c,n):
    g=c.graph; typ=g.nodes[n].get('entity_type',''); f=[1.0 if typ==t else 0.0 for t in TYPES]
    i,o=g.in_degree(n),g.out_degree(n); f += [math.log1p(i),math.log1p(o),math.log1p(i+o),1.0 if g.has_edge(c.source,n) else 0.0]
    inc=[];out=[];rc=Counter()
    for u,v,k,d in g.in_edges(n,keys=True,data=True):inc.append(float(d.get('confidence',0)));rc[d.get('relation','')]+=1
    for u,v,k,d in g.out_edges(n,keys=True,data=True):out.append(float(d.get('confidence',0)));rc[d.get('relation','')]+=1
    f += [np.mean(inc) if inc else 0,np.mean(out) if out else 0,np.std(inc) if len(inc)>1 else 0,np.std(out) if len(out)>1 else 0]
    tot=sum(rc.values()) or 1; f += [rc[r]/tot for r in REL]; f += [math.log1p(g.out_degree(c.source)),math.log1p(g.in_degree(c.target))]
    return np.asarray(f,np.float32)

class MLP(nn.Module):
    def __init__(self,d):
        super().__init__(); self.net=nn.Sequential(nn.Linear(d,64),nn.ReLU(),nn.Dropout(.1),nn.Linear(64,32),nn.ReLU(),nn.Dropout(.1),nn.Linear(32,1))
    def forward(self,x):return self.net(x)

ck=torch.load('step28_gate_onoff_model.pt',weights_only=False); mean=np.asarray(ck['scaler_mean']); scale=np.asarray(ck['scaler_scale'])
model=MLP(len(mean)); model.load_state_dict(ck['state']); model.eval()

cases=[]
for s in SEEDS:
    rng=random.Random(s); split='train' if s in TRAIN else ('val' if s in VAL else 'test')
    for i in range(N):
        c,e=build(i+1,rng); sets=bsets(c,rng); cases.append({'uid':f'{s}_{c.case_id}','split':split,'case':c,'sets':sets})
case_by={r['uid']:r for r in cases}; cl={(r.uid,r.node):float(r.pred_conf) for r in cand_df.itertuples()}

F=[]
for gr in gate_df.itertuples():
    rec=case_by[gr.uid]; c=rec['case']; bs=rec['sets'][gr.condition]; cs=np.array([cl[(gr.uid,h)] for h in bs])
    z=np.stack([nf(c,h) for h in bs]); w=cs/(cs.sum()+1e-8); pool=(z*w[:,None]).sum(0)
    F.append(np.concatenate([pool,[cs.mean(),cs.max(),cs.min(),cs.std(),len(cs)/5,math.log1p(c.graph.out_degree(c.source)),math.log1p(c.graph.in_degree(c.target))]]))
X=(np.stack(F)-mean)/scale
with torch.no_grad():pon=torch.sigmoid(model(torch.tensor(X,dtype=torch.float32))).squeeze().numpy()

def run(c,u,a):
    oa,ob=search_module.BRIDGE_ALPHA,search_module.BEAM_WIDTH; search_module.BRIDGE_ALPHA=float(a);search_module.BEAM_WIDTH=2
    try:return exp.run_one(c,'X' if u else 'No Bridge',u)
    finally:search_module.BRIDGE_ALPHA=oa;search_module.BEAM_WIDTH=ob

def M(r):return .7*float(r['found'])+.3*float(r['edge_recall'])

# Precompute validation outcomes on dense alpha grid.
agrid=np.round(np.arange(0,.501,.025),3)
val_idx=np.where(gate_df.split.values=='val')[0]
cache={}
for i in val_idx:
    gr=gate_df.iloc[i]; rec=case_by[gr.uid];c=rec['case'];bs=rec['sets'][gr.condition];u={h:cl[(gr.uid,h)] for h in bs}
    for a in agrid:cache[(i,float(a))]=run(c,u,float(a))

def nearest_grid(a):return float(agrid[np.argmin(np.abs(agrid-float(a)))])
rows=[]
for gmax in [.20,.25,.30,.35,.40,.45,.50]:
  for gamma in [.5,.75,1.0,1.25,1.5,2.0]:
    fs=[];ers=[];utils=[]
    for i in val_idx:
        a=gmax*(float(pon[i])**gamma); rr=cache[(i,nearest_grid(a))];fs.append(rr['found']);ers.append(rr['edge_recall']);utils.append(M(rr))
    rows.append({'gmax':gmax,'gamma':gamma,'success':np.mean(fs),'edge_recall':np.mean(ers),'utility':np.mean(utils)})
sel=pd.DataFrame(rows).sort_values(['success','edge_recall'],ascending=[False,False]); best=sel.iloc[0]; gmax=float(best.gmax); gamma=float(best.gamma)

# Held-out test exact continuous gate.
out=[]
for i in np.where(gate_df.split.values=='test')[0]:
    gr=gate_df.iloc[i];rec=case_by[gr.uid];c=rec['case'];bs=rec['sets'][gr.condition];pred={h:cl[(gr.uid,h)] for h in bs};g=gmax*(float(pon[i])**gamma)
    methods={'Graph Only':({},0.0),'Fixed-alpha Handcrafted':(bs,.3),'Learned Confidence + Fixed Gate':(pred,.3),'Full Continuous Learned Gate':(pred,g)}
    for m,(u,a) in methods.items():
        rr=run(c,u,a);out.append({'uid':gr.uid,'condition':gr.condition,'method':m,'alpha':a,'found':rr['found'],'edge_recall':rr['edge_recall'],'p_reliable':pon[i]})
res=pd.DataFrame(out)
overall=res.groupby('method').agg(n=('found','size'),success_rate=('found','mean'),edge_recall=('edge_recall','mean'),mean_alpha=('alpha','mean')).reset_index()
by=res.groupby(['method','condition']).agg(n=('found','size'),success_rate=('found','mean'),edge_recall=('edge_recall','mean'),mean_alpha=('alpha','mean')).reset_index()
behavior=res[res.method=='Full Continuous Learned Gate'].groupby('condition').agg(n=('alpha','size'),mean_gate=('alpha','mean'),median_gate=('alpha','median'),mean_reliability=('p_reliable','mean')).reset_index()

# paired bootstrap
rng=np.random.default_rng(20260833)
def boot(b,metric,B=5000):
    a=res[res.method=='Full Continuous Learned Gate'][['uid','condition',metric]].rename(columns={metric:'a'});bb=res[res.method==b][['uid','condition',metric]].rename(columns={metric:'b'});m=a.merge(bb,on=['uid','condition']);d=(m.a-m.b).to_numpy(float);ix=rng.integers(0,len(d),size=(B,len(d)));z=d[ix].mean(1);return d.mean(),np.quantile(z,.025),np.quantile(z,.975)
com=[]
for b in ['Graph Only','Fixed-alpha Handcrafted','Learned Confidence + Fixed Gate']:
  for metric in ['found','edge_recall']:
    d,l,h=boot(b,metric);com.append({'comparison':f'Full Continuous Learned Gate - {b}','metric':metric,'mean_diff':d,'ci95_low':l,'ci95_high':h})
comp=pd.DataFrame(com)
sel.to_csv('step30_continuous_gate_validation_grid.csv',index=False);res.to_csv('step30_continuous_gate_detailed.csv',index=False);overall.to_csv('step30_continuous_gate_overall.csv',index=False);by.to_csv('step30_continuous_gate_by_condition.csv',index=False);behavior.to_csv('step30_continuous_gate_behavior.csv',index=False);comp.to_csv('step30_continuous_gate_bootstrap.csv',index=False)
Path('step30_continuous_gate_report.json').write_text(json.dumps({'gmax':gmax,'gamma':gamma,'validation_top':sel.head(10).to_dict(orient='records'),'overall':overall.to_dict(orient='records'),'by_condition':by.to_dict(orient='records'),'behavior':behavior.to_dict(orient='records'),'bootstrap':comp.to_dict(orient='records')},indent=2))
print('selected gmax',gmax,'gamma',gamma);print('\nvalidation top');print(sel.head(10).to_string(index=False,float_format=lambda x:f'{x:.4f}'));print('\noverall');print(overall.to_string(index=False,float_format=lambda x:f'{x:.4f}'));print('\nby');print(by.to_string(index=False,float_format=lambda x:f'{x:.4f}'));print('\nbehavior');print(behavior.to_string(index=False,float_format=lambda x:f'{x:.4f}'));print('\nbootstrap');print(comp.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
