import csv
import json

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


# ============================================================
# 1. 输入与输出文件
# ============================================================

STEP15_JSON = "step15_bridge_noise_ablation.json"
STEP16_JSON = "step16_bridge_alpha_sensitivity.json"
STEP17_JSON = "step17_difficulty_alpha_grid.json"
STEP18_JSON = "step18_independent_test_results.json"

OUTPUT_JSON = "step19_combined_experiment_summary.json"
OUTPUT_CSV = "step19_combined_experiment_summary.csv"


# ============================================================
# 2. 总表中的一行
# ============================================================

@dataclass
class SummaryRow:
    experiment: str
    setting: str
    condition: str

    success_rate: float | None
    exact_match_rate: float | None
    mean_node_recall: float | None
    mean_edge_recall: float | None

    mean_visited_nodes: float | None
    mean_expanded_edges: float | None

    note: str


# ============================================================
# 3. JSON 读取
# ============================================================

def load_json(
    file_name: str,
) -> dict[str, Any] | None:
    path = Path(file_name)

    if not path.exists():
        print(
            f"WARNING: missing file: "
            f"{path.resolve()}"
        )
        return None

    with path.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


# ============================================================
# 4. 安全读取数值
# ============================================================

def as_float(
    value: Any,
) -> float | None:
    if value is None:
        return None

    try:
        return round(
            float(value),
            4,
        )
    except (
        TypeError,
        ValueError,
    ):
        return None


# ============================================================
# 5. 读取 Step 15
# ============================================================

def extract_step15_rows(
    data: dict[str, Any],
) -> list[SummaryRow]:
    rows = []

    summary = data.get(
        "summary",
        {},
    )

    aggregates = summary.get(
        "condition_aggregates",
        [],
    )

    for item in aggregates:
        rows.append(
            SummaryRow(
                experiment=(
                    "Step 15: Noise ablation"
                ),

                setting=(
                    "Easy graph; current Step 7 parameters"
                ),

                condition=item.get(
                    "condition_name",
                    "Unknown",
                ),

                success_rate=as_float(
                    item.get(
                        "success_rate"
                    )
                ),

                exact_match_rate=as_float(
                    item.get(
                        "exact_match_rate"
                    )
                ),

                mean_node_recall=as_float(
                    item.get(
                        "mean_node_recall"
                    )
                ),

                mean_edge_recall=as_float(
                    item.get(
                        "mean_edge_recall"
                    )
                ),

                mean_visited_nodes=as_float(
                    item.get(
                        "mean_visited_nodes"
                    )
                ),

                mean_expanded_edges=as_float(
                    item.get(
                        "mean_expanded_edges"
                    )
                ),

                note=(
                    "Noise stress test on the "
                    "original easy benchmark graph."
                ),
            )
        )

    return rows


# ============================================================
# 6. 读取 Step 16
# ============================================================

def extract_step16_rows(
    data: dict[str, Any],
) -> list[SummaryRow]:
    rows = []

    recommended_alpha = data.get(
        "recommended_alpha"
    )

    aggregates = data.get(
        "aggregate_results",
        [],
    )

    for item in aggregates:
        alpha = item.get(
            "bridge_alpha"
        )

        rows.append(
            SummaryRow(
                experiment=(
                    "Step 16: Alpha sensitivity"
                ),

                setting=(
                    f"BRIDGE_ALPHA={alpha}"
                ),

                condition=item.get(
                    "condition_name",
                    "Unknown",
                ),

                success_rate=as_float(
                    item.get(
                        "success_rate"
                    )
                ),

                exact_match_rate=as_float(
                    item.get(
                        "exact_match_rate"
                    )
                ),

                mean_node_recall=as_float(
                    item.get(
                        "mean_node_recall"
                    )
                ),

                mean_edge_recall=as_float(
                    item.get(
                        "mean_edge_recall"
                    )
                ),

                mean_visited_nodes=as_float(
                    item.get(
                        "mean_visited_nodes"
                    )
                ),

                mean_expanded_edges=as_float(
                    item.get(
                        "mean_expanded_edges"
                    )
                ),

                note=(
                    "Recommended alpha in this "
                    f"experiment: {recommended_alpha}."
                ),
            )
        )

    return rows


# ============================================================
# 7. 读取 Step 17
# ============================================================

def extract_step17_rows(
    data: dict[str, Any],
) -> list[SummaryRow]:
    rows = []

    recommendation = data.get(
        "recommendation",
        {},
    )

    aggregates = data.get(
        "aggregate_results",
        [],
    )

    for item in aggregates:
        difficulty = item.get(
            "difficulty"
        )

        beam_width = item.get(
            "beam_width"
        )

        alpha = item.get(
            "bridge_alpha"
        )

        rows.append(
            SummaryRow(
                experiment=(
                    "Step 17: Difficulty grid"
                ),

                setting=(
                    f"difficulty={difficulty}; "
                    f"beam={beam_width}; "
                    f"alpha={alpha}"
                ),

                condition=item.get(
                    "condition_name",
                    "Unknown",
                ),

                success_rate=as_float(
                    item.get(
                        "success_rate"
                    )
                ),

                exact_match_rate=as_float(
                    item.get(
                        "exact_match_rate"
                    )
                ),

                mean_node_recall=as_float(
                    item.get(
                        "mean_node_recall"
                    )
                ),

                mean_edge_recall=as_float(
                    item.get(
                        "mean_edge_recall"
                    )
                ),

                mean_visited_nodes=as_float(
                    item.get(
                        "mean_visited_nodes"
                    )
                ),

                mean_expanded_edges=as_float(
                    item.get(
                        "mean_expanded_edges"
                    )
                ),

                note=(
                    "Recommended setting: "
                    f"beam={recommendation.get('beam_width')}, "
                    f"alpha={recommendation.get('bridge_alpha')}."
                ),
            )
        )

    return rows


# ============================================================
# 8. 读取 Step 18
# ============================================================

def extract_step18_rows(
    data: dict[str, Any],
) -> list[SummaryRow]:
    rows = []

    fixed_parameters = data.get(
        "fixed_parameters",
        {},
    )

    aggregates = data.get(
        "aggregate_results",
        [],
    )

    fixed_beam = fixed_parameters.get(
        "beam_width"
    )

    fixed_alpha = fixed_parameters.get(
        "bridge_alpha"
    )

    for item in aggregates:
        rows.append(
            SummaryRow(
                experiment=(
                    "Step 18: Independent test"
                ),

                setting=(
                    f"beam={fixed_beam}; "
                    f"alpha={fixed_alpha}"
                ),

                condition=item.get(
                    "condition_name",
                    "Unknown",
                ),

                success_rate=as_float(
                    item.get(
                        "success_rate"
                    )
                ),

                exact_match_rate=as_float(
                    item.get(
                        "exact_match_rate"
                    )
                ),

                mean_node_recall=as_float(
                    item.get(
                        "mean_node_recall"
                    )
                ),

                mean_edge_recall=as_float(
                    item.get(
                        "mean_edge_recall"
                    )
                ),

                mean_visited_nodes=as_float(
                    item.get(
                        "mean_visited_nodes"
                    )
                ),

                mean_expanded_edges=as_float(
                    item.get(
                        "mean_expanded_edges"
                    )
                ),

                note=(
                    "Independent hard cases not used "
                    "for Step 17 parameter selection."
                ),
            )
        )

    return rows


# ============================================================
# 9. 提取关键结论
# ============================================================

def find_condition(
    rows: list[SummaryRow],
    experiment_prefix: str,
    condition: str,
) -> SummaryRow | None:
    for row in rows:
        if (
            row.experiment.startswith(
                experiment_prefix
            )
            and row.condition == condition
        ):
            return row

    return None


def build_key_findings(
    rows: list[SummaryRow],
) -> list[str]:
    findings = []

    baseline = find_condition(
        rows,
        "Step 18",
        "Baseline",
    )

    clean = find_condition(
        rows,
        "Step 18",
        "Clean Bridge",
    )

    noisy = find_condition(
        rows,
        "Step 18",
        "Noisy Bridge",
    )

    random_bridge = find_condition(
        rows,
        "Step 18",
        "Random Bridge",
    )

    if (
        baseline is not None
        and clean is not None
    ):
        findings.append(
            "On the independent hard test set, "
            f"Baseline success was "
            f"{baseline.success_rate:.2%}, while "
            f"Clean Bridge success was "
            f"{clean.success_rate:.2%}."
        )

    if noisy is not None:
        findings.append(
            "Noisy Bridge guidance retained "
            f"{noisy.success_rate:.2%} success on "
            "the independent test set."
        )

    if random_bridge is not None:
        findings.append(
            "Random Bridge guidance achieved "
            f"{random_bridge.success_rate:.2%} success, "
            "showing that arbitrary bridge entities "
            "did not provide useful navigation."
        )

    findings.append(
        "The selected main configuration is "
        "BEAM_WIDTH=2 and BRIDGE_ALPHA=0.30."
    )

    findings.append(
        "The independent-test relation-weight table "
        "should now be frozen to avoid test-set tuning."
    )

    return findings


# ============================================================
# 10. 打印核心表
# ============================================================

def print_core_summary(
    rows: list[SummaryRow],
) -> None:
    core_rows = [
        row
        for row in rows
        if row.experiment.startswith(
            "Step 18"
        )
    ]

    print("\n" + "=" * 120)
    print("FINAL INDEPENDENT TEST SUMMARY")
    print("=" * 120)

    print(
        f"{'Condition':<18}"
        f"{'Success':<12}"
        f"{'Exact':<12}"
        f"{'Node Recall':<15}"
        f"{'Edge Recall':<15}"
        f"{'Visited':<12}"
        f"{'Expanded':<12}"
    )

    print("-" * 120)

    for row in core_rows:
        success = (
            f"{row.success_rate:.2%}"
            if row.success_rate is not None
            else "N/A"
        )

        exact = (
            f"{row.exact_match_rate:.2%}"
            if row.exact_match_rate
            is not None
            else "N/A"
        )

        node_recall = (
            f"{row.mean_node_recall:.4f}"
            if row.mean_node_recall
            is not None
            else "N/A"
        )

        edge_recall = (
            f"{row.mean_edge_recall:.4f}"
            if row.mean_edge_recall
            is not None
            else "N/A"
        )

        visited = (
            f"{row.mean_visited_nodes:.4f}"
            if row.mean_visited_nodes
            is not None
            else "N/A"
        )

        expanded = (
            f"{row.mean_expanded_edges:.4f}"
            if row.mean_expanded_edges
            is not None
            else "N/A"
        )

        print(
            f"{row.condition:<18}"
            f"{success:<12}"
            f"{exact:<12}"
            f"{node_recall:<15}"
            f"{edge_recall:<15}"
            f"{visited:<12}"
            f"{expanded:<12}"
        )


# ============================================================
# 11. 保存 JSON
# ============================================================

def save_json(
    rows: list[SummaryRow],
    findings: list[str],
) -> None:
    output_data = {
        "experiment_name":
            "combined_experiment_summary",

        "main_configuration": {
            "beam_width": 2,
            "bridge_alpha": 0.30,
        },

        "key_findings":
            findings,

        "summary_rows": [
            asdict(row)
            for row in rows
        ],
    }

    output_path = Path(
        OUTPUT_JSON
    )

    with output_path.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            output_data,
            file,
            ensure_ascii=False,
            indent=4,
        )

    print(
        f"\nJSON saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 12. 保存 CSV
# ============================================================

def save_csv(
    rows: list[SummaryRow],
) -> None:
    output_path = Path(
        OUTPUT_CSV
    )

    fieldnames = [
        "experiment",
        "setting",
        "condition",

        "success_rate",
        "exact_match_rate",
        "mean_node_recall",
        "mean_edge_recall",

        "mean_visited_nodes",
        "mean_expanded_edges",

        "note",
    ]

    with output_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for row in rows:
            writer.writerow(
                asdict(
                    row
                )
            )

    print(
        f"CSV saved to: "
        f"{output_path.resolve()}"
    )


# ============================================================
# 13. 主程序
# ============================================================

def main() -> None:
    all_rows: list[
        SummaryRow
    ] = []

    step15 = load_json(
        STEP15_JSON
    )

    step16 = load_json(
        STEP16_JSON
    )

    step17 = load_json(
        STEP17_JSON
    )

    step18 = load_json(
        STEP18_JSON
    )

    if step15 is not None:
        all_rows.extend(
            extract_step15_rows(
                step15
            )
        )

    if step16 is not None:
        all_rows.extend(
            extract_step16_rows(
                step16
            )
        )

    if step17 is not None:
        all_rows.extend(
            extract_step17_rows(
                step17
            )
        )

    if step18 is not None:
        all_rows.extend(
            extract_step18_rows(
                step18
            )
        )

    if not all_rows:
        raise RuntimeError(
            "No experiment results were found."
        )

    findings = build_key_findings(
        all_rows
    )

    print_core_summary(
        all_rows
    )

    print("\nKey findings:")

    for index, finding in enumerate(
        findings,
        start=1,
    ):
        print(
            f"{index}. {finding}"
        )

    save_json(
        rows=all_rows,
        findings=findings,
    )

    save_csv(
        all_rows
    )

    print("\n" + "=" * 80)
    print("STEP 19 COMPLETED")
    print("=" * 80)

    print(
        "Step 15-18 experiment results "
        "were combined successfully."
    )


if __name__ == "__main__":
    main()
