# Reuse semantic text features from logistic script by importing its construction would retrain; keep compact.
import json, math
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import roc_auc_score, average_precision_score
BASE=Path('/mnt/data/dmdb_realgraph_experiment')
paths=json.load(open('/mnt/data/indication_paths.json')); manifest=pd.read_csv(BASE/'benchmark_manifest.csv'); cand=pd.read_csv(BASE/'bridge_marginal_training_samples.csv'); gate=pd.read_csv(BASE/'gate_training_samples.csv')
node_meta={}; G=nx.MultiDiGraph()
for rec in paths:
 for n in rec.get('nodes',[]):
  nid=str(n['id']); node_meta.setdefault(nid,{'name':str(n.get('name','')),'type':str(n.get('label','Unknown'))}); G.add_node(nid,**node_meta[nid])
 for e in rec.get('links',[]): G.add_edge(str(e['source']),str(e['target']),relation=str(e.get('key','unknown')))
man={(r.task,r.rid):r._asdict() for r in manifest.itertuples(index=False)}; sets=cand.groupby(['task','rid','split','condition'])['node'].apply(list).to_dict(); types=sorted({m['type'] for m in node_meta.values()})
texts=[]; nums=[]
for gr in gate.itertuples(index=False):
 m=man[(gr.task,gr.rid)]; bs=sets.get((gr.task,gr.rid,gr.split,gr.condition),[]); ty=[node_meta.get(h,{'type':'Unknown'})['type'] for h in bs]; names=[node_meta.get(h,{'name':h})['name'] for h in bs]; tc=Counter(ty)
 texts.append(f"task {gr.task} question {m['question']} candidates "+' ; '.join(f'{t} {n}' for t,n in zip(ty,names)))
 nums.append([len(bs)/10,math.log1p(G.out_degree(m['source'])),math.log1p(G.in_degree(m['target']))]+[tc[t]/max(1,len(bs)) for t in types]+[np.mean([G.has_edge(m['source'],h) for h in bs]) if bs else 0,np.mean([math.log1p(G.in_degree(h)+G.out_degree(h)) for h in bs]) if bs else 0])
sp=gate.split.to_numpy(str); tr=sp=='train'; va=sp=='val'; te=sp=='test'; gain=(gate.best_nonzero-gate.M0).to_numpy(float); y=gate.z.to_numpy(int)
word=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_features=50000,sublinear_tf=True).fit(np.asarray(texts)[tr]); char=TfidfVectorizer(lowercase=True,analyzer='char_wb',ngram_range=(3,5),min_df=3,max_features=50000,sublinear_tf=True).fit(np.asarray(texts)[tr]); sc=StandardScaler().fit(np.asarray(nums)[tr]); X=hstack([word.transform(texts),char.transform(texts),csr_matrix(sc.transform(nums))],format='csr')
for alpha in [1,3,10,30,100]:
 model=Ridge(alpha=alpha).fit(X[tr],gain[tr]); p=model.predict(X)
 print('alpha',alpha,'val auc',roc_auc_score(y[va],p[va]),'ap',average_precision_score(y[va],p[va]),'test auc',roc_auc_score(y[te],p[te]),'ap',average_precision_score(y[te],p[te]))
 if alpha==10:
  out=gate.copy();out['pred_gain']=p;out.to_csv(BASE/'semantic_gate_regression_predictions.csv',index=False)
