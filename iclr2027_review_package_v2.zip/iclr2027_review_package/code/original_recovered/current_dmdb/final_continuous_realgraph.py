import json, math, re
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np, pandas as pd, networkx as nx

BASE=Path('/mnt/data/dmdb_realgraph_experiment')
SEED=20260827
rng=np.random.default_rng(SEED)
paths=json.load(open('/mnt/data/indication_paths.json'))
manifest=pd.read_csv(BASE/'benchmark_manifest.csv')
cand=pd.read_csv(BASE/'semantic_bridge_predictions.csv')
gate=pd.read_csv(BASE/'semantic_gate_predictions.csv')

# Aggregate directed multigraph and gold records
G=nx.MultiDiGraph(); gold={}
for rec in paths:
    rid=str(rec.get('graph',{}).get('_id',''))
    nodes={str(n['id']): {'name':str(n.get('name','')), 'type':str(n.get('label','Unknown'))} for n in rec.get('nodes',[])}
    links=[]
    for nid,d in nodes.items():
        if nid not in G: G.add_node(nid,**d)
    for e in rec.get('links',[]):
        u,v,rel=str(e['source']),str(e['target']),str(e.get('key','unknown'))
        G.add_edge(u,v,relation=rel)
        links.append((u,v,rel))
    if rid: gold[rid]={'nodes':nodes,'links':links}

# collapse outgoing expansions to unique (u,v,rel), deterministic
OUT=defaultdict(list)
for u,v,d in G.edges(data=True):
    tup=(v,str(d.get('relation','unknown')))
    if tup not in OUT[u]: OUT[u].append(tup)

# Frozen relation quality: keyword semantics only, no test labels / no shortest-path oracle.
def rel_quality(rel):
    s=rel.lower().replace('_',' ')
    # causal / regulatory edges are more mechanistically informative
    if any(k in s for k in ['causes','prevents','treats','therapeutic']): return 1.00
    if any(k in s for k in ['regulates','activity','abundance','inhibits','stimulates','affects']): return 0.88
    if any(k in s for k in ['participates','produces','has output','capable of','precedes']): return 0.72
    if any(k in s for k in ['occurs in','located in','location of','correlated','associated']): return 0.52
    return 0.62

# Precompute degree-based anti-hub factor using only local graph structure.
MAXLOG=max(math.log1p(G.in_degree(n)+G.out_degree(n)) for n in G.nodes) or 1

def local_graph_score(v,rel):
    deg=math.log1p(G.in_degree(v)+G.out_degree(v))/MAXLOG
    return 0.82*rel_quality(rel)+0.18*(1.0-deg)

# Candidate confidence map by key
CSETS={}
for key,d in cand.groupby(['task','rid','split','condition']):
    # dedupe node, keep max confidence
    mm=d.groupby('node')['pred_semantic_conf'].max().to_dict()
    CSETS[key]={str(k):float(v) for k,v in mm.items()}

# Handcrafted fixed Bridge utility = equal high confidence for linked candidates.
# Learned confidence = semantic+structural logistic prediction already fitted train-only.

def bridge_state_score(path_nodes, conf):
    if not conf: return 0.0
    reached=[n for n in path_nodes if n in conf]
    if not reached: return 0.0
    uniq=list(dict.fromkeys(reached))
    cov=len(uniq)/max(1,len(conf))
    mean_c=float(np.mean([conf[n] for n in uniq]))
    cur=conf.get(path_nodes[-1],0.0)
    recent=sum(1 for n in path_nodes[-2:] if n in conf)/2.0
    sat=0.65 if len(uniq)<=1 else (0.85 if len(uniq)==2 else 1.0)
    return min(1.0,max(0.0,(0.45*cov+0.25*mean_c+0.15*cur+0.15*recent)*sat))

def run_search(source,target,conf,g,beam=2,max_hops=8,node_budget=14,edge_budget=20):
    # state: (rank_score, nodes tuple, rels tuple, local_graph_scores tuple)
    beam_states=[(0.0,(source,),(),())]
    generated={source}; expanded=0
    best_target=None
    for hop in range(max_hops):
        nxt=[]
        for _,pn,pr,pg in beam_states:
            u=pn[-1]
            for v,rel in OUT.get(u,[]):
                if expanded>=edge_budget: break
                expanded+=1
                if v in pn: continue
                if v not in generated and len(generated)>=node_budget: continue
                generated.add(v)
                nn=pn+(v,); rr=pr+(rel,); gg=pg+(local_graph_score(v,rel),)
                graph_score=float(np.mean(gg)) if gg else 0.0
                bscore=bridge_state_score(nn,conf)
                score=(1-g)*graph_score + g*bscore - 0.012*len(rr)
                st=(score,nn,rr,gg)
                nxt.append(st)
                if v==target and (best_target is None or score>best_target[0]): best_target=st
            if expanded>=edge_budget: break
        if best_target is not None:
            # return immediately once target is in generated frontier; ranking already controls frontier expansion
            break
        if not nxt: break
        nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True)
        beam_states=nxt[:beam]
    best=best_target if best_target is not None else (max(beam_states,key=lambda x:x[0]) if beam_states else (0,(source,),(),()))
    _,pn,rr,_=best
    edges=[(pn[i],pn[i+1],rr[i]) for i in range(len(rr))]
    return {'nodes':list(pn),'edges':edges,'found':bool(pn and pn[-1]==target),'visited_nodes':len(generated),'expanded_edges':expanded}

def eval_run(row,conf,g):
    r=run_search(row.source,row.target,conf,g)
    gedges=set(gold[row.rid]['links'])
    redges=set(r['edges'])
    er=len(gedges & redges)/max(1,len(gedges))
    ah=float(str(row.answer) in set(r['nodes']))
    return float(r['found']),float(er),ah,r['visited_nodes'],r['expanded_edges']

MAN={(r.task,r.rid):r for r in manifest.itertuples(index=False)}
GATE={(r.task,r.rid,r.split,r.condition):float(r.p_semantic_gate) for r in gate.itertuples(index=False)}

# Cache validation searches for graph/fixed/learned across alpha grid.
val_keys=[k for k in CSETS if k[2]=='val']
test_keys=[k for k in CSETS if k[2]=='test']
agrid=np.round(np.arange(0,0.501,0.05),3)

# evaluate continuous learned-confidence search per alpha on validation
cache={}
for j,key in enumerate(val_keys):
    task,rid,split,cond=key; row=MAN[(task,rid)]; conf=CSETS[key]
    for a in agrid:
        cache[(key,float(a))]=eval_run(row,conf,float(a))

def nearest(a): return float(agrid[np.argmin(np.abs(agrid-a))])
rows=[]
for gmax in [.20,.25,.30,.35,.40,.45,.50]:
    for gamma in [.5,.75,1.0,1.25,1.5,2.0]:
        vals=[]
        for key in val_keys:
            p=GATE[key]; a=nearest(gmax*(p**gamma)); f,er,ah,*_=cache[(key,a)]
            vals.append((f,er,ah))
        A=np.asarray(vals,float); util=.7*A[:,0].mean()+.3*A[:,1].mean()
        rows.append({'gmax':gmax,'gamma':gamma,'path_success':A[:,0].mean(),'edge_recall':A[:,1].mean(),'answer_hit':A[:,2].mean(),'utility':util})
sel=pd.DataFrame(rows).sort_values(['utility','path_success','edge_recall'],ascending=False)
best=sel.iloc[0]; gmax=float(best.gmax); gamma=float(best.gamma)
print('SELECT',gmax,gamma,best.to_dict())

# Test four variants. Handcrafted fixed uses equal confidence=1; learned fixed uses predicted conf; full continuous uses p gate.
out=[]
for key in test_keys:
    task,rid,split,cond=key; row=MAN[(task,rid)]; learned=CSETS[key]; hand={h:1.0 for h in learned}
    p=GATE[key]; g=gmax*(p**gamma)
    methods=[('Graph Only',{},0.0,p),('Fixed Bridge',hand,0.30,p),('Learned Confidence + Fixed Gate',learned,0.30,p),('Full Continuous Gate',learned,g,p)]
    for name,conf,a,pp in methods:
        f,er,ah,vn,ee=eval_run(row,conf,a)
        out.append({'task':task,'rid':rid,'condition':cond,'method':name,'gate':a,'p_reliable':pp,'found':f,'edge_recall':er,'answer_hit':ah,'visited_nodes':vn,'expanded_edges':ee})
res=pd.DataFrame(out)
res.to_csv(BASE/'final_continuous_test_detailed.csv',index=False)
sel.to_csv(BASE/'final_continuous_validation_grid.csv',index=False)

overall=res.groupby('method').agg(n=('found','size'),path_success=('found','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean'),mean_gate=('gate','mean'),visited_nodes=('visited_nodes','mean'),expanded_edges=('expanded_edges','mean')).reset_index()
bytask=res.groupby(['method','task']).agg(n=('found','size'),path_success=('found','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean'),mean_gate=('gate','mean')).reset_index()
bycond=res.groupby(['method','condition']).agg(n=('found','size'),path_success=('found','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean'),mean_gate=('gate','mean')).reset_index()
behavior=res[res.method=='Full Continuous Gate'].groupby(['task','condition']).agg(n=('gate','size'),mean_gate=('gate','mean'),mean_p=('p_reliable','mean'),path_success=('found','mean'),edge_recall=('edge_recall','mean')).reset_index()
overall.to_csv(BASE/'final_continuous_overall.csv',index=False); bytask.to_csv(BASE/'final_continuous_by_task.csv',index=False); bycond.to_csv(BASE/'final_continuous_by_condition.csv',index=False); behavior.to_csv(BASE/'final_continuous_gate_behavior.csv',index=False)

full=res[res.method=='Full Continuous Gate']

# paired bootstrap over matched test rows (5,000 resamples).
B=5000; brng=np.random.default_rng(SEED+99)
boots=[]
for base in ['Graph Only','Fixed Bridge','Learned Confidence + Fixed Gate']:
    bb=res[res.method==base]
    m=full.merge(bb,on=['task','rid','condition'],suffixes=('_full','_base'))
    for metric in ['found','edge_recall','answer_hit']:
        d=(m[f'{metric}_full']-m[f'{metric}_base']).to_numpy(float)
        ix=brng.integers(0,len(d),size=(B,len(d)))
        z=d[ix].mean(axis=1)
        lo,hi=np.quantile(z,[.025,.975])
        boots.append({'comparison':f'Full Continuous Gate - {base}','metric':metric,'mean_diff':float(d.mean()),'ci95_low':float(lo),'ci95_high':float(hi)})
pd.DataFrame(boots).to_csv(BASE/'final_continuous_bootstrap.csv',index=False)

report={'selected_gate':{'gmax':gmax,'gamma':gamma},'validation_best':best.to_dict(),'overall':overall.to_dict(orient='records'),'by_task':bytask.to_dict(orient='records'),'by_condition':bycond.to_dict(orient='records'),'gate_behavior':behavior.to_dict(orient='records'),'bootstrap':boots}
json.dump(report,open(BASE/'final_continuous_report.json','w'),indent=2)
print('\nOVERALL\n',overall.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nBY TASK\n',bytask.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nBY CONDITION\n',bycond.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nBOOT\n',pd.DataFrame(boots).to_string(index=False,float_format=lambda x:f'{x:.4f}'))
