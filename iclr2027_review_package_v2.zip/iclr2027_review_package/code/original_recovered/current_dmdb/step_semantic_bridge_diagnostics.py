import json, math, re
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np, pandas as pd
import networkx as nx
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

BASE=Path('/mnt/data/dmdb_realgraph_experiment')
paths=json.load(open('/mnt/data/indication_paths.json'))
manifest=pd.read_csv(BASE/'benchmark_manifest.csv')
cand=pd.read_csv(BASE/'bridge_marginal_training_samples.csv')

# Aggregate graph + node metadata
G=nx.MultiDiGraph(); node_meta={}
for rec in paths:
    for n in rec.get('nodes',[]):
        nid=str(n['id']);
        if nid not in node_meta or not node_meta[nid].get('name'):
            node_meta[nid]={'name':str(n.get('name','')), 'type':str(n.get('label','Unknown'))}
        G.add_node(nid, **node_meta[nid])
    for e in rec.get('links',[]):
        u,v=str(e['source']),str(e['target']); rel=str(e.get('key','unknown'))
        G.add_edge(u,v,relation=rel)

man={(r.task,r.rid):r._asdict() for r in manifest.itertuples(index=False)}
# relation vocabulary top 30 by incidence
relcnt=Counter(d.get('relation','') for _,_,d in G.edges(data=True))
REL=[r for r,_ in relcnt.most_common(30)]
TYPES=sorted({d.get('type','Unknown') for d in node_meta.values()})

def norm(s):
    s=str(s).lower().replace('_',' ')
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return ' '.join(s.split())

def numfeat(task,rid,node):
    m=man[(task,rid)]; source=m['source']; target=m['target']
    typ=node_meta.get(node,{}).get('type','Unknown')
    indeg,outdeg=G.in_degree(node),G.out_degree(node)
    rc=Counter()
    for u,v,d in G.in_edges(node,data=True): rc[d.get('relation','')]+=1
    for u,v,d in G.out_edges(node,data=True): rc[d.get('relation','')]+=1
    tot=sum(rc.values()) or 1
    f=[math.log1p(indeg),math.log1p(outdeg),math.log1p(indeg+outdeg),float(G.has_edge(source,node)),
       math.log1p(G.out_degree(source)),math.log1p(G.in_degree(target))]
    f += [rc[x]/tot for x in REL]
    # type onehot
    f += [1.0 if typ==t else 0.0 for t in TYPES]
    return f

texts=[]; nums=[]; labels=[]; splits=[]; rows=[]
for r in cand.itertuples():
    m=man[(r.task,r.rid)]; nm=node_meta.get(r.node,{'name':r.node,'type':'Unknown'})
    # Explicit query-bridge compatibility text. Include task/type tags but no gold/reference membership.
    text=(f"task {r.task} question {m['question']} bridge {nm['name']} bridge_type {nm['type']}")
    texts.append(text); nums.append(numfeat(r.task,r.rid,r.node)); labels.append(int(r.beneficial)); splits.append(r.split)
    rows.append((r.rid,r.condition,r.node,r.task))
Xn=np.asarray(nums,np.float32); y=np.asarray(labels); splits=np.asarray(splits)
tr=splits=='train'; va=splits=='val'; te=splits=='test'

# Word+char lexical semantic features; fit train only.
word=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_features=40000,sublinear_tf=True)
char=TfidfVectorizer(lowercase=True,analyzer='char_wb',ngram_range=(3,5),min_df=3,max_features=40000,sublinear_tf=True)
Xw_tr=word.fit_transform(np.asarray(texts)[tr]); Xc_tr=char.fit_transform(np.asarray(texts)[tr])
Xw_all=word.transform(texts); Xc_all=char.transform(texts)
sc=StandardScaler(); sc.fit(Xn[tr]); Xnum=csr_matrix(sc.transform(Xn))
X=hstack([Xw_all,Xc_all,Xnum],format='csr')

clf=LogisticRegression(max_iter=1000,C=1.0,class_weight='balanced',solver='liblinear',random_state=20260827)
clf.fit(X[tr],y[tr])
p=clf.predict_proba(X)[:,1]

report={}
for name,mask in [('train',tr),('val',va),('test',te)]:
    report[name]={'n':int(mask.sum()),'pos_rate':float(y[mask].mean()),'AUROC':float(roc_auc_score(y[mask],p[mask])),'AUPRC':float(average_precision_score(y[mask],p[mask])),'Brier':float(brier_score_loss(y[mask],p[mask]))}
print(json.dumps(report,indent=2))

out=cand.copy(); out['pred_semantic_conf']=p
out.to_csv(BASE/'semantic_bridge_predictions.csv',index=False)
json.dump(report,open(BASE/'semantic_bridge_report.json','w'),indent=2)
