import json, math, re
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

BASE=Path('/mnt/data/dmdb_realgraph_experiment')
paths=json.load(open('/mnt/data/indication_paths.json'))
manifest=pd.read_csv(BASE/'benchmark_manifest.csv')
cand=pd.read_csv(BASE/'bridge_marginal_training_samples.csv')
gate=pd.read_csv(BASE/'gate_training_samples.csv')
node_meta={}; G=nx.MultiDiGraph()
for rec in paths:
 for n in rec.get('nodes',[]):
  nid=str(n['id']); node_meta.setdefault(nid,{'name':str(n.get('name','')),'type':str(n.get('label','Unknown'))}); G.add_node(nid,**node_meta[nid])
 for e in rec.get('links',[]): G.add_edge(str(e['source']),str(e['target']),relation=str(e.get('key','unknown')))
man={(r.task,r.rid):r._asdict() for r in manifest.itertuples(index=False)}
# candidate sets reconstructed from marginal rows
sets=cand.groupby(['task','rid','split','condition'])['node'].apply(list).to_dict()
types=sorted({x.get('type','Unknown') for x in node_meta.values()})

def feats(gr):
 m=man[(gr.task,gr.rid)]; bs=sets.get((gr.task,gr.rid,gr.split,gr.condition),[])
 names=[node_meta.get(h,{'name':h})['name'] for h in bs]; ty=[node_meta.get(h,{'type':'Unknown'})['type'] for h in bs]
 # Set text with repeated bridge markers so char/word TFIDF can learn query--candidate compatibility.
 txt=f"task {gr.task} question {m['question']} candidates " + ' ; '.join(f"{t} {n}" for t,n in zip(ty,names))
 tc=Counter(ty)
 nums=[len(bs)/10.0, math.log1p(G.out_degree(m['source'])), math.log1p(G.in_degree(m['target']))]
 nums += [tc[t]/max(1,len(bs)) for t in types]
 # source adjacency and average degrees of candidate set, no target shortest distance
 nums += [np.mean([G.has_edge(m['source'],h) for h in bs]) if bs else 0,
          np.mean([math.log1p(G.in_degree(h)+G.out_degree(h)) for h in bs]) if bs else 0]
 return txt,nums
texts=[]; nums=[]
for gr in gate.itertuples(index=False):
 t,n=feats(gr); texts.append(t); nums.append(n)
Xn=np.asarray(nums,np.float32); y=gate.z.to_numpy(int); sp=gate.split.to_numpy(str)
tr=sp=='train'; va=sp=='val'; te=sp=='test'
word=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_features=50000,sublinear_tf=True)
char=TfidfVectorizer(lowercase=True,analyzer='char_wb',ngram_range=(3,5),min_df=3,max_features=50000,sublinear_tf=True)
word.fit(np.asarray(texts)[tr]); char.fit(np.asarray(texts)[tr])
sc=StandardScaler().fit(Xn[tr]); X=hstack([word.transform(texts),char.transform(texts),csr_matrix(sc.transform(Xn))],format='csr')
clf=LogisticRegression(max_iter=1200,C=.5,class_weight='balanced',solver='liblinear',random_state=20260827)
clf.fit(X[tr],y[tr]); p=clf.predict_proba(X)[:,1]
rep={}
for name,mask in [('train',tr),('val',va),('test',te)]:
 rep[name]={'n':int(mask.sum()),'pos_rate':float(y[mask].mean()),'AUROC':float(roc_auc_score(y[mask],p[mask])),'AUPRC':float(average_precision_score(y[mask],p[mask])),'Brier':float(brier_score_loss(y[mask],p[mask]))}
print(json.dumps(rep,indent=2))
out=gate.copy(); out['p_semantic_gate']=p; out.to_csv(BASE/'semantic_gate_predictions.csv',index=False); json.dump(rep,open(BASE/'semantic_gate_report.json','w'),indent=2)
