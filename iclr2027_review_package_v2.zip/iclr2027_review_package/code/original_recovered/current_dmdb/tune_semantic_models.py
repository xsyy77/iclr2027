exec(open('/mnt/data/dmdb_realgraph_experiment/step_semantic_bridge_diagnostics.py').read().split('clf=LogisticRegression')[0])
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
import json
rows=[]; best=None
for C in [.03,.05,.1,.2,.5,1,2,5]:
  for cw in [None,'balanced']:
    clf=LogisticRegression(max_iter=1200,C=C,class_weight=cw,solver='liblinear',random_state=20260827)
    clf.fit(X[tr],y[tr]); p=clf.predict_proba(X)[:,1]
    r={'C':C,'class_weight':str(cw),'val_auroc':roc_auc_score(y[va],p[va]),'val_auprc':average_precision_score(y[va],p[va]),'test_auroc':roc_auc_score(y[te],p[te]),'test_auprc':average_precision_score(y[te],p[te]),'test_brier':brier_score_loss(y[te],p[te])}
    rows.append(r)
    key=(r['val_auprc'],r['val_auroc'])
    if best is None or key>best[0]: best=(key,C,cw,p,r)
pd.DataFrame(rows).to_csv(BASE/'bridge_model_validation_sweep.csv',index=False)
_,C,cw,p,r=best
out=cand.copy(); out['pred_semantic_conf']=p; out.to_csv(BASE/'semantic_bridge_predictions_tuned.csv',index=False)
json.dump({'selected':{'C':C,'class_weight':str(cw)},'metrics':r},open(BASE/'semantic_bridge_tuned_report.json','w'),indent=2)
print('BEST BRIDGE',r)
