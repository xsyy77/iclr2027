import json, math
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, f1_score, balanced_accuracy_score
import lightgbm as lgb
BASE=Path('/mnt/data/dmdb_realgraph_experiment')
paths=json.load(open('/mnt/data/indication_paths.json'))
manifest=pd.read_csv(BASE/'benchmark_manifest.csv'); cand=pd.read_csv(BASE/'bridge_marginal_training_samples.csv'); gate=pd.read_csv(BASE/'gate_training_samples.csv')
node_meta={}; G=nx.MultiDiGraph()
for rec in paths:
 for n in rec.get('nodes',[]):
  nid=str(n['id']); node_meta.setdefault(nid,{'name':str(n.get('name','')),'type':str(n.get('label','Unknown'))}); G.add_node(nid,**node_meta[nid])
 for e in rec.get('links',[]): G.add_edge(str(e['source']),str(e['target']),relation=str(e.get('key','unknown')))
man={(r.task,r.rid):r._asdict() for r in manifest.itertuples(index=False)}
sets=cand.groupby(['task','rid','split','condition'])['node'].apply(list).to_dict(); TYPES=sorted({m['type'] for m in node_meta.values()})
texts=[]; nums=[]
for gr in gate.itertuples(index=False):
 m=man[(gr.task,gr.rid)]; bs=sets.get((gr.task,gr.rid,gr.split,gr.condition),[]); ty=[node_meta.get(h,{'type':'Unknown'})['type'] for h in bs]; names=[node_meta.get(h,{'name':h})['name'] for h in bs]; tc=Counter(ty)
 texts.append(f"task {gr.task} question {m['question']} candidates "+' ; '.join(f'{t} {n}' for t,n in zip(ty,names)))
 # more graph-summary features, no target shortest distance or gold membership
 vals=[len(bs), math.log1p(G.out_degree(m['source'])), math.log1p(G.in_degree(m['target']))]
 vals += [tc[t]/max(1,len(bs)) for t in TYPES]
 vals += [np.mean([G.has_edge(m['source'],h) for h in bs]) if bs else 0,
          np.max([G.has_edge(m['source'],h) for h in bs]) if bs else 0,
          np.mean([math.log1p(G.in_degree(h)) for h in bs]) if bs else 0,
          np.mean([math.log1p(G.out_degree(h)) for h in bs]) if bs else 0,
          np.std([math.log1p(G.in_degree(h)+G.out_degree(h)) for h in bs]) if len(bs)>1 else 0]
 nums.append(vals)
y=gate.z.to_numpy(int); sp=gate.split.to_numpy(str); tr=sp=='train'; va=sp=='val'; te=sp=='test'
vec=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=2,max_features=50000,sublinear_tf=True)
Xt=vec.fit_transform(np.asarray(texts)[tr]); Xa=vec.transform(texts)
svd=TruncatedSVD(n_components=128,random_state=20260827).fit(Xt); Z=svd.transform(Xa)
X=np.hstack([Z,np.asarray(nums,np.float32)])
scale_pos=(tr.sum()-y[tr].sum())/max(1,y[tr].sum())
model=lgb.LGBMClassifier(n_estimators=500,learning_rate=.025,num_leaves=15,max_depth=5,min_child_samples=40,subsample=.85,colsample_bytree=.8,reg_lambda=2.0,reg_alpha=.5,scale_pos_weight=scale_pos,random_state=20260827,verbosity=-1)
model.fit(X[tr],y[tr],eval_set=[(X[va],y[va])],callbacks=[lgb.early_stopping(50,verbose=False)])
p=model.predict_proba(X)[:,1]
rep={}
for name,mask in [('train',tr),('val',va),('test',te)]: rep[name]={'n':int(mask.sum()),'AUROC':float(roc_auc_score(y[mask],p[mask])),'AUPRC':float(average_precision_score(y[mask],p[mask])),'Brier':float(brier_score_loss(y[mask],p[mask]))}
print(json.dumps(rep,indent=2)); out=gate.copy(); out['p_semantic_gate_lgbm']=p; out.to_csv(BASE/'semantic_gate_lgbm_predictions.csv',index=False); json.dump(rep,open(BASE/'semantic_gate_lgbm_report.json','w'),indent=2)
# validation threshold F1
ths=np.linspace(.05,.95,91); best=max([(th,f1_score(y[va],p[va]>=th),balanced_accuracy_score(y[va],p[va]>=th)) for th in ths],key=lambda x:(x[1],x[2])); print('threshold',best)
