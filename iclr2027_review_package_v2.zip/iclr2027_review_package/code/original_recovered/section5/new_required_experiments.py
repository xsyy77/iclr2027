import json, math, re
from pathlib import Path
from collections import defaultdict
import numpy as np, pandas as pd, networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import roc_auc_score, average_precision_score

BASE=Path('/mnt/data/dmdb_realgraph_experiment')
SEED=20260903
rng=np.random.default_rng(SEED)
paths=json.load(open('/mnt/data/indication_paths.json'))
manifest=pd.read_csv(BASE/'benchmark_manifest.csv')
cand=pd.read_csv(BASE/'semantic_bridge_predictions.csv')
gate=pd.read_csv(BASE/'semantic_gate_predictions.csv')

# ---------------- Graph / gold ----------------
G=nx.MultiDiGraph(); gold={}; NODE_NAME={}; NODE_TYPE={}
for rec in paths:
    rid=str(rec.get('graph',{}).get('_id',''))
    nodes={str(n['id']): {'name':str(n.get('name','')), 'type':str(n.get('label','Unknown'))} for n in rec.get('nodes',[])}
    links=[]
    for nid,d in nodes.items():
        NODE_NAME.setdefault(nid,d['name']); NODE_TYPE.setdefault(nid,d['type'])
        if nid not in G: G.add_node(nid,**d)
    for e in rec.get('links',[]):
        u,v,rel=str(e['source']),str(e['target']),str(e.get('key','unknown'))
        G.add_edge(u,v,relation=rel); links.append((u,v,rel))
    if rid: gold[rid]={'nodes':nodes,'links':links}
OUT=defaultdict(list)
for u,v,d in G.edges(data=True):
    tup=(v,str(d.get('relation','unknown')))
    if tup not in OUT[u]: OUT[u].append(tup)
MAXLOG=max(math.log1p(G.in_degree(n)+G.out_degree(n)) for n in G.nodes) or 1

def rel_quality(rel):
    s=rel.lower().replace('_',' ')
    if any(k in s for k in ['causes','prevents','treats','therapeutic']): return 1.00
    if any(k in s for k in ['regulates','activity','abundance','inhibits','stimulates','affects']): return 0.88
    if any(k in s for k in ['participates','produces','has output','capable of','precedes']): return 0.72
    if any(k in s for k in ['occurs in','located in','location of','correlated','associated']): return 0.52
    return 0.62

def local_graph_score(v,rel):
    deg=math.log1p(G.in_degree(v)+G.out_degree(v))/MAXLOG
    return 0.82*rel_quality(rel)+0.18*(1.0-deg)

def bridge_state_score(path_nodes, conf):
    if not conf: return 0.0
    reached=[n for n in path_nodes if n in conf]
    if not reached: return 0.0
    uniq=list(dict.fromkeys(reached)); cov=len(uniq)/max(1,len(conf))
    mean_c=float(np.mean([conf[n] for n in uniq])); cur=conf.get(path_nodes[-1],0.0)
    recent=sum(1 for n in path_nodes[-2:] if n in conf)/2.0
    sat=0.65 if len(uniq)<=1 else (0.85 if len(uniq)==2 else 1.0)
    return min(1.0,max(0.0,(0.45*cov+0.25*mean_c+0.15*cur+0.15*recent)*sat))

def run_search(source,target,conf,g,beam=2,max_hops=8,node_budget=14,edge_budget=20):
    beam_states=[(0.0,(source,),(),())]; generated={source}; expanded=0; best_target=None
    for _ in range(max_hops):
        nxt=[]
        for _,pn,pr,pg in beam_states:
            u=pn[-1]
            for v,rel in OUT.get(u,[]):
                if expanded>=edge_budget: break
                expanded+=1
                if v in pn: continue
                if v not in generated and len(generated)>=node_budget: continue
                generated.add(v)
                nn=pn+(v,); rr=pr+(rel,); gg=pg+(local_graph_score(v,rel),)
                gs=float(np.mean(gg)) if gg else 0.0; bs=bridge_state_score(nn,conf)
                score=(1-g)*gs+g*bs-0.012*len(rr); st=(score,nn,rr,gg); nxt.append(st)
                if v==target and (best_target is None or score>best_target[0]): best_target=st
            if expanded>=edge_budget: break
        if best_target is not None: break
        if not nxt: break
        nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True); beam_states=nxt[:beam]
    best=best_target if best_target is not None else (max(beam_states,key=lambda x:x[0]) if beam_states else (0,(source,),(),()))
    _,pn,rr,_=best; edges=[(pn[i],pn[i+1],rr[i]) for i in range(len(rr))]
    return {'nodes':list(pn),'edges':edges,'found':bool(pn and pn[-1]==target)}

def eval_run(row,conf,g):
    r=run_search(str(row.source),str(row.target),conf,float(g))
    gedges=set(gold[str(row.rid)]['links']); redges=set(r['edges'])
    return float(r['found']), len(gedges & redges)/max(1,len(gedges)), float(str(row.answer) in set(r['nodes']))

MAN={(r.task,r.rid):r for r in manifest.itertuples(index=False)}
GATE={(r.task,r.rid,r.split,r.condition):float(r.p_semantic_gate) for r in gate.itertuples(index=False)}
CAND_GROUP={(k[0],k[1],k[2],k[3]):d.copy() for k,d in cand.groupby(['task','rid','split','condition'])}

# ---------------- Stage I: controlled biological-view ablation ----------------
# This is deliberately a linked-candidate ablation, not a claim about free-form LLM proposal quality.
VIEW_TYPES={
 'Molecular': {'Protein','ChemicalSubstance','MolecularActivity','GeneFamily'},
 'Cellular': {'Cell','CellularComponent','MacromolecularComplex','GrossAnatomicalStructure'},
 'System': {'BiologicalProcess','Pathway','PhenotypicFeature','OrganismTaxon'},
}

def view_of(node):
    t=NODE_TYPE.get(str(node),'Unknown')
    for v,types in VIEW_TYPES.items():
        if t in types: return v
    return 'Other'

stage1=[]
# Clean held-out only, fixed gate and equal confidence isolate representation.
for key,d in CAND_GROUP.items():
    task,rid,split,cond=key
    if split!='test' or cond!='Clean': continue
    row=MAN[(task,rid)]; dd=d.drop_duplicates('node').copy(); dd['view']=dd.node.map(view_of)
    variants={
      'Molecular only': dd[dd.view=='Molecular'].node.astype(str).tolist(),
      'Cellular only': dd[dd.view=='Cellular'].node.astype(str).tolist(),
      'System only': dd[dd.view=='System'].node.astype(str).tolist(),
      'Multi-view': dd[dd.view.isin(['Molecular','Cellular','System'])].node.astype(str).tolist(),
    }
    for name,nodes in variants.items():
        conf={n:1.0 for n in nodes}
        f,er,ah=eval_run(row,conf,0.30)
        stage1.append({'task':task,'rid':rid,'variant':name,'n_bridges':len(nodes),'has_bridge':int(bool(nodes)),
                       'path_success':f,'edge_recall':er,'answer_hit':ah})
s1=pd.DataFrame(stage1)
s1.to_csv(BASE/'stage1_multiview_detailed.csv',index=False)
s1sum=s1.groupby('variant').agg(n=('rid','size'),bridge_availability=('has_bridge','mean'),mean_bridges=('n_bridges','mean'),
    path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index()
s1sum.to_csv(BASE/'stage1_multiview_summary.csv',index=False)
s1task=s1.groupby(['variant','task']).agg(n=('rid','size'),bridge_availability=('has_bridge','mean'),mean_bridges=('n_bridges','mean'),path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index()
s1task.to_csv(BASE/'stage1_multiview_by_task.csv',index=False)

# paired bootstrap Multi-view vs best single-view per query (post-hoc diagnostic, not model selection)
piv=s1.pivot_table(index=['task','rid'],columns='variant',values=['path_success','edge_recall','answer_hit'])
boot1=[]; brng=np.random.default_rng(SEED+1); B=2000
for metric in ['path_success','edge_recall','answer_hit']:
    multi=piv[(metric,'Multi-view')].to_numpy(float)
    singles=np.column_stack([piv[(metric,v)].to_numpy(float) for v in ['Molecular only','Cellular only','System only']])
    bestsingle=singles.max(axis=1); dif=multi-bestsingle
    ix=brng.integers(0,len(dif),(B,len(dif))); z=dif[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
    boot1.append({'comparison':'Multi-view - per-query best single view','metric':metric,'mean_diff':dif.mean(),'ci95_low':lo,'ci95_high':hi})
pd.DataFrame(boot1).to_csv(BASE/'stage1_multiview_bootstrap.csv',index=False)

# ---------------- Stage II: scorer quality + intervention ----------------
# lexical query-node name similarity baseline
all_test=cand[cand.split=='test'].copy().reset_index(drop=True)
lex_scores=np.zeros(len(all_test));
for _,idx in all_test.groupby(['task','rid','condition']).groups.items():
    idx=list(idx); q=str(MAN[(all_test.loc[idx[0],'task'],all_test.loc[idx[0],'rid'])].question)
    docs=[q]+[NODE_NAME.get(str(n),str(n)) for n in all_test.loc[idx,'node']]
    try:
        X=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1).fit_transform(docs)
        sims=cosine_similarity(X[0],X[1:]).ravel()
    except Exception:
        sims=np.zeros(len(idx))
    lex_scores[idx]=sims
all_test['score_lexical']=lex_scores
all_test['score_graph']=all_test.node.map(lambda n: 1.0-(math.log1p(G.in_degree(str(n))+G.out_degree(str(n)))/MAXLOG if str(n) in G else 1.0))
all_test['score_ours']=all_test.pred_semantic_conf.astype(float)
all_test['score_oracle']=all_test.delta.astype(float)
# ranking metrics overall and Clean separately
rankrows=[]
for subset_name,ss in [('All conditions',all_test),('Clean',all_test[all_test.condition=='Clean'])]:
    y=ss.beneficial.astype(int).to_numpy()
    for name,col in [('Lexical similarity','score_lexical'),('Graph heuristic','score_graph'),('Ours','score_ours'),('Oracle utility','score_oracle')]:
        sc=ss[col].to_numpy(float)
        rankrows.append({'subset':subset_name,'method':name,'n':len(ss),'positive_rate':y.mean(),
                         'auroc':roc_auc_score(y,sc) if len(np.unique(y))>1 else np.nan,
                         'auprc':average_precision_score(y,sc) if len(np.unique(y))>1 else np.nan})
pd.DataFrame(rankrows).to_csv(BASE/'stage2_ranking_metrics.csv',index=False)

# downstream intervention, K=1, equal confidence, fixed gate. Random averaged over 20 deterministic selections/query.
inter=[]
for key,d in all_test.groupby(['task','rid','split','condition']):
    task,rid,split,cond=key; row=MAN[(task,rid)]; dd=d.drop_duplicates('node').copy()
    choices={
      'Lexical Selection': str(dd.loc[dd.score_lexical.idxmax(),'node']),
      'Graph-Heuristic Selection': str(dd.loc[dd.score_graph.idxmax(),'node']),
      'Ours Reliability Selection': str(dd.loc[dd.score_ours.idxmax(),'node']),
      'Oracle Selection': str(dd.loc[dd.score_oracle.idxmax(),'node']),
    }
    for name,n in choices.items():
        f,er,ah=eval_run(row,{n:1.0},0.30)
        inter.append({'task':task,'rid':rid,'condition':cond,'method':name,'rep':0,'path_success':f,'edge_recall':er,'answer_hit':ah})
    nodes=dd.node.astype(str).tolist()
    for rep in range(20):
        rr=np.random.default_rng(SEED+rep*100003+(abs(hash((task,rid,cond)))%100000))
        n=nodes[int(rr.integers(0,len(nodes)))]
        f,er,ah=eval_run(row,{n:1.0},0.30)
        inter.append({'task':task,'rid':rid,'condition':cond,'method':'Random Selection','rep':rep,'path_success':f,'edge_recall':er,'answer_hit':ah})
si=pd.DataFrame(inter); si.to_csv(BASE/'stage2_selection_intervention_detailed.csv',index=False)
# average random first per query, then aggregate to avoid 100x weighting
siq=si.groupby(['task','rid','condition','method']).agg(path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index()
siq.to_csv(BASE/'stage2_selection_intervention_per_query.csv',index=False)
sis=[]
for subset_name,ss in [('All conditions',siq),('Clean',siq[siq.condition=='Clean'])]:
    z=ss.groupby('method').agg(n=('rid','size'),path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index(); z['subset']=subset_name; sis.append(z)
pd.concat(sis,ignore_index=True).to_csv(BASE/'stage2_selection_intervention_summary.csv',index=False)
# Bootstrap Ours vs non-oracle baselines over per-query matched results
boot2=[]; brng=np.random.default_rng(SEED+2)
for subset_name,ss in [('All conditions',siq),('Clean',siq[siq.condition=='Clean'])]:
    ours=ss[ss.method=='Ours Reliability Selection']
    for base in ['Random Selection','Lexical Selection','Graph-Heuristic Selection']:
        bb=ss[ss.method==base]
        mm=ours.merge(bb,on=['task','rid','condition'],suffixes=('_ours','_base'))
        for metric in ['path_success','edge_recall','answer_hit']:
            dif=(mm[f'{metric}_ours']-mm[f'{metric}_base']).to_numpy(float)
            ix=brng.integers(0,len(dif),(B,len(dif))); z=dif[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
            boot2.append({'subset':subset_name,'comparison':f'Ours - {base}','metric':metric,'mean_diff':dif.mean(),'ci95_low':lo,'ci95_high':hi})
pd.DataFrame(boot2).to_csv(BASE/'stage2_selection_bootstrap.csv',index=False)

# ---------------- Stage III: fixed vs hard vs continuous vs oracle ----------------
# use learned confidence throughout; select hard gate threshold and on-strength on validation.
agrid=np.round(np.arange(0,0.501,0.05),3)
valkeys=[k for k in CAND_GROUP if k[2]=='val']; testkeys=[k for k in CAND_GROUP if k[2]=='test']
cache={}
for key in valkeys:
    task,rid,split,cond=key; row=MAN[(task,rid)]; dd=CAND_GROUP[key].drop_duplicates('node'); conf=dict(zip(dd.node.astype(str),dd.pred_semantic_conf.astype(float)))
    for a in agrid: cache[(key,float(a))]=eval_run(row,conf,float(a))
hardgrid=[]
for gon in [0.20,0.25,0.30,0.35,0.40,0.45,0.50]:
    for tau in np.round(np.arange(.10,.91,.05),2):
        vals=[]
        for key in valkeys:
            a=float(gon if GATE[key]>=tau else 0.0); vals.append(cache[(key,float(a))])
        A=np.asarray(vals,float); util=.7*A[:,0].mean()+.3*A[:,1].mean()
        hardgrid.append({'g_on':gon,'threshold':tau,'path_success':A[:,0].mean(),'edge_recall':A[:,1].mean(),'answer_hit':A[:,2].mean(),'utility':util})
hg=pd.DataFrame(hardgrid).sort_values(['utility','path_success','edge_recall'],ascending=False); hg.to_csv(BASE/'stage3_hard_gate_validation_grid.csv',index=False)
besth=hg.iloc[0]; GON=float(besth.g_on); TAU=float(besth.threshold)
# current continuous params selected by existing validation
rep=json.load(open(BASE/'final_continuous_report.json')); GMAX=float(rep['selected_gate']['gmax']); GAM=float(rep['selected_gate']['gamma'])
rows3=[]
for key in testkeys:
    task,rid,split,cond=key; row=MAN[(task,rid)]; dd=CAND_GROUP[key].drop_duplicates('node'); conf=dict(zip(dd.node.astype(str),dd.pred_semantic_conf.astype(float))); p=GATE[key]
    methods={'Graph Only':0.0,'Fixed Guidance':0.30,'Hard Gate':GON if p>=TAU else 0.0,'Continuous Gate':GMAX*(p**GAM)}
    # oracle best alpha on this query under same candidate set (upper bound only)
    vals=[]
    for a in agrid:
        ev=eval_run(row,conf,float(a)); vals.append((.7*ev[0]+.3*ev[1],float(a)))
    oa=max(vals,key=lambda x:x[0])[1]; methods['Oracle Gate']=oa
    for name,a in methods.items():
        f,er,ah=eval_run(row,{} if name=='Graph Only' else conf,a)
        rows3.append({'task':task,'rid':rid,'condition':cond,'method':name,'p_reliable':p,'gate':a,'path_success':f,'edge_recall':er,'answer_hit':ah})
s3=pd.DataFrame(rows3); s3.to_csv(BASE/'stage3_gate_comparison_detailed.csv',index=False)
s3sum=s3.groupby(['method','condition']).agg(n=('rid','size'),mean_gate=('gate','mean'),path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index(); s3sum.to_csv(BASE/'stage3_gate_comparison_by_condition.csv',index=False)
s3overall=s3.groupby('method').agg(n=('rid','size'),mean_gate=('gate','mean'),path_success=('path_success','mean'),edge_recall=('edge_recall','mean'),answer_hit=('answer_hit','mean')).reset_index(); s3overall.to_csv(BASE/'stage3_gate_comparison_overall.csv',index=False)
# bootstrap Continuous vs Fixed and Hard, overall + each condition
boot3=[]; brng=np.random.default_rng(SEED+3)
for cond in ['All']+['Clean','25%','50%','75%','Random']:
    ss=s3 if cond=='All' else s3[s3.condition==cond]
    cc=ss[ss.method=='Continuous Gate']
    for base in ['Fixed Guidance','Hard Gate']:
        bb=ss[ss.method==base]; mm=cc.merge(bb,on=['task','rid','condition'],suffixes=('_c','_b'))
        for metric in ['path_success','edge_recall','answer_hit']:
            dif=(mm[f'{metric}_c']-mm[f'{metric}_b']).to_numpy(float)
            ix=brng.integers(0,len(dif),(B,len(dif))); z=dif[ix].mean(1); lo,hi=np.quantile(z,[.025,.975])
            boot3.append({'condition':cond,'comparison':f'Continuous - {base}','metric':metric,'mean_diff':dif.mean(),'ci95_low':lo,'ci95_high':hi})
pd.DataFrame(boot3).to_csv(BASE/'stage3_gate_bootstrap.csv',index=False)

print('\nSTAGE I\n',s1sum.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nSTAGE I bootstrap\n',pd.DataFrame(boot1).to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nSTAGE II ranking\n',pd.DataFrame(rankrows).to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nSTAGE II selection\n',pd.concat(sis,ignore_index=True).to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nSTAGE III selected hard gate',{'g_on':GON,'threshold':TAU},'continuous',{'gmax':GMAX,'gamma':GAM})
print('\nSTAGE III overall\n',s3overall.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
print('\nSTAGE III by condition\n',s3sum.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
