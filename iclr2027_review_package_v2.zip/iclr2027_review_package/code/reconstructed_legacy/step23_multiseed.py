"""Reconstructed multi-seed extension of preserved step22_large_exploratory_study.py."""
import random, json
from pathlib import Path
import numpy as np, pandas as pd
import step22_large_exploratory_study as exp

SEEDS=[20260826,20260827,20260828,20260829,20260830]
N_CASES=200

def run_seed(seed):
    rng=random.Random(seed); rows=[]
    oldb,olda=exp.search_module.BEAM_WIDTH,exp.search_module.BRIDGE_ALPHA
    exp.search_module.BEAM_WIDTH=2; exp.search_module.BRIDGE_ALPHA=.30
    try:
        cases=[exp.build_case(i+1,rng) for i in range(N_CASES)]
        for c in cases:
            conds=[('No Bridge',{}),('Clean Bridge',dict(c.clean_bridges)),('25% Noise',exp.make_noisy(c,.25,rng)),('50% Noise',exp.make_noisy(c,.50,rng)),('75% Noise',exp.make_noisy(c,.75,rng)),('Random Bridge',exp.make_random(c,rng))]
            for name,b in conds:
                z=exp.run_one(c,name,b); z['seed']=seed; rows.append(z)
    finally: exp.search_module.BEAM_WIDTH=oldb; exp.search_module.BRIDGE_ALPHA=olda
    return rows

def main():
    df=pd.DataFrame([r for s in SEEDS for r in run_seed(s)])
    df.to_csv('step23_multiseed_detailed_results.csv',index=False)
    sm=df.groupby('condition').agg(n=('found','size'),success_rate=('found','mean'),mean_edge_recall=('edge_recall','mean'),mean_visited_nodes=('visited_nodes','mean'),mean_expanded_edges=('expanded_edges','mean')).reset_index(); sm.to_csv('step23_multiseed_summary.csv',index=False)
    ps=df.groupby(['seed','condition']).agg(n=('found','size'),success_rate=('found','mean'),mean_edge_recall=('edge_recall','mean'),mean_visited_nodes=('visited_nodes','mean'),mean_expanded_edges=('expanded_edges','mean')).reset_index(); ps.to_csv('step23_per_seed_summary.csv',index=False)
    rng=np.random.default_rng(20260831); pairs=[]
    piv=df.pivot_table(index=['seed','case_id'],columns='condition',values=['found','edge_recall'])
    for b in ['25% Noise','50% Noise','75% Noise','Random Bridge','No Bridge']:
        for metric in ['found','edge_recall']:
            d=(piv[(metric,'Clean Bridge')]-piv[(metric,b)]).to_numpy(float); ix=rng.integers(0,len(d),(5000,len(d))); z=d[ix].mean(1); lo,hi=np.quantile(z,[.025,.975]); pairs.append({'comparison':f'Clean Bridge - {b}','metric':metric,'mean_diff':d.mean(),'ci95_low':lo,'ci95_high':hi})
    pd.DataFrame(pairs).to_csv('step23_paired_bootstrap_comparisons.csv',index=False)
    Path('step23_multiseed_report.json').write_text(json.dumps({'seeds':SEEDS,'n_cases_per_seed':N_CASES,'summary':sm.to_dict('records'),'bootstrap':pairs},indent=2))
if __name__=='__main__': main()
