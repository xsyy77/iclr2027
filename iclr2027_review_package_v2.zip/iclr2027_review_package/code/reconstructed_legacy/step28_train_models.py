"""Reconstructed legacy checkpoint trainer. Produces a gate checkpoint compatible with step30."""
import numpy as np, pandas as pd, torch, torch.nn as nn
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, average_precision_score
class MLP(nn.Module):
 def __init__(self,d): super().__init__(); self.net=nn.Sequential(nn.Linear(d,64),nn.ReLU(),nn.Dropout(.1),nn.Linear(64,32),nn.ReLU(),nn.Dropout(.1),nn.Linear(32,1))
 def forward(self,x): return self.net(x)
def main():
 g=pd.read_csv('step27_gate_training_samples.csv'); conds=['Clean Bridge','25% Noise','50% Noise','75% Noise','Random Bridge']; X=np.column_stack([[g.condition.eq(c).astype(float) for c in conds],g.gain.to_numpy(float)]).T if False else None
 # compact deterministic features from available table only
 X=np.column_stack([g.condition.eq(c).astype(float).to_numpy() for c in conds]+[g.gain.to_numpy(float)])
 y=g.z.to_numpy(np.float32); tr=g.split.eq('train').to_numpy(); sc=StandardScaler().fit(X[tr]); Z=sc.transform(X).astype('float32')
 m=MLP(Z.shape[1]); opt=torch.optim.Adam(m.parameters(),lr=1e-3,weight_decay=1e-4); loss=nn.BCEWithLogitsLoss(pos_weight=torch.tensor([(tr.sum()-y[tr].sum())/max(1,y[tr].sum())]))
 Xt=torch.tensor(Z[tr]); yt=torch.tensor(y[tr])[:,None]
 for _ in range(300): opt.zero_grad(); L=loss(m(Xt),yt); L.backward(); opt.step()
 torch.save({'state':m.state_dict(),'scaler_mean':sc.mean_,'scaler_scale':sc.scale_,'feature_note':'reconstructed legacy compact gate features'},'step28_gate_onoff_model.pt')
if __name__=='__main__': main()
