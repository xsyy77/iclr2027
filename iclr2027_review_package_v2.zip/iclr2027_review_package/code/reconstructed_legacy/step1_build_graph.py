"""Reconstructed compatibility version of the missing historical step1_build_graph.py.

This file is NOT byte-identical to the original. It restores the interface required by
step7_guided_search.py so the legacy demo can run. Current paper experiments do not depend on it.
"""
from __future__ import annotations
import networkx as nx


def _node(g, nid, name, entity_type):
    g.add_node(nid, name=name, entity_type=entity_type, description=f"Synthetic {entity_type} node")


def _edge(g, u, v, relation, confidence):
    g.add_edge(u, v, relation=relation, confidence=float(confidence), evidence="Synthetic controlled evidence")


def build_neuroscience_graph() -> nx.MultiDiGraph:
    g = nx.MultiDiGraph()
    nodes = [
        ("APOE", "APOE", "Gene"), ("ApoE4", "ApoE4 protein", "Protein"),
        ("Microglia", "Microglia", "CellType"), ("Neuroinflammation", "Neuroinflammation", "BiologicalProcess"),
        ("SynapticDysfunction", "Synaptic dysfunction", "NeuralProcess"), ("MemoryImpairment", "Memory impairment", "Phenotype"),
        ("TREM2", "TREM2", "Gene"), ("Astrocyte", "Astrocyte", "CellType"),
        ("OxidativeStress", "Oxidative stress", "BiologicalProcess"), ("MotorDysfunction", "Motor dysfunction", "Phenotype"),
    ]
    for x in nodes: _node(g, *x)
    path = [
        ("APOE","ApoE4","encodes",.93),("ApoE4","Microglia","impairs",.91),
        ("Microglia","Neuroinflammation","dysfunction_causes",.92),
        ("Neuroinflammation","SynapticDysfunction","promotes",.90),
        ("SynapticDysfunction","MemoryImpairment","causes",.94),
    ]
    distractors = [
        ("APOE","TREM2","associated_with",.99),("TREM2","Astrocyte","regulates",.98),
        ("Astrocyte","OxidativeStress","promotes",.97),("OxidativeStress","MotorDysfunction","causes",.96),
    ]
    for e in path+distractors: _edge(g,*e)
    return g
