"""Reconstructed compatibility version of the missing historical step12_batch_experiment.py.

Restores BenchmarkCase/build_batch_graph/build_benchmark_cases used by step15-step17.
It is a deterministic synthetic benchmark matching the preserved interfaces and experimental intent,
but it must not be represented as the byte-identical original historical source.
"""
from __future__ import annotations
from dataclasses import dataclass
import networkx as nx

@dataclass
class BenchmarkCase:
    case_id: str
    question: str
    source_node: str
    target_node: str
    gold_path_nodes: list[str]
    gold_path_relations: list[str]
    predicted_bridge_utilities: dict[str, float]


def _add_node(g,n,t):
    g.add_node(n,name=n,entity_type=t,description="Controlled synthetic biomedical node")

def _add_edge(g,u,v,r,c):
    g.add_edge(u,v,relation=r,confidence=float(c),evidence="Controlled synthetic evidence")


def build_benchmark_cases() -> list[BenchmarkCase]:
    specs = [
        ("C01","GENE_A","PHENO_A",["GENE_A","PROT_A","CELL_A","PROC_A","PHENO_A"],["encodes","impairs","promotes","causes"],{"PROT_A":.90,"PROC_A":.94}),
        ("C02","GENE_B","PHENO_B",["GENE_B","PROT_B","CELL_B","PROC_B","NEURAL_B","PHENO_B"],["encodes","impairs","dysfunction_causes","promotes","causes"],{"PROT_B":.89,"PROC_B":.93,"NEURAL_B":.96}),
        ("C03","GENE_C","PHENO_C",["GENE_C","PROT_C","CELL_C","PROC_C","PHENO_C"],["encodes","impairs","promotes","causes"],{"CELL_C":.91,"PROC_C":.95}),
        ("C04","GENE_D","PHENO_D",["GENE_D","PROT_D","CELL_D","PROC_D","NEURAL_D","PHENO_D"],["encodes","impairs","dysfunction_causes","promotes","causes"],{"PROT_D":.90,"CELL_D":.92,"NEURAL_D":.97}),
        ("C05","GENE_E","PHENO_E",["GENE_E","PROT_E","CELL_E","PROC_E","PHENO_E"],["encodes","impairs","promotes","causes"],{"PROT_E":.91,"PROC_E":.96}),
        ("C06","GENE_F","PHENO_F",["GENE_F","PROT_F","CELL_F","PROC_F","NEURAL_F","PHENO_F"],["encodes","impairs","dysfunction_causes","promotes","causes"],{"CELL_F":.90,"PROC_F":.94,"NEURAL_F":.97}),
    ]
    return [BenchmarkCase(cid,f"How can {s} lead to {t}?",s,t,nodes,rels,bridges) for cid,s,t,nodes,rels,bridges in specs]


def build_batch_graph() -> nx.MultiDiGraph:
    g=nx.MultiDiGraph()
    type_order=["Gene","Protein","CellType","BiologicalProcess","NeuralProcess","Phenotype"]
    for case in build_benchmark_cases():
        for i,n in enumerate(case.gold_path_nodes): _add_node(g,n,type_order[min(i,len(type_order)-1)])
        for i,r in enumerate(case.gold_path_relations): _add_edge(g,case.gold_path_nodes[i],case.gold_path_nodes[i+1],r,.91+.01*(i%3))
        # locally stronger dead-end branches make guidance meaningful
        for j in range(1,5):
            prev=case.source_node
            for k in range(1,5):
                n=f"{case.case_id}_DISTRACTOR_{j}_{k}"; _add_node(g,n,type_order[min(k,len(type_order)-2)])
                _add_edge(g,prev,n,["causes","promotes","regulates","supports"][k-1],.995-.003*k)
                prev=n
    return g
