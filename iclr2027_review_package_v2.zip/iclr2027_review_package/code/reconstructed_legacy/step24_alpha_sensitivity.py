"""Reconstructed alpha sensitivity experiment using the preserved controlled generator."""
import random, json
from pathlib import Path
import pandas as pd
import step22_large_exploratory_study as exp
SEEDS=[20260826,20260827,20260828]; ALPHAS=[0,.1,.2,.3,.4,.5]; N=200

def main():
 rows=[]; oldb,olda=exp.search_module.BEAM_WIDTH,exp.search_module.BRIDGE_ALPHA; exp.search_module.BEAM_WIDTH=2
 try:
  for s in SEEDS:
   rng=random.Random(s); cases=[exp.build_case(i+1,rng) for i in range(N)]
   for a in ALPHAS:
    exp.search_module.BRIDGE_ALPHA=a
    for c in cases:
     for name,b in [('Clean Bridge',dict(c.clean_bridges)),('25% Noise',exp.make_noisy(c,.25,rng)),('50% Noise',exp.make_noisy(c,.5,rng)),('75% Noise',exp.make_noisy(c,.75,rng)),('Random Bridge',exp.make_random(c,rng))]:
      z=exp.run_one(c,name,b); rows.append({'seed':s,'alpha':a,**z})
 finally: exp.search_module.BEAM_WIDTH=oldb; exp.search_module.BRIDGE_ALPHA=olda
 d=pd.DataFrame(rows); sm=d.groupby(['alpha','condition']).agg(n=('found','size'),success_rate=('found','mean'),mean_edge_recall=('edge_recall','mean')).reset_index(); sm.to_csv('step24_alpha_sensitivity_summary.csv',index=False); Path('step24_alpha_sensitivity_report.json').write_text(json.dumps({'summary':sm.to_dict('records')},indent=2))
if __name__=='__main__': main()
