"""Reconstructed diagnostic summary for legacy controller inputs/results."""
import json, pandas as pd
from pathlib import Path
def main():
 g=pd.read_csv('step27_gate_training_samples.csv'); c=pd.read_csv('step27_confidence_training_samples.csv')
 rep={'gate_rows':len(g),'candidate_rows':len(c),'gate_positive_rate_by_split':g.groupby('split').z.mean().to_dict(),'bridge_beneficial_rate_by_split':c.groupby('split').beneficial.mean().to_dict()}
 Path('step29_controller_diagnostics.json').write_text(json.dumps(rep,indent=2)); print(json.dumps(rep,indent=2))
if __name__=='__main__': main()
