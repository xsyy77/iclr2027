"""Reconstructed fixed-global-alpha vs per-query oracle experiment."""
import random, json
from pathlib import Path
import numpy as np, pandas as pd
import step22_large_exploratory_study as exp
ALPHAS=[0,.1,.2,.3,.4,.5]; VAL_SEEDS=[20260826,20260827]; TEST_SEEDS=[20260828,20260829,20260830]; N=200

def all_rows(seeds):
 out=[]; oldb,olda=exp.search_module.BEAM_WIDTH,exp.search_module.BRIDGE_ALPHA; exp.search_module.BEAM_WIDTH=2
 try:
  for s in seeds:
   rng=random.Random(s)
   for i in range(N):
    c=exp.build_case(i+1,rng); sets={'Clean Bridge':dict(c.clean_bridges),'25% Noise':exp.make_noisy(c,.25,rng),'50% Noise':exp.make_noisy(c,.5,rng),'75% Noise':exp.make_noisy(c,.75,rng),'Random Bridge':exp.make_random(c,rng)}
    for cond,b in sets.items():
     for a in ALPHAS:
      exp.search_module.BRIDGE_ALPHA=a; z=exp.run_one(c,cond,b); out.append({'seed':s,'uid':f'{s}_{c.case_id}','alpha':a,**z})
 finally: exp.search_module.BEAM_WIDTH=oldb; exp.search_module.BRIDGE_ALPHA=olda
 return pd.DataFrame(out)

def main():
 val=all_rows(VAL_SEEDS); test=all_rows(TEST_SEEDS); val['utility']=.7*val.found+.3*val.edge_recall; test['utility']=.7*test.found+.3*test.edge_recall
 vs=val.groupby('alpha').agg(path_success=('found','mean'),edge_recall=('edge_recall','mean'),utility=('utility','mean')).reset_index().sort_values(['utility','path_success'],ascending=False); fixed=float(vs.iloc[0].alpha); vs.to_csv('step26_validation_alpha_selection.csv',index=False)
 fixed_df=test[test.alpha==fixed].copy(); fixed_df.to_csv('step26_fixed_alpha_test_results.csv',index=False)
 idx=test.groupby(['uid','condition'])['utility'].idxmax(); oracle=test.loc[idx].copy(); oracle.to_csv('step26_oracle_alpha_test_results.csv',index=False)
 pair=oracle.merge(fixed_df,on=['uid','condition'],suffixes=('_oracle','_fixed')); pair.to_csv('step26_fixed_vs_oracle_paired.csv',index=False)
 cc=pair.groupby('condition').agg(n=('uid','size'),fixed_path_success=('found_fixed','mean'),oracle_path_success=('found_oracle','mean'),fixed_edge_recall=('edge_recall_fixed','mean'),oracle_edge_recall=('edge_recall_oracle','mean')).reset_index(); cc.to_csv('step26_condition_comparison.csv',index=False)
 dist=oracle.groupby(['condition','alpha']).size().rename('count').reset_index(); dist['fraction']=dist['count']/dist.groupby('condition')['count'].transform('sum'); dist.to_csv('step26_oracle_alpha_distribution.csv',index=False)
 allgrid=pd.concat([val.assign(split='val'),test.assign(split='test')]); allgrid.to_csv('step26_global_vs_oracle_alpha_detailed.csv',index=False)
 Path('step26_global_vs_oracle_alpha_report.json').write_text(json.dumps({'fixed_alpha':fixed,'condition_comparison':cc.to_dict('records'),'oracle_distribution':dist.to_dict('records')},indent=2))
if __name__=='__main__': main()
