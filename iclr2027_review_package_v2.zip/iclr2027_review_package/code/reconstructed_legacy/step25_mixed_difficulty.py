"""Reconstructed mixed-difficulty experiment: easy cases weaken distractors; hard cases preserve them."""
import random, json
from pathlib import Path
import numpy as np, pandas as pd
import step22_large_exploratory_study as exp
SEEDS=[20260826,20260827,20260828,20260829,20260830]; N=200

def main():
 rows=[]; oldb,olda=exp.search_module.BEAM_WIDTH,exp.search_module.BRIDGE_ALPHA; exp.search_module.BEAM_WIDTH=2; exp.search_module.BRIDGE_ALPHA=.3
 try:
  for s in SEEDS:
   rng=random.Random(s)
   for i in range(N):
    c=exp.build_case(i+1,rng); difficulty='easy' if rng.random()<.4 else 'hard'
    if difficulty=='easy':
     gp=set(zip(c.gold_nodes[:-1],c.gold_nodes[1:]))
     for u,v,k,d in c.graph.edges(keys=True,data=True): d['confidence']=rng.uniform(.94,.98) if (u,v) in gp else rng.uniform(.80,.88)
    for name,b in [('No Bridge',{}),('Clean Bridge',dict(c.clean_bridges)),('25% Noise',exp.make_noisy(c,.25,rng)),('50% Noise',exp.make_noisy(c,.5,rng)),('75% Noise',exp.make_noisy(c,.75,rng)),('Random Bridge',exp.make_random(c,rng))]:
     z=exp.run_one(c,name,b); rows.append({'seed':s,'difficulty':difficulty,**z})
 finally: exp.search_module.BEAM_WIDTH=oldb; exp.search_module.BRIDGE_ALPHA=olda
 d=pd.DataFrame(rows); d.to_csv('step25_mixed_difficulty_detailed.csv',index=False)
 sm=d.groupby('condition').agg(n=('found','size'),success_rate=('found','mean'),mean_edge_recall=('edge_recall','mean')).reset_index(); sm.to_csv('step25_mixed_difficulty_summary.csv',index=False)
 br=d.groupby(['difficulty','condition']).agg(n=('found','size'),success_rate=('found','mean'),mean_edge_recall=('edge_recall','mean')).reset_index(); br.to_csv('step25_mixed_difficulty_breakdown.csv',index=False)
 Path('step25_mixed_difficulty_report.json').write_text(json.dumps({'summary':sm.to_dict('records'),'breakdown':br.to_dict('records')},indent=2))
if __name__=='__main__': main()
