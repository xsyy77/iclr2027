"""Reconstructed training-sample generator for legacy confidence/gate experiments."""
import random, math
from collections import Counter
import numpy as np, pandas as pd
import step22_large_exploratory_study as exp
SEEDS=[20260826,20260827,20260828,20260829,20260830,20260831,20260832]; N=200

def utility(r): return .7*float(r['found'])+.3*float(r['edge_recall'])
def main():
 cand=[]; gate=[]; oldb,olda=exp.search_module.BEAM_WIDTH,exp.search_module.BRIDGE_ALPHA; exp.search_module.BEAM_WIDTH=2
 try:
  for si,s in enumerate(SEEDS):
   split='train' if si<4 else ('val' if si==4 else 'test'); rng=random.Random(s)
   for i in range(N):
    c=exp.build_case(i+1,rng); uid=f'{s}_{c.case_id}'; sets={'Clean Bridge':dict(c.clean_bridges),'25% Noise':exp.make_noisy(c,.25,rng),'50% Noise':exp.make_noisy(c,.5,rng),'75% Noise':exp.make_noisy(c,.75,rng),'Random Bridge':exp.make_random(c,rng)}
    exp.search_module.BRIDGE_ALPHA=0; base=exp.run_one(c,'No Bridge',{})
    for cond,bs in sets.items():
     exp.search_module.BRIDGE_ALPHA=.3; full=exp.run_one(c,cond,bs); gains=[]
     for n in bs:
      one=exp.run_one(c,cond,{n:bs[n]}); delta=utility(one)-utility(base); gains.append(delta)
      cand.append({'uid':uid,'split':split,'condition':cond,'node':n,'delta':delta,'beneficial':int(delta>0),'pred_conf':1/(1+math.exp(-5*delta))})
     gate.append({'uid':uid,'split':split,'condition':cond,'z':int(utility(full)>utility(base)),'gain':utility(full)-utility(base)})
 finally: exp.search_module.BEAM_WIDTH=oldb; exp.search_module.BRIDGE_ALPHA=olda
 pd.DataFrame(cand).to_csv('step27_confidence_training_samples.csv',index=False); pd.DataFrame(gate).to_csv('step27_gate_training_samples.csv',index=False)
if __name__=='__main__': main()
