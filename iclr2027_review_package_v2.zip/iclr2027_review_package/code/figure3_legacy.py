import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.colors import LinearSegmentedColormap

# ============================================================
# Figure 3 — FINAL STANDALONE / DATA-LOCKED VERSION
# Section 5.3: Complementarity and Coverage of Multi-View
# Mechanistic Bridges
#
# NO external CSV is required to run this file.
#
# Locked from the final Stage-I CSVs:
# 1) stage1_useful_coverage_summary.csv
# 2) stage1_costmatched_summary.csv
# 3) stage1_useful_candidate_by_query.csv
#
# IMPORTANT:
# - Does NOT use the old section5_3_figure4_data.xlsx.
# - Does NOT use the old 31.05 / 43.53 / 58.64 working-data values.
# - All displayed text uses the same base font size (10 pt).
# ============================================================

# ------------------------------------------------------------
# 0. Global paper-style typography
# ------------------------------------------------------------
BASE_FS = 10

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": BASE_FS,
    "axes.titlesize": BASE_FS,
    "axes.labelsize": BASE_FS,
    "xtick.labelsize": BASE_FS,
    "ytick.labelsize": BASE_FS,
    "legend.fontsize": BASE_FS,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# ------------------------------------------------------------
# 1. LOCKED FINAL DATA
# ------------------------------------------------------------

# ============================================================
# Panel (a)
# Source:
# stage1_useful_coverage_summary.csv
#
# n = 248 queries
#
# Molecular:      76 / 248 = 30.6452%
# Cellular:        4 / 248 =  1.6129%
# System:        100 / 248 = 40.3226%
# Multi-view:    152 / 248 = 61.2903%
# ============================================================

coverage_labels = [
    "Cellular",
    "Molecular",
    "System",
    "Multi-view",
]

coverage_counts = np.array([
    4,
    76,
    100,
    152,
], dtype=float)

N_TOTAL = 248

coverage_values = coverage_counts / N_TOTAL * 100.0

# Accuracy lock
expected_coverage = np.array([
    1.61290322580645,
    30.64516129032258,
    40.32258064516129,
    61.29032258064516,
])

if not np.allclose(coverage_values, expected_coverage, atol=1e-10):
    raise ValueError("Panel (a) locked coverage values do not match final CSV.")

# ============================================================
# Panel (b)
# Source:
# stage1_costmatched_summary.csv
#
# Locked matched proposal budget = 9
#
# System-only:
#   PS = 0.3508064516129032
#   ER = 0.3833957296711965
#
# Multi-view:
#   PS = 0.3508064516129032
#   ER = 0.3873241265431418
# ============================================================

BUDGET = 9

retrieval_metrics = ["Path Success", "Edge Recall"]

system_values = np.array([
    0.3508064516129032,
    0.3833957296711965,
]) * 100.0

multiview_values = np.array([
    0.3508064516129032,
    0.3873241265431418,
]) * 100.0

# Accuracy locks
assert np.isclose(system_values[0], 35.08064516129032)
assert np.isclose(system_values[1], 38.33957296711965)
assert np.isclose(multiview_values[0], 35.08064516129032)
assert np.isclose(multiview_values[1], 38.73241265431418)

# ============================================================
# Panel (c)
# Source:
# stage1_useful_candidate_by_query.csv
#
# Recomputed directly from final query-level indicators.
#
# Query counts:
#   Gene       n = 123
#   Metabolite n = 21
#   Process    n = 104
#
# Columns:
# Cellular / Molecular / System / Multi-view union
# ============================================================

task_labels = ["Gene", "Metabolite", "Process"]
view_labels = ["Cellular", "Molecular", "System", "Multi-view"]

# Exact counts from final query-level CSV.
# Order = Cellular, Molecular, System, Multi-view union
task_useful_counts = np.array([
    [2, 36, 42, 70],   # Gene, n=123
    [2,  8, 10, 15],   # Metabolite, n=21
    [0, 32, 48, 67],   # Process, n=104
], dtype=float)

task_ns = np.array([123, 21, 104], dtype=float)

task_coverage = task_useful_counts / task_ns[:, None] * 100.0

expected_task_coverage = np.array([
    [1.62601626016260, 29.26829268292683, 34.14634146341464, 56.91056910569106],
    [9.52380952380952, 38.09523809523810, 47.61904761904762, 71.42857142857143],
    [0.00000000000000, 30.76923076923077, 46.15384615384615, 64.42307692307692],
])

if not np.allclose(task_coverage, expected_task_coverage, atol=1e-10):
    raise ValueError("Panel (c) task-level coverage values do not match final CSV.")

# ------------------------------------------------------------
# 2. Colors
# ------------------------------------------------------------

COLORS = {
    "Cellular":   "#D9DCE3",
    "Molecular":  "#F0C5CF",
    "System":     "#E8C3A7",
    "Multi-view": "#C9829B",
}

GRID_COLOR = "#D5D5D5"
TEXT_COLOR = "#222222"

heatmap_cmap = LinearSegmentedColormap.from_list(
    "coverage_heatmap",
    [
        "#F7F7F7",
        "#E9E4E8",
        "#E1CDD6",
        "#D4AABC",
        "#C9829B",
    ],
)

# ------------------------------------------------------------
# 3. Figure layout
# ------------------------------------------------------------

fig = plt.figure(figsize=(11.4, 4.25))

# Larger gap between a and b so the shared legend can sit there.
gs = fig.add_gridspec(
    nrows=1,
    ncols=3,
    width_ratios=[1.05, 1.05, 1.28],
    wspace=0.62,
)

ax_a = fig.add_subplot(gs[0, 0])
ax_b = fig.add_subplot(gs[0, 1])
ax_c = fig.add_subplot(gs[0, 2])

# ------------------------------------------------------------
# 4. Panel (a): Candidate coverage
# ------------------------------------------------------------

x_a = np.arange(len(coverage_labels))

bars_a = ax_a.bar(
    x_a,
    coverage_values,
    width=0.66,
    color=[COLORS[x] for x in coverage_labels],
    edgecolor="white",
    linewidth=0.8,
    zorder=3,
)

ax_a.set_ylabel("Useful-candidate coverage (%)")
ax_a.set_xticks(x_a)
ax_a.set_xticklabels(
    ["Cellular", "Molecular", "System", "Multi-\nview"]
)

ax_a.set_ylim(0, 70)
ax_a.set_yticks(np.arange(0, 71, 10))

ax_a.grid(
    axis="y",
    linestyle="--",
    linewidth=0.6,
    alpha=0.45,
    color=GRID_COLOR,
    zorder=0,
)

ax_a.spines["top"].set_visible(False)
ax_a.spines["right"].set_visible(False)

for rect, val in zip(bars_a, coverage_values):
    ax_a.text(
        rect.get_x() + rect.get_width() / 2,
        val + 1.4,
        f"{val:.2f}",
        ha="center",
        va="bottom",
        fontsize=BASE_FS,
        color=TEXT_COLOR,
    )

# ------------------------------------------------------------
# 5. Panel (b): Matched-budget retrieval
# ------------------------------------------------------------

x_b = np.arange(len(retrieval_metrics))
bar_width = 0.31

bars_system = ax_b.bar(
    x_b - bar_width / 2,
    system_values,
    width=bar_width,
    color=COLORS["System"],
    edgecolor="white",
    linewidth=0.8,
    zorder=3,
)

bars_multi = ax_b.bar(
    x_b + bar_width / 2,
    multiview_values,
    width=bar_width,
    color=COLORS["Multi-view"],
    edgecolor="white",
    linewidth=0.8,
    zorder=3,
)

ax_b.set_ylabel("Matched-budget score (%)")
ax_b.set_xticks(x_b)
ax_b.set_xticklabels(["Path Success", "Edge Recall"])

# Narrow y range makes the matched-budget conclusion visible
# without altering any values.
ax_b.set_ylim(30, 42)
ax_b.set_yticks(np.arange(30, 43, 2))

ax_b.grid(
    axis="y",
    linestyle="--",
    linewidth=0.6,
    alpha=0.45,
    color=GRID_COLOR,
    zorder=0,
)

ax_b.spines["top"].set_visible(False)
ax_b.spines["right"].set_visible(False)

for rect, val in zip(bars_system, system_values):
    ax_b.text(
        rect.get_x() + rect.get_width() / 2,
        val + 0.35,
        f"{val:.2f}",
        ha="center",
        va="bottom",
        fontsize=BASE_FS,
        color=TEXT_COLOR,
    )

for rect, val in zip(bars_multi, multiview_values):
    ax_b.text(
        rect.get_x() + rect.get_width() / 2,
        val + 0.35,
        f"{val:.2f}",
        ha="center",
        va="bottom",
        fontsize=BASE_FS,
        color=TEXT_COLOR,
    )

ax_b.text(
    0.5,
    1.025,
    f"Matched proposal budget = {BUDGET}",
    transform=ax_b.transAxes,
    ha="center",
    va="bottom",
    fontsize=BASE_FS,
)

# ------------------------------------------------------------
# 6. Shared legend BETWEEN panels (a) and (b)
# ------------------------------------------------------------

legend_handles = [
    Patch(
        facecolor=COLORS["System"],
        edgecolor="white",
        label="System-only",
    ),
    Patch(
        facecolor=COLORS["Multi-view"],
        edgecolor="white",
        label="Multi-view",
    ),
]

# Need final axes positions before calculating midpoint.
fig.subplots_adjust(
    left=0.065,
    right=0.985,
    top=0.86,
    bottom=0.24,
)

pos_a = ax_a.get_position()
pos_b = ax_b.get_position()

gap_center_x = (pos_a.x1 + pos_b.x0) / 2.0
gap_center_y = pos_a.y0 + 0.64 * pos_a.height

fig.legend(
    handles=legend_handles,
    loc="center",
    bbox_to_anchor=(gap_center_x, gap_center_y),
    ncol=1,
    frameon=False,
    fontsize=BASE_FS,
    handlelength=1.5,
    handletextpad=0.5,
    borderaxespad=0,
)

# ------------------------------------------------------------
# 7. Panel (c): Task-level useful-candidate coverage
# ------------------------------------------------------------

im = ax_c.imshow(
    task_coverage,
    cmap=heatmap_cmap,
    vmin=0,
    vmax=75,
    aspect="auto",
    interpolation="nearest",
)

ax_c.set_xticks(np.arange(len(view_labels)))
ax_c.set_xticklabels(
    ["Cellular", "Molecular", "System", "Multi-\nview"]
)

ax_c.set_yticks(np.arange(len(task_labels)))
ax_c.set_yticklabels(task_labels)

ax_c.tick_params(
    axis="both",
    which="major",
    length=0,
    labelsize=BASE_FS,
)

# white cell boundaries
ax_c.set_xticks(
    np.arange(-0.5, len(view_labels), 1),
    minor=True,
)
ax_c.set_yticks(
    np.arange(-0.5, len(task_labels), 1),
    minor=True,
)

ax_c.grid(
    which="minor",
    color="white",
    linewidth=1.2,
)

ax_c.tick_params(
    which="minor",
    bottom=False,
    left=False,
)

for spine in ax_c.spines.values():
    spine.set_visible(False)

# Exact cell labels
for i in range(task_coverage.shape[0]):
    for j in range(task_coverage.shape[1]):
        value = task_coverage[i, j]

        label_color = (
            "white"
            if value >= 52
            else TEXT_COLOR
        )

        ax_c.text(
            j,
            i,
            f"{value:.1f}",
            ha="center",
            va="center",
            fontsize=BASE_FS,
            color=label_color,
        )

# Horizontal colorbar
cbar = fig.colorbar(
    im,
    ax=ax_c,
    orientation="horizontal",
    fraction=0.075,
    pad=0.13,
    aspect=28,
)

cbar.set_label(
    "Useful-candidate coverage (%)",
    fontsize=BASE_FS,
    labelpad=4,
)

cbar.set_ticks([0, 15, 30, 45, 60, 75])
cbar.ax.tick_params(
    labelsize=BASE_FS,
    length=2.5,
)

cbar.outline.set_linewidth(0.6)

# ------------------------------------------------------------
# 8. Panel labels — same font size as all other text
# ------------------------------------------------------------

ax_a.text(
    0.5,
    -0.22,
    r"$\bf{a}$  Candidate coverage",
    transform=ax_a.transAxes,
    ha="center",
    va="top",
    fontsize=BASE_FS,
)

ax_b.text(
    0.5,
    -0.22,
    r"$\bf{b}$  Matched retrieval",
    transform=ax_b.transAxes,
    ha="center",
    va="top",
    fontsize=BASE_FS,
)

ax_c.text(
    0.5,
    -0.28,
    r"$\bf{c}$  View complementarity across tasks",
    transform=ax_c.transAxes,
    ha="center",
    va="top",
    fontsize=BASE_FS,
)

# ------------------------------------------------------------
# 9. Console verification
# ------------------------------------------------------------

print("\n================ FIGURE 3 LOCK CHECK ================")

print("\nPanel (a): useful-candidate coverage")
for label, count, pct in zip(
    coverage_labels,
    coverage_counts.astype(int),
    coverage_values,
):
    print(f"{label:12s}: {count:3d}/{N_TOTAL} = {pct:.4f}%")

print("\nPanel (b): matched proposal budget = 9")
print(
    f"System-only | PS={system_values[0]:.4f}% "
    f"| ER={system_values[1]:.4f}%"
)
print(
    f"Multi-view  | PS={multiview_values[0]:.4f}% "
    f"| ER={multiview_values[1]:.4f}%"
)

print("\nPanel (c): task-level useful-candidate coverage")
for i, task in enumerate(task_labels):
    values = task_coverage[i]
    print(
        f"{task:10s} | "
        f"Cellular={values[0]:.4f}% | "
        f"Molecular={values[1]:.4f}% | "
        f"System={values[2]:.4f}% | "
        f"Multi-view={values[3]:.4f}%"
    )

print("\nAll values passed hard-coded consistency checks.")
print("=====================================================\n")

# ------------------------------------------------------------
# 10. Export
# ------------------------------------------------------------

plt.savefig(
    "figure3.pdf",
    bbox_inches="tight",
    dpi=600,
)

plt.savefig(
    "figure3.png",
    bbox_inches="tight",
    dpi=600,
)

plt.show()
