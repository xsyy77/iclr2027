# Portable rerun

Run `python portable/reproduce_dmdb.py` after installing `requirements.txt`.
It reads the packaged raw DrugMechDB graph, manifest, Bridge predictions, and gate predictions, runs the original final retrieval algorithm with repository-relative paths in a temporary directory, and compares three generated CSVs byte-for-byte with the saved mixed-condition outputs. It does **not** reproduce the separate 248-query clean-condition table or retrain the Bridge/gate estimators.

`run_final_dmdb.py` is a path-adapted copy of `code/original_recovered/current_dmdb/final_continuous_realgraph.py`; the scoring and search logic is unchanged. Set `BRIDGE_OUTPUT_DIR` to choose a persistent output directory (prepopulate the three required CSV inputs there).

The EpiKG original source in `code/original_recovered/current_epikg/` uses Python's process-randomized `hash(rel)` to seed sampling and split assignment. A new run with the packaged graph and MCQ data produced different test metrics from the archived files. The archived EpiKG numbers are therefore traceable to saved outputs but **not exactly reproducible** from these materials; see `REPRODUCIBILITY_STATUS.md`. We do not present a portable EpiKG rerun as an exact reproduction.
