"""Fresh rerun of the archived DrugMechDB mixed-condition retrieval from packaged inputs."""
from pathlib import Path
import os, shutil, subprocess, sys, tempfile

root=Path(__file__).resolve().parents[1]
source=root/'data/processed/drugmechdb'
files=['benchmark_manifest.csv','semantic_bridge_predictions.csv','semantic_gate_predictions.csv']
outputs=['final_continuous_overall.csv','final_continuous_validation_grid.csv','final_continuous_bootstrap.csv']
with tempfile.TemporaryDirectory(prefix='dmdb_repro_') as temp:
    out=Path(temp)
    for name in files: shutil.copy2(source/name,out/name)
    env=os.environ.copy(); env['BRIDGE_OUTPUT_DIR']=str(out)
    subprocess.run([sys.executable,str(root/'portable/run_final_dmdb.py')],env=env,check=True,stdout=subprocess.DEVNULL)
    mismatches=[name for name in outputs if (out/name).read_bytes()!=(source/name).read_bytes()]
    if mismatches: raise SystemExit('MISMATCH: '+', '.join(mismatches))
    print('PASS: independent rerun matches saved DrugMechDB mixed-condition outputs byte-for-byte (3/3 files).')
