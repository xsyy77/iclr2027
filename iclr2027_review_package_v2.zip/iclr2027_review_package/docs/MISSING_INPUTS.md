# Missing or unresolved inputs

This package contains every experiment/code/data artifact that could be traced back to the uploaded project materials in this session. It **does not claim byte-for-byte full reproducibility** of every sentence in the current manuscript because several upstream files are not currently available as raw files.

## DrugMechDB raw inputs referenced by scripts but not found/materialized

The core DrugMechDB scripts expect files such as:

- `indication_paths.json` or `audit_run/indication_paths_full.json`
- `benchmark_manifest.csv`
- `bridge_marginal_training_samples.csv`
- `gate_training_samples.csv`
- in some rerun scripts, `semantic_gate_predictions.csv`
- `final_continuous_report.json` for `rerun_stage12_fixed.py`

The package includes downstream predictions/results where available, but these missing inputs prevent a clean-room rerun from raw data.

## Stage-I 40.32% -> 61.29% claim

The current paper states that useful-candidate coverage rises from 40.32% (strongest single view) to 61.29% (Multi-view). A currently traceable figure reconstruction and Stage-I rerun code exist, but the exact raw/generated artifact that produces **40.32 and 61.29** was not located. Therefore this particular sentence is marked **provenance unresolved** and should not be advertised as fully reproduced until the original source table/script is restored.

The traceable Stage-I figure reconstruction uses these confirmed values:

- candidate availability: Molecular 81.05, System 93.15, Multi-view 98.79
- matched-budget PS/ER: Molecular 26.17/32.95, System 29.91/34.16, Multi-view 28.97/34.87
- controlled PS/ER: Molecular 31.05/43.53, System 34.68/47.27, Multi-view 39.11/58.64
- task-level ER matrix stored in `code/figure3_stage1_reconstructed.py`

## Exploratory Section 3 / Figure 1

The manuscript describes a corruption study over 1,000 retrieval instances and five seeds (Clean, 25%, 50%, 75%, Random, No Bridge). The exact executable script and raw output table for the current Figure 1 were not located in the uploaded artifacts during this audit. The paper text and final PDF are included, but this experiment is **not yet clean-room reproducible from this bundle**.

## EpiKG

Executable EpiKG rerun scripts are included, but their raw inputs were not available in the current mounted/uploaded artifacts:

- `triplets(1).json`
- `epikg_benchmark_manifest.csv`
- EpiBench MCQ source consumed by the script

Thus Table 4 can be traced to the EpiKG code and manuscript, but cannot be fully rerun without restoring these raw inputs.

## CWQ / OpenBioLink / BioHopR

- A CWQ transfer script artifact was found, but the recoverable materialized copy is truncated (`code/run_cwq_same_pipeline.partial.txt`) and is not runnable. Its result CSVs were not located. Restore the original full script before claiming CWQ reproducibility.
- OpenBioLink runnable code/results were not recovered in this audit.
- BioHopR runnable code/results were not recovered in this audit.

The current Section 5.1 still lists CWQ/OpenBioLink/BioHopR, while the current main-text results shown in Sections 5.2--5.6 are DrugMechDB + EpiKG. This should be reconciled before submission.

## LaTeX build dependencies/assets

The current TeX references:

- `iclr2025_conference.sty`
- `references.bib`
- `figure 1.pdf`
- `figure2.pdf`
- `figure3.pdf`
- `figure5.pdf` (rendered as Figure 4 in the current manuscript)

The current PDF and TeX are included. `figure3_reference.pdf` is included, and Figure 4 is reproducible from bundled code/data. The remaining exact source assets/style/bibliography were not all recovered in this audit.
