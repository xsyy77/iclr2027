# Reproducibility audit for the current manuscript

Status labels:

- **VERIFIED**: bundled data/code directly reproduces or numerically verifies the result.
- **TRACEABLE/PARTIAL**: code or downstream data exists, but an upstream raw input is missing.
- **UNRESOLVED**: the exact generating artifact could not be located.

| Manuscript component | Status | Supporting artifacts | Notes |
|---|---|---|---|
| Section 3 exploratory corruption study | UNRESOLVED | current PDF/TeX only | Exact executable/raw output not recovered. |
| Section 4.3 Bridge feature construction | VERIFIED (code definition) | `step_semantic_bridge_diagnostics.py` | Exact semantic + graph features are present in code. |
| Section 4.4 query gate features | VERIFIED (code definition) | `step_semantic_gate_diagnostics.py` | Exact DrugMechDB query/candidate-set features are present. |
| Section 4.4 path score | VERIFIED (code definition) | `final_continuous_realgraph.py` | Relation prior, anti-hub term, Bridge score and length penalty are explicit. |
| Table 1 DrugMechDB Clean values | VERIFIED | `main_results_current.csv`, `verify_bundle.py` | Graph Only / Fixed Bridge / Confidence+Fixed / Ours values verify. |
| Stage-I Figure 3 traceable values | VERIFIED/PARTIAL | `figure3_stage1_reconstructed.py`, `figure3_verified_experimental_data.xlsx`, `rerun_stage12_fixed.py` | Figure values are traceable; exact 40.32->61.29 claim is unresolved. |
| Stage-II retrieval-aware AUROC/AUPRC | VERIFIED | `semantic_bridge_predictions.csv`, `verify_bundle.py` | Recomputed from candidate-level predictions. |
| Stage-II utility-weight sensitivity | VERIFIED | `stage2_utility_weight_sensitivity*.csv` | Weight 0.5--0.9 gives unchanged labels/AUROC/AUPRC. |
| Stage-III Graph/global/mean/full controls | VERIFIED | `stage3_controls_summary.csv`, `stage3_controls_bootstrap.csv` | Includes paired 5000-resample bootstrap. |
| Stage-III shuffled gates | VERIFIED | `stage3_full_vs_shuffled.csv`, `stage3_shuffled_gate_repetitions.csv` | 500 reassignments; ER 97.6%, utility 96.0% Full>shuffle. |
| Figure 4 | VERIFIED | `figure4_stage3_shuffled_gate.py`, shuffle repetitions CSV, reproduced PDF/PNG | Re-generated inside this package. |
| EpiKG Table 4 | TRACEABLE/PARTIAL | EpiKG rerun scripts | Raw graph/manifest/MCQ inputs need restoration. |
| CWQ transfer | TRACEABLE/PARTIAL | `run_cwq_same_pipeline.partial.txt` | Source artifact found, but the materialized copy is truncated/non-runnable and final output CSVs were not recovered. |
| OpenBioLink transfer | UNRESOLVED | none recovered | Listed in current setup but no recovered runnable artifact in this audit. |
| BioHopR transfer | UNRESOLVED | none recovered | Listed in current setup but no recovered runnable artifact in this audit. |

## Protocol warning: do not mix two DrugMechDB result families

Two experiment families appeared in project artifacts:

1. A same-snapshot end-to-end family in `figure3_verified_experimental_data.xlsx` (Graph 27.02/33.97/70.56; Semantic+Fixed 33.87/39.26/73.39; Utility+Fixed 32.66/38.51/72.18; Full 32.26/38.44/72.58).
2. The current Table-1 **Clean-condition** family in `main_results_current.csv` (Graph 27.02/33.97/70.56; Fixed Bridge 39.11/58.56/91.53; Confidence+Fixed 39.52/58.94/91.13; Ours 39.52/59.46/91.94).

These should never be silently mixed. The current manuscript uses family (2).

## Statistical interpretation warning

For Full vs mean-matched constant, paired 95% bootstrap intervals cross zero for ER and utility. The manuscript appropriately describes this as a modest numerical advantage rather than a significant large gain.

For Full vs shuffled gates, `shuffle_q025_diff` / `shuffle_q975_diff` are the distribution across random reassignments, **not** a query-level paired bootstrap CI. The clean paper statement is the fraction of shuffled runs beaten by Full (97.6% ER, 96.0% utility).
