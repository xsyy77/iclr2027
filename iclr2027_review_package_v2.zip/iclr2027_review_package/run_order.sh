#!/usr/bin/env bash
set -euo pipefail

# This helper documents the intended execution order.
# DrugMechDB scripts require raw inputs listed in docs/MISSING_INPUTS.md.

python code/rerun_stage12_fixed.py
python code/step_semantic_bridge_diagnostics.py
python code/step_semantic_gate_diagnostics.py
python code/final_continuous_realgraph.py

# Figure 3 can be regenerated from the confirmed/hard-coded Stage-I values.
python code/figure3_stage1_reconstructed.py

# Figure 4 uses data/stage3_shuffled_gate_repetitions.csv.
cp data/stage3_shuffled_gate_repetitions.csv code/stage3_shuffled_gate_repetitions.csv
python code/figure4_stage3_shuffled_gate.py

# EpiKG external validation (requires its raw benchmark/graph inputs).
python code/epikg_fixed_manifest_rerun.py

# Optional transfer experiment; downloads RoG-CWQ when internet is available.
# CWQ source in this bundle is truncated; restore original run_cwq_same_pipeline.py before execution.
