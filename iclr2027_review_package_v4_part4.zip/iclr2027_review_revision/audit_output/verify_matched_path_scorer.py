"""Independent feature/label, inference-budget and paired-statistics verification."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,sys
import joblib,numpy as np,pandas as pd
from scipy.special import expit
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';D=R/'data/processed/drugmechdb';O=ROOT/'audit_output/matched_path_scorer';I=ROOT/'audit_output/experiment1_recovered_proposer'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
pr=json.loads((O/'protocol.json').read_text());done=json.loads((O/'completion.json').read_text());assert done['complete']
for name,h in pr['frozen_inputs'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
model=joblib.load(O/'model.joblib');gate=joblib.load(I/'gate_model.joblib');assert model['clf'].get_params()==gate['clf'].get_params();assert hashlib.sha256((O/'model.joblib').read_bytes()).hexdigest()==done['model_sha256'];man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)};c=pd.read_csv(D/'semantic_bridge_predictions.csv',float_precision='round_trip');confmap={key:g.groupby('node',sort=False).pred_semantic_conf.max().to_dict() for key,g in c.groupby(['task','rid','split','condition'])};types=model['types'];node_types=model['node_types']
def features(task,source,target,conf,nodes,relations):
    cs=list(conf);ty=[node_types.get(n,'Unknown') for n in cs];q=np.asarray([len(cs)/10.,np.log1p(r.G.out_degree(source)),np.log1p(r.G.in_degree(target))]+[ty.count(t)/max(1,len(cs)) for t in types]+[np.mean([r.G.has_edge(source,n) for n in cs]) if cs else 0.,np.mean([np.log1p(r.G.degree(n)) for n in cs]) if cs else 0.]+[float(task==t) for t in ['Gene','Metabolite','Process']],np.float32)
    reached=[]
    for node in nodes:
        if node in conf and node not in reached:reached.append(node)
    cov=len(reached)/max(1,len(conf));mc=np.mean([conf[n] for n in reached]) if reached else 0.;current=conf.get(nodes[-1],0.);recent=sum(n in conf for n in nodes[-2:])/2.;sat=(.65 if len(reached)<=1 else .85 if len(reached)==2 else 1.) if reached else 0.;graph=np.mean([r.graph_score(v,rel) for v,rel in zip(nodes[1:],relations)]);bridge=min(1.,(.45*cov+.25*mc+.15*current+.15*recent)*sat) if reached else 0.
    state=np.asarray([graph,bridge,len(relations)/8.,cov,mc,current,recent,sat,np.log1p(r.G.degree(nodes[-1])),np.mean([r.rel_quality(rel) for rel in relations]),float(nodes[-1]==target)],np.float32)
    return np.concatenate([q,state,q*graph,q*bridge]).astype(np.float32)
lab=pd.read_csv(O/'train_path_labels.csv.gz',float_precision='round_trip');saved=np.load(O/'train_features.npz');X=saved['X'];y=saved['y'];weight=saved['sample_weight'];assert len(X)==len(lab);case=pd.read_csv(O/'train_cases.csv');assert len(case)==6770;assert set(case.rid)<=set(r.manifest[r.manifest.split=='train'].rid);counts=lab.groupby(['task','rid','condition']).size();expect_weights=[];m0cache={}
for i,x in enumerate(lab.itertuples(index=False)):
    key=(x.task,x.rid);q=man[key];conf=confmap[(x.task,x.rid,'train',x.condition)];nodes=json.loads(x.nodes);rels=json.loads(x.relations);assert len(nodes)==len(rels)+1 and len(rels)<=8 and nodes[0]==q.source and len(nodes)==len(set(nodes))
    for a,b,rel in zip(nodes,nodes[1:],rels):assert (b,rel) in r.OUT.get(a,[])
    f=features(x.task,q.source,q.target,conf,nodes,rels);assert np.allclose(f,X[i],rtol=0,atol=2e-6)
    if key not in m0cache:
        z=r.search(q.source,q.target,{},0.);gd=set(r.gold[x.rid]);m0cache[key]=.7*float(z['found'])+.3*len(set(z['edges'])&gd)/max(1,len(gd))
    gd=set(r.gold[x.rid]);edges=set(zip(nodes,nodes[1:],rels));u=.7*float(nodes[-1]==q.target)+.3*len(edges&gd)/max(1,len(gd));delta=u-m0cache[key];assert np.allclose([m0cache[key],u,delta],[x.M0,x.M_path,x.delta],atol=1e-14,rtol=0) and int(delta>1e-12)==x.beneficial==y[i];expect_weights.append(1/counts[(x.task,x.rid,x.condition)])
    if (i+1)%25000==0:print(f'Independent TRAIN path-state feature/labels {i+1}/{len(lab)}',flush=True)
ew=np.asarray(expect_weights);ew/=ew.mean();assert np.allclose(ew,weight,rtol=0,atol=1e-14);sc=model['sc'];assert sc.n_samples_seen_==len(X);assert np.allclose(sc.mean_,X.mean(axis=0,dtype=np.float64),atol=1e-12,rtol=0)
def independent_search(task,source,target,conf):
    beam=[((source,),(),0.)];visited={source};expanded=0;best=None
    for step in range(8):
        paths=[]
        for ns,rs,_ in beam:
            for node,rel in r.OUT.get(ns[-1],[]):
                if expanded==20:break
                expanded+=1
                if node in ns:continue
                if node not in visited and len(visited)>=14:continue
                visited.add(node);paths.append((ns+(node,),rs+(rel,)))
            if expanded==20:break
        if not paths:break
        xx=np.asarray([features(task,source,target,conf,ns,rs) for ns,rs in paths],np.float32);z=sc.transform(xx);p=expit(z@model['clf'].coef_[0]+model['clf'].intercept_[0]);ranked=[(ns,rs,float(value)) for (ns,rs),value in zip(paths,p)]
        for state in ranked:
            if state[0][-1]==target and (best is None or state[2]>best[2]):best=state
        if best is not None:break
        beam=sorted(ranked,key=lambda state:(state[2],-len(state[0])),reverse=True)[:2]
    result=best if best is not None else max(beam,key=lambda s:s[2]);ns,rs,_=result;return dict(found=ns[-1]==target,nodes=list(ns),edges=[(ns[i],ns[i+1],rs[i]) for i in range(len(rs))],visited_nodes=len(visited),expanded_edges=expanded)
d=pd.concat([pd.read_csv(O/n,float_precision='round_trip') for n in ['val_per_query.csv','test_per_query.csv','automatic_test_per_query.csv']],ignore_index=True);assert not d.duplicated(['setting','split','task','rid','method']).any();checked=0
for x in d.itertuples(index=False):
    q=man[(x.task,x.rid)];conf=json.loads(x.selected_confidences);z=independent_search(q.task,q.source,q.target,conf) if x.method=='LearnedPathScorer' else r.search(q.source,q.target,conf,x.gate);assert z['nodes']==json.loads(x.nodes) and z['edges']==[tuple(e) for e in json.loads(x.edges)] and z['visited_nodes']==x.visited_nodes and z['expanded_edges']==x.expanded_edges;gd=set(r.gold[x.rid]);er=len(set(z['edges'])&gd)/max(1,len(gd));assert np.allclose([z['found'],er,float(str(q.answer) in z['nodes']),.7*z['found']+.3*er],[x.PS,x.ER,x.AH,x.utility],atol=1e-14,rtol=0);checked+=1
print('All learned-path and reference-control searches independently verified',flush=True)
stats=pd.read_csv(O/'paired_cluster_bootstrap.csv',float_precision='round_trip')
for x in stats.itertuples(index=False):
    dd=d[(d.setting==x.setting)&(d.split==x.split)];base=dd[dd.method=='LearnedPathScorer'].set_index(['task','rid']);other=dd[dd.method==x.comparison.removesuffix(' - LearnedPathScorer')].set_index(['task','rid']).reindex(base.index);delta=other[x.metric]-base[x.metric];g=delta.groupby(level='rid').agg(['sum','size']).sort_index();draw=np.random.default_rng(20260914).integers(0,len(g),size=(5000,len(g)));boot=g['sum'].to_numpy()[draw].sum(axis=1)/g['size'].to_numpy()[draw].sum(axis=1);lo,hi=np.quantile(boot,[.025,.975]);assert np.allclose([delta.mean(),lo,hi],[x.delta,x.ci95_low,x.ci95_high],atol=1e-13,rtol=0)
for name,h in pr['frozen_inputs'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
report={'passed':True,'train_path_features_labels_recomputed':len(lab),'train_cases':len(case),'all_train_ids_disjoint_from_validation_test':True,'query_balanced_state_weights_verified':True,'classifier_parameters_match_original_gate_LR':True,'paths_independently_replayed':checked,'paired_cluster_statistics_recomputed':len(stats),'original_method_and_inputs_unchanged':True,'scope':'numeric linear path-scoring baseline, not all learned path scorer families; supervision source/utility and search budgets matched, label granularity differs'};(O/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2),flush=True)
