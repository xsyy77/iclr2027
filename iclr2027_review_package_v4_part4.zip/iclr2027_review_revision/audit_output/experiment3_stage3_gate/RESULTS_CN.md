# 实验 3：固定自动候选流程的 Stage-III gate controls

状态：运行完成，独立核验通过。结果不支持原 adaptive gate 在本自动候选配置下具有相对常数或 reassigned gate 的独立优势。未据测试结果调整 gate、selector、候选或模型。

## 对应问题

- kKLG Q3：在真正主配置中比较 constant、mean-matched、shuffled，不能把不同 Full 的表格互相替代。
- novelty reviewer Q3：配对区间及 query-specific gate 有用/退步的具体范围。
- weak-accept reviewer Q3：明确候选/selection 配置，并给 Full 对 mean-matched 的区间。

这组统一配置的补充实验直接回答归因问题；它不能恢复原 Table 4 的历史生成链，也不能单独解释原 Table 1/4 差异。

## 冻结协议

1. 锁定实验 1 的恢复 proposer、manifest 端点、proposal Top3 和 learned confidence。Stage II 的测试排名不用于改变本组 selected set；这不是新 greedy、Safety Gate 或 Pareto 方法。
2. 原 gate 模型、原训练数据和原预测复用，g=0.5*sqrt(p)。所有 guidance arms 使用相同候选及 confidence；Graph Only 为 gate=0。
3. 图谱仍为含 held-out mechanism edges 的传导式聚合图。搜索保持 beam=2、max_hops=8、node_budget=14、edge_budget=20、原邻接顺序。
4. 常数网格 g∈{0,0.05,...,0.50}，仅用 239 条 validation 的 .7 PS+.3 ER 定参；并列保留更小 gate。选中 **g=0.35**。验证集 adaptive gate 均值为 0.332158968837。
5. 测试均值匹配常数为 0.347511511574。它使用测试 gate 分布，只是不可部署的诊断，不与验证集选择的常数混称。
6. 500 次全局 gate 重分配，以及 500 次 task 内 gate 重分配。后者保留 Gene/Metabolite/Process 各自的 gate 分布，作为 query-specific matching 的主要打乱检验。所有 donor index 在结果运行前写入并锁定。每次重复使用此前已声明的 seed=20261108+rep，未调用 Python hash()。
7. 相同 query/gate 的执行结果缓存复用：缓存键含 task、rid、gate，且 selected set/confidence 已固定。完整 248,000 条 shuffled query 记录均指向可审计的唯一路径缓存，没有把重复结果当成额外独立样本。
8. 5000 次 rid-cluster paired bootstrap，248 个 task-query 对应 218 个机制簇。相对 shuffled 的配对区间比较每个 query 的 500 次平均结果。随机化 p 另从 500 个整批打乱结果计算，不能把 124,000 条记录当作独立样本。
9. 两种 null × 四个指标共八项随机化检验同时报告 raw p 及 Holm 校正 p；bootstrap 区间为逐比较区间，不作多重校正。测试集此前多次查看，本轮为补充评估，不能称独立确认。

## 全部测试结果

| 方法 | gate | PS (%) | ER (%) | AH (%) | Utility |
|---|---:|---:|---:|---:|---:|
| Graph Only | 0.00000 | 27.02 | 33.97 | 70.56 | 0.291019 |
| Fixed 0.3 | 0.30000 | 34.68 | 39.34 | 73.39 | 0.360774 |
| Adaptive Full | 0.34751 | 34.68 | 39.12 | 73.39 | 0.360109 |
| Validation-best constant | 0.35000 | 34.68 | 39.56 | 73.39 | 0.361419 |
| Validation-mean constant | 0.33216 | 34.68 | 39.29 | 72.98 | 0.360613 |
| Test-mean constant (diagnostic) | 0.34751 | 34.68 | 39.56 | 73.39 | 0.361419 |

Adaptive 与常数的平均 PS/AH 相同，不意味着逐查询路径相同或已证明统计等价；相关配对区间和退步查询完整报告如下。

## 配对差异

pp 表示百分点，utility 的差值也乘 100 便于展示。

| Adaptive Full 相对 | 指标 | 差值 (pp) | 95% cluster CI (pp) | 改善/退步 |
|---|---|---:|---|---|
| Fixed 0.3 | PS | +0.000 | [-1.205, +1.210] | 1/1 |
| Fixed 0.3 | ER | -0.222 | [-1.408, +0.820] | 3/3 |
| Fixed 0.3 | AH | +0.000 | [-1.606, +1.639] | 2/2 |
| Fixed 0.3 | utility | -0.067 | [-1.167, +0.953] | 3/3 |
| Validation-best constant | PS | +0.000 | [-1.205, +1.210] | 1/1 |
| Validation-best constant | ER | -0.437 | [-1.493, +0.274] | 2/3 |
| Validation-best constant | AH | +0.000 | [-1.200, +1.210] | 1/1 |
| Validation-best constant | utility | -0.131 | [-1.257, +0.879] | 2/3 |
| Validation-mean constant | PS | +0.000 | [-1.205, +1.210] | 1/1 |
| Validation-mean constant | ER | -0.168 | [-1.280, +0.820] | 3/3 |
| Validation-mean constant | AH | +0.403 | [-0.823, +1.984] | 2/1 |
| Validation-mean constant | utility | -0.050 | [-1.158, +0.962] | 3/3 |
| Test-mean constant (diagnostic) | PS | +0.000 | [-1.205, +1.210] | 1/1 |
| Test-mean constant (diagnostic) | ER | -0.437 | [-1.493, +0.274] | 2/3 |
| Test-mean constant (diagnostic) | AH | +0.000 | [-1.200, +1.210] | 1/1 |
| Test-mean constant (diagnostic) | utility | -0.131 | [-1.257, +0.879] | 2/3 |
| Global shuffled mean | PS | -0.002 | [-0.681, +0.688] | 4/2 |
| Global shuffled mean | ER | +0.002 | [-0.682, +0.588] | 16/7 |
| Global shuffled mean | AH | +0.356 | [-0.453, +1.290] | 7/3 |
| Global shuffled mean | utility | -0.001 | [-0.631, +0.585] | 16/7 |
| Within task shuffled mean | PS | +0.107 | [-0.511, +0.845] | 4/2 |
| Within task shuffled mean | ER | +0.022 | [-0.570, +0.572] | 15/7 |
| Within task shuffled mean | AH | +0.336 | [-0.484, +1.327] | 7/3 |
| Within task shuffled mean | utility | +0.082 | [-0.465, +0.698] | 15/7 |

## Gate matching 的打乱检验

单侧检验 H1 为真实匹配的指标更高。p=(1+# shuffled aggregate ≥ observed)/(501)。shuffled 2.5%/97.5% 分位数是重分配分布区间，不是总体泛化置信区间，完整值见 shuffle_randomization_tests.csv。

| 打乱方式 | 指标 | Adaptive (%) | Shuffled 均值 (%) | 单侧 p | Holm p（8 项） |
|---|---|---:|---:|---:|---:|
| Global | PS | 34.677 | 34.679 | 0.7345 | 1.0000 |
| Global | ER | 39.122 | 39.120 | 0.5130 | 1.0000 |
| Global | AH | 73.387 | 73.031 | 0.3812 | 1.0000 |
| Global | utility | 36.011 | 36.011 | 0.5130 | 1.0000 |
| Within task | PS | 34.677 | 34.570 | 0.6048 | 1.0000 |
| Within task | ER | 39.122 | 39.100 | 0.4890 | 1.0000 |
| Within task | AH | 73.387 | 73.051 | 0.3972 | 1.0000 |
| Within task | utility | 36.011 | 35.929 | 0.4271 | 1.0000 |

所有 raw p 均未达到 0.05，八项 Holm 校正 p 均为 1；在本配置下，没有统计支持的 query–gate matching 优势。不能据此证明所有 adaptive guidance 都无效。

## 相对 Graph Only 的负迁移（描述性）

PS 受损指 Graph Only 成功而当前方法失败；ER 受损指当前方法 ER 低于同一 query 的 Graph Only。

| 方法 | PS 受损查询 | PS 获益查询 | ER 受损查询 | ER 获益查询 |
|---|---:|---:|---:|---:|
| Graph Only | 0 | 0 | 0 | 0 |
| Fixed 0.3 | 0 | 19 | 3 | 36 |
| Adaptive Full | 1 | 20 | 6 | 39 |
| Validation-best constant | 0 | 19 | 4 | 37 |
| Validation-mean constant | 0 | 19 | 4 | 36 |
| Test-mean constant (diagnostic) | 0 | 19 | 4 | 37 |

本次 adaptive PS 受损 1 条，验证集最佳常数为 0 条；ER 受损分别为 6 条和 4 条。这些是已观察计数，不构成未来无损保证，也不足以单独证明一种 controller 显著更安全。分任务计数见 negative_transfer.csv；全部相对差异见 paired_query_differences.csv。

## 最强但不越界的结论

- 自动候选指导相对 Graph Only 的总体收益仍成立，不能将该总体收益归因于 query-specific gate。
- Adaptive Full 相对验证集最佳常数的 ER 为 −0.437 pp，95% 配对区间约 [−1.493,+0.274] pp；未显示额外收益，也不能把跨零区间描述为已证明显著劣于常数。
- 相对全局 shuffled mean 的 ER 仅 +0.0021 pp，相对 task 内 shuffled mean +0.0224 pp，两者区间均跨零，随机化检验也不支持真实匹配更优。
- 本轮不支持保留“原 gate 在自动候选上稳定优于统一指导”的强表述。原受控候选的证据保留其适用范围；不能直接外推到本协议。
- 验证集选出的 g=0.35 是一个可复现的简单基准，其数值由验证集决定，而非依据测试集替换。是否在最终修订中采用它，应在剩余必要实验完成后全局决定，并明确 adaptive gate 的负面/不确定结果。

## 可用英文回复草稿

We evaluated gate controls under a single frozen automatic-candidate configuration: the proposal Top-3 set, learned confidence scores, graph, and search budgets are identical across guidance arms. The original adaptive gate achieves PS/ER/AH of 34.68/39.12/73.39%, compared with 34.68/39.56/73.39% for a constant gate of 0.35 selected solely on validation data. The paired mechanism-clustered ER difference is −0.437 percentage points, with a 95% interval of [−1.493, +0.274]. We additionally report 500 global and 500 within-task gate reassignments. Neither control supports a statistically significant advantage of the actual query–gate matching in this automatic-candidate setting. We therefore do not attribute the overall improvement over graph-only retrieval to adaptive control, and will narrow the corresponding claim. These supplementary controls do not recover the historical Table 4 generation procedure.

## 独立核验

- Stage I 的 Graph Only、Fixed 0.3、Adaptive 共 1461 条 val/test 路径完全复现。
- 61311 个唯一路径用恢复 proposer 中另一份搜索实现独立重放；路径、边和计数全部一致，重新计算 183933 个 PS/ER/AH。
- 1000 组 donor permutation 根据原 seed 独立重建；248000 条 query 记录与 donor、gate 及路径缓存逐项一致。
- 验证集常数选择、28 组配对统计及全部 8 项随机化/Holm 计算均复核通过。
- Stage I/II 共 40 个输出文件哈希不变；原包 296 个成员逐字节不变。

## 输出文件

- protocol.json、selected_constants.json、validation_gate_grid*.csv：冻结协议与验证集定参。
- per_query.csv、summary.csv、by_task.csv：六个控制方法的全部 val/test 结果。
- shuffle_donor_indices.npz、query_index.json：精确打乱映射；shuffle_*_per_query.csv.gz：全部打乱 query 记录。
- search_cache.csv.gz：完整路径及计数，按 cache_id 与各结果相连。
- paired_cluster_bootstrap.csv、shuffle_randomization_tests.csv、paired_query_differences.csv、negative_transfer.csv：统计、逐查询变化和负迁移。
- verification.json、independent_verification.json、SHA256SUMS.txt：核验与文件哈希。
- ../run_experiment3_gate_controls.py、../verify_experiment3.py、../report_experiment3.py：运行、独立核验、报告入口。
