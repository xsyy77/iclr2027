# 实验 1：恢复 proposer 的自动候选完整流程

状态：已完成，独立校验通过。新补充实验；不是原 Table 1 的历史端到端复现。未改原始提交文件，未按测试结果调参。

## 协议

- 使用已恢复 Figure 3 proposer 的原函数、视图、分数、两跳规则、K=3 及 node-ID tie break；首先在原端点上逐条复现 248 条 Figure 3 查询的候选实体、顺序及 proposal 分数。
- 正式运行统一采用 submitted manifest 的 source/target，同时用于候选与检索。测试集有 8 条 source 与原 Figure 3 元数据不同；完整映射见 endpoint_mapping.csv。故统一端点后的池不能继续称为原 Figure 3 完全相同的池。
- 图谱是提交版全量聚合图，包含 held-out mechanism edges。这是传导式图访问，不是 train-only 或图谱独立的无泄漏证明。生成时仅保留端点及 drug/disease 名称，清除 record-specific reference nodes/links、gold 对象；图本身保持不变。候选及 Top3 不使用 answer/reference-membership。
- 487 条 val/test 查询全部保留（239/248）；合计 28086 条候选记录。最大未截断邻域 483，没有触及 cap=600。
- 单视图与多视图均使用至多三个候选。所有单视图结果均报告，System Fixed 仅根据验证集 .7 PS+.3 ER 被选为主单视图比较对象，未在测试集挑选。
- Multi-view Fixed、Utility Fixed、Full 使用完全相同的 proposal Top3 集合。后两者使用原 reliability 模型的 confidence；Full 使用原 gate 模型在新集合上重新生成的 g=0.5*sqrt(p)。未使用新 greedy、Pareto 或 Safety Gate。
- 两个模型按原代码、原训练行及 random_state=20260827 重训，训练行分别为 18925、6770；未在自动候选上重新生成训练标签。训练分布与自动候选可能不同，须保留这一限制。
- 搜索 beam=2、max_hops=8、node_budget=14、edge_budget=20，保持原邻接顺序。原种子未改；统计抽样沿用已声明的 20260914，不挑 seed。
- 测试集此前已多次查看，结果属于补充评估，不是新的独立确认。

## 全部测试结果

| 方法 | PS (%) | ER (%) | AH (%) |
|---|---:|---:|---:|
| Graph Only | 27.02 | 33.97 | 70.56 |
| Molecular Fixed | 28.23 | 34.95 | 72.98 |
| Cellular Fixed | 25.81 | 33.95 | 70.56 |
| System Fixed | 35.08 | 38.34 | 71.37 |
| Multi-view Fixed | 35.08 | 38.73 | 73.39 |
| Utility Fixed | 34.68 | 39.34 | 73.39 |
| Full | 34.68 | 39.12 | 73.39 |

## 主要配对差异

5000 次配对 cluster bootstrap，以 rid 为簇，保留相同机制下的多个任务；248 个 task-query 对应 218 个 rid。区间为逐比较的 95% 区间，未作多重比较校正。

| 比较 | 指标 | 差值 (pp) | 95% cluster bootstrap CI (pp) | 改善/退步查询 |
|---|---|---:|---|---|
| Multi-view Fixed - Graph Only | PS | +8.06 | [+4.40, +12.11] | 20/0 |
| Multi-view Fixed - Graph Only | ER | +4.76 | [+2.88, +6.84] | 34/2 |
| Multi-view Fixed - System Fixed | PS | +0.00 | [-2.38, +2.33] | 4/4 |
| Multi-view Fixed - System Fixed | ER | +0.39 | [-1.92, +2.71] | 17/11 |
| Utility Fixed - Multi-view Fixed | PS | -0.40 | [-1.25, +0.00] | 0/1 |
| Utility Fixed - Multi-view Fixed | ER | +0.61 | [-0.45, +1.78] | 6/5 |
| Full - Utility Fixed | PS | +0.00 | [-1.20, +1.21] | 1/1 |
| Full - Utility Fixed | ER | -0.22 | [-1.41, +0.82] | 3/3 |
| Full - Graph Only | PS | +7.66 | [+3.88, +11.81] | 20/1 |
| Full - Graph Only | ER | +5.15 | [+2.63, +7.68] | 39/6 |

## 候选覆盖与严格同 K 子集

- 自动多视图完整池的 benchmark-answer 覆盖为 99.19% (246/248)。按 proposal 分数取 Top3 后为 42.74% (106/248)。这是答案实体覆盖，不是 useful-candidate coverage，也不是最终 AH。
- 全体比较采用相同最大预算 K=3，不代表每个视图都有足够候选。平均 selected size 在 availability_summary.csv 完整报告。
- 三个单视图均有至少 3 个候选的严格子集共 107 条查询；以下各方法实际均选 3 个。这是补充子集分析，不用于替换全体结果。

- Cellular Fixed: n=107, PS=25.23%, ER=32.14%, AH=70.09%。
- Molecular Fixed: n=107, PS=27.10%, ER=33.60%, AH=73.83%。
- Multi-view Fixed: n=107, PS=29.91%, ER=35.53%, AH=71.96%。
- System Fixed: n=107, PS=30.84%, ER=34.82%, AH=69.16%。

## 能用于 rebuttal 的结论

1. 这组补充实验提供了明确的自动候选检索收益：Multi-view Fixed 相对 Graph Only 的 PS +8.06 pp、ER +4.76 pp，cluster bootstrap 区间均高于零。它直接回答“没有预存 reference-aligned Clean 候选时，自动生成的候选是否能帮助检索”。
2. 多视图相对验证集选出的 System 单视图，PS 相同，ER +0.39 pp，区间跨零；不能称其固定容量检索普遍最优。完整池覆盖高、Top3 覆盖下降，说明候选可用性和预算内选择仍是不同问题。
3. Utility Fixed 的 ER 比等权多视图 +0.61 pp，但区间跨零，PS -0.40 pp；不能声称 confidence weighting 已在本配置显著改善检索。
4. Full 的 ER 比 Utility Fixed -0.22 pp，区间跨零；本组结果不支持原 query-specific gate 的额外收益。Full 相对 Graph Only 的收益不能全部归因于 learned stages。
5. 此实验没有测试或恢复历史完整 greedy selector，也不证明原 Table 1 的 692 条 Clean 输入怎样产生。Stage II 超预算选择与 Stage III gate controls 仍应按计划独立验证。

## 可用英文回复草稿

We evaluated an explicitly specified automatic-candidate pipeline using the recovered graph-linked proposal functions. Candidate construction uses known endpoint metadata and the fixed aggregate graph without reading the held-out answer or query-specific reference-mechanism membership. On all 248 test queries, automatic multi-view proposals with fixed guidance obtain PS/ER/AH of 35.08/38.73/73.39%, compared with 27.02/33.97/70.56% for graph-only retrieval. The paired, mechanism-clustered 95% bootstrap intervals for the PS and ER improvements are [4.40, 12.11] and [2.88, 6.84] percentage points. These results provide supplementary evidence that automatic proposals can improve retrieval beyond supplied Clean candidates. We explicitly distinguish this transductive evaluation from historical candidate provenance: the aggregate graph includes held-out mechanism edges, and this experiment does not recover the original Table 1 candidate-selection lineage. Learned confidence weighting and the original gate do not show a statistically supported additional improvement in this configuration; we report their matched results separately.

## 核验

- 原 Graph Only：248 条测试查询均与提交存档一致。
- 两套搜索实现：3409 次路径、边、成功标志和计数全部一致；输出路径全部图有效且满足预算。
- 独立从输出重建 3409 个选择集合，重新计算 10227 个指标、1948 个覆盖记录，全部通过。
- 原 ZIP 的 296 个文件逐字节一致；输入代码及数据哈希不变。
- 重训预测对归档的最大绝对差：bridge 0.000144451437414，gate 4.91499042077e-07。不是逐值精确恢复归档模型，偏差已披露。

## 文件与复跑

- protocol.json：运行前冻结的协议；environment.json：实际依赖版本。
- candidates_scored.csv、availability_per_query.csv：候选实体、分数与覆盖。
- recomputed_gates.csv：新集合的 gate 特征、预测及强度。
- per_query.csv：全部 3409 条 val/test 检索记录，含完整路径和配置。
- summary.csv、by_task.csv、paired_cluster_bootstrap.csv：汇总、分任务与配对统计。
- strict_same_k_*.csv：严格同 K 的补充子集分析。
- verification.json、independent_verification.json：两层检查结果。
- ../run_recovered_proposer_pipeline.py：实验入口；../verify_experiment1.py：独立核验；../report_experiment1.py：补充汇总。入口拒绝覆盖已完成输出；复跑须先给脚本指定新的输出目录，保留本次结果。
