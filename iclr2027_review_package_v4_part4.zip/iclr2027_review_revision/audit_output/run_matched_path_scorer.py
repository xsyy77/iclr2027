"""One explicitly requested reviewer baseline. Fixed protocol, no winner search."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,sys,time,warnings
import joblib,numpy as np,pandas as pd
from sklearn.base import clone
from sklearn.preprocessing import StandardScaler
from sklearn.exceptions import ConvergenceWarning
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';D=R/'data/processed/drugmechdb';I=ROOT/'audit_output/experiment1_recovered_proposer';O=ROOT/'audit_output/matched_path_scorer'
O.mkdir(exist_ok=True);assert not (O/'model.joblib').exists(),'Refuse repeated baseline fitting';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));sys.path.insert(0,str(ROOT/'audit_output/reviewer_comments'));import dmdb_retrievers as r
from path_scorer_control import SearchControl
warnings.filterwarnings('error',category=ConvergenceWarning)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
def log(x):print(x,flush=True)
START=time.perf_counter();inputs=[D/n for n in ['semantic_bridge_predictions.csv','semantic_gate_predictions.csv','benchmark_manifest.csv']]+[R/'methods/dmdb_retrievers.py',I/'gate_model.joblib',ROOT/'audit_output/reviewer_comments/path_scorer_control.py',ROOT/'audit_output/run_matched_path_scorer.py'];hashes={str(p.relative_to(ROOT)):sha(p) for p in inputs}
save('protocol.json',{'review_question':'9P9q-Q1: learned path scorer with matching supervision and search budget','role':'external baseline only; Full method unchanged','primary_setting':'actual archived Table1 Clean candidates/confidences/gates','secondary_setting':'frozen automatic proposal Top3, no adaptation','supervision_match':'same TRAIN mechanisms/candidate-corruption cases and .7PS+.3ER reference utility; path-state label is I[M(path)>M(GraphOnly)], versus query-benefit gate label. Matching source/utility, NOT identical label granularity','training_paths':'admitted candidate prefixes under frozen original Full TRAIN trajectories, all five conditions; no VALIDATION/TEST outcomes used in training','classifier':'clone original gate LR C=.5, balanced,liblinear,max_iter1200,seed20260827; fixed, no tuning grid','features':'numeric pre-search query/candidate statistics and task; existing graph/Bridge scoring components, length, current node degree, known-target reached; interactions of query stats with graph/Bridge score; no gold/shortest-path/post-retrieval feature','feature_scope':'compact linear path-scoring control, not strongest possible text/neural path scorer; no TFIDF text in this baseline, Bridge confidences carry same frozen semantic signal','weighting':'TRAIN state sample weights inverse number of admitted states in each query-condition case, normalized mean1; original balanced-class LR retained','search_match':{'beam':2,'max_hops':8,'node_budget':14,'edge_budget':20,'adjacency':'same original OUT; one edge budget, no extra search/retrieval pass'},'model_selection':'none: one fixed model/configuration; validation reported before test, no outcome-driven changes','new_method_claim':False,'test_scope':'previously inspected original248 reused for review baseline; not fresh independent confirmation','frozen_inputs':hashes})
node_types={}
for rec in r.paths:
    for n in rec['nodes']:node_types.setdefault(str(n['id']),str(n.get('label','Unknown')))
gate_model=joblib.load(I/'gate_model.joblib');engine=SearchControl(r,gate_model['types'],node_types);cand=pd.read_csv(D/'semantic_bridge_predictions.csv',float_precision='round_trip');gates=pd.read_csv(D/'semantic_gate_predictions.csv',float_precision='round_trip');man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)};confmap={key:g.groupby('node',sort=False).pred_semantic_conf.max().to_dict() for key,g in cand.groupby(['task','rid','split','condition'],sort=False)};gatemap={(x.task,x.rid,x.split,x.condition):.5*math.sqrt(x.p_semantic_gate) for x in gates.itertuples(index=False)}
def metrics(z,q):
    gd=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gd)/max(1,len(gd));return ps,er,float(str(q.answer) in z['nodes']),.7*ps+.3*er
features=[];labels=[];weights=[];trace_rows=[];case_rows=[];search_checks=0
for index,(key,conf) in enumerate((k,v) for k,v in confmap.items() if k[2]=='train'):
    task,rid,split,condition=key;q=man[(task,rid)];base=r.search(q.source,q.target,{},0.);m0=metrics(base,q)[3];z,traces=engine.search(task,q.source,q.target,conf,gatemap[key],trace=True);expected=r.search(q.source,q.target,conf,gatemap[key]);assert z==expected;search_checks+=1
    case_rows.append(dict(task=task,rid=rid,condition=condition,admitted_states=len(traces),M0=m0,teacher_gate=gatemap[key]));n=max(1,len(traces))
    for rec in traces:
        ns=rec['nodes'];rs=rec['relations'];edges={(ns[j],ns[j+1],rs[j]) for j in range(len(rs))};gd=set(r.gold[rid]);ps=float(ns[-1]==q.target);er=len(edges&gd)/max(1,len(gd));u=.7*ps+.3*er;delta=u-m0;features.append(rec['features']);labels.append(int(delta>1e-12));weights.append(1/n);trace_rows.append(dict(task=task,rid=rid,condition=condition,depth=rec['depth'],nodes=json.dumps(ns),relations=json.dumps(rs),M0=m0,M_path=u,delta=delta,beneficial=int(delta>1e-12)))
    if (index+1)%1000==0:log(f'TRAIN trace cases {index+1}/6770; no validation/test path labels used')
x=np.asarray(features,np.float32);y=np.asarray(labels,int);w=np.asarray(weights,float);w/=w.mean();pd.DataFrame(trace_rows).to_csv(O/'train_path_labels.csv.gz',index=False,compression='gzip');pd.DataFrame(case_rows).to_csv(O/'train_cases.csv',index=False);np.savez_compressed(O/'train_features.npz',X=x,y=y,sample_weight=w)
log(f'Fitting single fixed baseline: {len(y)} path states, positive rate={y.mean():.5f}');sc=StandardScaler().fit(x);clf=clone(gate_model['clf']);clf.fit(sc.transform(x),y,sample_weight=w);model={'clf':clf,'sc':sc,'types':gate_model['types'],'node_types':node_types};joblib.dump(model,O/'model.joblib');modelhash=sha(O/'model.joblib');save('training_summary.json',{'train_cases':len(case_rows),'train_states':len(y),'positive_rate':float(y.mean()),'search_replays_equal':search_checks,'feature_dimensions':x.shape[1],'class_parameters':clf.get_params(),'iterations':clf.n_iter_.tolist(),'model_sha256':modelhash})
results=[]
for split in ['val','test']:
    for q in r.manifest[r.manifest.split==split].itertuples(index=False):
        key=(q.task,q.rid,split,'Clean');conf=confmap[key];arms={'GraphOnly':r.search(q.source,q.target,{},0.),'FixedLearnedConfidence':r.search(q.source,q.target,conf,.3),'OriginalFull':r.search(q.source,q.target,conf,gatemap[key]),'LearnedPathScorer':engine.search(q.task,q.source,q.target,conf,model=model)}
        for name,z in arms.items():
            ps,er,ah,u=metrics(z,q);assert z['visited_nodes']<=14 and z['expanded_edges']<=20;results.append(dict(setting='Table1 Clean',split=split,task=q.task,rid=q.rid,method=name,selected_confidences=json.dumps(conf) if name!='GraphOnly' else '{}',gate=gatemap[key] if name=='OriginalFull' else .3 if name=='FixedLearnedConfidence' else 0. if name=='GraphOnly' else None,PS=ps,ER=er,AH=ah,utility=u,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges']))
    current=pd.DataFrame(results);current[current.split==split].to_csv(O/f'{split}_per_query.csv',index=False);log(current[current.split==split].groupby('method')[['PS','ER','AH','utility']].mean().to_string());assert sha(O/'model.joblib')==modelhash
    if split=='val':save('pre_test_checkpoint.json',{'model_sha256':modelhash,'config_unchanged_after_validation':True,'tuned_on_validation':False,'test_not_yet_evaluated_in_this_run':True})
auto=pd.read_csv(I/'per_query.csv',float_precision='round_trip');auto=auto[(auto.split=='test')&(auto.method=='Full')];secondary=[]
for xrow in auto.itertuples(index=False):
    q=man[(xrow.task,xrow.rid)];conf=json.loads(xrow.selected_confidences);expected=r.search(q.source,q.target,conf,xrow.gate);assert expected['nodes']==json.loads(xrow.nodes);baseline=engine.search(q.task,q.source,q.target,conf,model=model)
    for name,z in [('OriginalFull',expected),('LearnedPathScorer',baseline)]:
        ps,er,ah,u=metrics(z,q);secondary.append(dict(setting='Automatic Top3',split='test',task=q.task,rid=q.rid,method=name,selected_confidences=json.dumps(conf),gate=xrow.gate if name=='OriginalFull' else None,PS=ps,ER=er,AH=ah,utility=u,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges']))
pd.DataFrame(secondary).to_csv(O/'automatic_test_per_query.csv',index=False);d=pd.concat([pd.DataFrame(results),pd.DataFrame(secondary)],ignore_index=True);d.groupby(['setting','split','method'])[['PS','ER','AH','utility']].mean().to_csv(O/'summary.csv');pairs=[]
for (setting,split),g in d.groupby(['setting','split']):
    base=g[g.method=='LearnedPathScorer'].set_index(['task','rid']);ids=sorted(base.index.get_level_values('rid').unique());draw=np.random.default_rng(20260914).integers(0,len(ids),size=(5000,len(ids)))
    for othername in [n for n in g.method.unique() if n!='LearnedPathScorer']:
        other=g[g.method==othername].set_index(['task','rid']).reindex(base.index)
        for metric in ['PS','ER','AH','utility']:
            delta=other[metric]-base[metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(ids);boot=cl['sum'].to_numpy()[draw].sum(axis=1)/cl['size'].to_numpy()[draw].sum(axis=1);lo,hi=np.quantile(boot,[.025,.975]);pairs.append(dict(setting=setting,split=split,comparison=othername+' - LearnedPathScorer',metric=metric,delta=delta.mean(),ci95_low=lo,ci95_high=hi))
pd.DataFrame(pairs).to_csv(O/'paired_cluster_bootstrap.csv',index=False);assert all(sha(ROOT/n)==h for n,h in hashes.items());save('completion.json',{'complete':True,'review_question':'9P9q-Q1','original_method_files_unchanged':True,'input_hashes_unchanged':True,'model_fitted_once':True,'model_sha256':modelhash,'validation_and_test_not_used_as_training_labels':True,'elapsed_seconds':time.perf_counter()-START,'independent_verification_pending':True});log(d.groupby(['setting','split','method'])[['PS','ER','AH','utility']].mean().to_string());log('COMPLETE ONE MATCHED PATH-SCORER BASELINE')
