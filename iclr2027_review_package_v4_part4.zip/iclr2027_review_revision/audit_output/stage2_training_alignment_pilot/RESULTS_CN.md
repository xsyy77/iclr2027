# Stage II/III：暂停后续实验后的问题诊断与最小修复

## 工作方向纠正

Stage II/III 的组件优势没有成立时，不再机械推进搜索稳健性等外围实验。先判断训练/任务是否对齐、组件是否有足够可利用空间，再决定修复还是简化。之前的负面/不确定结果保留，原实验及输入全部不改。

## 已确认的问题与推断边界

1. 原模型在归档候选（包括 Clean 和 corruption）训练。原 train Clean 池平均 2.80 个候选，而自动验证池平均 58.82 个。两个协议明显不同；此统计本身不能单独证明性能下降的因果来源。
2. 在新明确的 singleton usefulness 定义下，自动验证候选有益率为 1.57%，旧评分器 AUROC=0.7218、AUPRC=0.0335。原 missing-label writer 尚未恢复，因此不能把新 singleton 标签与旧 Clean 标签当成完全同口径的比较。单候选 usefulness 也不等于 K=3 的集合边际贡献。
3. 原 gate_training_samples 的 9205 条 z 均等于 best_nonzero>M0 的二元指示：学习目标回答是否存在有益的非零指导，没有直接标注最佳 gate 大小。g=0.5*sqrt(p) 是后续映射。两者目标不完全相同，是需要检验的设计问题，不能仅凭此断言它就是失败的唯一原因。
4. 仅在原验证集、既有 11 个 g 值上做不可部署 oracle：平均 utility 相对常数 0.35 仅有 0.002974 的剩余空间；只有 7/239 条 query 能超过该常数，198/239 条在所有这 11 个 g 上 utility 完全相同。这是对该离散动作集合的 headroom 诊断，不是整个连续区间的全局上界。

## 已执行的最小 Stage-II 修复

- 不更换方法架构、不增加特征、不增加超参数、不换 seed。
- 使用恢复 proposer 和已明确的背景图，在 1354 个 TRAIN 查询上自动生成 75237 条候选；全部保留。训练 useful 标签只由 TRAIN 的 Graph Only 与 singleton(confidence=1,gate=.3) 检索 utility 差值构造，阈值 >1e-12。
- 新训练有益率 1.75%，自动验证有益率 1.57%。这是重新定义并生成的自动候选训练协议，不能称历史源代码恢复。
- 原 TFIDF/StandardScaler/LogisticRegression 参数逐项克隆，仅在新训练行拟合；原 random_state=20260827 保留。
- 验证集候选、端点、图、搜索预算、gate=.3 与旧实验不变。旧模型与新模型同时比较 proposal 集合上的加权、reliability Top3 的等权选择和加权选择。
- 在结果运行前定义推进标准：新方案 PS 不低于 Proposal Equal，utility 必须高于 Proposal Equal 和 Proposal Old Learned 中较高者。门槛未通过就不推进到测试。
- 本轮没有运行任何 TEST query 的新检索或产生新测试标签。原图仍包含测试机制边，传导式图设定未改变。原验证集已被用于此前开发，所以本轮验证改善也不是独立泛化证明。

## 验证结果

| 验证方法 | PS (%) | ER (%) | AH (%) | Utility | 进入测试门槛 |
|---|---:|---:|---:|---:|---|
| Proposal Equal | 30.96 | 38.10 | 67.78 | 0.331038 | 基线 |
| Proposal Old Learned | 30.96 | 37.24 | 68.20 | 0.328465 | 基线 |
| Old Reliability Equal | 25.52 | 35.25 | 68.62 | 0.284421 | 基线 |
| Old Reliability Learned | 25.52 | 34.92 | 68.62 | 0.283417 | 基线 |
| Proposal Refit Learned | 30.96 | 38.24 | 69.04 | 0.331457 | 通过开发门槛 |
| Refit Reliability Equal | 26.78 | 36.64 | 70.71 | 0.297356 | 未通过 |
| Refit Reliability Learned | 26.36 | 36.71 | 70.71 | 0.294657 | 未通过 |

## 新旧 usefulness 判别

统一使用同一套新 singleton 验证标签进行比较，positive rate=1.57%。

| 模型 | 自动验证池 AUROC | 自动验证池 AUPRC |
|---|---:|---:|
| original | 0.7218 | 0.0335 |
| automatic_train_refit | 0.8802 | 0.1622 |

## 当前决定

至少一项最小修复通过预先规定的验证集开发门槛：Proposal Refit Learned。这只是验证集开发证据，不是独立测试确认，不能把它写成性能问题已解决。

Stage III 暂不追加更复杂 controller。根据目前证据，保留验证集选出的常数 0.35 作为简洁、可复现的基准；gate 的独立优势主张仍待收缩，不能通过换一个故事继续保留。最终保留哪些组件，应在明确修复证据后一次性修改全文，不能先承诺 learned stages 必须都获益。

## 核验

- 独立重算 75237 条新训练标签；validation 候选预测重算 14057 条。
- 1673 条验证路径用恢复代码的另一实现重新执行，选择、路径及指标一致。
- 模型所有可配置参数与原模型一致，StandardScaler 拟合样本数与 TRAIN 行数一致。
- 预先写下的验证推进规则已独立复核；TEST 执行次数为 0；全部前序实验输出哈希保持不变。

## 文件

- protocol.json：修复前写下的方案、门槛和前序文件哈希。
- automatic_training_and_validation_candidates.csv：train 候选、重算标签及 val 候选。
- refitted_automatic_train_model.joblib、validation_scored_candidates.csv：新模型与新旧验证分数。
- validation_per_query.csv、validation_summary.csv、validation_decision.json：全部验证结果与推进判断。
- verification.json、independent_verification.json：执行核验与独立核验。
- ../stage23_repair_diagnosis/：原 gate 标签核查、自动验证候选诊断及 oracle headroom。
