# 最小修复的冻结测试：自动训练候选对齐＋soft reliability weighting

## 为什么做这项修复

旧模型在归档候选上训练，直接迁移到大的自动候选池后不足以支撑 K=3 的硬选择。采用一次最小修复：在自动生成的 TRAIN 候选上重建 singleton usefulness 标签，原特征、TFIDF/StandardScaler/LogisticRegression 参数和 seed 完全不变，模型只拟合 TRAIN。

先执行 train/val pilot，并独立重算 75,237 条训练标签与 1,673 条验证路径。只有“保留 proposal Top3，只更新 confidence 加权”通过预定验证门槛；新的硬选择仍未通过，没有进入测试。详见 ../stage2_training_alignment_pilot/RESULTS_CN.md。

## 本轮冻结规则

- 不再训练或调模型；冻结验证通过的 checkpoint、原 Stage I proposal Top3、图、端点和搜索器。
- 比较 Equal、Original Learned、Aligned Learned。每种 weighting 都在同一 239 条验证查询上用相同 11 个常数 gate 网格独立选择，公平控制 gate 调参预算；另报告全部固定 g=.3 结果。
- 不使用 greedy、type bonus、adaptive gate、Safety Gate 或 Pareto。此版本保留 retrieval-aware reliability weighting，放弃当前无证据的硬选择和 query-specific gate 性能主张；不是仅修改措辞继续声称所有旧组件有效。
- 验证选择的常数：{"Equal": 0.35, "Original Learned": 0.35, "Aligned Learned": 0.35}。
- 模型、协议、验证参数均锁定后，执行一次全部 248 条测试查询。测试集此前已多次查看，所以仍属于补充评估，不能称新的独立确认。保留全部结果，不再根据这次测试增加参数或切换模型。
- 背景图仍是原传导式聚合图，包含测试机制边；新训练标签属于明确的新操作化，不等同于恢复旧 label writer。

## 全部测试结果

Fixed0.3 是统一固定常数；ValBest 是各 weighting 自己在相同验证网格中选出的常数，非测试最优。

| 测试方法 | gate | PS (%) | ER (%) | AH (%) | Utility |
|---|---:|---:|---:|---:|---:|
| Aligned Learned Fixed0.3 | 0.30 | 34.68 | 38.52 | 73.79 | 0.358294 |
| Aligned Learned ValBest | 0.35 | 34.68 | 38.83 | 73.79 | 0.359221 |
| Equal Fixed0.3 | 0.30 | 35.08 | 38.73 | 73.39 | 0.361762 |
| Equal ValBest | 0.35 | 35.08 | 38.37 | 72.98 | 0.360673 |
| Graph Only | 0.00 | 27.02 | 33.97 | 70.56 | 0.291019 |
| Original Learned Fixed0.3 | 0.30 | 34.68 | 39.34 | 73.39 | 0.360774 |
| Original Learned ValBest | 0.35 | 34.68 | 39.56 | 73.39 | 0.361419 |

## 配对增量

5000 次 rid-cluster bootstrap，seed=20260914；逐比较 95% 区间，未作多重比较校正。utility 差也乘 100 展示，不能混称为 ER 百分点。

| 比较 | 指标 | 差值 (pp) | 95% cluster CI (pp) | 改善/退步 |
|---|---|---:|---|---|
| Aligned Learned Fixed0.3 - Equal Fixed0.3 | PS | -0.403 | [-1.250, +0.000] | 0/1 |
| Aligned Learned Fixed0.3 - Equal Fixed0.3 | ER | -0.215 | [-1.081, +0.636] | 3/5 |
| Aligned Learned Fixed0.3 - Equal Fixed0.3 | AH | +0.403 | [-0.820, +1.953] | 2/1 |
| Aligned Learned Fixed0.3 - Equal Fixed0.3 | utility | -0.347 | [-1.156, +0.144] | 3/5 |
| Aligned Learned Fixed0.3 - Original Learned Fixed0.3 | PS | +0.000 | [+0.000, +0.000] | 0/0 |
| Aligned Learned Fixed0.3 - Original Learned Fixed0.3 | ER | -0.827 | [-2.181, +0.436] | 5/8 |
| Aligned Learned Fixed0.3 - Original Learned Fixed0.3 | AH | +0.403 | [-0.823, +2.000] | 2/1 |
| Aligned Learned Fixed0.3 - Original Learned Fixed0.3 | utility | -0.248 | [-0.654, +0.131] | 5/8 |
| Aligned Learned ValBest - Equal ValBest | PS | -0.403 | [-1.250, +0.000] | 0/1 |
| Aligned Learned ValBest - Equal ValBest | ER | +0.457 | [-0.752, +1.827] | 6/5 |
| Aligned Learned ValBest - Equal ValBest | AH | +0.806 | [-1.190, +2.834] | 4/2 |
| Aligned Learned ValBest - Equal ValBest | utility | -0.145 | [-0.978, +0.475] | 6/5 |
| Aligned Learned ValBest - Original Learned ValBest | PS | +0.000 | [+0.000, +0.000] | 0/0 |
| Aligned Learned ValBest - Original Learned ValBest | ER | -0.733 | [-1.992, +0.484] | 5/7 |
| Aligned Learned ValBest - Original Learned ValBest | AH | +0.403 | [-0.827, +1.976] | 2/1 |
| Aligned Learned ValBest - Original Learned ValBest | utility | -0.220 | [-0.598, +0.145] | 5/7 |
| Aligned Learned ValBest - Aligned Learned Fixed0.3 | PS | +0.000 | [+0.000, +0.000] | 0/0 |
| Aligned Learned ValBest - Aligned Learned Fixed0.3 | ER | +0.309 | [-0.493, +1.189] | 3/1 |
| Aligned Learned ValBest - Aligned Learned Fixed0.3 | AH | +0.000 | [-1.210, +1.205] | 1/1 |
| Aligned Learned ValBest - Aligned Learned Fixed0.3 | utility | +0.093 | [-0.148, +0.357] | 3/1 |
| Aligned Learned ValBest - Graph Only | PS | +7.661 | [+4.016, +11.600] | 19/0 |
| Aligned Learned ValBest - Graph Only | ER | +4.858 | [+2.660, +7.210] | 38/6 |
| Aligned Learned ValBest - Graph Only | AH | +3.226 | [+0.403, +6.198] | 11/3 |
| Aligned Learned ValBest - Graph Only | utility | +6.820 | [+3.840, +10.043] | 42/6 |

## 自动测试池 usefulness 判别

全部 14029 条自动测试候选，按统一 singleton(confidence=1,g=.3) 相对 Graph Only 的 utility 差重算评估标签；positive rate=1.647%。只在模型冻结后计算，不参与训练或选择。

| 模型 | AUROC | AUPRC |
|---|---:|---:|
| Original | 0.6722 | 0.0317 |
| Aligned | 0.8642 | 0.1216 |

判别指标是描述性比较，没有在此计算其显著性区间。判别改善不等于多 Bridge 选择或完整检索改善；后者必须依据上面的 matched retrieval 和配对区间判断。不能把 AUPRC 提升包装成 greedy 或 gate 的贡献。

## 如何据此决定论文

只有区间和指标实际支持的增量才能写成性能证据。即便新训练改善判别，也不能说旧 greedy 或 query-specific gate 被修好；本方案明确简化了这些不受支持的部分。若新加权相对公平常数基线仍没有统计支持，保留结果并收紧性能主张，停止以调参追求正结果。

## 核验

独立恢复实现重放 9623 条路径；重算 14029 条测试 usefulness 标签和 14029 条模型预测；验证集定参规则及 24 组配对统计复核通过；冻结模型和前序输出哈希一致。

模型训练/验证开发过程见 ../stage2_training_alignment_pilot/；本目录 protocol.json、selected_constants.json、validation_gate_grid.csv、test_per_query.csv、test_candidate_usefulness.csv、paired_cluster_bootstrap.csv、independent_verification.json 提供完整证据。
