"""Independent reverse-order selection and path/metric verification for Stage II."""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';O=ROOT/'audit_output/experiment2_stage2_selection'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'))
import dmdb_retrievers as r
pr=json.loads((O/'protocol.json').read_text(encoding='utf-8'));co=json.loads((O/'selected_config.json').read_text());done=json.loads((O/'verification.json').read_text())
assert done['complete']
c=pd.read_csv(O/'candidate_scores.csv',keep_default_na=False);sel=pd.read_csv(O/'selection_per_query.csv');d=pd.read_csv(O/'per_query.csv')
trace=pd.read_csv(O/'selection_trace.csv',keep_default_na=False)
assert len(d)==9253 and len(sel)==4383
assert not d.duplicated(['task','rid','selector','weighting']).any()
pool={(t,i):g for (t,i),g in c.groupby(['task','rid'])}
manifest={(x.task,x.rid):x for x in r.manifest.itertuples(index=False)}
nei={n:set(r.G.predecessors(n))|set(r.G.successors(n)) for n in c.node.unique()}
types={n:r.G.nodes[n].get('type','Unknown') for n in c.node.unique()}
names={}
for rec in r.paths:
    for n in rec.get('nodes',[]):names.setdefault(str(n['id']),str(n.get('name','')))
for key,g in pool.items():
    nodes=sorted(g.node);q=manifest[key];docs=[str(q.question)]+[names.get(n,n) for n in nodes]
    try:
        xx=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1).fit_transform(docs)
        vals=cosine_similarity(xx[:1],xx[1:]).ravel()
    except ValueError as e:
        if 'empty vocabulary' not in str(e):raise
        vals=np.zeros(len(nodes))
    saved=g.set_index('node').reindex(nodes)
    assert np.allclose(saved.lexical_score,vals,rtol=0,atol=1e-14)
    assert np.allclose(saved.graph_score,[1-math.log1p(r.G.in_degree(n)+r.G.out_degree(n))/r.MAXLOG for n in nodes],rtol=0,atol=1e-14)

def parameters(name):
    if name=='Reliability':return 0.,0.
    if name=='Greedy Red':return co['Red']['mu'],co['Red']['beta']
    if name=='Greedy Type':return co['Type']['mu'],co['Type']['beta']
    if name=='Greedy Full':return co['Full']['mu'],co['Full']['beta']
    if name=='Matched No Red':return 0.,co['Full']['beta']
    if name=='Matched No Type':return co['Full']['mu'],0.
    raise ValueError(name)

def replay(key,name,mu_override=None,beta_override=None):
    g=pool.get(key,c.iloc[:0]);left=sorted(g.node,reverse=True)
    if name in ['Proposal','Lexical','Graph']:
        col={'Proposal':'pre','Lexical':'lexical_score','Graph':'graph_score'}[name]
        sig=dict(zip(g.node,g[col]));return sorted(left,key=lambda n:(-sig[n],n))[:3]
    mu,beta=parameters(name) if mu_override is None else (mu_override,beta_override)
    conf=dict(zip(g.node,g.confidence));chosen=[]
    while left and len(chosen)<3:
        # Build a table independently and select by gain then identifier.
        options=[]
        for n in left:
            overlaps=[]
            for h in chosen:
                union=nei[n]|nei[h];intersection=sum(1 for v in nei[n] if v in nei[h])
                overlaps.append(intersection/max(1,len(union)))
            red=max(overlaps) if overlaps else 0.
            bonus=int(all(types[n]!=types[h] for h in chosen))
            options.append((conf[n]-mu*red+beta*bonus,n))
        win=sorted(options,key=lambda z:(-z[0],z[1]))[0][1]
        chosen.append(win);left.remove(win)
    return chosen

sel_lookup={};selection_checks=0
trace_lookup={(t,i,s):g.sort_values('rank') for (t,i,s),g in trace.groupby(['task','rid','selector'])}
for x in sel.itertuples(index=False):
    key=(x.task,x.rid);nodes=replay(key,x.selector)
    assert nodes==json.loads(x.selected_nodes),(key,x.selector)
    assert x.pool_size==len(pool.get(key,[])) and x.selected_size==len(nodes)
    assert x.answer_selected==int(str(manifest[key].answer) in nodes)
    if nodes:assert trace_lookup[(x.task,x.rid,x.selector)].node.tolist()==nodes
    sel_lookup[(key,x.selector)]=nodes;selection_checks+=1

grid=pd.read_csv(O/'validation_grid.csv');vd=pd.read_csv(O/'validation_grid_per_query.csv')
val_checks=0
for x in vd.itertuples(index=False):
    key=(x.task,x.rid);assert manifest[key].split=='val'
    nodes=replay(key,'Reliability',x.mu,x.beta)
    assert nodes==json.loads(x.selected_nodes)
    cs=dict(zip(pool[key].node,pool[key].confidence));q=manifest[key]
    z=r.search(q.source,q.target,{n:cs[n] for n in nodes},.3)
    er=len(set(z['edges'])&set(r.gold[q.rid]))/max(1,len(set(r.gold[q.rid])))
    assert np.allclose([float(z['found']),er,float(str(q.answer) in z['nodes'])],[x.PS,x.ER,x.AH],rtol=0,atol=1e-14)
    val_checks+=1
for x in grid.itertuples(index=False):
    g=vd[(vd.mu==x.mu)&(vd.beta==x.beta)]
    assert len(g)==239
    utility=.7*g.PS.mean()+.3*g.ER.mean()
    assert abs(utility-x.utility)<1e-14 and abs(round(utility,12)-x.utility_tie_key)<1e-14
for kind,table in [('Full',grid),('Red',grid[grid.beta==0]),('Type',grid[grid.mu==0])]:
    x=table.sort_values(['utility_tie_key','mu','beta'],ascending=[False,True,True],kind='stable').iloc[0]
    assert (float(x.mu),float(x.beta))==(co[kind]['mu'],co[kind]['beta'])

metric_checks=0;path_checks=0
for x in d.itertuples(index=False):
    key=(x.task,x.rid);q=manifest[key];nodes=json.loads(x.selected_nodes);conf=json.loads(x.selected_confidences)
    expected=[] if x.selector=='Graph Only' else sel_lookup[(key,x.selector)]
    assert nodes==expected==list(conf)
    cs=dict(zip(pool[key].node,pool[key].confidence)) if key in pool else {}
    assert np.allclose(list(conf.values()),[1. if x.weighting=='Equal' else cs[n] for n in nodes],rtol=0,atol=1e-14)
    gate=0. if x.selector=='Graph Only' else .3
    assert abs(x.gate-gate)<1e-14
    z=r.search(q.source,q.target,conf,gate)
    assert z['nodes']==json.loads(x.nodes) and z['edges']==[tuple(e) for e in json.loads(x.edges)]
    assert (z['visited_nodes'],z['expanded_edges'])==(x.visited_nodes,x.expanded_edges)
    gold=set(r.gold[q.rid]);er=len(set(z['edges'])&gold)/max(1,len(gold))
    assert np.allclose([float(z['found']),er,float(str(q.answer) in z['nodes'])],[x.PS,x.ER,x.AH],rtol=0,atol=1e-14)
    assert x.split==q.split and x.selected_size==len(nodes)
    metric_checks+=3;path_checks+=1
summary=pd.read_csv(O/'summary.csv').set_index(['split','selector','weighting'])
for key,g in d.groupby(['split','selector','weighting']):
    for metric in ['PS','ER','AH','selected_size','answer_selected','visited_nodes','expanded_edges']:
        assert abs(g[metric].mean()-summary.loc[key,metric])<1e-13
for name,h in {**pr['locked_stage1_hashes'],**pr['source_hashes']}.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
report={'passed':True,'reverse_input_order_selection_replays':selection_checks,'lexical_and_graph_score_query_checks':len(pool),'validation_grid_queries_replayed':val_checks,'all_three_validation_parameter_choices_verified':True,'serialized_paths_reexecuted':path_checks,'metrics_independently_recomputed':metric_checks,'stage1_and_source_hashes_unchanged':True}
(O/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
