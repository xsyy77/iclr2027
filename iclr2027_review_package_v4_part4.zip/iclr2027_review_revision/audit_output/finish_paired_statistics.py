from pathlib import Path
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
s=pd.read_csv(P/'search_order_per_query.csv'); out=[]
def boot(d):
 rng=np.random.default_rng(20261109); z=np.concatenate([d[rng.integers(len(d),size=(500,len(d)))].mean(1) for _ in range(20)])
 return np.quantile(z,[.025,.975])
for order,g in s.groupby('order'):
 for baseline in ['Graph Only','Semantic+Fixed','Utility+Fixed']:
  m=g[g.method=='Full'].merge(g[g.method==baseline],on=['task','rid'],suffixes=('_f','_b'))
  for metric in ['PS','ER','AH']:
   d=(m[metric+'_f']-m[metric+'_b']).to_numpy(); lo,hi=boot(d)
   out.append(dict(order=order,baseline=baseline,metric=metric,delta=d.mean(),lo=lo,hi=hi,improved=int((d>1e-12).sum()),degraded=int((d< -1e-12).sum())))
pd.DataFrame(out).to_csv(P/'search_order_paired_bootstrap.csv',index=False)
c=pd.read_csv(P/'table1_gate_controls_per_query.csv'); full=c[c.method=='Full']; sh=c[c.method.str.startswith('Shuffled ')]; avg=sh.groupby(['task','rid'])[['PS','ER','AH','utility']].mean().reset_index(); m=full.merge(avg,on=['task','rid'],suffixes=('_f','_b')); rows=[]
for metric in ['PS','ER','AH','utility']:
 d=(m[metric+'_f']-m[metric+'_b']).to_numpy(); lo,hi=boot(d); means=sh.groupby('method')[metric].mean(); actual=full[metric].mean()
 rows.append(dict(metric=metric,delta=d.mean(),lo=lo,hi=hi,permutation_p_one_sided=(1+(means>=actual-1e-12).sum())/(1+len(means))))
pd.DataFrame(rows).to_csv(P/'table1_shuffle_paired_statistics.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
print(pd.DataFrame(out).query("baseline=='Semantic+Fixed' and metric=='ER'").to_string(index=False))
