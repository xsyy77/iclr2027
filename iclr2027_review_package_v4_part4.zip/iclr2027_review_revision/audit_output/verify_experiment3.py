"""Independent Stage-III permutation, search, statistics and provenance checks."""
from pathlib import Path
import hashlib,json,math,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package'
I=ROOT/'audit_output/experiment1_recovered_proposer';O=ROOT/'audit_output/experiment3_stage3_gate';E=ROOT/'audit_output/new_candidate_evidence'
pr=json.loads((O/'protocol.json').read_text(encoding='utf-8'));v=json.loads((O/'verification.json').read_text())
assert v['complete']
def read(name):return pd.read_csv(O/name,float_precision='round_trip')
d=read('per_query.csv');cache=read('search_cache.csv.gz');gm=pd.read_csv(I/'recomputed_gates.csv');orig=pd.read_csv(I/'per_query.csv')
man=pd.read_csv(R/'data/processed/drugmechdb/benchmark_manifest.csv');ml={(x.task,x.rid):x for x in man.itertuples(index=False)}
assert len(d)==2922 and not d.duplicated(['task','rid','method']).any()
assert len(cache)==v['unique_search_executions'] and cache.cache_id.tolist()==list(range(len(cache)))
assert not cache.duplicated(['task','rid','gate']).any()
controls={k:g.set_index(['task','rid']) for k,g in d.groupby('method')}
query_index=json.loads((O/'query_index.json').read_text());tasks=np.array([x['task'] for x in query_index]);n=len(query_index)
assert n==248
gg={(x.task,x.rid):float(x.gate) for x in gm.itertuples(index=False)}
testg=np.array([gg[(x['task'],x['rid'])] for x in query_index])
donors=np.load(O/'shuffle_donor_indices.npz');permutation_checks=0
for rep in range(500):
    assert np.array_equal(donors['global_indices'][rep],np.random.default_rng(20261108+rep).permutation(n))
    rng=np.random.default_rng(20261108+rep);expected=np.arange(n)
    for task in sorted(set(tasks)):
        ix=np.flatnonzero(tasks==task);expected[ix]=rng.permutation(ix)
    assert np.array_equal(donors['within_task_indices'][rep],expected)
    for field in ['global_indices','within_task_indices']:
        assert sorted(donors[field][rep])==list(range(n));permutation_checks+=1
    assert np.array_equal(tasks[donors['within_task_indices'][rep]],tasks)

# Independent recovered search implementation; executes no experiment driver/output writes.
source=E/'candidate_generation/run_dmdb_proposal_samek.py'
s=source.read_text().split('# Build proposal diagnostics first')[0]
s=s.replace("ROOT=Path('/mnt/data/dmdb_samek')",f'ROOT=Path({str(O)!r})').replace("PATHS=ROOT/'indication_paths.json'",f'PATHS=Path({str(R/"data/raw/drugmechdb/indication_paths.json")!r})').replace("TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'",f'TEST_ROWS=Path({str(E/"figure3/proposal_availability_by_query.csv")!r})').replace('OUTDIR.mkdir(exist_ok=True)','')
ns={};exec(compile(s,str(source),'exec'),ns)
conf={(x.task,x.rid):json.loads(x.selected_confidences) for x in orig[orig.method=='Utility Fixed'].itertuples(index=False)}
path_checks=0
for x in cache.itertuples(index=False):
    q=ml[(x.task,x.rid)];z=ns['run_search'](q.source,q.target,conf[(x.task,x.rid)],x.gate)
    assert z['nodes']==json.loads(x.nodes),(x.cache_id,'nodes')
    assert z['edges']==[tuple(e) for e in json.loads(x.edges)],(x.cache_id,'edges')
    assert (z['visited_nodes'],z['expanded_edges'])==(x.visited_nodes,x.expanded_edges)
    gold=set(ns['gold'][x.rid]['links']);er=len(gold&set(z['edges']))/max(1,len(gold))
    assert np.allclose([z['found'],er,float(str(q.answer) in z['nodes'])],[x.PS,x.ER,x.AH],rtol=0,atol=1e-14)
    assert abs(x.utility-(.7*x.PS+.3*x.ER))<1e-14
    path_checks+=1
    if path_checks%20000==0:print(f'Independent paths checked: {path_checks}/{len(cache)}',flush=True)
cache=cache.set_index('cache_id');grid=read('validation_gate_grid.csv');vd=read('validation_gate_grid_per_query.csv')
for x in vd.itertuples(index=False):
    q=ml[(x.task,x.rid)];assert q.split=='val';z=cache.loc[x.cache_id]
    assert (z.task,z.rid,z.gate)==(x.task,x.rid,x.gate)
    assert np.allclose(z[['PS','ER','AH','utility']].to_numpy(dtype=float),[x.PS,x.ER,x.AH,x.utility],rtol=0,atol=1e-14)
for x in grid.itertuples(index=False):
    zz=vd[vd.gate==x.gate];assert len(zz)==239
    assert abs(zz.utility.mean()-x.utility)<1e-14
    assert abs(round(x.utility,12)-x.utility_tie_key)<1e-14
constants=json.loads((O/'selected_constants.json').read_text())
chosen=grid.sort_values(['utility_tie_key','gate'],ascending=[False,True],kind='stable').iloc[0]
assert chosen.gate==constants['validation_best']
assert abs(constants['validation_mean']-gm[gm.split=='val'].gate.mean())<1e-14
assert abs(constants['test_mean_diagnostic']-gm[gm.split=='test'].gate.mean())<1e-14
for x in d.itertuples(index=False):
    out=cache.loc[x.cache_id];expected={'Graph Only':0.,'Fixed 0.3':.3,'Adaptive Full':gg[(x.task,x.rid)],'Validation-best constant':constants['validation_best'],'Validation-mean constant':constants['validation_mean'],'Test-mean constant (diagnostic)':constants['test_mean_diagnostic']}[x.method]
    assert abs(x.gate-expected)<1e-15
    assert (x.task,x.rid,x.split)==(out.task,out.rid,out.split)
    assert np.allclose([x.PS,x.ER,x.AH,x.utility],[out.PS,out.ER,out.AH,out.utility],rtol=0,atol=1e-14)

ss=read('shuffle_summary.csv');tests=read('shuffle_randomization_tests.csv');null_means={};shuffle_checks=0
for family,filename,field in [('Global','shuffle_global_per_query.csv.gz','global_indices'),('Within task','shuffle_within_task_per_query.csv.gz','within_task_indices')]:
    dd=read(filename)
    assert len(dd)==124000 and not dd.duplicated(['rep','query_index']).any()
    dd=dd.sort_values(['rep','query_index']);expected_indices=donors[field].ravel()
    assert np.array_equal(dd.donor_index.to_numpy(),expected_indices)
    assert np.allclose(dd.gate,testg[expected_indices],rtol=0,atol=1e-15)
    selected=cache.loc[dd.cache_id.to_numpy()]
    assert np.array_equal(dd.task.to_numpy(),selected.task.to_numpy()) and np.array_equal(dd.rid.to_numpy(),selected.rid.to_numpy())
    assert np.allclose(dd[['PS','ER','AH','utility']].to_numpy(),selected[['PS','ER','AH','utility']].to_numpy(),rtol=0,atol=1e-14)
    avg=dd.groupby('rep')[['PS','ER','AH','utility']].mean();saved=ss[ss.family==family].set_index('rep').sort_index()
    assert np.allclose(avg,saved[['PS','ER','AH','utility']],rtol=0,atol=1e-14)
    null_means[family]=dd.groupby(['task','rid'])[['PS','ER','AH','utility']].mean()
    actual=d[(d.split=='test')&(d.method=='Adaptive Full')]
    for metric in ['PS','ER','AH','utility']:
        x=tests[(tests.family==family)&(tests.metric==metric)].iloc[0]
        observed=actual[metric].mean();pv=(1+int((avg[metric]>=observed-1e-12).sum()))/501
        assert abs(pv-x.p_one_sided)<1e-14
        assert abs(x.shuffle_mean-avg[metric].mean())<1e-14
    shuffle_checks+=len(dd)
# Independently calculate Holm correction in sorted order.
ordered=tests.sort_values('p_one_sided',kind='stable');running=0.
for rank,(index,x) in enumerate(ordered.iterrows()):
    running=max(running,min(1.,(8-rank)*x.p_one_sided));assert abs(running-x.p_holm_8_tests)<1e-14

keys=pd.MultiIndex.from_tuples([(x['task'],x['rid']) for x in query_index],names=['task','rid'])
actual=d[(d.split=='test')&(d.method=='Adaptive Full')].set_index(['task','rid']).reindex(keys)
clusters=sorted(set(keys.get_level_values('rid')));ix=np.random.default_rng(20260914).integers(0,len(clusters),size=(5000,len(clusters)))
bs=read('paired_cluster_bootstrap.csv');bootstrap_checks=0
for x in bs.itertuples(index=False):
    name=x.comparison.removeprefix('Adaptive Full - ')
    if name.endswith(' shuffled mean'):other=null_means[name.removesuffix(' shuffled mean')].reindex(keys)
    else:other=d[(d.split=='test')&(d.method==name)].set_index(['task','rid']).reindex(keys)
    delta=actual[x.metric]-other[x.metric];c=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters)
    boots=c['sum'].to_numpy()[ix].sum(axis=1)/c['size'].to_numpy()[ix].sum(axis=1);lo,hi=np.quantile(boots,[.025,.975])
    assert np.allclose([delta.mean(),lo,hi],[x.delta,x.ci95_low,x.ci95_high],rtol=0,atol=1e-14)
    assert (int((delta>1e-12).sum()),int((delta< -1e-12).sum()))==(x.improved,x.degraded)
    bootstrap_checks+=1
summary=read('summary.csv').set_index(['split','method'])
for key,zz in d.groupby(['split','method']):
    assert np.allclose(summary.loc[key,['PS','ER','AH','utility','gate']].to_numpy(dtype=float),zz[['PS','ER','AH','utility','gate']].mean().to_numpy(),rtol=0,atol=1e-14)
for name,h in {**pr['source_hashes'],**pr['locked_input_hashes']}.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
old_protocol=json.loads((I/'protocol.json').read_text())
for name,h in old_protocol['source_hashes'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
report={'passed':True,'independent_recovered_search_path_checks':path_checks,'unique_path_metrics_recomputed':3*path_checks,'permutations_reproduced':permutation_checks,'shuffle_query_records_checked':shuffle_checks,'validation_only_constant_selection_verified':True,'paired_bootstrap_comparisons_recomputed':bootstrap_checks,'randomization_tests_and_holm_correction_verified':8,'all_prior_output_and_source_hashes_match':True}
(O/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2),flush=True)
