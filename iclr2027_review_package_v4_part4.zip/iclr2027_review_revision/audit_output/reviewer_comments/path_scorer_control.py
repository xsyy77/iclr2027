"""9P9q-Q1: standalone matched-budget learned-linear path scoring BASELINE.
Never changes the submitted method. Search inputs/features contain no reference labels.
"""
import math
import numpy as np

class SearchControl:
    def __init__(self,retriever,types,node_types):
        self.r=retriever;self.types=types;self.node_types=node_types

    def query_features(self,task,source,target,conf):
        r=self.r;nodes=list(conf);types=[self.node_types.get(n,'Unknown') for n in nodes]
        return np.asarray([len(nodes)/10.,math.log1p(r.G.out_degree(source)),math.log1p(r.G.in_degree(target))]+[types.count(t)/max(1,len(nodes)) for t in self.types]+[float(np.mean([r.G.has_edge(source,n) for n in nodes])) if nodes else 0.,float(np.mean([math.log1p(r.G.degree(n)) for n in nodes])) if nodes else 0.]+[float(task==t) for t in ['Gene','Metabolite','Process']],dtype=np.float32)

    def path_features(self,query_features,target,conf,nodes,relations,graph_scores):
        r=self.r;hits=list(dict.fromkeys(n for n in nodes if n in conf));cov=len(hits)/max(1,len(conf));mc=float(np.mean([conf[n] for n in hits])) if hits else 0.;cur=float(conf.get(nodes[-1],0.));recent=sum(n in conf for n in nodes[-2:])/2.;sat=(.65 if len(hits)<=1 else .85 if len(hits)==2 else 1.) if hits else 0.;gs=float(np.mean(graph_scores));bs=r.bridge_score(nodes,conf)
        state=[gs,bs,len(relations)/8.,cov,mc,cur,recent,sat,math.log1p(r.G.degree(nodes[-1])),float(np.mean([r.rel_quality(rel) for rel in relations])),float(nodes[-1]==target)]
        # Query-dependent weights over the EXISTING graph/Bridge scores; no new model feature in Full.
        return np.concatenate([query_features,np.asarray(state,np.float32),query_features*gs,query_features*bs]).astype(np.float32)

    def search(self,task,source,target,conf,gate=0.,model=None,trace=False):
        r=self.r;qf=self.query_features(task,source,target,conf);states=[(0.,(source,),(),())];generated={source};expanded=0;best=None;records=[]
        for depth in range(8):
            nxt=[];features=[];level_records=[]
            for _,pn,pr,pg in states:
                for v,rel in r.OUT.get(pn[-1],[]):
                    if expanded>=20:break
                    expanded+=1
                    if v in pn:continue
                    if v not in generated and len(generated)>=14:continue
                    generated.add(v);nn=pn+(v,);rr=pr+(rel,);gg=pg+(r.graph_score(v,rel),);feature=self.path_features(qf,target,conf,nn,rr,gg);score=(1-gate)*float(np.mean(gg))+gate*r.bridge_score(nn,conf)-.012*len(rr);nxt.append((score,nn,rr,gg));features.append(feature);level_records.append(dict(depth=depth+1,nodes=list(nn),relations=list(rr),features=feature))
                if expanded>=20:break
            if model is not None and nxt:
                scores=model['clf'].predict_proba(model['sc'].transform(np.asarray(features,np.float32)))[:,1];nxt=[(float(score),st[1],st[2],st[3]) for score,st in zip(scores,nxt)]
            for st,rec in zip(nxt,level_records):
                rec['score']=float(st[0])
                if trace:records.append(rec)
                if st[1][-1]==target and (best is None or st[0]>best[0]):best=st
            if best is not None:break
            if not nxt:break
            nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True);states=nxt[:2]
        z=best if best is not None else (max(states,key=lambda x:x[0]) if states else (0.,(source,),(),()));out={'found':z[1][-1]==target,'nodes':list(z[1]),'edges':[(z[1][i],z[1][i+1],z[2][i]) for i in range(len(z[2]))],'visited_nodes':len(generated),'expanded_edges':expanded}
        return (out,records) if trace else out
