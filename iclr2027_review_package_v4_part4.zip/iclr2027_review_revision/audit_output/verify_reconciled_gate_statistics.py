"""Independent statistics/config verification for revised main-configuration Table4."""
from pathlib import Path
import hashlib,json,numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'audit_output/reconciled_gate_controls';cfg=json.loads((O/'configuration.json').read_text());assert json.loads((O/'full_replay_verification.json').read_text())['passed'];d=pd.read_csv(O/'per_query_controls.csv.gz',float_precision='round_trip');full=d[d.method=='Full'].set_index(['task','rid']);shuffle=d[d.method.str.startswith('Shuffled ')];shmean=shuffle.groupby(['task','rid'])[['PS','ER','AH','utility']].mean();stats=pd.read_csv(O/'paired_mechanism_cluster_CI.csv',float_precision='round_trip');ids=sorted(full.index.get_level_values('rid').unique());draw=np.random.default_rng(20260914).integers(0,len(ids),size=(5000,len(ids)))
for x in stats.itertuples(index=False):
    name=x.comparison.removeprefix('Full - ');other=shmean.reindex(full.index) if name.startswith('Shuffled') else d[d.method==name].set_index(['task','rid']).reindex(full.index);delta=full[x.metric]-other[x.metric];frame=pd.DataFrame({'rid':full.index.get_level_values('rid'),'delta':delta.to_numpy()});cl=frame.groupby('rid').agg(total=('delta','sum'),size=('delta','size')).reindex(ids);counts=np.asarray([np.bincount(row,minlength=len(ids)) for row in draw]);boot=(counts@cl.total.to_numpy())/(counts@cl['size'].to_numpy());lo,hi=np.quantile(boot,[.025,.975]);assert np.allclose([delta.mean(),lo,hi],[x.delta,x.ci95_low,x.ci95_high],atol=1e-13,rtol=0)
r=pd.read_csv(O/'shuffle_randomization_tests.csv',float_precision='round_trip');agg=shuffle.groupby('method')[['PS','ER','AH','utility']].mean();pv={}
for x in r.itertuples(index=False):
    p=(1+int((agg[x.metric]>=full[x.metric].mean()-1e-12).sum()))/501;assert abs(p-x.p_one_sided)<1e-14;pv[x.metric]=p
rank=sorted(pv,key=pv.get);adjusted={};maximum=0.
for i,k in enumerate(rank):maximum=max(maximum,min(1.,(len(rank)-i)*pv[k]));adjusted[k]=maximum
assert all(abs(adjusted[x.metric]-x.p_holm_4_metrics)<1e-14 for x in r.itertuples(index=False))
effects=pd.read_csv(O/'all_query_effects_vs_validation_mean.csv');delta=effects.utility-effects.utility_constant;assert effects.status.tolist()==np.where(delta>1e-12,'benefit',np.where(delta< -1e-12,'harm','unchanged')).tolist();assert len(effects)==248
for name,h in cfg['source_hashes'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
proof={'passed':True,'main_Full_equal_to_Table1':True,'replayed_query_records':124992,'paired_cluster_intervals_recomputed':len(stats),'randomization_tests_and_Holm_recomputed':len(r),'all_query_effects_checked':len(effects),'old_Table4_preserved_not_relabelled':True,'original_method_unchanged':True,'scope':'revised Table4 uses the actual main configuration; no assertion of recovered old Table4 historical generator'};(O/'independent_verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(json.dumps(proof,indent=2))
