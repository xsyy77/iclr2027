"""Independent verification + complete report of frozen soft-weighting follow-up."""
from pathlib import Path
import hashlib,json,sys
import joblib,numpy as np,pandas as pd
from scipy.sparse import csr_matrix,hstack
from sklearn.metrics import roc_auc_score,average_precision_score
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';I=ROOT/'audit_output/experiment1_recovered_proposer';P=ROOT/'audit_output/stage2_training_alignment_pilot';E=ROOT/'audit_output/new_candidate_evidence';O=ROOT/'audit_output/aligned_weighting_evaluation'
pr=json.loads((O/'protocol.json').read_text(encoding='utf-8'));v=json.loads((O/'verification.json').read_text());assert v['complete']
def read(n):return pd.read_csv(O/n,float_precision='round_trip')
c=read('all_candidate_predictions.csv');cache=read('search_cache.csv');d=read('test_per_query.csv');labels=read('test_candidate_usefulness.csv');grid=read('validation_gate_grid.csv');const=json.loads((O/'selected_constants.json').read_text());pairs=read('paired_cluster_bootstrap.csv')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)}
psrc=E/'candidate_generation/run_dmdb_proposal_samek.py'
s=psrc.read_text().split('# Build proposal diagnostics first')[0].replace("ROOT=Path('/mnt/data/dmdb_samek')",f'ROOT=Path({str(O)!r})').replace("PATHS=ROOT/'indication_paths.json'",f'PATHS=Path({str(R/"data/raw/drugmechdb/indication_paths.json")!r})').replace("TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'",f'TEST_ROWS=Path({str(E/"figure3/proposal_availability_by_query.csv")!r})').replace('OUTDIR.mkdir(exist_ok=True)','')
p={};exec(compile(s,str(psrc),'exec'),p)
pool={(t,i):g.sort_values(['pre','node'],ascending=[False,True]) for (t,i),g in c.groupby(['task','rid'])}
checks=0
for x in cache.itertuples(index=False):
    q=man[(x.task,x.rid)];g=pool[(x.task,x.rid)].head(3)
    nodes=g.node.tolist();cs={n:1. for n in nodes} if x.weighting=='Equal' else dict(zip(nodes,g['confidence' if x.weighting=='Original Learned' else 'aligned_confidence']))
    assert nodes==json.loads(x.selected_nodes) and cs==json.loads(x.selected_confidences)
    z=p['run_search'](q.source,q.target,cs,x.gate);gd=set(p['gold'][q.rid]['links']);er=len(set(z['edges'])&gd)/max(1,len(gd))
    assert z['nodes']==json.loads(x.nodes) and z['edges']==[tuple(e) for e in json.loads(x.edges)]
    assert np.allclose([z['found'],er,float(str(q.answer) in z['nodes'])],[x.PS,x.ER,x.AH],rtol=0,atol=1e-14)
    assert abs(x.utility-(.7*x.PS+.3*x.ER))<1e-14;checks+=1
assert len(d)==1736 and set(d.split)=={'test'} and not d.duplicated(['task','rid','method']).any()
cachelookup=cache.set_index('cache_id')
for x in d.itertuples(index=False):
    y=cachelookup.loc[x.cache_id];assert (x.task,x.rid,x.gate)==(y.task,y.rid,y.gate)
    assert np.allclose([x.PS,x.ER,x.AH],[y.PS,y.ER,y.AH],rtol=0,atol=1e-14)
for weighting,g in grid.groupby('weighting'):
    best=g.sort_values(['utility_tie_key','gate'],ascending=[False,True]).iloc[0];assert const[weighting]==best.gate
    for x in g.itertuples(index=False):
        zz=cache[(cache.split=='val')&(cache.weighting==weighting)&(cache.gate==x.gate)];assert len(zz)==239
        assert np.allclose(zz[['PS','ER','AH','utility']].mean(),[x.PS,x.ER,x.AH,x.utility],rtol=0,atol=1e-14)
        assert abs(x.utility_tie_key-round(x.utility,12))<1e-14
labelchecks=0
for key,dd in labels.groupby(['task','rid'],sort=False):
    q=man[key];assert q.split=='test';gd=set(p['gold'][q.rid]['links']);z=p['run_search'](q.source,q.target,{},0.);base=.7*z['found']+.3*len(set(z['edges'])&gd)/max(1,len(gd))
    for x in dd.itertuples(index=False):
        z=p['run_search'](q.source,q.target,{x.node:1.},.3);delta=.7*z['found']+.3*len(set(z['edges'])&gd)/max(1,len(gd))-base
        assert abs(delta-x.delta)<1e-14 and int(delta>1e-12)==x.beneficial;labelchecks+=1
src=R/'code/original_recovered/current_dmdb/step_semantic_bridge_diagnostics.py';s=src.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')))
b={};exec(compile(s,str(src),'exec'),b);model=joblib.load(P/'refitted_automatic_train_model.joblib')
testc=c[c.split=='test']
for start in range(0,len(testc),512):
    batch=testc.iloc[start:start+512];texts=[];nums=[]
    for x in batch.itertuples(index=False):
        q=b['man'][(x.task,x.rid)];nm=b['node_meta'].get(x.node,{'name':x.node,'type':'Unknown'});texts.append(f"task {x.task} question {q['question']} bridge {nm['name']} bridge_type {nm['type']}");nums.append(b['numfeat'](x.task,x.rid,x.node))
    xx=hstack([model['word'].transform(texts),model['char'].transform(texts),csr_matrix(model['sc'].transform(np.asarray(nums,np.float32)))],format='csr');assert np.allclose(model['clf'].predict_proba(xx)[:,1],batch.aligned_confidence,rtol=0,atol=1e-14)
clusters=sorted(d.rid.unique());ix=np.random.default_rng(20260914).integers(0,len(clusters),size=(5000,len(clusters)))
for x in pairs.itertuples(index=False):
    lhs,rhs=x.comparison.split(' - ');aa=d[d.method==lhs].set_index(['task','rid']);bb=d[d.method==rhs].set_index(['task','rid']).reindex(aa.index);delta=aa[x.metric]-bb[x.metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters);boot=cl['sum'].to_numpy()[ix].sum(axis=1)/cl['size'].to_numpy()[ix].sum(axis=1);lo,hi=np.quantile(boot,[.025,.975]);assert np.allclose([delta.mean(),lo,hi],[x.delta,x.ci95_low,x.ci95_high],rtol=0,atol=1e-14)
for name,h in pr['locked_hashes'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
rank=json.loads((O/'test_ranking.json').read_text())
for name,col in [('Original','old_confidence'),('Aligned','aligned_confidence')]:
    assert abs(rank['metrics'][name]['AUROC']-roc_auc_score(labels.beneficial,labels[col]))<1e-14
    assert abs(rank['metrics'][name]['AUPRC']-average_precision_score(labels.beneficial,labels[col]))<1e-14
verification={'passed':True,'independent_path_replays':checks,'test_candidate_labels_independently_recomputed':labelchecks,'test_predictions_recomputed':len(testc),'same_validation_tuning_budget_and_choices_verified':True,'paired_bootstrap_recomputed':len(pairs),'frozen_model_and_prior_files_unchanged':True}
(O/'independent_verification.json').write_text(json.dumps(verification,indent=2),encoding='utf-8')
summary=d.groupby('method')[['PS','ER','AH','utility','gate']].mean();table='| 测试方法 | gate | PS (%) | ER (%) | AH (%) | Utility |\n|---|---:|---:|---:|---:|---:|\n'
for name,x in summary.iterrows():table+=f'| {name} | {x.gate:.2f} | {100*x.PS:.2f} | {100*x.ER:.2f} | {100*x.AH:.2f} | {x.utility:.6f} |\n'
bt='| 比较 | 指标 | 差值 (pp) | 95% cluster CI (pp) | 改善/退步 |\n|---|---|---:|---|---|\n'
for x in pairs.itertuples(index=False):bt+=f'| {x.comparison} | {x.metric} | {100*x.delta:+.3f} | [{100*x.ci95_low:+.3f}, {100*x.ci95_high:+.3f}] | {x.improved}/{x.degraded} |\n'
text=f'''# 最小修复的冻结测试：自动训练候选对齐＋soft reliability weighting

## 为什么做这项修复

旧模型在归档候选上训练，直接迁移到大的自动候选池后不足以支撑 K=3 的硬选择。采用一次最小修复：在自动生成的 TRAIN 候选上重建 singleton usefulness 标签，原特征、TFIDF/StandardScaler/LogisticRegression 参数和 seed 完全不变，模型只拟合 TRAIN。

先执行 train/val pilot，并独立重算 75,237 条训练标签与 1,673 条验证路径。只有“保留 proposal Top3，只更新 confidence 加权”通过预定验证门槛；新的硬选择仍未通过，没有进入测试。详见 ../stage2_training_alignment_pilot/RESULTS_CN.md。

## 本轮冻结规则

- 不再训练或调模型；冻结验证通过的 checkpoint、原 Stage I proposal Top3、图、端点和搜索器。
- 比较 Equal、Original Learned、Aligned Learned。每种 weighting 都在同一 239 条验证查询上用相同 11 个常数 gate 网格独立选择，公平控制 gate 调参预算；另报告全部固定 g=.3 结果。
- 不使用 greedy、type bonus、adaptive gate、Safety Gate 或 Pareto。此版本保留 retrieval-aware reliability weighting，放弃当前无证据的硬选择和 query-specific gate 性能主张；不是仅修改措辞继续声称所有旧组件有效。
- 验证选择的常数：{json.dumps(const,ensure_ascii=False)}。
- 模型、协议、验证参数均锁定后，执行一次全部 248 条测试查询。测试集此前已多次查看，所以仍属于补充评估，不能称新的独立确认。保留全部结果，不再根据这次测试增加参数或切换模型。
- 背景图仍是原传导式聚合图，包含测试机制边；新训练标签属于明确的新操作化，不等同于恢复旧 label writer。

## 全部测试结果

Fixed0.3 是统一固定常数；ValBest 是各 weighting 自己在相同验证网格中选出的常数，非测试最优。

{table}
## 配对增量

5000 次 rid-cluster bootstrap，seed=20260914；逐比较 95% 区间，未作多重比较校正。utility 差也乘 100 展示，不能混称为 ER 百分点。

{bt}
## 自动测试池 usefulness 判别

全部 {rank['n']} 条自动测试候选，按统一 singleton(confidence=1,g=.3) 相对 Graph Only 的 utility 差重算评估标签；positive rate={100*rank['positive_rate']:.3f}%。只在模型冻结后计算，不参与训练或选择。

| 模型 | AUROC | AUPRC |
|---|---:|---:|
| Original | {rank['metrics']['Original']['AUROC']:.4f} | {rank['metrics']['Original']['AUPRC']:.4f} |
| Aligned | {rank['metrics']['Aligned']['AUROC']:.4f} | {rank['metrics']['Aligned']['AUPRC']:.4f} |

判别指标是描述性比较，没有在此计算其显著性区间。判别改善不等于多 Bridge 选择或完整检索改善；后者必须依据上面的 matched retrieval 和配对区间判断。不能把 AUPRC 提升包装成 greedy 或 gate 的贡献。

## 如何据此决定论文

只有区间和指标实际支持的增量才能写成性能证据。即便新训练改善判别，也不能说旧 greedy 或 query-specific gate 被修好；本方案明确简化了这些不受支持的部分。若新加权相对公平常数基线仍没有统计支持，保留结果并收紧性能主张，停止以调参追求正结果。

## 核验

独立恢复实现重放 {checks} 条路径；重算 {labelchecks} 条测试 usefulness 标签和 {len(testc)} 条模型预测；验证集定参规则及 {len(pairs)} 组配对统计复核通过；冻结模型和前序输出哈希一致。

模型训练/验证开发过程见 ../stage2_training_alignment_pilot/；本目录 protocol.json、selected_constants.json、validation_gate_grid.csv、test_per_query.csv、test_candidate_usefulness.csv、paired_cluster_bootstrap.csv、independent_verification.json 提供完整证据。
'''
(O/'RESULTS_CN.md').write_text(text,encoding='utf-8')
paths=[x for x in O.iterdir() if x.is_file() and x.name!='SHA256SUMS.txt']+[ROOT/'audit_output/evaluate_aligned_weighting.py',Path(__file__)]
(O/'SHA256SUMS.txt').write_text('\n'.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+str(x.relative_to(ROOT)) for x in sorted(paths))+'\n',encoding='utf-8')
print(json.dumps(verification,indent=2));print(summary.to_string());print('Report:',O/'RESULTS_CN.md',flush=True)
