"""Frozen Stage-I subset/confidence; Stage-III constants and reassigned gates.

No retraining, candidate changes, selector changes, or adaptive-gate parameter tuning.
"""
from pathlib import Path
import hashlib,json,math,sys,time,zipfile
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'package/iclr2027_review_package'
I=ROOT/'audit_output/experiment1_recovered_proposer'
J=ROOT/'audit_output/experiment2_stage2_selection'
O=ROOT/'audit_output/experiment3_stage3_gate'
O.mkdir(exist_ok=True)
assert not (O/'per_query.csv').exists(),'Refuse to overwrite completed controls'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'))
import dmdb_retrievers as r
START=time.perf_counter()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
def log(s):print(s,flush=True)
for folder in [I,J]:assert json.loads((folder/'independent_verification.json').read_text())['passed']
locked={str(p.relative_to(ROOT)):sha(p) for folder in [I,J] for p in folder.iterdir() if p.is_file()}
sources=[R/'methods/dmdb_retrievers.py',R/'paper_checks/parameter_sensitivity/dmdb_parameter_sensitivity.py',R/'data/raw/drugmechdb/indication_paths.json',R/'data/processed/drugmechdb/benchmark_manifest.csv']
protocol={
 'status':'supplementary evaluation on previously inspected test data, not fresh independent confirmation',
 'locked_inputs':'all StageI and StageII output files hashed; StageI proposal Top3/confidence and recomputed gate reused without edits',
 'subset':'StageI proposal-score Top3, NOT selected using StageII test results',
 'weighting':'same frozen learned confidence in all guidance arms; Graph Only gate=0',
 'adaptive_gate':'original g=0.5*sqrt(p), same saved predictions; no tuning or Safety Gate',
 'gate_grid':[float(x) for x in np.round(np.arange(0,.501,.05),2)],
 'validation_selection':'.7 PS+.3 ER, average across 239 validation task-queries; round to 12 decimals, choose smaller constant gate on ties',
 'controls':['Graph Only','Fixed 0.3','Adaptive Full','Validation-best constant','Validation-mean constant','Test-mean constant (diagnostic)'],
 'means':'mean of saved original adaptive strengths on respective split; test mean is nondeployable diagnostic',
 'shuffle':{'global_repetitions':500,'within_task_repetitions':500,'seed_per_rep':'20261108+rep, same RNG initialized independently for each null family','global':'permute gate donor indices across all 248 test queries','within_task':'permute within each task in alphabetical task order, leaving each task gate distribution unchanged','donors':'store exact integer index matrices, no hash()-based randomness'},
 'search':{'beam':2,'max_hops':8,'node_budget':14,'edge_budget':20,'adjacency':'unchanged original'},
 'statistics':{'metrics':['PS','ER','AH','utility'],'utility':'.7 PS+.3 ER','bootstrap':5000,'bootstrap_seed':20260914,'unit':'rid clusters','shuffle_comparison':'paired difference to per-query average over 500 assignments; randomization p=(1+count(shuffle aggregate >= observed))/(501), one-sided','within_task_is_primary_query_matching_test':True,'multiplicity':'report raw p and Holm-adjusted p across both null families and all four metrics (8 tests); pointwise bootstrap CIs not multiplicity adjusted'},
 'negative_transfer':'per-query PS loss/ER loss versus Graph Only; descriptive counts, no no-harm guarantee',
 'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in sources},'locked_input_hashes':locked}
save('protocol.json',protocol)
d1=pd.read_csv(I/'per_query.csv');gm=pd.read_csv(I/'recomputed_gates.csv')
man=r.manifest[r.manifest.split.isin(['val','test'])]
rows=list(man.itertuples(index=False));test=[x for x in rows if x.split=='test'];val=[x for x in rows if x.split=='val']
assert (len(val),len(test))==(239,248)
base={(x.task,x.rid):x for x in d1[d1.method=='Utility Fixed'].itertuples(index=False)}
full={(x.task,x.rid):x for x in d1[d1.method=='Full'].itertuples(index=False)}
graph={(x.task,x.rid):x for x in d1[d1.method=='Graph Only'].itertuples(index=False)}
gates={(x.task,x.rid):float(x.gate) for x in gm.itertuples(index=False)}
conf={key:json.loads(x.selected_confidences) for key,x in base.items()}
assert len(conf)==487 and len(gates)==487
test_gates=np.array([gates[(x.task,x.rid)] for x in test])
val_mean=float(np.mean([gates[(x.task,x.rid)] for x in val]));test_mean=float(test_gates.mean())
save('query_index.json',[dict(index=i,task=x.task,rid=x.rid) for i,x in enumerate(test)])
# Freeze all permutations before executing validation or test controls.
donors_global=[];donors_task=[];task_groups={task:np.array([i for i,x in enumerate(test) if x.task==task]) for task in sorted({x.task for x in test})}
for rep in range(500):
    donors_global.append(np.random.default_rng(20261108+rep).permutation(len(test)))
    rng=np.random.default_rng(20261108+rep);indices=np.arange(len(test))
    for task,ix in task_groups.items():indices[ix]=rng.permutation(ix)
    donors_task.append(indices)
donors_global=np.asarray(donors_global);donors_task=np.asarray(donors_task)
np.savez_compressed(O/'shuffle_donor_indices.npz',global_indices=donors_global,within_task_indices=donors_task)
donor_hash=sha(O/'shuffle_donor_indices.npz')

cache={};cache_records=[]
def evaluate(row,gate):
    key=(row.task,row.rid,float(gate))
    if key not in cache:
        z=r.search(row.source,row.target,conf[(row.task,row.rid)],float(gate));gold=set(r.gold[row.rid])
        assert z['expanded_edges']<=20 and z['visited_nodes']<=14
        for u,v,rel in z['edges']:assert any(vv.get('relation')==rel for vv in r.G.get_edge_data(u,v).values())
        ps=float(z['found']);er=len(set(z['edges'])&gold)/max(1,len(gold));ah=float(str(row.answer) in z['nodes'])
        record=dict(cache_id=len(cache_records),task=row.task,rid=row.rid,split=row.split,gate=float(gate),PS=ps,ER=er,AH=ah,utility=.7*ps+.3*er,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges'])
        cache[key]=record;cache_records.append(record)
    return cache[key]

grid=[];grid_detail=[]
for gate in protocol['gate_grid']:
    rr=[evaluate(row,gate) for row in val]
    grid_detail.extend(dict(gate=gate,task=x['task'],rid=x['rid'],cache_id=x['cache_id'],**{m:x[m] for m in ['PS','ER','AH','utility']}) for x in rr)
    means={m:float(np.mean([x[m] for x in rr])) for m in ['PS','ER','AH','utility']}
    grid.append(dict(gate=gate,utility_tie_key=round(means['utility'],12),**means))
grid=pd.DataFrame(grid);grid.to_csv(O/'validation_gate_grid.csv',index=False);pd.DataFrame(grid_detail).to_csv(O/'validation_gate_grid_per_query.csv',index=False)
best=float(grid.sort_values(['utility_tie_key','gate'],ascending=[False,True],kind='stable').iloc[0].gate)
save('selected_constants.json',{'validation_best':best,'validation_mean':val_mean,'test_mean_diagnostic':test_mean})
log(f'Validation constants frozen: best={best}, val_mean={val_mean:.12g}, test_mean diagnostic={test_mean:.12g}')

records=[];oldmatches=0
for row in rows:
    key=(row.task,row.rid)
    variants=[('Graph Only',0.),('Fixed 0.3',.3),('Adaptive Full',gates[key]),('Validation-best constant',best),('Validation-mean constant',val_mean),('Test-mean constant (diagnostic)',test_mean)]
    for method,gate in variants:
        out=evaluate(row,gate)
        if method in ['Graph Only','Fixed 0.3','Adaptive Full']:
            old={'Graph Only':graph,'Fixed 0.3':base,'Adaptive Full':full}[method][key]
            assert np.allclose([out[m] for m in ['PS','ER','AH']],[getattr(old,m) for m in ['PS','ER','AH']],rtol=0,atol=1e-14)
            assert json.loads(out['nodes'])==json.loads(old.nodes) and json.loads(out['edges'])==json.loads(old.edges)
            oldmatches+=1
        records.append(dict(method=method,**out))
controls=pd.DataFrame(records);controls.to_csv(O/'per_query.csv',index=False)
metrics=['PS','ER','AH','utility','gate']
controls.groupby(['split','method'])[metrics].mean().to_csv(O/'summary.csv')
controls.groupby(['split','task','method'])[metrics].agg(['mean','size']).to_csv(O/'by_task.csv')
log(f'Original StageI paths reproduced: {oldmatches}/1461')

# CSV contains links to a unique path cache, avoiding copying identical paths 248,000 times.
shuffle_arrays={};shuffle_summary=[];shuffle_means=[]
for family,donors in [('Global',donors_global),('Within task',donors_task)]:
    values=np.empty((500,len(test),4));outrows=[]
    for rep,indices in enumerate(donors):
        for i,(row,donor) in enumerate(zip(test,indices)):
            out=evaluate(row,float(test_gates[donor]))
            values[rep,i]=[out[m] for m in ['PS','ER','AH','utility']]
            outrows.append(dict(family=family,rep=rep,query_index=i,task=row.task,rid=row.rid,donor_index=int(donor),cache_id=out['cache_id'],gate=out['gate'],PS=out['PS'],ER=out['ER'],AH=out['AH'],utility=out['utility']))
        if (rep+1)%100==0:log(f'{family} shuffle {rep+1}/500; unique path executions={len(cache_records)}')
        means=values[rep].mean(axis=0);shuffle_summary.append(dict(family=family,rep=rep,**dict(zip(['PS','ER','AH','utility'],map(float,means)))))
    pd.DataFrame(outrows).to_csv(O/('shuffle_global_per_query.csv.gz' if family=='Global' else 'shuffle_within_task_per_query.csv.gz'),index=False,compression='gzip')
    shuffle_arrays[family]=values
    for i,row in enumerate(test):shuffle_means.append(dict(family=family,task=row.task,rid=row.rid,**dict(zip(['PS','ER','AH','utility'],map(float,values[:,i].mean(axis=0))))))
pd.DataFrame(shuffle_summary).to_csv(O/'shuffle_summary.csv',index=False)
pd.DataFrame(shuffle_means).to_csv(O/'shuffle_mean_per_query.csv',index=False)
pd.DataFrame(cache_records).to_csv(O/'search_cache.csv.gz',index=False,compression='gzip')

# Paired mechanism-cluster bootstrap, same draws across comparisons.
tt=controls[controls.split=='test'];actual=tt[tt.method=='Adaptive Full'].set_index(['task','rid'])
keys=pd.MultiIndex.from_tuples([(x.task,x.rid) for x in test],names=['task','rid'])
actual=actual.reindex(keys);clusters=sorted({x.rid for x in test});rng=np.random.default_rng(20260914)
draws=rng.integers(0,len(clusters),size=(5000,len(clusters)))
pairs=[];diff_rows=[]
def pair(name,other):
    other=other.reindex(keys)
    for metric in ['PS','ER','AH','utility']:
        delta=actual[metric]-other[metric]
        cl=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters)
        boots=cl['sum'].to_numpy()[draws].sum(axis=1)/cl['size'].to_numpy()[draws].sum(axis=1)
        lo,hi=np.quantile(boots,[.025,.975])
        pairs.append(dict(comparison='Adaptive Full - '+name,metric=metric,n=len(delta),rid_clusters=len(clusters),delta=float(delta.mean()),ci95_low=float(lo),ci95_high=float(hi),improved=int((delta>1e-12).sum()),degraded=int((delta< -1e-12).sum()),unchanged=int((abs(delta)<=1e-12).sum())))
        for (task,rid),value in delta.items():diff_rows.append(dict(comparator=name,metric=metric,task=task,rid=rid,delta=value))
for method in protocol['controls']:
    if method=='Adaptive Full':continue
    pair(method,tt[tt.method==method].set_index(['task','rid']))
randomization=[]
for family,values in shuffle_arrays.items():
    means=pd.DataFrame(values.mean(axis=0),index=keys,columns=['PS','ER','AH','utility'])
    pair(family+' shuffled mean',means)
    for j,metric in enumerate(['PS','ER','AH','utility']):
        observed=float(actual[metric].mean());null=values[:,:,j].mean(axis=1)
        randomization.append(dict(family=family,metric=metric,observed=observed,shuffle_mean=float(null.mean()),shuffle_ci95_low=float(np.quantile(null,.025)),shuffle_ci95_high=float(np.quantile(null,.975)),delta=observed-float(null.mean()),p_one_sided=(1+int((null>=observed-1e-12).sum()))/501))
rr=pd.DataFrame(randomization);ordered=np.argsort(rr.p_one_sided.to_numpy(),kind='stable');adj=np.empty(len(rr));last=0.
for rank,index in enumerate(ordered):
    last=max(last,min(1.,(len(rr)-rank)*float(rr.iloc[index].p_one_sided)));adj[index]=last
rr['p_holm_8_tests']=adj;rr.to_csv(O/'shuffle_randomization_tests.csv',index=False)
pd.DataFrame(pairs).to_csv(O/'paired_cluster_bootstrap.csv',index=False)
pd.DataFrame(diff_rows).to_csv(O/'paired_query_differences.csv',index=False)

# Negative transfer is descriptive, measured versus the same Graph Only query outcomes.
harm=[]
go=tt[tt.method=='Graph Only'].set_index(['task','rid'])
for task in ['All']+sorted({x.task for x in test}):
    for method in protocol['controls']:
        aa=tt[tt.method==method].set_index(['task','rid']);bb=go.reindex(aa.index)
        if task!='All':aa=aa.loc[aa.index.get_level_values('task')==task];bb=bb.reindex(aa.index)
        harm.append(dict(task=task,method=method,n=len(aa),ps_harmed=int(((bb.PS>0)&(aa.PS==0)).sum()),ps_helped=int(((bb.PS==0)&(aa.PS>0)).sum()),er_harmed=int((aa.ER<bb.ER-1e-12).sum()),er_helped=int((aa.ER>bb.ER+1e-12).sum())))
pd.DataFrame(harm).to_csv(O/'negative_transfer.csv',index=False)
changed=[name for name,h in locked.items() if sha(ROOT/name)!=h];assert not changed
assert sha(O/'shuffle_donor_indices.npz')==donor_hash
zipchecks=0
with zipfile.ZipFile(ROOT/'iclr2027_review_package_v3.zip') as z:
    for info in z.infolist():
        if info.is_dir():continue
        assert (ROOT/'package'/info.filename).read_bytes()==z.read(info.filename);zipchecks+=1
save('verification.json',{'complete':True,'queries':{'validation':239,'test':248},'controls_per_split':6,'control_rows':len(controls),'shuffle_rows':500*248*2,'unique_search_executions':len(cache_records),'stage1_exact_path_matches':oldmatches,'locked_files_unchanged':len(locked),'changed_locked_files':changed,'original_zip_members_unchanged':zipchecks,'permutation_hash':donor_hash,'validation_best_gate':best,'elapsed_seconds':time.perf_counter()-START})
log(tt.groupby('method')[metrics].mean().to_string());log(rr.to_string(index=False));log('COMPLETE: '+str(O))
