"""Explicit reconstruction, NOT authenticated historical source.

Only the paper's c-mu*Red+beta*TypeBonus greedy rule is implemented.
Graph, scores and parameters are supplied by the caller; no reference labels.
"""
def select(pool, scores, neighbors, types, mu, beta, k=3):
    left = set(pool)
    chosen, trace = [], []
    while left and len(chosen) < k:
        used_types = {types[n] for n in chosen}
        parts = {}
        for node in left:
            redundancy = max((len(neighbors[node] & neighbors[h]) /
                              max(1, len(neighbors[node] | neighbors[h]))
                              for h in chosen), default=0.0)
            bonus = float(types[node] not in used_types)
            parts[node] = (redundancy, bonus,
                           scores[node] - mu * redundancy + beta * bonus)
        node = min(left, key=lambda n: (-parts[n][2], n))
        redundancy, bonus, gain = parts[node]
        trace.append(dict(node=node, confidence=scores[node], red=redundancy,
                          type_bonus=bonus, gain=gain))
        chosen.append(node)
        left.remove(node)
    return chosen, trace
