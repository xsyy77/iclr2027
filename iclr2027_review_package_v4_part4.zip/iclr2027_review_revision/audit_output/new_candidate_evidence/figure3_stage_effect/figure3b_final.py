import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import Patch

# ============================================================
# Figure 3(b): Per-Query Stage Effects on Retrieval Utility
# Real DrugMechDB held-out queries (n = 248)
# ============================================================

CSV_PATH = "drugmechdb_real_e2e_provisional_detailed.csv"

# ------------------------------------------------------------
# 1. Load real data
# ------------------------------------------------------------
df = pd.read_csv(CSV_PATH)

# Use task + rid together, because rid alone is not guaranteed unique
df["query_id"] = df["task"].astype(str) + "||" + df["rid"].astype(str)

# Real retrieval utility
df["utility"] = 0.7 * df["path_success"] + 0.3 * df["edge_recall"]

pivot = df.pivot(index="query_id", columns="method", values="utility")

required_methods = [
    "Graph Only",
    "Semantic Selection + Fixed",
    "Utility Selection + Fixed",
    "Full",
]

pivot = pivot.dropna(subset=required_methods)

if len(pivot) != 248:
    raise ValueError(f"Expected 248 matched held-out queries, but found {len(pivot)}.")

# ------------------------------------------------------------
# 2. Real per-query deltas
# ------------------------------------------------------------
transitions = [
    {
        "title": "Semantic+Fixed\n− Graph Only",
        "short": "Semantic+Fixed − Graph Only",
        "delta": (
            pivot["Semantic Selection + Fixed"] - pivot["Graph Only"]
        ).to_numpy(),
    },
    {
        "title": "Utility+Fixed\n− Semantic+Fixed",
        "short": "Utility+Fixed − Semantic+Fixed",
        "delta": (
            pivot["Utility Selection + Fixed"] - pivot["Semantic Selection + Fixed"]
        ).to_numpy(),
    },
    {
        "title": "Full\n− Utility+Fixed",
        "short": "Full − Utility+Fixed",
        "delta": (
            pivot["Full"] - pivot["Utility Selection + Fixed"]
        ).to_numpy(),
    },
]

# ------------------------------------------------------------
# 3. Real summary stats
# ------------------------------------------------------------
def summarize(delta):
    eps = 1e-12
    n = len(delta)

    harmed = np.sum(delta < -eps)
    unchanged = np.sum(np.abs(delta) <= eps)
    improved = np.sum(delta > eps)

    return {
        "n": n,
        "harmed_n": harmed,
        "unchanged_n": unchanged,
        "improved_n": improved,
        "harmed_pct": harmed / n * 100,
        "unchanged_pct": unchanged / n * 100,
        "improved_pct": improved / n * 100,
        "mean": np.mean(delta),
    }

# ------------------------------------------------------------
# 4. Accuracy check
# If data mismatch, stop immediately.
# ------------------------------------------------------------
expected = {
    "Semantic+Fixed − Graph Only": {
        "improved_pct": 16.53,
        "unchanged_pct": 80.65,
        "harmed_pct": 2.82,
        "mean": 0.06385,
    },
    "Utility+Fixed − Semantic+Fixed": {
        "improved_pct": 11.29,
        "unchanged_pct": 77.82,
        "harmed_pct": 10.89,
        "mean": -0.01071,
    },
    "Full − Utility+Fixed": {
        "improved_pct": 0.40,
        "unchanged_pct": 99.19,
        "harmed_pct": 0.40,
        "mean": -0.00302,
    },
}

for item in transitions:
    s = summarize(item["delta"])
    e = expected[item["short"]]

    if abs(s["improved_pct"] - e["improved_pct"]) > 0.02:
        raise ValueError(f"{item['short']} improved_pct mismatch: {s['improved_pct']:.5f}")
    if abs(s["unchanged_pct"] - e["unchanged_pct"]) > 0.02:
        raise ValueError(f"{item['short']} unchanged_pct mismatch: {s['unchanged_pct']:.5f}")
    if abs(s["harmed_pct"] - e["harmed_pct"]) > 0.02:
        raise ValueError(f"{item['short']} harmed_pct mismatch: {s['harmed_pct']:.5f}")
    if abs(s["mean"] - e["mean"]) > 0.0002:
        raise ValueError(f"{item['short']} mean ΔU mismatch: {s['mean']:.5f}")

    print("\n" + item["short"])
    print(f"Improved:  {s['improved_n']} ({s['improved_pct']:.2f}%)")
    print(f"Unchanged: {s['unchanged_n']} ({s['unchanged_pct']:.2f}%)")
    print(f"Harmed:    {s['harmed_n']} ({s['harmed_pct']:.2f}%)")
    print(f"Mean ΔU:   {s['mean']:+.5f}")

# ------------------------------------------------------------
# 5. Style
# ------------------------------------------------------------
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# Pale, same-family style
NEG_COLOR = "#B8C6D9"       # harmed / decreased
ZERO_COLOR = "#EEDFCF"      # unchanged
POS_COLOR = "#E8AFC0"       # improved / increased

AXIS_COLOR = "#444444"
SEP_COLOR = "#DDDDDD"

# ------------------------------------------------------------
# 6. Figure layout
# ------------------------------------------------------------
fig = plt.figure(figsize=(9.2, 3.9))
gs = GridSpec(
    nrows=2,
    ncols=3,
    height_ratios=[5.2, 1.9],
    wspace=0.45,
    hspace=0.32,
)

top_axes = []
bottom_axes = []

for j in range(3):
    top_axes.append(fig.add_subplot(gs[0, j]))
    bottom_axes.append(fig.add_subplot(gs[1, j]))

# ------------------------------------------------------------
# 7. Plot each panel
# ------------------------------------------------------------
ymin, ymax = -0.45, 0.50

for idx, item in enumerate(transitions):
    delta = item["delta"].copy()
    stats = summarize(delta)

    # sort ascending
    delta_sorted = np.sort(delta)
    x = np.arange(1, len(delta_sorted) + 1)

    # color by sign
    eps = 1e-12
    bar_colors = []
    for v in delta_sorted:
        if v < -eps:
            bar_colors.append(NEG_COLOR)
        elif v > eps:
            bar_colors.append(POS_COLOR)
        else:
            bar_colors.append(ZERO_COLOR)

    ax = top_axes[idx]

    ax.bar(
        x,
        delta_sorted,
        color=bar_colors,
        width=0.95,
        linewidth=0,
    )

    ax.axhline(0, color="#999999", linewidth=0.7)
    ax.set_xlim(1, len(delta_sorted))
    ax.set_ylim(ymin, ymax)

    ax.set_title(item["title"], fontweight="bold", pad=10)

    ax.set_ylabel(r"$\Delta U$")
    ax.set_xlabel("Queries (sorted)", labelpad=4)

    ax.set_xticks([1, len(delta_sorted)])
    ax.set_xticklabels(["1", str(len(delta_sorted))])

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(AXIS_COLOR)
    ax.spines["bottom"].set_color(AXIS_COLOR)

    ax.tick_params(axis="both", colors=AXIS_COLOR, width=0.8)

    # subtle separator between panels
    if idx < 2:
        ax.spines["right"].set_visible(True)
        ax.spines["right"].set_color(SEP_COLOR)
        ax.spines["right"].set_linewidth(1.0)

    # ---- bottom composition bar + text ----
    bax = bottom_axes[idx]
    bax.set_xlim(0, 100)
    bax.set_ylim(0, 1)
    bax.axis("off")

    harmed = stats["harmed_pct"]
    unchanged = stats["unchanged_pct"]
    improved = stats["improved_pct"]

    # stacked proportion bar
    ybar = 0.70
    hbar = 0.18
    bax.barh(ybar, harmed, left=0, height=hbar, color=NEG_COLOR, edgecolor="none")
    bax.barh(ybar, unchanged, left=harmed, height=hbar, color=ZERO_COLOR, edgecolor="none")
    bax.barh(ybar, improved, left=harmed + unchanged, height=hbar, color=POS_COLOR, edgecolor="none")

    # percentage labels underneath
    bax.text(harmed / 2, 0.28, f"{harmed:.2f}%", ha="center", va="center", color=AXIS_COLOR)
    bax.text(harmed + unchanged / 2, 0.28, f"{unchanged:.2f}%", ha="center", va="center", color=AXIS_COLOR)
    bax.text(harmed + unchanged + improved / 2, 0.28, f"{improved:.2f}%", ha="center", va="center", color=AXIS_COLOR)

    # mean text
    bax.text(
        50,
        -0.12,
        rf"Mean $\Delta U$: {stats['mean']:+.5f}",
        ha="center",
        va="center",
        fontsize=10,
        color=AXIS_COLOR,
    )

    # subtle separator on bottom row too
    if idx < 2:
        bax.plot([100, 100], [0.02, 0.98], color=SEP_COLOR, linewidth=1.0, clip_on=False)

# ------------------------------------------------------------
# 8. Legend
# ------------------------------------------------------------
legend_handles = [
    Patch(facecolor=NEG_COLOR, edgecolor="none", label="Decreased utility"),
    Patch(facecolor=ZERO_COLOR, edgecolor="none", label="Unchanged"),
    Patch(facecolor=POS_COLOR, edgecolor="none", label="Increased utility"),
]

fig.legend(
    handles=legend_handles,
    loc="upper center",
    bbox_to_anchor=(0.5, 1.05),
    ncol=3,
    frameon=False,
    columnspacing=1.8,
    handlelength=1.3,
)

# ------------------------------------------------------------
# 9. Export
# ------------------------------------------------------------
plt.savefig("figure3b_paper_style.pdf", bbox_inches="tight", dpi=600)
plt.savefig("figure3b_paper_style.png", bbox_inches="tight", dpi=600)
plt.show()