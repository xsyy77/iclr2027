import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

# ============================================================
# Figure 3 — REAL candidate-count distributions
# Source: proposal_availability_by_query.csv
# Uses all held-out queries
# x-axis is log10(count + 1), but tick labels are shown in raw count
# ============================================================

# ---------- file path ----------
CSV_PATH = "proposal_availability_by_query.csv"

# ---------- read csv ----------
df = pd.read_csv(CSV_PATH)

# ---------- rename for plotting ----------
task_order = ["Gene", "Metabolite", "Process"]
method_map = {
    "Cellular": "n_cellular",
    "Molecular": "n_molecular",
    "System": "n_system",
    "Multi-view": "n_union"
}
plot_order = ["Multi-view", "System", "Molecular", "Cellular"]

# ---------- colors ----------
COLORS = {
    "Multi-view": "#078B8C",   # teal
    "System": "#1477C9",       # blue
    "Molecular": "#C85A0A",    # orange
    "Cellular": "#D82268"      # magenta
}

# ---------- plotting style ----------
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 11,
    "axes.titlesize": 18,
    "axes.labelsize": 14,
    "xtick.labelsize": 10.5,
    "ytick.labelsize": 10.5,
    "axes.linewidth": 0.8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# ---------- transformed x-axis ----------
# raw count max in your data is 442, so use log10(443)
xmin = 0.0
xmax = np.log10(443)
bins = np.linspace(xmin, xmax, 25)
binw = bins[1] - bins[0]
xgrid = np.linspace(xmin, xmax, 600)

# ---------- compute common y-limit ----------
maxy = 0
for task in task_order:
    df_task = df[df["task"] == task]
    for method, col in method_map.items():
        raw = df_task[col].astype(float).to_numpy()
        z = np.log10(raw + 1.0)

        counts, _ = np.histogram(z, bins=bins)
        maxy = max(maxy, counts.max())

        if len(np.unique(z)) > 1:
            kde = gaussian_kde(z, bw_method=0.33)
            y = kde(xgrid) * len(z) * binw
            maxy = max(maxy, y.max())

ylim = int(np.ceil(maxy / 5) * 5)

# ---------- create figure ----------
fig, axes = plt.subplots(1, 3, figsize=(15.8, 5.7), sharey=True)

for ax, task in zip(axes, task_order):
    df_task = df[df["task"] == task]

    # histogram + kde
    for method in ["Cellular", "Molecular", "System", "Multi-view"]:
        col = method_map[method]
        raw = df_task[col].astype(float).to_numpy()
        z = np.log10(raw + 1.0)
        color = COLORS[method]

        ax.hist(
            z,
            bins=bins,
            histtype="bar",
            facecolor="none",
            edgecolor=color,
            linewidth=0.8,
            alpha=0.28
        )

        if len(np.unique(z)) > 1:
            kde = gaussian_kde(z, bw_method=0.33)
            y = kde(xgrid) * len(z) * binw
            ax.plot(xgrid, y, color=color, linewidth=2.25)

    # top-left statistics text
    y0 = ylim - 0.9
    dy = ylim * 0.087

    for i, method in enumerate(plot_order):
        col = method_map[method]
        raw = df_task[col].astype(float).to_numpy()

        mean_val = raw.mean()
        availability = (raw >= 3).mean() * 100

        ax.text(
            0.04,
            y0 - i * dy,
            f"{method}  {mean_val:.1f}  ({availability:.1f}% ≥3)",
            color=COLORS[method],
            fontsize=11.6,
            va="top"
        )

    # titles and axes
    ax.set_title(task, pad=7)
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(0, ylim)
    ax.set_xlabel("Candidate count per query")
    ax.set_ylabel("Frequency")

    # show raw-count ticks on log axis
    raw_ticks = [0, 1, 3, 10, 30, 100, 300]
    ax.set_xticks([np.log10(v + 1) for v in raw_ticks])
    ax.set_xticklabels([str(v) for v in raw_ticks])

    ax.tick_params(axis="both", which="both", direction="in", top=True, right=True, length=4)
    ax.minorticks_on()
    ax.tick_params(which="minor", length=2)

    # sample size
    ax.text(
        0.98, 0.98,
        f"n={len(df_task)}",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9.3,
        color="#555555"
    )

# ---------- layout and save ----------
fig.subplots_adjust(left=0.06, right=0.99, top=0.90, bottom=0.15, wspace=0.16)

plt.savefig("figure3_candidate_count_real.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.savefig("figure3_candidate_count_real.pdf", bbox_inches="tight", facecolor="white")

plt.show()