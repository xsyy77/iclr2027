# 新候选证据包核验：Figure 3 生成链取得实质恢复

## 已经证实

输入是用户新提供的 dmdb_candidate_figure3_evidence_files.zip，SHA256 为 4a713e5f0ebff0e3de6c3fc1bde041385e5a805847ed3ddd9dc89299601d54fb。包内清单的 5 个文件哈希全部通过校验。README 的来源描述作为待核实陈述，而非证明。

使用提供的 run_dmdb_proposal_samek.py 函数、提交 v3 的原始图谱及新 availability CSV 的 task/rid 列表，实际重新生成候选。原脚本引用的 dmdb_graph_only_rerun.csv 不在包内，因此查询清单从 availability CSV 提供；路径适配和这个输入替代已明确记录。

- 248 条查询的 source、target 和四类候选计数全部逐条一致。
- 生成 14,041 条 query–candidate 实体记录，保存于 audit/replayed_candidate_entities.csv。
- 新 availability CSV 与提交版内嵌 RAW 的 3 个任务 × 4 种视图，共 12 组数组，全部按原顺序逐项一致。
- 聚合图谱构造后，删除 gold、原始 paths，以及每条记录中除 drug/disease 端点及名称外的字段，重新生成的 248 组候选及分数全部一致。

因此，现在有证据说明：提供的脚本能够从聚合图谱与已知查询端点复现 Figure 3 的候选计数，并产出可审计实体明细；不能再笼统说 Figure 3 只有无法复现的计数。该证据仍不能唯一证明这份脚本就是当时执行的历史文件。聚合图谱含有参考机制边，这也不是图谱独立的无泄漏证明。

## 对应 Table 1 的程度

重建池包含 Table 1 Clean 692 条候选中的 668 条；225/248 条查询的完整 Clean 集合包含在重建池中，只有 6/248 条查询的集合完全相同。故这是具体的上游候选线索，但尚未证明“这个池经过哪个选择器产生了全部 692 条 Clean 输入”。新包也未包含该选择器或原始 marginal-training-samples 写入程序。

## 端点差异定位

新脚本从原始记录 drug_mesh 直接取 source，而提交 manifest 在 8 条 task–query 记录上使用不同的源 ID，其中包括 None、多 Mesh 值或不同 ID 与 DB:DBxxxxx 的差异。

旧 provisional 结果的 6 行选择输出包含重建池以外的节点，集中于 DB01285_MESH_D013262_1 的 Gene 与 Process 两条查询、三个非 Graph 方法。仅在诊断副本中将 source 改为提交 manifest 的源节点后，这 6 行所选实体均落入候选池。它支持端点处理差异的解释，但不证明旧结果的真实执行路径，也不能把修正池仍当作原 Figure 3 完全相同的池。未修改任何提交数据或提供的原脚本。

## provisional 结果身份

新包中逐查询结果汇总得到：

| 方法 | PS (%) | ER (%) | AH (%) | 平均 gate |
|---|---:|---:|---:|---:|
| Graph Only | 27.02 | 33.97 | 70.56 | 0 |
| Semantic Selection + Fixed | 33.87 | 39.26 | 73.39 | 0.50 |
| Utility Selection + Fixed | 32.66 | 38.51 | 72.18 | 0.35 |
| Full | 32.26 | 38.44 | 72.58 | 0.37262 |

这些数字对应先前工作簿中的 provisional 结果，而不是 Table 1 的 Full ER 59.46%，也不是 Table 4 的 Full ER 38.05%。其输入包含 selected_nodes，能帮助追溯，但没有完整生成脚本与所选节点置信度，不能仅据此宣称完整运行复现。Full 在这套结果里也没有优于 Semantic Selection + Fixed，不能将它当作学习模块全面有效的证据。

## 可直接加强的回复段落

We have now located additional candidate-generation artifacts and checked them against the submitted Figure 3 data. Using the supplied graph-linked proposal code and the submitted graph, we reproduce all four candidate counts for each of the 248 queries. All 12 task-by-view count arrays match the submitted figure in their original order, and the replay produces 14,041 query–candidate records. Removing reference-mechanism records from the proposal runtime, while retaining the aggregate graph and known endpoint metadata, leaves the candidates unchanged. This establishes a reproducible construction for the Figure 3 candidate-count analysis. We distinguish this evidence from the still-unresolved mapping to the archived Table 1 Clean candidate inputs and do not claim that count agreement alone recovers the historical end-to-end pipeline.

## 后续只追踪两个具体连接

1. 端点归一化及候选筛选记录：解释重建池到全部 692 条 Clean 候选的对应，尤其尚不在池内的候选。不要以数量相近替代逐实体对应。
2. 旧 provisional 的 selected_nodes 生成代码，以及真正写出 marginal-training-samples 的程序。这些实际调用记录比另造冗余公式更有价值。

核验入口：audit_evidence.py。完整逐查询比较、端点诊断、原图数组比较与哈希记录均保存在 audit/。
