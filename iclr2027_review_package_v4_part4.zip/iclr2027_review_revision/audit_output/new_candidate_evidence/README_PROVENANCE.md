# File provenance

These five files are copies of locally found materials, not a recovered complete historical Table 1 pipeline.

- figure3/: per-query candidate-count input and plotting script.
- candidate_generation/: local same-K experiment script that writes a same-schema availability CSV. Its identity as the exact historical Figure 3 generator is unverified. The script has hard-coded /mnt/data/dmdb_samek paths.
- figure3_stage_effect/: provisional per-query stage-effect input and plotting script. Its Full Path Success is 32.26%, different from the manuscript Table 1 value of 39.52%; do not use as Table 1 provenance.
- The original DrugMechDB redundancy-aware K=3 selector with Red(h,H) and mu was not found and is not included here.

SHA256SUMS.txt records hashes of the original local files copied into this archive.
