#!/usr/bin/env python3
import json, math, re
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
import pandas as pd
import networkx as nx

ROOT=Path('/mnt/data/dmdb_samek')
PATHS=ROOT/'indication_paths.json'
TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'
OUTDIR=ROOT/'proposal_samek_results'
OUTDIR.mkdir(exist_ok=True)
SEED=20260914
FIXED_GATE=0.30
BEAM=2; MAX_HOPS=8; NODE_BUDGET=14; EDGE_BUDGET=20
KS=[1,2,3]
BOOTSTRAP=5000

VIEW_TYPES={
 'Molecular': {'Protein','ChemicalSubstance','MolecularActivity','GeneFamily'},
 'Cellular': {'Cell','CellularComponent','MacromolecularComplex','GrossAnatomicalStructure'},
 'System': {'BiologicalProcess','Pathway','PhenotypicFeature','OrganismTaxon'},
}
INTENT={
 'Gene':'gene protein molecular mechanism',
 'Metabolite':'metabolite chemical intermediate',
 'Process':'biological process pathway mechanism',
}

paths=json.load(open(PATHS))
test=pd.read_csv(TEST_ROWS)[['task','rid']].drop_duplicates().copy()
test['rid']=test['rid'].astype(str)
rec_by_rid={str(r.get('graph',{}).get('_id','')):r for r in paths}

# Aggregate directed graph: identical graph substrate used in the existing DMDB scripts.
G=nx.MultiDiGraph(); gold={}; NODE_NAME={}; NODE_TYPE={}
for rec in paths:
    rid=str(rec.get('graph',{}).get('_id',''))
    nodes={str(n['id']): {'name':str(n.get('name','')), 'type':str(n.get('label','Unknown'))}
           for n in rec.get('nodes',[])}
    links=[]
    for nid,d in nodes.items():
        NODE_NAME.setdefault(nid,d['name']); NODE_TYPE.setdefault(nid,d['type'])
        if nid not in G: G.add_node(nid,**d)
    for e in rec.get('links',[]):
        u,v,rel=str(e['source']),str(e['target']),str(e.get('key','unknown'))
        G.add_edge(u,v,relation=rel); links.append((u,v,rel))
    if rid: gold[rid]={'nodes':nodes,'links':links}

OUT=defaultdict(list); IN=defaultdict(list)
for u,v,d in G.edges(data=True):
    rel=str(d.get('relation','unknown'))
    if (v,rel) not in OUT[u]: OUT[u].append((v,rel))
    if (u,rel) not in IN[v]: IN[v].append((u,rel))
MAXLOG=max(math.log1p(G.in_degree(n)+G.out_degree(n)) for n in G.nodes) or 1.0

def rel_quality(rel):
    s=rel.lower().replace('_',' ')
    if any(k in s for k in ['causes','prevents','treats','therapeutic']): return 1.00
    if any(k in s for k in ['regulates','activity','abundance','inhibits','stimulates','affects']): return 0.88
    if any(k in s for k in ['participates','produces','has output','capable of','precedes']): return 0.72
    if any(k in s for k in ['occurs in','located in','location of','correlated','associated']): return 0.52
    return 0.62

def local_graph_score(v,rel):
    deg=math.log1p(G.in_degree(v)+G.out_degree(v))/MAXLOG
    return 0.82*rel_quality(rel)+0.18*(1.0-deg)

def bridge_state_score(path_nodes,conf):
    if not conf: return 0.0
    reached=[n for n in path_nodes if n in conf]
    if not reached: return 0.0
    uniq=list(dict.fromkeys(reached)); cov=len(uniq)/max(1,len(conf))
    mean_c=float(np.mean([conf[n] for n in uniq])); cur=conf.get(path_nodes[-1],0.0)
    recent=sum(1 for n in path_nodes[-2:] if n in conf)/2.0
    sat=0.65 if len(uniq)<=1 else (0.85 if len(uniq)==2 else 1.0)
    return min(1.0,max(0.0,(0.45*cov+0.25*mean_c+0.15*cur+0.15*recent)*sat))

def run_search(source,target,conf,g):
    beam_states=[(0.0,(source,),(),())]; generated={source}; expanded=0; best_target=None
    for _ in range(MAX_HOPS):
        nxt=[]
        for _,pn,pr,pg in beam_states:
            u=pn[-1]
            for v,rel in OUT.get(u,[]):
                if expanded>=EDGE_BUDGET: break
                expanded+=1
                if v in pn: continue
                if v not in generated and len(generated)>=NODE_BUDGET: continue
                generated.add(v)
                nn=pn+(v,); rr=pr+(rel,); gg=pg+(local_graph_score(v,rel),)
                gs=float(np.mean(gg)) if gg else 0.0
                bs=bridge_state_score(nn,conf)
                score=(1-g)*gs+g*bs-0.012*len(rr)
                st=(score,nn,rr,gg); nxt.append(st)
                if v==target and (best_target is None or score>best_target[0]): best_target=st
            if expanded>=EDGE_BUDGET: break
        if best_target is not None: break
        if not nxt: break
        nxt.sort(key=lambda x:(x[0],-len(x[1])),reverse=True)
        beam_states=nxt[:BEAM]
    best=best_target if best_target is not None else (max(beam_states,key=lambda x:x[0]) if beam_states else (0,(source,),(),()))
    _,pn,rr,_=best
    edges=[(pn[i],pn[i+1],rr[i]) for i in range(len(rr))]
    return {'nodes':list(pn),'edges':edges,'found':float(bool(pn and pn[-1]==target)),
            'visited_nodes':len(generated),'expanded_edges':expanded}

def tokens(s):
    return set(re.sub(r'[^a-z0-9]+',' ',str(s).lower().replace('_',' ')).split())

def jaccard(a,b):
    A,B=tokens(a),tokens(b)
    return len(A&B)/len(A|B) if A and B else 0.0

def view_of(node):
    typ=NODE_TYPE.get(str(node),'Unknown')
    for view,types in VIEW_TYPES.items():
        if typ in types: return view
    return 'Other'

def local_candidate_universe(source,target,depth=2,cap=600):
    # Inference-time graph context only: forward source neighborhood + reverse target neighborhood.
    # No reference-path membership or candidate-to-target shortest path is used.
    seen={source,target}
    front={source}
    for _ in range(depth):
        nxt=set()
        for u in front:
            for v,_ in OUT.get(u,[]):
                if v not in seen: seen.add(v); nxt.add(v)
                if len(seen)>=cap: break
            if len(seen)>=cap: break
        front=nxt
    front={target}
    for _ in range(depth):
        nxt=set()
        for v in front:
            for u,_ in IN.get(v,[]):
                if u not in seen: seen.add(u); nxt.add(u)
                if len(seen)>=cap: break
            if len(seen)>=cap: break
        front=nxt
    seen.discard(source); seen.discard(target)
    return seen

def proposal_candidates(task,rid):
    rec=rec_by_rid[rid]; gm=rec['graph']
    source=str(gm.get('drug_mesh')); target=str(gm.get('disease_mesh'))
    q=f"How does {gm.get('drug','')} affect {gm.get('disease','')}? {INTENT.get(task,task)}"
    local=local_candidate_universe(source,target)
    source_nei={v for v,_ in OUT.get(source,[])}
    target_pre={u for u,_ in IN.get(target,[])}
    items=[]
    for n in local:
        view=view_of(n)
        if view=='Other': continue
        name=NODE_NAME.get(n,n)
        deg=G.in_degree(n)+G.out_degree(n)
        sem=jaccard(q,name)
        source_adj=float(n in source_nei); target_adj=float(n in target_pre)
        anti=1.0-math.log1p(deg)/MAXLOG
        source_rel=max([rel_quality(rel) for v,rel in OUT.get(source,[]) if v==n] or [0.0])
        target_rel=max([rel_quality(rel) for u,rel in IN.get(target,[]) if u==n] or [0.0])
        # Frozen inference-time proposal score. Gold/reference membership is never a feature.
        pre=0.35*sem+0.20*source_adj+0.20*target_adj+0.10*anti+0.075*source_rel+0.075*target_rel
        items.append({'node':n,'view':view,'pre':pre,'sem_query':sem,
                      'source_adj':source_adj,'target_adj':target_adj,'anti_hub':anti})
    items.sort(key=lambda x:(-x['pre'],x['node']))
    return source,target,q,items

def select(items,variant,k):
    if variant in ('Molecular','Cellular','System'):
        return [x['node'] for x in items if x['view']==variant][:k]
    if variant=='Multi-view':
        # Equal-K multi-view = top K proposals from the union of the three view-conditioned pools.
        return [x['node'] for x in items[:k]]
    raise ValueError(variant)

# Build proposal diagnostics first (no gold used for candidate construction).
proposal_rows=[]
cache={}
for task,rid in test.itertuples(index=False):
    source,target,q,items=proposal_candidates(task,rid)
    cache[(task,rid)]=(source,target,q,items)
    c=Counter(x['view'] for x in items)
    proposal_rows.append({'task':task,'rid':rid,'source':source,'target':target,
                          'n_molecular':c['Molecular'],'n_cellular':c['Cellular'],
                          'n_system':c['System'],'n_union':len(items)})
pd.DataFrame(proposal_rows).to_csv(OUTDIR/'proposal_availability_by_query.csv',index=False)

all_runs=[]
for k in KS:
    for task,rid in test.itertuples(index=False):
        source,target,q,items=cache[(task,rid)]
        c=Counter(x['view'] for x in items)
        strict=all(c[v]>=k for v in ('Molecular','Cellular','System'))
        gedges=set(gold[rid]['links'])
        gnodes=set(gold[rid]['nodes'])
        for variant in ('Molecular','Cellular','System','Multi-view'):
            nodes=select(items,variant,k)
            out=run_search(source,target,{n:1.0 for n in nodes},FIXED_GATE)
            er=len(gedges & set(out['edges']))/max(1,len(gedges))
            all_runs.append({'K':k,'task':task,'rid':rid,'variant':variant,
                             'strict_all_views_have_K':int(strict),'n_bridges':len(nodes),
                             'path_success':out['found'],'edge_recall':er,
                             'selected_gold_node_overlap':sum(n in gnodes for n in nodes),
                             'selected_views':'|'.join(view_of(n) for n in nodes),
                             'visited_nodes':out['visited_nodes'],'expanded_edges':out['expanded_edges']})
runs=pd.DataFrame(all_runs)
runs.to_csv(OUTDIR/'proposal_samek_detailed.csv',index=False)

# Availability at each K, separate from equal-budget retrieval.
av=[]; pdat=pd.DataFrame(proposal_rows)
for k in KS:
    for view,col in [('Molecular','n_molecular'),('Cellular','n_cellular'),('System','n_system'),('Multi-view','n_union')]:
        av.append({'K':k,'variant':view,'availability_ge_K':float((pdat[col]>=k).mean()),'n_queries':len(pdat)})
pd.DataFrame(av).to_csv(OUTDIR/'proposal_availability_summary.csv',index=False)

# Strict matched subset: every single view can supply exactly K candidates; all variants then use exactly K.
summ=[]; task_summ=[]
for k in KS:
    m=runs[(runs.K==k)&(runs.strict_all_views_have_K==1)]
    for variant,d in m.groupby('variant'):
        summ.append({'K':k,'variant':variant,'n':len(d),
                     'path_success':d.path_success.mean(),'edge_recall':d.edge_recall.mean(),
                     'mean_bridges':d.n_bridges.mean()})
    for (task,variant),d in m.groupby(['task','variant']):
        task_summ.append({'K':k,'task':task,'variant':variant,'n':len(d),
                          'path_success':d.path_success.mean(),'edge_recall':d.edge_recall.mean()})
pd.DataFrame(summ).to_csv(OUTDIR/'proposal_samek_matched_summary.csv',index=False)
pd.DataFrame(task_summ).to_csv(OUTDIR/'proposal_samek_matched_by_task.csv',index=False)

# Primary K=3 paired bootstrap: Multi-view versus each fixed single view on strict matched queries.
k=3
m=runs[(runs.K==k)&(runs.strict_all_views_have_K==1)]
piv=m.pivot_table(index=['task','rid'],columns='variant',values=['path_success','edge_recall'])
rng=np.random.default_rng(SEED); boot=[]
for base in ('Molecular','Cellular','System'):
    for metric in ('path_success','edge_recall'):
        d=(piv[(metric,'Multi-view')]-piv[(metric,base)]).to_numpy(float)
        ix=rng.integers(0,len(d),size=(BOOTSTRAP,len(d)))
        z=d[ix].mean(axis=1); lo,hi=np.quantile(z,[.025,.975])
        boot.append({'K':k,'comparison':f'Multi-view - {base}','metric':metric,
                     'n':len(d),'mean_diff':float(d.mean()),'ci95_low':float(lo),'ci95_high':float(hi),
                     'bootstrap_resamples':BOOTSTRAP})
pd.DataFrame(boot).to_csv(OUTDIR/'proposal_samek_k3_bootstrap.csv',index=False)

meta={
 'purpose':'Inference-time graph-linked proposal diagnostic with equal final Bridge count',
 'candidate_source':'2-hop source-forward union target-reverse local graph context; no gold/reference membership or shortest-path feature',
 'query_context':'Drug/disease endpoint names plus task intent reconstructed from benchmark metadata',
 'fixed_gate':FIXED_GATE,'beam':BEAM,'max_hops':MAX_HOPS,'node_budget':NODE_BUDGET,'edge_budget':EDGE_BUDGET,
 'K_values':KS,'primary_equal_budget_K':3,'test_examples':int(len(test)),
 'caveat':'This instantiates inference-time graph-linked Prop_v-style proposal; it is not free-form LLM concept generation.'
}
json.dump(meta,open(OUTDIR/'experiment_config.json','w'),indent=2)

print('\nMATCHED SUMMARY')
print(pd.DataFrame(summ).to_string(index=False))
print('\nK=3 BOOTSTRAP')
print(pd.DataFrame(boot).to_string(index=False))
print('\nAVAILABILITY')
print(pd.DataFrame(av).to_string(index=False))
