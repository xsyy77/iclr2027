from pathlib import Path
from collections import Counter
import json,hashlib,ast
import pandas as pd
E=Path('audit_output/new_candidate_evidence').resolve();R=Path('package/iclr2027_review_package').resolve();O=E/'audit';O.mkdir(exist_ok=True)
hashes=[]
for line in (E/'SHA256SUMS.txt').read_text().splitlines():
    expected,name=line.split(maxsplit=1);actual=hashlib.sha256((E/name).read_bytes()).hexdigest();assert actual==expected
    hashes.append({'file':name,'sha256':actual})
a=pd.read_csv(E/'figure3/proposal_availability_by_query.csv',keep_default_na=False)
src=(E/'candidate_generation/run_dmdb_proposal_samek.py').read_text()
src=src.split('# Build proposal diagnostics first')[0]
src=src.replace("ROOT=Path('/mnt/data/dmdb_samek')",f'ROOT=Path({str(O)!r})').replace("PATHS=ROOT/'indication_paths.json'",f'PATHS=Path({str(R/"data/raw/drugmechdb/indication_paths.json")!r})').replace("TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'",f'TEST_ROWS=Path({str(E/"figure3/proposal_availability_by_query.csv")!r})')
ns={};exec(compile(src,'provided_candidate_generator','exec'),ns)
generated=[];entities=[];items_by_key={}
for row in a.itertuples(index=False):
    source,target,q,items=ns['proposal_candidates'](row.task,row.rid);items_by_key[(row.task,row.rid)]=items
    c=Counter(x['view'] for x in items)
    generated.append(dict(task=row.task,rid=row.rid,source=source,target=target,n_molecular=c['Molecular'],n_cellular=c['Cellular'],n_system=c['System'],n_union=len(items)))
    entities.extend(dict(task=row.task,rid=row.rid,**x) for x in items)
g=pd.DataFrame(generated);g.to_csv(O/'replayed_availability.csv',index=False);pd.DataFrame(entities).to_csv(O/'replayed_candidate_entities.csv',index=False)
m=a.merge(g,on=['task','rid'],suffixes=('_saved','_replayed'),validate='one_to_one');cols=['source','target','n_molecular','n_cellular','n_system','n_union']
for col in cols:m[col+'_matches']=m[col+'_saved']==m[col+'_replayed']
m.to_csv(O/'availability_comparison.csv',index=False)
# Compare distributions to the frozen Figure 3 arrays in the submission.
original=R/'supplementary_code/figure3_candidate_count_real.py'
tree=ast.parse(original.read_text());raw=None
for node in tree.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RAW' for t in node.targets):raw=ast.literal_eval(node.value)
(O/'raw_structure.json').write_text(json.dumps(raw,indent=2))
array_checks=[]
for task,views in raw.items():
    for view,values in views.items():
        col={'Molecular':'n_molecular','Cellular':'n_cellular','System':'n_system','Multi-view':'n_union'}[view]
        actual=a.loc[a.task==task,col].tolist()
        array_checks.append(dict(task=task,view=view,n=len(actual),ordered_match=actual==values,distribution_match=sorted(actual)==sorted(values)))
pd.DataFrame(array_checks).to_csv(O/'submission_figure3_array_comparison.csv',index=False)
# Inference independence test: strip record-specific mechanism/answer content
# after aggregate graph construction, retaining only known endpoint metadata.
for rid,rec in list(ns['rec_by_rid'].items()):
    gm=rec['graph'];ns['rec_by_rid'][rid]={'graph':{k:gm.get(k) for k in ['drug_mesh','disease_mesh','drug','disease']}}
ns['gold']={};ns['paths']=[];ns['test']=pd.DataFrame()
for row in a.itertuples(index=False):assert ns['proposal_candidates'](row.task,row.rid)[3]==items_by_key[(row.task,row.rid)]
details=pd.read_csv(E/'figure3_stage_effect/drugmechdb_real_e2e_provisional_detailed.csv')
summary=details.groupby('method')[['path_success','edge_recall','answer_hit','gate','n_proposed','n_selected']].mean();summary.to_csv(O/'provisional_summary.csv')
membership=[]
for row in details.itertuples(index=False):
    selected=[] if pd.isna(row.selected_nodes) else str(row.selected_nodes).split('|')
    pool={x['node'] for x in items_by_key[(row.task,row.rid)]}
    membership.append(dict(task=row.task,rid=row.rid,method=row.method,n_selected=len(selected),outside_pool=json.dumps(sorted(set(selected)-pool))))
pd.DataFrame(membership).to_csv(O/'provisional_selection_membership.csv',index=False)
clean=pd.read_csv(R/'data/processed/drugmechdb/semantic_bridge_predictions.csv');clean=clean[(clean.split=='test')&(clean.condition=='Clean')]
overlap=[]
for (task,rid),dd in clean.groupby(['task','rid']):
    old=set(dd.node);new={x['node'] for x in items_by_key[(task,rid)]};overlap.append(dict(task=task,rid=rid,clean=len(old),proposed=len(new),intersection=len(old&new),subset=old<=new,identical=old==new))
pd.DataFrame(overlap).to_csv(O/'table1_clean_overlap.csv',index=False)
manifest=pd.read_csv(R/'data/processed/drugmechdb/benchmark_manifest.csv',keep_default_na=False);mm=a.merge(manifest[manifest.split=='test'],on=['task','rid'],suffixes=('_proposal','_manifest'),validate='one_to_one')
mm[['task','rid','source_proposal','source_manifest','target_proposal','target_manifest']].to_csv(O/'endpoint_comparison.csv',index=False)
endpoint_diagnostics=[]
for row in mm.itertuples(index=False):
    if row.source_proposal==row.source_manifest:continue
    original=ns['rec_by_rid'][row.rid]['graph']['drug_mesh']
    ns['rec_by_rid'][row.rid]['graph']['drug_mesh']=row.source_manifest
    corrected={x['node'] for x in ns['proposal_candidates'](row.task,row.rid)[3]}
    ns['rec_by_rid'][row.rid]['graph']['drug_mesh']=original
    for detail in details[(details.task==row.task)&(details.rid==row.rid)].itertuples(index=False):
        nodes=[] if pd.isna(detail.selected_nodes) else str(detail.selected_nodes).split('|')
        endpoint_diagnostics.append(dict(task=row.task,rid=row.rid,method=detail.method,corrected_pool_size=len(corrected),outside_corrected_pool=json.dumps(sorted(set(nodes)-corrected))))
pd.DataFrame(endpoint_diagnostics).to_csv(O/'endpoint_correction_diagnostic.csv',index=False)
report={'archive_sha256':hashlib.sha256(Path(r'C:\Users\shiyu\Downloads\dmdb_candidate_figure3_evidence_files.zip').read_bytes()).hexdigest(),'hashes_verified':len(hashes),'queries':len(a),'counts_match':{col:int(m[col+'_matches'].sum()) for col in cols},'candidate_rows':len(entities),'label_object_removal_identical_queries':len(a),'provisional_selected_outside_pool':sum(x['outside_pool']!='[]' for x in membership),'clean_overlap':pd.DataFrame(overlap)[['clean','intersection','subset','identical']].sum().to_dict(),'endpoint_mismatches':{c:int((mm[c+'_proposal']!=mm[c+'_manifest']).sum()) for c in ['source','target']},'replay_input_note':'original dmdb_graph_only_rerun.csv absent; task/rid rows supplied by new availability CSV; raw graph from submitted v3','historical_identity':'numeric agreement alone does not establish historical execution identity'}
(O/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(summary.to_string())
report['figure3_arrays']=array_checks
report['outside_pool_after_endpoint_diagnostic']=sum(x['outside_corrected_pool']!='[]' for x in endpoint_diagnostics)
(O/'verification.json').write_text(json.dumps(report,indent=2))
print('Array checks',array_checks);print('Endpoint diagnostic remaining outside',report['outside_pool_after_endpoint_diagnostic'])
