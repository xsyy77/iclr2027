# 实验 2：锁定自动候选池上的 Stage-II 选择与加权消融

状态：已完成，独立核验通过。结果支持报告真实选择行为，但没有证明该新增 greedy 操作化相对简单选择有独立检索优势。原 Stage I 及原提交文件未修改，没有看到测试结果后继续调参。

## Stage I 的锁定范围

本次以实验 1 的候选、分数、模型、协议和输出共 23 个文件为冻结输入，逐文件哈希一致。锁定的是这版自动候选协议与本轮数据，不是“Stage I 的所有强主张都被证明”：多视图相对最强单视图的优势仍不显著，原 Table 1 的历史候选生成链也没有因此恢复。

## 与 reviewer 问题的对应

kKLG Q2 要求在超过 K 的池中，实际执行并比较 selection，而不能用 K≤3 的归档输入证明 greedy 的作用。本次测试集有 239/248 条查询的池超过 K=3；验证集为 234/239。greedy 相对 confidence-only 改变了 67/248 个选择集合，已真正触发组件。

本次用明确的新增实现检查论文所述增益形式，**不是历史 DrugMechDB selector 的恢复**，不能倒推原主表调用过本程序。

## 冻结协议

- 输入：实验 1 的恢复 proposer union 候选及已重训并冻结的 reliability confidence，合计 28086 条 val/test 候选；不重新生成候选、不重新训练模型。
- 检索：同一原始聚合图、原邻接顺序，beam=2、max_hops=8、node_budget=14、edge_budget=20。全部非 Graph Only 方法固定 gate=0.3；不使用 adaptive gate。
- K=3；候选不足时保留全部，不丢弃查询。主分析覆盖全体，同时单列 pool>K 子集。
- Proposal：恢复 proposer 的 pre 排序；Lexical：提交版 char_wb 3–5 gram TFIDF query/name cosine；Graph：提交版 anti-hub；Reliability：冻结 confidence 的 Top3。所有 ties 用 node ID 升序。
- 新 greedy：gain=c−mu*Red+beta*TypeBonus；Red 为与已选节点的最大一跳无向邻域 Jaccard，空集合=0；TypeBonus 为当前未出现类型指示；选满 K 或池耗尽，不设 gain threshold。类型取提交检索图节点属性，沿用先前补建操作化。
- 每个选择规则同时运行 Equal（每个入选节点 confidence=1）和 Learned（冻结预测 confidence）。前者隔离选择作用，后者评估选择＋加权。它们不是两个不同训练版本。
- 参数网格完全沿用之前补充实验：mu∈{0,0.1,0.25,0.5}，beta∈{0,0.05,0.1}。仅在 239 个验证查询按 .7 PS+.3 ER 选择；objective 保留 12 位处理并列，优先更小 mu、beta。
- Red-only、Type-only 分别在相应轴上验证选择；Full 在完整网格选择。Matched No Red/Type 仅删除 Full 的一项，不重新定参。所有选定集合在测试检索前写入并锁定哈希。
- 已多次查看过测试数据，本次属于补充探索性评估，不声称新的独立确认。原训练标签来自原归档候选分布，不能据本实验推断在自动候选上重训后的效果。

## 验证集选择结果

| 模型 | mu | beta | 验证 utility |
|---|---:|---:|---:|
| Red-only | 0.25 | 0.0 | 0.28475547 |
| Type-only | 0.0 | 0.0 | 0.28341656 |
| Full grid | 0.25 | 0.0 | 0.28475547 |

Full 的 beta=0，因此实际退化为 Red-only；Type-only 选到 beta=0，因此实际退化为 Reliability Top3。不是遗漏或重复运行错误。正 beta 版本已在 validation_grid.csv 中完整保存，但没有依据测试结果换用另一个版本。测试结果不能用于声称类型奖励的独立收益。

## 全部 248 条测试结果

Graph Only 为 PS/ER/AH=27.02/33.97/70.56%。以下完整报告九种选择定义及两种加权，包含参数选择造成的相同方法。

| 选择规则 | confidence | n | PS (%) | ER (%) | AH (%) | Top3 答案覆盖 (%) |
|---|---|---:|---:|---:|---:|---:|
| Proposal | Equal | 248 | 35.08 | 38.73 | 73.39 | 42.74 |
| Proposal | Learned | 248 | 34.68 | 39.34 | 73.39 | 42.74 |
| Lexical | Equal | 248 | 33.47 | 38.72 | 72.98 | 22.98 |
| Lexical | Learned | 248 | 33.87 | 38.90 | 72.98 | 22.98 |
| Graph | Equal | 248 | 29.03 | 35.74 | 70.56 | 6.45 |
| Graph | Learned | 248 | 29.84 | 35.96 | 70.56 | 6.45 |
| Reliability | Equal | 248 | 31.85 | 38.65 | 71.37 | 14.11 |
| Reliability | Learned | 248 | 31.85 | 39.17 | 71.77 | 14.11 |
| Greedy Red | Equal | 248 | 31.85 | 38.93 | 71.37 | 14.92 |
| Greedy Red | Learned | 248 | 31.85 | 39.26 | 71.77 | 14.92 |
| Greedy Type | Equal | 248 | 31.85 | 38.65 | 71.37 | 14.11 |
| Greedy Type | Learned | 248 | 31.85 | 39.17 | 71.77 | 14.11 |
| Greedy Full | Equal | 248 | 31.85 | 38.93 | 71.37 | 14.92 |
| Greedy Full | Learned | 248 | 31.85 | 39.26 | 71.77 | 14.92 |
| Matched No Red | Equal | 248 | 31.85 | 38.65 | 71.37 | 14.11 |
| Matched No Red | Learned | 248 | 31.85 | 39.17 | 71.77 | 14.11 |
| Matched No Type | Equal | 248 | 31.85 | 38.93 | 71.37 | 14.92 |
| Matched No Type | Learned | 248 | 31.85 | 39.26 | 71.77 | 14.92 |

## 超预算子集（239 条测试查询）

| 选择规则 | confidence | n | PS (%) | ER (%) | AH (%) | Top3 答案覆盖 (%) |
|---|---|---:|---:|---:|---:|---:|
| Proposal | Equal | 239 | 32.64 | 37.04 | 72.38 | 40.59 |
| Proposal | Learned | 239 | 32.22 | 37.67 | 72.38 | 40.59 |
| Lexical | Equal | 239 | 30.96 | 37.03 | 71.97 | 20.08 |
| Lexical | Learned | 239 | 31.38 | 37.21 | 71.97 | 20.08 |
| Graph | Equal | 239 | 26.36 | 33.93 | 69.46 | 2.93 |
| Graph | Learned | 239 | 27.20 | 34.16 | 69.46 | 2.93 |
| Reliability | Equal | 239 | 29.29 | 36.95 | 70.29 | 10.88 |
| Reliability | Learned | 239 | 29.29 | 37.50 | 70.71 | 10.88 |
| Greedy Red | Equal | 239 | 29.29 | 37.25 | 70.29 | 11.72 |
| Greedy Red | Learned | 239 | 29.29 | 37.58 | 70.71 | 11.72 |
| Greedy Type | Equal | 239 | 29.29 | 36.95 | 70.29 | 10.88 |
| Greedy Type | Learned | 239 | 29.29 | 37.50 | 70.71 | 10.88 |
| Greedy Full | Equal | 239 | 29.29 | 37.25 | 70.29 | 11.72 |
| Greedy Full | Learned | 239 | 29.29 | 37.58 | 70.71 | 11.72 |
| Matched No Red | Equal | 239 | 29.29 | 36.95 | 70.29 | 10.88 |
| Matched No Red | Learned | 239 | 29.29 | 37.50 | 70.71 | 10.88 |
| Matched No Type | Equal | 239 | 29.29 | 37.25 | 70.29 | 11.72 |
| Matched No Type | Learned | 239 | 29.29 | 37.58 | 70.71 | 11.72 |

## 关键配对统计

以 rid 为簇进行 5000 次配对 bootstrap，沿用 seed=20260914；区间为逐比较 95% percentile 区间，未作多重比较校正。完整统计含所有预定比较、三个检索指标和入选答案覆盖，见 paired_cluster_bootstrap.csv。

| 比较 | 子集 | 指标 | 差值 (pp) | 95% CI (pp) | 改善/退步 |
|---|---|---|---:|---|---|
| Reliability (Equal) − Proposal (Equal) | All | PS | -3.23 | [-6.53, -0.40] | 2/10 |
| Reliability (Equal) − Proposal (Equal) | All | ER | -0.08 | [-3.10, +2.86] | 27/25 |
| Reliability (Equal) − Proposal (Equal) | Pool>K | PS | -3.35 | [-6.84, -0.41] | 2/10 |
| Reliability (Equal) − Proposal (Equal) | Pool>K | ER | -0.09 | [-3.20, +2.94] | 27/25 |
| Reliability (Learned) − Proposal (Learned) | All | PS | -2.82 | [-6.05, +0.00] | 2/9 |
| Reliability (Learned) − Proposal (Learned) | All | ER | -0.17 | [-3.08, +2.74] | 25/23 |
| Reliability (Learned) − Proposal (Learned) | Pool>K | PS | -2.93 | [-6.30, +0.00] | 2/9 |
| Reliability (Learned) − Proposal (Learned) | Pool>K | ER | -0.18 | [-3.25, +2.73] | 25/23 |
| Greedy Full (Learned) − Reliability (Learned) | All | PS | +0.00 | [+0.00, +0.00] | 0/0 |
| Greedy Full (Learned) − Reliability (Learned) | All | ER | +0.08 | [-0.55, +0.76] | 3/3 |
| Greedy Full (Learned) − Reliability (Learned) | Pool>K | PS | +0.00 | [+0.00, +0.00] | 0/0 |
| Greedy Full (Learned) − Reliability (Learned) | Pool>K | ER | +0.09 | [-0.55, +0.82] | 3/3 |
| Greedy Full (Learned) − Matched No Red (Learned) | All | PS | +0.00 | [+0.00, +0.00] | 0/0 |
| Greedy Full (Learned) − Matched No Red (Learned) | All | ER | +0.08 | [-0.55, +0.76] | 3/3 |
| Greedy Full (Learned) − Matched No Red (Learned) | Pool>K | PS | +0.00 | [+0.00, +0.00] | 0/0 |
| Greedy Full (Learned) − Matched No Red (Learned) | Pool>K | ER | +0.09 | [-0.55, +0.82] | 3/3 |
| Reliability (Learned) − Lexical (Learned) | All | PS | -2.02 | [-6.18, +1.66] | 6/11 |
| Reliability (Learned) − Lexical (Learned) | All | ER | +0.27 | [-2.56, +3.14] | 29/25 |
| Reliability (Learned) − Lexical (Learned) | Pool>K | PS | -2.09 | [-6.50, +1.73] | 6/11 |
| Reliability (Learned) − Lexical (Learned) | Pool>K | ER | +0.28 | [-2.65, +3.11] | 29/25 |
| Proposal (Learned) − Proposal (Equal) | All | PS | -0.40 | [-1.25, +0.00] | 0/1 |
| Proposal (Learned) − Proposal (Equal) | All | ER | +0.61 | [-0.45, +1.78] | 6/5 |
| Proposal (Learned) − Proposal (Equal) | Pool>K | PS | -0.42 | [-1.29, +0.00] | 0/1 |
| Proposal (Learned) − Proposal (Equal) | Pool>K | ER | +0.63 | [-0.52, +1.88] | 6/5 |

## 可以得出的结论

1. **选择是否真正执行：是。** 原归档 K≤3 的缺陷没有被沿用到本实验；239 条测试查询超预算，冗余项改变 67 个测试集合，有逐步 gain/Red/type trace 可复核。
2. **新增 greedy 是否显示独立检索优势：否。** Learned 加权下，greedy 相对 Reliability 的 ER 仅 +0.0835 pp，配对区间跨零，PS 相同；不能主张冗余项带来稳定提升。
3. **confidence Top3 是否优于 proposal Top3：本配置不支持。** 等权隔离选择时，Reliability 的 PS 比 Proposal 低 3.23 pp，区间约 [−6.53,−0.40] pp；ER 差 −0.0837 pp，区间跨零。Learned 加权下 PS 低 2.82 pp、ER 低 0.1711 pp，区间触零或跨零。这是冻结模型在自动候选分布上的实际表现，不能以原 Clean AUROC 替代该比较。
4. **类型奖励：验证集选零。** 这不证明所有类型奖励都无效，但不支持在本轮选定方法中保留它作为有效组件。
5. **原可靠性判别结果没有被撤销。** 原 Clean usefulness 判别与 K=1 受控结果仍是其各自协议下的证据；本次说明它们不能自动外推为真实大候选池的 K=3 选择优势。

## 论文与 rebuttal 的直接含义（暂不改正文）

- 可以回应已补全超预算 selection、逐步轨迹、等权/加权控制及独立验证；不能说找回了历史完整选择器，也不能说新增实验确认了 greedy 有效。
- 待全套实验结束统一修订时，Stage II 应区分“reliability estimation / weighting”和“redundancy-aware subset selection”。完整 greedy 优势的强表述当前无支持。
- 保留 Stage I 锁定的 Proposal Top3 作为后续同配置 gate 控制的预定基准，避免根据本次测试结果再选择并优化新 selector。是否保留任何新增组件应由完整证据决定，而非本轮测试排名。
- 不因本结果新增参数网格、挑 seed、重复调参；Stage III controls 另按原计划执行。

## kKLG Q2 英文草稿

We agree that the archived at-most-three candidate sets do not test subset selection under a Bridge budget of three. We therefore performed a separate, explicitly specified supplementary selection experiment on the frozen automatic proposal pools. Of 248 test queries, 239 have pools larger than K=3. We report proposal-score, lexical, graph-heuristic, confidence-only, and redundancy/type-aware selection under both equal and learned confidence, with a fixed gate and identical search budgets. Selector coefficients were chosen on the validation split, yielding mu=0.25 and beta=0; the redundancy term changes 67 test-query selection sets. However, its ER improvement over confidence-only selection under learned weighting is only 0.0835 percentage points, with a paired mechanism-clustered interval crossing zero. We do not use this experiment to claim an independent redundancy benefit or historical recovery of the original selector, and will revise the corresponding claim accordingly.

## 核验与文件

- 4383 个选择集合独立逆序重放一致；487 组 lexical/graph 分数重新计算一致。
- 验证网格 2868 个 query–configuration 独立重放；三个参数选择规则均核实。
- 9253 条保存路径重新执行一致，27759 个检索指标重新计算一致。
- Stage I 的 Graph Only/Proposal 等权/Proposal 加权共 1461 个路径记录与本轮完全一致。
- Stage I 全部 23 个文件哈希不变；原 ZIP 296 个成员逐字节不变。
- protocol.json：运行前冻结协议及输入哈希。selected_config.json、validation_grid*.csv：参数选择证据。
- candidate_scores.csv、selection_per_query.csv、selection_trace.csv：候选信号、集合与逐步 gain。
- per_query.csv、summary.csv、by_task.csv、over_budget_summary.csv、paired_cluster_bootstrap.csv：所有结果。
- verification.json、independent_verification.json：两层检查。
- ../run_experiment2_selection.py、../verify_experiment2.py、../report_experiment2.py：入口、核验与报告；入口拒绝覆盖已完成结果。
