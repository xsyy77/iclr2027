"""Stage II on LOCKED experiment-1 pools; new specified selector, not historical recovery."""
from pathlib import Path
import collections,hashlib,json,math,sys,time,zipfile
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'package/iclr2027_review_package'
I=ROOT/'audit_output/experiment1_recovered_proposer'
O=ROOT/'audit_output/experiment2_stage2_selection'
O.mkdir(exist_ok=True)
assert not (O/'per_query.csv').exists(),'Refuse to overwrite completed run'
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'methods'))
import dmdb_retrievers as r
START=time.perf_counter()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
def log(x):print(x,flush=True)
assert json.loads((I/'independent_verification.json').read_text())['passed']
locked={str(p.relative_to(ROOT)):sha(p) for p in I.iterdir() if p.is_file()}
source_inputs=[R/'methods/dmdb_retrievers.py',R/'data/raw/drugmechdb/indication_paths.json',R/'data/processed/drugmechdb/benchmark_manifest.csv',ROOT/'audit_output/stage1_submission/complete_pipeline_supplement.py']
protocol={
 'status':'supplementary exploratory Stage-II evaluation; previously inspected test set',
 'StageI_lock':'all experiment-1 files hashed and reused unchanged; no proposal/scorer retraining',
 'K':3,'gate':.3,'search':{'beam':2,'max_hops':8,'node_budget':14,'edge_budget':20,'order':'original'},
 'selection_signals':{'Proposal':'recovered pre score','Lexical':'submitted char_wb TFIDF 3-5, cosine(query,node-name), fitted per query pool','Graph':'submitted anti-hub score 1-log1p(total degree)/MAXLOG','Reliability':'frozen experiment1 confidence'},
 'new_greedy_operationalization':{'gain':'confidence-mu*max_Jaccard+beta*new_type_indicator','neighbors':'undirected union of predecessor/successor nodes in submitted directed graph','Red_empty':0,'TypeBonus':'1 if type absent from selected set','type_metadata':'submitted retrieval graph node type; same definition as prior supplemental operationalization','stop':'K or pool exhaustion; no gain threshold','tie':'ascending node ID'},
 'historical_scope':'Does NOT recover original DrugMechDB general selector; uses previously declared supplemental formula/grid, now on recovered proposer pools',
 'grid':{'mu':[0.,.1,.25,.5],'beta':[0.,.05,.1]},
 'validation_objective':'.7 PS+.3 ER with learned weighting, fixed gate .3; round objective to 12 decimals for ties, prefer smaller mu then beta',
 'parameter_selection':'239 val queries only; Red optimized on beta=0 slice; Type on mu=0 slice; Full on all 12; matched ablations remove one Full term without reoptimizing',
 'weightings':['Equal','Learned'],'no_adaptive_gate':True,
 'subsets':['All test queries','Pool size > K'],
 'bootstrap':{'unit':'rid cluster','resamples':5000,'seed':20260914,'interval':'pointwise percentile 95%, no multiplicity correction'},
 'test_use':'report all prespecified selectors/weights; no test-based updates',
 'locked_stage1_hashes':locked,'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in source_inputs}}
save('protocol.json',protocol)
c=pd.read_csv(I/'candidates_scored.csv',keep_default_na=False)
assert len(c)==28086 and not c.duplicated(['task','rid','node']).any()
man=r.manifest[r.manifest.split.isin(['val','test'])].copy()
assert len(man)==487
rows=list(man.itertuples(index=False));val=[x for x in rows if x.split=='val']
names={}
for rec in r.paths:
    for node in rec.get('nodes',[]):names.setdefault(str(node['id']),str(node.get('name','')))
groups={(t,i):g.sort_values('node').copy() for (t,i),g in c.groupby(['task','rid'],sort=False)}
neighbors={n:set(r.G.predecessors(n))|set(r.G.successors(n)) for n in c.node.unique()}
lex={};anti={};scores={};pre={};pools={};ctypes={n:r.G.nodes[n].get('type','Unknown') for n in c.node.unique()}
for row in rows:
    key=(row.task,row.rid);g=groups.get(key,c.iloc[:0]);nodes=g.node.tolist();pools[key]=nodes
    scores[key]=dict(zip(g.node,g.confidence));pre[key]=dict(zip(g.node,g.pre))
    if nodes:
        docs=[str(row.question)]+[names.get(n,n) for n in nodes]
        try:
            xx=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1).fit_transform(docs)
            vals=cosine_similarity(xx[0],xx[1:]).ravel()
        except ValueError as e:
            if 'empty vocabulary' not in str(e):raise
            vals=np.zeros(len(nodes))
    else:vals=[]
    lex[key]=dict(zip(nodes,map(float,vals)))
    anti[key]={n:1-math.log1p(r.G.in_degree(n)+r.G.out_degree(n))/r.MAXLOG for n in nodes}
c['lexical_score']=[lex[(x.task,x.rid)][x.node] for x in c.itertuples(index=False)]
c['graph_score']=[anti[(x.task,x.rid)][x.node] for x in c.itertuples(index=False)]
c['selector_type']=[ctypes[n] for n in c.node]
c.to_csv(O/'candidate_scores.csv',index=False)
log(f'Locked StageI pool loaded: {len(c)} candidates; val/test={len(val)}/{len(rows)-len(val)}')

def greedy(key,mu,beta):
    left=pools[key].copy();chosen=[];trace=[]
    while left and len(chosen)<3:
        parts={}
        for n in left:
            red=max((len(neighbors[n]&neighbors[h])/max(1,len(neighbors[n]|neighbors[h])) for h in chosen),default=0.)
            bonus=float(ctypes[n] not in {ctypes[h] for h in chosen})
            parts[n]=(scores[key][n]-mu*red+beta*bonus,red,bonus)
        node=min(left,key=lambda n:(-parts[n][0],n));gain,red,bonus=parts[node]
        trace.append(dict(rank=len(chosen)+1,node=node,confidence=scores[key][node],redundancy=red,type_bonus=bonus,gain=gain,mu=mu,beta=beta))
        chosen.append(node);left.remove(node)
    return chosen,trace

def evaluate(row,nodes,weighting):
    cs={n:(1. if weighting=='Equal' else scores[(row.task,row.rid)][n]) for n in nodes}
    z=r.search(row.source,row.target,cs,.3)
    gd=set(r.gold[row.rid])
    return z,dict(PS=float(z['found']),ER=len(set(z['edges'])&gd)/max(1,len(gd)),AH=float(str(row.answer) in z['nodes']))

grid=[];grid_details=[]
for mu in protocol['grid']['mu']:
    for beta in protocol['grid']['beta']:
        outcomes=[]
        for row in val:
            selected,_=greedy((row.task,row.rid),mu,beta);_,metrics=evaluate(row,selected,'Learned');outcomes.append(metrics)
            grid_details.append(dict(task=row.task,rid=row.rid,mu=mu,beta=beta,selected_nodes=json.dumps(selected),**metrics))
        means=pd.DataFrame(outcomes).mean().to_dict();utility=.7*means['PS']+.3*means['ER']
        grid.append(dict(mu=mu,beta=beta,utility=utility,utility_tie_key=round(utility,12),**means))
grid=pd.DataFrame(grid);grid.to_csv(O/'validation_grid.csv',index=False)
pd.DataFrame(grid_details).to_csv(O/'validation_grid_per_query.csv',index=False)
def best(table):
    x=table.sort_values(['utility_tie_key','mu','beta'],ascending=[False,True,True],kind='stable').iloc[0]
    return {'mu':float(x.mu),'beta':float(x.beta),'validation_utility':float(x.utility)}
config={'Red':best(grid[grid.beta==0]),'Type':best(grid[grid.mu==0]),'Full':best(grid)}
save('selected_config.json',config)
log('Validation-only selected configurations: '+json.dumps(config))
selectors=['Proposal','Lexical','Graph','Reliability','Greedy Red','Greedy Type','Greedy Full','Matched No Red','Matched No Type']
selection={};traces=[];selection_rows=[]
for row in rows:
    key=(row.task,row.rid)
    for name in selectors:
        if name in ['Proposal','Lexical','Graph']:
            signal={'Proposal':pre,'Lexical':lex,'Graph':anti}[name][key]
            chosen=sorted(pools[key],key=lambda n:(-signal[n],n))[:3]
            trace=[dict(rank=i+1,node=n,signal=signal[n]) for i,n in enumerate(chosen)]
        else:
            pars={'Reliability':{'mu':0.,'beta':0.},'Greedy Red':config['Red'],'Greedy Type':config['Type'],'Greedy Full':config['Full'],'Matched No Red':{'mu':0.,'beta':config['Full']['beta']},'Matched No Type':{'mu':config['Full']['mu'],'beta':0.}}[name]
            chosen,trace=greedy(key,pars['mu'],pars['beta'])
        selection[(key,name)]=chosen
        traces.extend(dict(task=row.task,rid=row.rid,split=row.split,selector=name,**t) for t in trace)
        selection_rows.append(dict(task=row.task,rid=row.rid,split=row.split,selector=name,pool_size=len(pools[key]),selected_size=len(chosen),selected_nodes=json.dumps(chosen),answer_selected=int(str(row.answer) in chosen)))
pd.DataFrame(traces).to_csv(O/'selection_trace.csv',index=False)
sel=pd.DataFrame(selection_rows);sel.to_csv(O/'selection_per_query.csv',index=False)

# Freeze all selections before inspecting any held-out retrieval result.
selection_file_hash=sha(O/'selection_per_query.csv')
results=[];baseline_checks=0
prior=pd.read_csv(I/'per_query.csv')
prior_lookup={(x.task,x.rid,x.method):x for x in prior.itertuples(index=False)}
for row in rows:
    key=(row.task,row.rid)
    z=r.search(row.source,row.target,{},0.);gd=set(r.gold[row.rid]);met=dict(PS=float(z['found']),ER=len(set(z['edges'])&gd)/max(1,len(gd)),AH=float(str(row.answer) in z['nodes']))
    methods=[('Graph Only','None',[],z,met,0.)]
    for selector in selectors:
        nodes=selection[(key,selector)]
        for weighting in ['Equal','Learned']:
            z,met=evaluate(row,nodes,weighting);methods.append((selector,weighting,nodes,z,met,.3))
    for selector,weighting,nodes,z,met,gate in methods:
        assert z['expanded_edges']<=20 and z['visited_nodes']<=14
        for u,v,rel in z['edges']:assert any(e.get('relation')==rel for e in r.G.get_edge_data(u,v).values())
        stage1_method=('Graph Only' if selector=='Graph Only' else ('Multi-view Fixed' if weighting=='Equal' else 'Utility Fixed'))
        if selector in ['Graph Only','Proposal']:
            prev=prior_lookup[(row.task,row.rid,stage1_method)]
            assert np.allclose([met[m] for m in ['PS','ER','AH']],[getattr(prev,m) for m in ['PS','ER','AH']],rtol=0,atol=1e-14)
            assert z['nodes']==json.loads(prev.nodes) and z['edges']==[tuple(e) for e in json.loads(prev.edges)]
            baseline_checks+=1
        results.append(dict(task=row.task,rid=row.rid,split=row.split,selector=selector,weighting=weighting,gate=gate,pool_size=len(pools[key]),selected_size=len(nodes),selected_nodes=json.dumps(nodes),selected_confidences=json.dumps({n:(1. if weighting=='Equal' else scores[key][n]) for n in nodes}),answer_selected=int(str(row.answer) in nodes),**met,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges']))
d=pd.DataFrame(results)
assert len(d)==487*19 and not d.duplicated(['task','rid','selector','weighting']).any()
d.to_csv(O/'per_query.csv',index=False)
metrics=['PS','ER','AH','answer_selected','selected_size','visited_nodes','expanded_edges']
d.groupby(['split','selector','weighting'])[metrics].mean().to_csv(O/'summary.csv')
d.groupby(['split','task','selector','weighting'])[metrics].agg(['mean','size']).to_csv(O/'by_task.csv')
d[d.pool_size>3].groupby(['split','selector','weighting'])[metrics].agg(['mean','size']).to_csv(O/'over_budget_summary.csv')
test=d[d.split=='test'];pairs=[]
comparisons=[]
for w in ['Equal','Learned']:
    comparisons += [(s,w,'Proposal',w) for s in ['Lexical','Graph','Reliability','Greedy Red','Greedy Type','Greedy Full']]
    comparisons += [('Reliability',w,'Lexical',w),('Reliability',w,'Graph',w),('Greedy Full',w,'Reliability',w),('Greedy Full',w,'Matched No Red',w),('Greedy Full',w,'Matched No Type',w)]
comparisons += [(s,'Learned',s,'Equal') for s in selectors]
comparisons += [(s,'Equal','Graph Only','None') for s in ['Proposal','Lexical','Reliability','Greedy Full']]
for subset,ss in [('All',test),('Pool>K',test[test.pool_size>3])]:
    clusters=sorted(ss.rid.unique());rng=np.random.default_rng(20260914);ix=rng.integers(0,len(clusters),size=(5000,len(clusters)))
    for lhs,lw,rhs,rw in comparisons:
        aa=ss[(ss.selector==lhs)&(ss.weighting==lw)].set_index(['task','rid'])
        bb=ss[(ss.selector==rhs)&(ss.weighting==rw)].set_index(['task','rid']).reindex(aa.index)
        assert len(aa)>0 and not bb.PS.isna().any()
        for metric in ['PS','ER','AH','answer_selected']:
            delta=aa[metric]-bb[metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters)
            boots=cl['sum'].to_numpy()[ix].sum(axis=1)/cl['size'].to_numpy()[ix].sum(axis=1)
            lo,hi=np.quantile(boots,[.025,.975])
            pairs.append(dict(subset=subset,lhs=lhs,lhs_weight=lw,rhs=rhs,rhs_weight=rw,metric=metric,n=len(delta),rid_clusters=len(clusters),delta=delta.mean(),ci95_low=lo,ci95_high=hi,improved=int((delta>1e-12).sum()),degraded=int((delta< -1e-12).sum()),unchanged=int((abs(delta)<=1e-12).sum())))
pd.DataFrame(pairs).to_csv(O/'paired_cluster_bootstrap.csv',index=False)
changed=[]
for name,h in locked.items():
    if sha(ROOT/name)!=h:changed.append(name)
assert not changed
assert sha(O/'selection_per_query.csv')==selection_file_hash
zip_checks=0
with zipfile.ZipFile(ROOT/'iclr2027_review_package_v3.zip') as z:
    for info in z.infolist():
        if info.is_dir():continue
        assert (ROOT/'package'/info.filename).read_bytes()==z.read(info.filename)
        zip_checks+=1
selection_diff=[]
for selector in selectors:
    for ref in ['Proposal','Reliability']:
        keys=[(x.task,x.rid) for x in rows if x.split=='test'];selection_diff.append(dict(selector=selector,reference=ref,queries=len(keys),changed_set=sum(set(selection[(k,selector)])!=set(selection[(k,ref)]) for k in keys),changed_order=sum(selection[(k,selector)]!=selection[(k,ref)] for k in keys)))
pd.DataFrame(selection_diff).to_csv(O/'selection_changes.csv',index=False)
sizes={split:[len(pools[(x.task,x.rid)]) for x in rows if x.split==split] for split in ['val','test']}
save('verification.json',{'complete':True,'queries':{'val':239,'test':248},'candidate_rows':len(c),'per_query_rows':len(d),'selectors':len(selectors),'stage1_baseline_path_matches':baseline_checks,'stage1_locked_files_unchanged':len(locked),'changed_stage1_files':changed,'original_zip_members_unchanged':zip_checks,'selection_hash_before_test':selection_file_hash,'over_budget_queries':{sp:sum(n>3 for n in ns) for sp,ns in sizes.items()},'full_parameters':config['Full'],'elapsed_seconds':time.perf_counter()-START})
log(test.groupby(['selector','weighting'])[['PS','ER','AH']].mean().to_string())
log('COMPLETE: '+str(O))
