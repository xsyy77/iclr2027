"""Steps 1-4: reconstruct original formula, preserve model, tune existing parameters.
Original train/val for fitting/selection; original test reused for transparent analysis.
No conditional scorer, replacement rule, new features or new loss.
"""
from pathlib import Path
import hashlib,json,math,sys,warnings,time
import joblib,numpy as np,pandas as pd
from scipy.sparse import csr_matrix,hstack
from sklearn.base import clone
from sklearn.exceptions import ConvergenceWarning
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';P=ROOT/'audit_output/stage2_training_alignment_pilot';I=ROOT/'audit_output/experiment1_recovered_proposer';O=ROOT/'audit_output/stage2_original_greedy_repair'
O.mkdir(exist_ok=True);assert not (O/'test_per_query.csv').exists();sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
warnings.filterwarnings('error',category=ConvergenceWarning)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def log(s):print(s,flush=True)
inputs=[P/'refitted_automatic_train_model.joblib',P/'automatic_training_and_validation_candidates.csv',I/'candidates_scored.csv',R/'methods/dmdb_retrievers.py'];hashes={str(p.relative_to(ROOT)):sha(p) for p in inputs}
save('protocol.json',{'scope':'original-method reconstruction and bounded parameter optimization; previous historical-source search closed','formula':'Gain=c-mu*max_neighbor_Jaccard+beta*new_type; start EMPTY, add until K=3 or exhausted; ties node ID','model':'original TFIDF/graph features, train-only preprocessing, class-balanced logistic, original solver/seed; C in [.1,1,10] only','supervision':'original marginal usefulness formula with H=empty, fixed gate .3; TRAIN only; audit GraphOnly baseline equivalence before reusing labels','reconstruction':'operational Red/type/ties declared, not proof of historical exact execution','mu':[0.,.1,.25,.5],'beta':[0.,.05,.1],'search':'original order, K3, g.3, beam2,hops8,nodes14,edges20','selection':'maximize original validation utility .7PS+.3ER with learned guidance; round12 ties prefer C closer to1, smaller mu,beta','controls':['GraphOnly','Proposal','Lexical','Graph','ConfidenceOnly','Greedy','NoRed','NoType'],'weightings':['Equal','Learned'],'test_scope':'original248 previously inspected, reused analysis NOT fresh independent confirmation; no 6734 cohort retuning','lock':'must preserve original method and primary PS/ER >= ProposalEqual plus paired utility CI lower95>0 versus ProposalEqual and strongest simple same-weight comparator; reused test cannot give independent-confirmation lock','frozen_inputs':hashes})
model=joblib.load(P/'refitted_automatic_train_model.joblib');old=joblib.load(I/'bridge_model.joblib');assert model['clf'].get_params()==old['clf'].get_params();assert json.loads((P/'independent_verification.json').read_text())['passed']
a=pd.read_csv(P/'automatic_training_and_validation_candidates.csv',float_precision='round_trip');test=pd.read_csv(I/'candidates_scored.csv',float_precision='round_trip');test=test[test.split=='test'].copy();c=pd.concat([a,test],ignore_index=True);man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)};audit=[]
for q in r.manifest[r.manifest.split.isin(['train','val'])].itertuples(index=False):
    z0=r.search(q.source,q.target,{},0.);z=r.search(q.source,q.target,{},.3);assert z0['nodes']==z['nodes'] and z0['edges']==z['edges'];audit.append((q.task,q.rid))
train=a[a.split=='train'];base={}
for key,g in train.groupby(['task','rid']):
    q=man[key];z=r.search(q.source,q.target,{},.3);gd=set(r.gold[q.rid]);u=.7*float(z['found'])+.3*len(set(z['edges'])&gd)/max(1,len(gd));assert np.allclose(g.base_utility,u,rtol=0,atol=1e-14);delta=.7*g.singleton_PS+.3*g.singleton_ER-u;assert np.array_equal((delta>1e-12).astype(int).to_numpy(),g.beneficial.to_numpy());base[key]=u
assert not c.duplicated(['task','rid','node']).any();assert set(train.rid).isdisjoint(set(c[c.split.isin(['val','test'])].rid))
save('step1_audit.json',{'passed':True,'original_model_parameters_equal':True,'train_val_empty_guidance_baseline_paths_checked':len(audit),'stored_train_labels_checked':len(train),'label_definition':'H=empty original marginal usefulness','no_new_features_or_loss':True,'no_duplicate_query_candidates':True,'reference_data_used_only_for_training_labels_and_evaluation':True,'historical_source_search_closed':True});log('STEP1 PASS: 1593 baseline paths and 75237 labels; original-method reconstruction fixed')
src=R/'code/original_recovered/current_dmdb/step_semantic_bridge_diagnostics.py';s=src.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')));b={};exec(compile(s,str(src),'exec'),b)
key=next(iter(b['man']));static={n:b['numfeat'](*key,n) for n in c.node.unique()};docs=[];nums=[]
for x in c.itertuples(index=False):
    q=man[(x.task,x.rid)];nm=b['node_meta'].get(x.node,{'name':x.node,'type':'Unknown'});docs.append(f"task {x.task} question {q.question} bridge {nm['name']} bridge_type {nm['type']}");num=list(static[x.node]);num[3:6]=[float(r.G.has_edge(q.source,x.node)),math.log1p(r.G.out_degree(q.source)),math.log1p(r.G.in_degree(q.target))];nums.append(num)
xx=hstack([model['word'].transform(docs),model['char'].transform(docs),csr_matrix(model['sc'].transform(np.asarray(nums,np.float32)))],format='csr');tr=(c.split=='train').to_numpy();va=(c.split=='val').to_numpy();te=(c.split=='test').to_numpy();groups={(t,i):g.sort_values(['pre','node'],ascending=[False,True]) for (t,i),g in c.groupby(['task','rid'],sort=False)};neighbors={n:set(r.G.predecessors(n))|set(r.G.successors(n)) for n in c.node.unique()};types={n:r.G.nodes[n].get('type','Unknown') for n in c.node.unique()};lex=pd.read_csv(ROOT/'audit_output/experiment2_stage2_selection/candidate_scores.csv',float_precision='round_trip');lexmap={(x.task,x.rid,x.node):x.lexical_score for x in lex.itertuples(index=False)}
def greedy(key,scores,mu,beta,trace=False):
    left=set(groups[key].node);chosen=[];steps=[]
    while left and len(chosen)<3:
        parts={n:(max((len(neighbors[n]&neighbors[h])/max(1,len(neighbors[n]|neighbors[h])) for h in chosen),default=0.),float(types[n] not in {types[h] for h in chosen})) for n in left};win=min(left,key=lambda n:(-(scores[n]-mu*parts[n][0]+beta*parts[n][1]),n));red,bonus=parts[win];steps.append(dict(node=win,confidence=scores[win],red=red,type_bonus=bonus,gain=scores[win]-mu*red+beta*bonus));chosen.append(win);left.remove(win)
    return (chosen,steps) if trace else chosen
def evaluate(key,nodes,scores,weighting):
    q=man[key];conf={n:(1. if weighting=='Equal' else scores[n]) for n in nodes};z=r.search(q.source,q.target,conf,.3);gd=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gd)/max(1,len(gd));return dict(PS=ps,ER=er,AH=float(str(q.answer) in z['nodes']),utility=.7*ps+.3*er,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges'])
grid=[];models={};val_scores={};gridrows=[]
for C in [.1,1.,10.]:
    checkpoint=dict(model)
    if C!=1.:
        clf=clone(model['clf']).set_params(C=C);log(f'STEP2 fitting original LR C={C}');clf.fit(xx[tr],c.loc[tr,'beneficial'].to_numpy(dtype=int));checkpoint['clf']=clf
    else:log('STEP2 reuse independently verified original LR C=1 checkpoint')
    models[C]=checkpoint;joblib.dump(checkpoint,O/f'model_C{C:g}.joblib');vv=c[va][['task','rid','node']].copy();vv['confidence']=checkpoint['clf'].predict_proba(xx[va])[:,1];vv.to_csv(O/f'val_scores_C{C:g}.csv',index=False);sc={(t,i):dict(zip(g.node,g.confidence)) for (t,i),g in vv.groupby(['task','rid'])};val_scores[C]=sc
    for mu in [0.,.1,.25,.5]:
        for beta in [0.,.05,.1]:
            rr=[]
            for q in r.manifest[r.manifest.split=='val'].itertuples(index=False):
                key=(q.task,q.rid);nodes=greedy(key,sc[key],mu,beta) if key in groups else [];res=evaluate(key,nodes,sc.get(key,{}),'Learned');row=dict(C=C,mu=mu,beta=beta,task=q.task,rid=q.rid,selected_nodes=json.dumps(nodes),**res);rr.append(row);gridrows.append(row)
            means=pd.DataFrame(rr)[['PS','ER','AH','utility']].mean().to_dict();grid.append(dict(C=C,mu=mu,beta=beta,**means))
    log(f'STEP3 validation grid complete C={C}')
grid=pd.DataFrame(grid);grid['tie']=grid.utility.round(12);grid['C_distance']=abs(np.log10(grid.C));grid.to_csv(O/'validation_grid.csv',index=False);pd.DataFrame(gridrows).to_csv(O/'validation_grid_per_query.csv',index=False);win=grid.sort_values(['tie','C_distance','mu','beta'],ascending=[False,True,True,True]).iloc[0];C=float(win.C);mu=float(win.mu);beta=float(win.beta);save('selected_configuration.json',{k:float(win[k]) for k in ['C','mu','beta','PS','ER','AH','utility']});log('STEP3 FROZEN '+json.dumps({k:float(win[k]) for k in ['C','mu','beta','PS','ER','utility']}))
checkpoint=models[C];tt=c[te][['task','rid','node']].copy();tt['confidence']=checkpoint['clf'].predict_proba(xx[te])[:,1];tt.to_csv(O/'test_scores.csv',index=False);testsc={(t,i):dict(zip(g.node,g.confidence)) for (t,i),g in tt.groupby(['task','rid'])};allrows=[];selections=[];traces=[]
for split,sc in [('val',val_scores[C]),('test',testsc)]:
    for q in r.manifest[r.manifest.split==split].itertuples(index=False):
        key=(q.task,q.rid);g=groups.get(key,c.iloc[:0]);scores=sc.get(key,{});pool=g.node.tolist();gs,trace=greedy(key,scores,mu,beta,True) if pool else ([],[]);choices={'Proposal':pool[:3],'Lexical':sorted(pool,key=lambda n:(-lexmap[(*key,n)],n))[:3],'Graph':sorted(pool,key=lambda n:(math.log1p(r.G.degree(n)),n))[:3],'ConfidenceOnly':sorted(pool,key=lambda n:(-scores[n],n))[:3],'Greedy':gs,'NoRed':greedy(key,scores,0.,beta) if pool else [],'NoType':greedy(key,scores,mu,0.) if pool else []}
        traces.extend(dict(split=split,task=q.task,rid=q.rid,rank=i+1,**step) for i,step in enumerate(trace))
        for method,nodes in choices.items():
            selections.append(dict(split=split,task=q.task,rid=q.rid,method=method,pool_size=len(pool),selected_nodes=json.dumps(nodes)))
            for weighting in ['Equal','Learned']:allrows.append(dict(split=split,task=q.task,rid=q.rid,method=method,weighting=weighting,pool_size=len(pool),selected_nodes=json.dumps(nodes),**evaluate(key,nodes,scores,weighting)))
pd.DataFrame(selections).to_csv(O/'selections.csv',index=False);pd.DataFrame(traces).to_csv(O/'greedy_trace.csv',index=False);d=pd.DataFrame(allrows);d[d.split=='val'].to_csv(O/'validation_controls.csv',index=False);d[d.split=='test'].to_csv(O/'test_per_query.csv',index=False);summary=d.groupby(['split','method','weighting'])[['PS','ER','AH','utility']].mean();summary.to_csv(O/'summary.csv');paired=[]
for split in ['val','test']:
    dd=d[d.split==split]
    for weighting in ['Equal','Learned']:
        primary=dd[(dd.method=='Greedy')&(dd.weighting==weighting)].set_index(['task','rid']);clusters=sorted(primary.index.get_level_values('rid').unique());ix=np.random.default_rng(20260914).integers(0,len(clusters),size=(5000,len(clusters)))
        for name in ['Proposal','Lexical','Graph','ConfidenceOnly','NoRed','NoType']:
            other=dd[(dd.method==name)&(dd.weighting==weighting)].set_index(['task','rid']).reindex(primary.index)
            for metric in ['PS','ER','AH','utility']:
                delta=primary[metric]-other[metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters);boots=cl['sum'].to_numpy()[ix].sum(axis=1)/cl['size'].to_numpy()[ix].sum(axis=1);lo,hi=np.quantile(boots,[.025,.975]);paired.append(dict(split=split,weighting=weighting,comparison='Greedy - '+name,metric=metric,delta=delta.mean(),ci95_low=lo,ci95_high=hi))
pd.DataFrame(paired).to_csv(O/'paired_cluster_bootstrap.csv',index=False);assert all(sha(ROOT/n)==h for n,h in hashes.items());save('completion.json',{'complete':True,'steps_completed':[1,2,3,4],'validation_queries':239,'reused_test_queries':248,'test_used_to_select_parameters':False,'core_method_preserved':True,'no_conditioning_or_replacement_or_new_loss':True,'input_hashes_unchanged':True,'independent_verification_pending':True,'locked':False,'reason':'independent replay pending; reused test is not fresh confirmation'});log(summary.loc['test'].to_string());log('COMPLETE STEPS1-4; independent replay required')
