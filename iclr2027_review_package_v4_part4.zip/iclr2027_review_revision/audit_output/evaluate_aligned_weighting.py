"""One frozen follow-up of the val-passing soft-weighting repair. No further fitting.
Three weightings get the SAME val-only gate grid; test run once and all retained.
"""
from pathlib import Path
import hashlib,json,math,sys
import joblib,numpy as np,pandas as pd
from scipy.sparse import csr_matrix,hstack
from sklearn.metrics import roc_auc_score,average_precision_score
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';I=ROOT/'audit_output/experiment1_recovered_proposer';P=ROOT/'audit_output/stage2_training_alignment_pilot';O=ROOT/'audit_output/aligned_weighting_evaluation'
O.mkdir(exist_ok=True);assert not (O/'test_per_query.csv').exists(),'Refuse repeated test overwrite'
assert json.loads((P/'independent_verification.json').read_text())['passed']
decision=json.loads((P/'validation_decision.json').read_text());assert decision['methods_passed']['Proposal Refit Learned']
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'))
import dmdb_retrievers as r
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
lock={str(p.relative_to(ROOT)):sha(p) for folder in [I,P] for p in folder.iterdir() if p.is_file()}
protocol={'purpose':'one follow-up evaluation of validation-passing minimal repair; no further model fitting','candidate_selection':'frozen StageI proposal Top3, no learned hard selection or greedy','weightings':['Equal','Original Learned','Aligned Learned'],'gate_selection':'each weighting independently selects g from 0:.05:.50 on same 239 val queries and .7 PS+.3 ER; round utility 12 decimals, prefer smaller g; identical tuning budget','test_methods':'all three weightings at fixed .3 and own validation-selected constant, plus Graph Only; report all; no adaptive gate','candidate_scoring_evaluation':'all frozen TEST automatic candidates, explicitly new singleton utility labels at conf=1,g=.3 vs Graph Only; evaluate only after fixed model, never used for training/selection','statistics':'5000 paired rid-cluster bootstrap seed20260914; pointwise intervals, no multiplicity adjustment','scope':'previously inspected test set: supplementary, not independent confirmation; same transductive graph','advance_from_pilot':decision['methods_passed'],'locked_hashes':lock}
save('protocol.json',protocol)
c=pd.read_csv(I/'candidates_scored.csv');s1=pd.read_csv(I/'per_query.csv');model=joblib.load(P/'refitted_automatic_train_model.joblib')
src=R/'code/original_recovered/current_dmdb/step_semantic_bridge_diagnostics.py';s=src.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')))
b={};exec(compile(s,str(src),'exec'),b)
prob=[]
for start in range(0,len(c),512):
    dd=c.iloc[start:start+512];texts=[];nums=[]
    for x in dd.itertuples(index=False):
        q=b['man'][(x.task,x.rid)];nm=b['node_meta'].get(x.node,{'name':x.node,'type':'Unknown'})
        texts.append(f"task {x.task} question {q['question']} bridge {nm['name']} bridge_type {nm['type']}");nums.append(b['numfeat'](x.task,x.rid,x.node))
    xx=hstack([model['word'].transform(texts),model['char'].transform(texts),csr_matrix(model['sc'].transform(np.asarray(nums,np.float32)))],format='csr');prob.extend(model['clf'].predict_proba(xx)[:,1])
c['aligned_confidence']=prob
pilot_scores=pd.read_csv(P/'validation_scored_candidates.csv')
matched=c[c.split=='val'].merge(pilot_scores[['task','rid','node','refit_confidence']],on=['task','rid','node'],validate='one_to_one')
assert len(matched)==14057 and np.allclose(matched.aligned_confidence,matched.refit_confidence,rtol=0,atol=1e-14)
c.to_csv(O/'all_candidate_predictions.csv',index=False)
group={(t,i):g.sort_values(['pre','node'],ascending=[False,True]) for (t,i),g in c.groupby(['task','rid'])};man=r.manifest[r.manifest.split.isin(['val','test'])]
cache={};cache_records=[]
def ev(q,weight,gate):
    key=(q.task,q.rid,weight,gate)
    if key not in cache:
        g=group[(q.task,q.rid)].head(3);conf={n:1. for n in g.node} if weight=='Equal' else dict(zip(g.node,g['confidence' if weight=='Original Learned' else 'aligned_confidence']))
        z=r.search(q.source,q.target,conf,gate);gold=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gold)/max(1,len(gold));ah=float(str(q.answer) in z['nodes'])
        out=dict(cache_id=len(cache_records),task=q.task,rid=q.rid,split=q.split,weighting=weight,gate=gate,selected_nodes=json.dumps(list(conf)),selected_confidences=json.dumps(conf),PS=ps,ER=er,AH=ah,utility=.7*ps+.3*er,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']));cache[key]=out;cache_records.append(out)
    return cache[key]
grid=[];validation=[]
for weight in protocol['weightings']:
    for gate in map(float,np.round(np.arange(0,.501,.05),2)):
        rr=[ev(q,weight,gate) for q in man[man.split=='val'].itertuples(index=False)];validation.extend(rr)
        means=pd.DataFrame(rr)[['PS','ER','AH','utility']].mean().to_dict();grid.append(dict(weighting=weight,gate=gate,utility_tie_key=round(means['utility'],12),**means))
grid=pd.DataFrame(grid);grid.to_csv(O/'validation_gate_grid.csv',index=False);pd.DataFrame(validation).to_csv(O/'validation_per_query.csv',index=False)
chosen={weight:float(grid[grid.weighting==weight].sort_values(['utility_tie_key','gate'],ascending=[False,True]).iloc[0].gate) for weight in protocol['weightings']};save('selected_constants.json',chosen)
print('Val-only gates frozen:',chosen,flush=True)
out=[];candidate_labels=[]
for q in man[man.split=='test'].itertuples(index=False):
    for weight in protocol['weightings']:
        for setting,gate in [('Fixed0.3',.3),('ValBest',chosen[weight])]:out.append(dict(method=weight+' '+setting,**ev(q,weight,gate)))
    out.append(dict(method='Graph Only',**ev(q,'Equal',0.)))
    gd=set(r.gold[q.rid]);base=ev(q,'Equal',0.)['utility']
    for x in group[(q.task,q.rid)].itertuples(index=False):
        z=r.search(q.source,q.target,{x.node:1.},.3);er=len(set(z['edges'])&gd)/max(1,len(gd));delta=.7*float(z['found'])+.3*er-base
        candidate_labels.append(dict(task=q.task,rid=q.rid,node=x.node,old_confidence=x.confidence,aligned_confidence=x.aligned_confidence,delta=delta,beneficial=int(delta>1e-12)))
d=pd.DataFrame(out);assert len(d)==248*7;d.to_csv(O/'test_per_query.csv',index=False);d.groupby('method')[['PS','ER','AH','utility','gate']].mean().to_csv(O/'test_summary.csv')
d.groupby(['task','method'])[['PS','ER','AH','utility']].agg(['mean','size']).to_csv(O/'test_by_task.csv')
pd.DataFrame(cache_records).to_csv(O/'search_cache.csv',index=False)
labels=pd.DataFrame(candidate_labels);labels.to_csv(O/'test_candidate_usefulness.csv',index=False)
rank={name:{'AUROC':float(roc_auc_score(labels.beneficial,labels[col])),'AUPRC':float(average_precision_score(labels.beneficial,labels[col]))} for name,col in [('Original','old_confidence'),('Aligned','aligned_confidence')]};save('test_ranking.json',{'n':len(labels),'positive_rate':float(labels.beneficial.mean()),'metrics':rank})
comparisons=[('Aligned Learned Fixed0.3','Equal Fixed0.3'),('Aligned Learned Fixed0.3','Original Learned Fixed0.3'),('Aligned Learned ValBest','Equal ValBest'),('Aligned Learned ValBest','Original Learned ValBest'),('Aligned Learned ValBest','Aligned Learned Fixed0.3'),('Aligned Learned ValBest','Graph Only')]
clusters=sorted(d.rid.unique());ix=np.random.default_rng(20260914).integers(0,len(clusters),size=(5000,len(clusters)));pairs=[]
for lhs,rhs in comparisons:
    a=d[d.method==lhs].set_index(['task','rid']);bb=d[d.method==rhs].set_index(['task','rid']).reindex(a.index)
    for metric in ['PS','ER','AH','utility']:
        delta=a[metric]-bb[metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(clusters);boot=cl['sum'].to_numpy()[ix].sum(axis=1)/cl['size'].to_numpy()[ix].sum(axis=1);lo,hi=np.quantile(boot,[.025,.975]);pairs.append(dict(comparison=lhs+' - '+rhs,metric=metric,delta=delta.mean(),ci95_low=lo,ci95_high=hi,improved=int((delta>1e-12).sum()),degraded=int((delta< -1e-12).sum())))
pd.DataFrame(pairs).to_csv(O/'paired_cluster_bootstrap.csv',index=False)
assert all(sha(ROOT/name)==h for name,h in lock.items())
save('verification.json',{'complete':True,'test_queries':248,'test_candidate_labels':len(labels),'prior_files_unchanged':len(lock),'all_selections_fixed_proposal_top3':True,'no_new_training':True,'all_three_weightings_same_validation_grid':True})
print(d.groupby('method')[['PS','ER','AH','utility']].mean().to_string());print(json.dumps(rank,indent=2));print('COMPLETE',flush=True)
