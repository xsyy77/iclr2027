"""Independent checks of the experiment-1 serialized artifacts (does not train/tune)."""
from pathlib import Path
import collections, hashlib, json, sys, zipfile
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'package/iclr2027_review_package'
O=ROOT/'audit_output/experiment1_recovered_proposer'
protocol=json.loads((O/'protocol.json').read_text(encoding='utf-8'))
verification=json.loads((O/'verification.json').read_text())
assert verification['complete']
d=pd.read_csv(O/'per_query.csv',keep_default_na=False)
c=pd.read_csv(O/'candidates_scored.csv',keep_default_na=False)
av=pd.read_csv(O/'availability_per_query.csv')
man=pd.read_csv(R/'data/processed/drugmechdb/benchmark_manifest.csv',keep_default_na=False)
assert len(d)==3409 and not d.duplicated(['task','rid','method']).any()
assert d.groupby(['task','rid']).method.nunique().eq(7).all()
assert c.groupby(['task','rid','node']).size().eq(1).all()
queries={(x.task,x.rid):x for x in man.itertuples(index=False)}
candidate_groups={(t,rid):v for (t,rid),v in c.groupby(['task','rid'])}
raw=json.loads((R/'data/raw/drugmechdb/indication_paths.json').read_text())
gold={str(rec['graph']['_id']):{(str(e['source']),str(e['target']),str(e.get('key','unknown'))) for e in rec.get('links',[])} for rec in raw}
graph_edges=set().union(*gold.values())
selection_checks=0;metric_checks=0
for x in d.itertuples(index=False):
    row=queries[(x.task,x.rid)];pool=candidate_groups.get((x.task,x.rid),c.iloc[:0])
    conf=json.loads(x.selected_confidences);nodes=json.loads(x.nodes);edges=[tuple(e) for e in json.loads(x.edges)]
    assert x.split==row.split
    if x.method=='Graph Only':expected=[]
    else:
        sub=pool
        if x.method in ['Molecular Fixed','Cellular Fixed','System Fixed']:
            sub=sub[sub.view==x.method.split()[0]]
        expected=sub.sort_values(['pre','node'],ascending=[False,True]).head(3).node.tolist()
    assert list(conf)==expected==json.loads(x.selected_nodes)
    if x.method in ['Full','Utility Fixed']:
        lookup=dict(zip(pool.node,pool.confidence))
        assert np.allclose([conf[n] for n in expected],[lookup[n] for n in expected],rtol=0,atol=1e-14)
    else:assert all(v==1 for v in conf.values())
    assert nodes[0]==row.source
    assert len(nodes)==len(edges)+1
    assert len(nodes)==len(set(nodes))
    assert all(e[0]==nodes[i] and e[1]==nodes[i+1] for i,e in enumerate(edges))
    assert set(edges)<=graph_edges
    assert x.PS==float(nodes[-1]==row.target)
    assert x.AH==float(str(row.answer) in nodes)
    assert abs(x.ER-len(set(edges)&gold[x.rid])/max(1,len(gold[x.rid])))<1e-14
    assert 0<=x.expanded_edges<=20 and len(set(nodes))<=x.visited_nodes<=14
    expected_gate=0.0 if x.method=='Graph Only' else (.5*np.sqrt(x.p_gate) if x.method=='Full' else .3)
    assert abs(x.gate-expected_gate)<1e-14
    selection_checks+=1;metric_checks+=3
for (task,rid),group in d.groupby(['task','rid']):
    by=group.set_index('method')
    assert by.loc['Utility Fixed','selected_nodes']==by.loc['Full','selected_nodes']==by.loc['Multi-view Fixed','selected_nodes']
for x in av.itertuples(index=False):
    pool=candidate_groups.get((x.task,x.rid),c.iloc[:0])
    if x.view!='Multi-view':pool=pool[pool.view==x.view]
    selected=pool.sort_values(['pre','node'],ascending=[False,True]).head(3)
    answer=str(queries[(x.task,x.rid)].answer)
    assert x.pool_size==len(pool) and x.selected_size==len(selected)
    assert x.pool_answer_covered==int(answer in set(pool.node))
    assert x.top3_answer_covered==int(answer in set(selected.node))

summary=pd.read_csv(O/'summary.csv').set_index(['split','method'])
for (split,method),group in d.groupby(['split','method']):
    for metric in ['PS','ER','AH','gate','visited_nodes','expanded_edges']:
        assert abs(summary.loc[(split,method),metric]-group[metric].mean())<1e-13
zip_checks=0
with zipfile.ZipFile(ROOT/'iclr2027_review_package_v3.zip') as z:
    for info in z.infolist():
        if info.is_dir():continue
        path=ROOT/'package'/info.filename
        assert path.is_file(),path
        assert path.read_bytes()==z.read(info.filename),path
        zip_checks+=1
for name,h in protocol['source_hashes'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
test=d[d.split=='test'];rows=[]
for method,group in test.groupby('method'):
    rows.append(dict(method=method,n=len(group),PS=group.PS.mean()*100,ER=group.ER.mean()*100,AH=group.AH.mean()*100))
report={'passed':True,'serialized_selections_checked':selection_checks,'metrics_independently_recomputed':metric_checks,'availability_rows_checked':len(av),'original_zip_members_byte_identical':zip_checks,'all_source_hashes_match':True,'same_union_subset_in_three_main_methods':True,'notes':'Search itself was separately compared against recovered proposer search for all 3409 runs in the main runner; this verifier independently reconstructs selections and metrics from saved paths.'}
(O/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
print(pd.DataFrame(rows).to_string(index=False))
