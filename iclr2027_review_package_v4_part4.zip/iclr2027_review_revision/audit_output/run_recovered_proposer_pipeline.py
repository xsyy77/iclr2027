"""Experiment 1: recovered Figure-3 proposer, frozen Top3, original estimators/search.

New supplementary evaluation, NOT recovery of the historical Table-1 selector.
Run from the workspace root. Never writes into the submitted package.
"""
from pathlib import Path
from types import SimpleNamespace
import ast, collections, hashlib, json, math, platform, sys, time, warnings, zipfile
import joblib
import networkx as nx
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, hstack
from sklearn.exceptions import ConvergenceWarning

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / 'package/iclr2027_review_package'
E = ROOT / 'audit_output/new_candidate_evidence'
O = ROOT / 'audit_output/experiment1_recovered_proposer'
O.mkdir(exist_ok=True)
assert not (O / 'per_query.csv').exists(), 'Refuse to overwrite a completed run'
warnings.filterwarnings('error', category=ConvergenceWarning)
START = time.perf_counter()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name, obj): (O/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')
def log(s): print(s, flush=True)

source = E/'candidate_generation/run_dmdb_proposal_samek.py'
protocol = {
 'status':'frozen supplementary evaluation on previously inspected data, not a new independent holdout',
 'graph':'submitted aggregate directed DrugMechDB graph, including held-out mechanism edges; transductive graph access',
 'proposer':'recovered Figure3 functions, unchanged formulas/views/depth/cap/score/ties',
 'endpoints':'submitted benchmark_manifest source/target for BOTH proposal and retrieval; raw endpoint discrepancies saved',
 'proposal_query':'recovered drug/disease names + task intent; reliability uses original manifest question',
 'selection':'recovered proposal score descending then node ID; up to K=3 per view/union; identical union subset in Semantic/Utility/Full',
 'stage2':'original fitted train-only retrieval-usefulness estimator applied as soft confidence weighting; NO greedy-selector claim',
 'stage3':'original fitted train-only gate; recompute features on NEW union Top3; g=0.5*sqrt(p), no retuning',
 'models':'refit original source, training rows, preprocessing, hyperparameters, random_state=20260827',
 'search':{'beam':2,'max_hops':8,'node_budget':14,'edge_budget':20,'adjacency':'unchanged submitted order'},
 'fixed_gate':0.3,'K':3,'bootstrap_resamples':5000,'bootstrap_seed':20260914,
 'bootstrap_unit':'rid clusters, keeping tasks of the same underlying mechanism together',
 'single_view_comparator':'select strongest single view on validation utility .7*PS+.3*ER; report all views regardless',
 'methods':['Graph Only','Molecular Fixed','Cellular Fixed','System Fixed','Multi-view Fixed','Utility Fixed','Full'],
 'no_test_tuning':True,
 'scope':'automatic proposal + fixed proposal Top3 + learned weighting + original gate; does not test redundancy-aware greedy selection',
 'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in [source,R/'methods/dmdb_retrievers.py',R/'code/original_recovered/current_dmdb/step_semantic_bridge_diagnostics.py',R/'code/original_recovered/current_dmdb/step_semantic_gate_diagnostics.py',R/'data/raw/drugmechdb/indication_paths.json',R/'data/processed/drugmechdb/benchmark_manifest.csv',R/'data/processed/drugmechdb/bridge_marginal_training_samples.csv',R/'data/processed/drugmechdb/gate_training_samples.csv']}}
save('protocol.json', protocol)
save('environment.json', {'python':sys.version,'platform':platform.platform(),'versions':{m:__import__(m).__version__ for m in ['numpy','pandas','scipy','sklearn','networkx','joblib']}})
initial_hashes = {str(p.relative_to(R)):sha(p) for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
save('package_hashes_before.json', initial_hashes)
sys.dont_write_bytecode = True
sys.path.insert(0,str(R/'methods'))
import dmdb_retrievers as r
manifest=r.manifest.copy()
assert not manifest.duplicated(['task','rid']).any()
assert manifest.groupby('rid').split.nunique().max()==1
rows=list(manifest[manifest.split.isin(['val','test'])].itertuples(index=False))
assert collections.Counter(x.split for x in rows)=={'val':239,'test':248}

# Load only recovered setup/functions, never the original output-writing experiment.
s=source.read_text(encoding='utf-8').split('# Build proposal diagnostics first')[0]
s=s.replace("ROOT=Path('/mnt/data/dmdb_samek')",f'ROOT=Path({str(O)!r})')
s=s.replace("PATHS=ROOT/'indication_paths.json'",f'PATHS=Path({str(R/"data/raw/drugmechdb/indication_paths.json")!r})')
s=s.replace("TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'",f'TEST_ROWS=Path({str(E/"figure3/proposal_availability_by_query.csv")!r})')
s=s.replace('OUTDIR.mkdir(exist_ok=True)','')
p={};exec(compile(s,str(source),'exec'),p)
assert dict(r.OUT)==dict(p['OUT'])
assert r.G.number_of_edges()==p['G'].number_of_edges()

# Exact raw-endpoint replay of the previously verified Figure3 entity-level output.
old=pd.read_csv(E/'audit/replayed_candidate_entities.csv',keep_default_na=False)
for (task,rid), group in old.groupby(['task','rid'],sort=False):
    items=p['proposal_candidates'](task,rid)[3]
    assert [x['node'] for x in items]==group.node.tolist()
    assert np.allclose([x['pre'] for x in items],group.pre,rtol=0,atol=1e-15)
log('Raw Figure3 replay: all 248 candidate lists agree')

# Metadata normalization is an explicit intervention, not a claim to preserve Figure3 pools.
endpoints=[]
raw_metadata={rid:dict(rec['graph']) for rid,rec in p['rec_by_rid'].items()}
for row in manifest.itertuples(index=False):
    gm=raw_metadata[str(row.rid)]
    endpoints.append(dict(task=row.task,rid=row.rid,split=row.split,raw_source=str(gm.get('drug_mesh')),source=str(row.source),raw_target=str(gm.get('disease_mesh')),target=str(row.target)))
    # No proposal access to reference nodes/links or benchmark answers.
    p['rec_by_rid'][str(row.rid)]={'graph':{'drug_mesh':str(row.source),'disease_mesh':str(row.target),'drug':gm.get('drug',''),'disease':gm.get('disease','')}}
p['gold']={};p['paths']=[];p['test']=None
pd.DataFrame(endpoints).to_csv(O/'endpoint_mapping.csv',index=False)
candidates=[];pools={};availability=[];cache={};max_universe=0
for row in rows:
    src,tgt,q,items=p['proposal_candidates'](row.task,row.rid)
    assert (src,tgt)==(row.source,row.target)
    universe=p['local_candidate_universe'](src,tgt)
    uncapped=p['local_candidate_universe'](src,tgt,cap=10**9)
    # If capped set iteration could affect membership, STOP rather than silently change proposer.
    assert universe==uncapped, f'Cap-sensitive proposer: {row.task} {row.rid}'
    max_universe=max(max_universe,len(uncapped))
    key=(row.task,row.rid);cache[key]=items
    for view in ['Molecular','Cellular','System','Multi-view']:
        pp=items if view=='Multi-view' else [x for x in items if x['view']==view]
        pools[(key,view)]=p['select'](items,view,3)
        availability.append(dict(task=row.task,rid=row.rid,split=row.split,view=view,pool_size=len(pp),selected_size=len(pools[(key,view)]),pool_answer_covered=int(str(row.answer) in {x['node'] for x in pp}),top3_answer_covered=int(str(row.answer) in pools[(key,view)])))
    candidates.extend(dict(task=row.task,rid=row.rid,split=row.split,rank=i+1,**item) for i,item in enumerate(items))
c=pd.DataFrame(candidates);c.to_csv(O/'candidates_unscored.csv',index=False)
pd.DataFrame(availability).to_csv(O/'availability_per_query.csv',index=False)
log(f'Normalized proposal: {len(c)} candidates, maximum uncapped universe {max_universe}')

def model_source(name, stop):
    src=R/'code/original_recovered/current_dmdb'/name
    text=src.read_text().split(stop)[0]
    assert stop not in text
    return text.replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')))

log('Refitting original bridge estimator on original train rows')
b={};exec(compile(model_source('step_semantic_bridge_diagnostics.py','\nreport={}'),'original_bridge_fit','exec'),b)
assert int(b['tr'].sum())>0
bridge_old=pd.read_csv(R/'data/processed/drugmechdb/semantic_bridge_predictions.csv')
assert len(bridge_old)==len(b['p'])
assert bridge_old[['task','rid','split','condition','node']].equals(b['cand'][['task','rid','split','condition','node']])
bridge_error=float(np.max(np.abs(bridge_old.pred_semantic_conf-b['p'])))
joblib.dump({k:b[k] for k in ['word','char','sc','clf','REL','TYPES']},O/'bridge_model.joblib')
scores=[]
for start in range(0,len(c),512):
    batch=c.iloc[start:start+512];texts=[];nums=[]
    for row in batch.itertuples(index=False):
        nm=b['node_meta'].get(row.node,{'name':row.node,'type':'Unknown'});m=b['man'][(row.task,row.rid)]
        texts.append(f"task {row.task} question {m['question']} bridge {nm['name']} bridge_type {nm['type']}")
        nums.append(b['numfeat'](row.task,row.rid,row.node))
    xx=hstack([b['word'].transform(texts),b['char'].transform(texts),csr_matrix(b['sc'].transform(np.asarray(nums,np.float32)))],format='csr')
    scores.extend(b['clf'].predict_proba(xx)[:,1])
c['confidence']=scores
assert np.isfinite(c.confidence).all() and c.confidence.between(0,1).all()
c.to_csv(O/'candidates_scored.csv',index=False)
confidence={(task,rid):dict(zip(dd.node,dd.confidence)) for (task,rid),dd in c.groupby(['task','rid'])}
log(f'Bridge refit done; archived prediction max difference {bridge_error:.12g}')

log('Refitting original gate estimator on original train rows')
g={};exec(compile(model_source('step_semantic_gate_diagnostics.py','\nrep={}'),'original_gate_fit','exec'),g)
gate_old=pd.read_csv(R/'data/processed/drugmechdb/semantic_gate_predictions.csv')
assert gate_old[['task','rid','split','condition']].equals(g['gate'][['task','rid','split','condition']])
gate_error=float(np.max(np.abs(gate_old.p_semantic_gate-g['p'])))
joblib.dump({k:g[k] for k in ['word','char','sc','clf','types']},O/'gate_model.joblib')
texts=[];nums=[]
for row in rows:
    selected=pools[((row.task,row.rid),'Multi-view')]
    g['sets'][(row.task,row.rid,row.split,'Automatic')]=selected
    txt,num=g['feats'](SimpleNamespace(task=row.task,rid=row.rid,split=row.split,condition='Automatic'))
    texts.append(txt);nums.append(num)
xx=hstack([g['word'].transform(texts),g['char'].transform(texts),csr_matrix(g['sc'].transform(np.asarray(nums,np.float32)))],format='csr')
gp=g['clf'].predict_proba(xx)[:,1]
gate_probs={(row.task,row.rid):float(v) for row,v in zip(rows,gp)}
pd.DataFrame([dict(task=row.task,rid=row.rid,split=row.split,p_gate=float(v),gate=.5*math.sqrt(v),feature_text=txt,numeric_features=json.dumps(num)) for row,v,txt,num in zip(rows,gp,texts,nums)]).to_csv(O/'recomputed_gates.csv',index=False)
log(f'Gate refit done; archived prediction max difference {gate_error:.12g}')

# Establish search compatibility BEFORE evaluating the new candidate setting.
arch=pd.read_csv(R/'data/processed/drugmechdb/final_continuous_test_detailed.csv')
baseline_checks=0
for row in rows:
    if row.split!='test':continue
    z=r.search(row.source,row.target,{},0.)
    z2=p['run_search'](row.source,row.target,{},0.)
    assert z==z2
    gd=set(r.gold[row.rid]);er=len(gd&set(z['edges']))/max(1,len(gd));ah=float(str(row.answer) in z['nodes'])
    oldrow=arch[(arch.task==row.task)&(arch.rid==row.rid)&(arch.condition=='Clean')&(arch.method=='Graph Only')]
    assert len(oldrow)==1
    assert np.allclose([float(z['found']),er,ah],oldrow[['found','edge_recall','answer_hit']].iloc[0],rtol=0,atol=1e-14)
    baseline_checks+=1
log('All 248 archived Graph Only query outcomes and recovered search agree')

results=[];independent_search_checks=0
for row in rows:
    key=(row.task,row.rid);union=pools[(key,'Multi-view')];cs={n:confidence[key][n] for n in union};prob=gate_probs[key]
    methods=[('Graph Only',{},0.)]
    methods += [(f'{view} Fixed',{n:1. for n in pools[(key,view)]},.3) for view in ['Molecular','Cellular','System','Multi-view']]
    methods += [('Utility Fixed',cs,.3),('Full',cs,.5*math.sqrt(prob))]
    for method,conf,gate in methods:
        t=time.perf_counter();z=r.search(row.source,row.target,conf,gate);elapsed=time.perf_counter()-t
        # Separate recovered implementation must return exactly the same path AND counters.
        assert z==p['run_search'](row.source,row.target,conf,gate)
        independent_search_checks+=1
        assert z['expanded_edges']<=20 and z['visited_nodes']<=14 and len(z['edges'])<=8
        for u,v,rel in z['edges']:assert any(d.get('relation')==rel for d in r.G.get_edge_data(u,v).values())
        gd=set(r.gold[row.rid]);results.append(dict(task=row.task,rid=row.rid,split=row.split,method=method,selected_nodes=json.dumps(list(conf)),selected_confidences=json.dumps(conf),gate=gate,p_gate=prob,PS=float(z['found']),ER=len(gd&set(z['edges']))/max(1,len(gd)),AH=float(str(row.answer) in z['nodes']),nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges'],search_seconds=elapsed))
d=pd.DataFrame(results)
assert len(d)==487*7 and not d.duplicated(['task','rid','method']).any()
d.to_csv(O/'per_query.csv',index=False)
metrics=['PS','ER','AH','gate','visited_nodes','expanded_edges','search_seconds']
d.groupby(['split','method'],sort=True)[metrics].mean().to_csv(O/'summary.csv')
d.groupby(['split','task','method'],sort=True)[metrics].agg(['mean','size']).to_csv(O/'by_task.csv')
av=pd.DataFrame(availability);av.groupby(['split','view'])[['pool_size','selected_size','pool_answer_covered','top3_answer_covered']].mean().to_csv(O/'availability_summary.csv')
single=d[(d.split=='val')&d.method.isin(['Molecular Fixed','Cellular Fixed','System Fixed'])].copy()
single['utility']=.7*single.PS+.3*single.ER
vs=single.groupby('method').utility.mean().sort_index().sort_values(ascending=False,kind='stable')
best_single=str(vs.index[0]);save('validation_single_view_choice.json',{'objective':'.7 PS+.3 ER','scores':vs.to_dict(),'selected':best_single,'tie_break':'method name alphabetical'})
comparisons=[('Multi-view Fixed','Graph Only'),('Multi-view Fixed',best_single),('Utility Fixed','Multi-view Fixed'),('Full','Utility Fixed'),('Full','Multi-view Fixed'),('Full','Graph Only')]
comparisons+= [('Multi-view Fixed',v) for v in ['Molecular Fixed','Cellular Fixed','System Fixed'] if v!=best_single]
# Clustered paired bootstrap: repeated tasks of one mechanism are not independent.
test=d[d.split=='test'];cluster_ids=sorted(test.rid.unique());rng=np.random.default_rng(20260914)
draws=rng.integers(0,len(cluster_ids),size=(5000,len(cluster_ids)))
paired=[]
for a,base in comparisons:
    aa=test[test.method==a].set_index(['task','rid']);bb=test[test.method==base].set_index(['task','rid'])
    assert aa.index.equals(bb.index)
    for metric in ['PS','ER','AH']:
        diff=(aa[metric]-bb[metric]);cl=diff.groupby(level='rid').agg(['sum','size']).reindex(cluster_ids)
        boots=cl['sum'].to_numpy()[draws].sum(axis=1)/cl['size'].to_numpy()[draws].sum(axis=1)
        lo,hi=np.quantile(boots,[.025,.975])
        paired.append(dict(comparison=f'{a} - {base}',metric=metric,n_queries=len(diff),n_rid_clusters=len(cluster_ids),delta=float(diff.mean()),ci95_low=float(lo),ci95_high=float(hi),improved=int((diff>1e-12).sum()),degraded=int((diff< -1e-12).sum()),unchanged=int((abs(diff)<=1e-12).sum())))
pd.DataFrame(paired).to_csv(O/'paired_cluster_bootstrap.csv',index=False)
changed=[name for name,h in initial_hashes.items() if sha(R/name)!=h]
assert not changed, changed
save('verification.json',{'complete':True,'raw_figure3_queries_replayed':248,'validation_queries':239,'test_queries':248,'test_rid_clusters':len(cluster_ids),'candidate_rows':len(c),'maximum_uncapped_universe':max_universe,'cap_sensitive_queries':0,'reference_objects_removed_before_normalized_proposal':True,'graph_only_archived_query_matches':baseline_checks,'independent_search_path_counter_matches':independent_search_checks,'bridge_archived_prediction_max_abs_difference':bridge_error,'gate_archived_prediction_max_abs_difference':gate_error,'bridge_training_rows':int(b['tr'].sum()),'gate_training_rows':int(g['tr'].sum()),'original_package_files_checked':len(initial_hashes),'changed_original_files':changed,'elapsed_seconds':time.perf_counter()-START})
log(d[d.split=='test'].groupby('method')[['PS','ER','AH']].mean().to_string())
log('COMPLETE; outputs '+str(O))
