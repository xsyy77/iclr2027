"""Explicit new operationalization; never a claim of historical recovery."""
from pathlib import Path
import ast,json,sys,hashlib,joblib,re
from types import SimpleNamespace
import numpy as np
import pandas as pd
from scipy.sparse import hstack,csr_matrix
R=Path('package/iclr2027_review_package').resolve()
O=Path('audit_output/stage1_submission/full_supplement');O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
protocol={'status':'new complete supplementary operationalization, not historical reconstruction','proposer':'previously specified directed two-hop, three-type-view union','selector':'K=3 greedy gain=c-mu*Red+beta*TypeBonus; Red=max undirected one-hop-neighborhood Jaccard to selected, empty=0; TypeBonus=1 for node type absent from selected; stop only at K or pool exhaustion; node-ID tie break','selector_validation_grid':{'mu':[0,.1,.25,.5],'beta':[0,.05,.1]},'objective':'.7 PS + .3 ER; ties prefer smaller mu then beta','gate_grid':{'gmax':[.2,.25,.3,.35,.4,.45,.5],'gamma':[.5,.75,1.,1.25,1.5,2.]},'gate_selection':'validation utility; exact continuous search, no discretization; ties prefer smaller gmax then gamma','training':'original saved training rows, original estimator settings and original seed; no new seed','evaluation':'all validation and test queries; no tuning using test; previously inspected test set, supplementary exploratory evaluation, not a fresh confirmatory holdout','scope':'transductive graph; new proposer and general selector; original estimator code and retrieval; all ablations retained'}
(O/'protocol.json').write_text(json.dumps(protocol,indent=2))
def source(name,stop):
    s=(R/'code/original_recovered/current_dmdb'/name).read_text().split(stop)[0]
    return s.replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')))
b={};exec(source('step_semantic_bridge_diagnostics.py','\ntexts=[]'),b)
model=joblib.load(O.parent/'supplement/learned_k1/refitted_model.joblib');b.update(model)
assert b['REL']==model['REL'] and b['TYPES']==model['TYPES']
tree=ast.parse((O.parent/'supplement_stage1.py').read_text())
scope={'r':r,'re':re,'views':{'Molecular':{'Protein','ChemicalSubstance','MolecularActivity','GeneFamily'},'Cellular':{'Cell','CellularComponent','MacromolecularComplex','GrossAnatomicalStructure'},'System':{'BiologicalProcess','Pathway','PhenotypicFeature','OrganismTaxon'}}}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<proposer>','exec'),scope)
manifest=r.manifest[r.manifest.split.isin(['val','test'])].copy();entries=[];pool={}
for row in manifest.itertuples(index=False):
    pp,score=scope['propose'](row.source,row.target,row.question)
    nodes=sorted(set().union(*map(set,pp.values())));pool[(row.task,row.rid)]=nodes
    for n in nodes:entries.append(dict(task=row.task,rid=row.rid,split=row.split,node=n))
c=pd.DataFrame(entries);texts=[];nums=[]
for row in c.itertuples(index=False):
    m=b['man'][(row.task,row.rid)];nm=b['node_meta'][row.node]
    texts.append(f"task {row.task} question {m['question']} bridge {nm['name']} bridge_type {nm['type']}")
    nums.append(b['numfeat'](row.task,row.rid,row.node))
X=hstack([b['word'].transform(texts),b['char'].transform(texts),csr_matrix(b['sc'].transform(np.asarray(nums,np.float32)))],format='csr')
c['confidence']=b['clf'].predict_proba(X)[:,1];c.to_csv(O/'automatic_candidates.csv',index=False)
conf={(t,i):dict(zip(d.node,d.confidence)) for (t,i),d in c.groupby(['task','rid'])}
neighbors={n:set(r.G.predecessors(n))|set(r.G.successors(n)) for n in c.node.unique()}
def select(key,mu,beta,trace=False):
    remaining=list(pool[key]);chosen=[];records=[];scores=conf.get(key,{})
    while remaining and len(chosen)<3:
        def parts(n):
            red=max((len(neighbors[n]&neighbors[h])/max(1,len(neighbors[n]|neighbors[h])) for h in chosen),default=0.)
            bonus=float(r.G.nodes[n].get('type') not in {r.G.nodes[h].get('type') for h in chosen})
            return scores[n]-mu*red+beta*bonus,red,bonus
        n=min(remaining,key=lambda h:(-parts(h)[0],h));gain,red,bonus=parts(n)
        records.append(dict(task=key[0],rid=key[1],rank=len(chosen)+1,node=n,confidence=scores[n],redundancy=red,type_bonus=bonus,gain=gain))
        chosen.append(n);remaining.remove(n)
    return {n:scores[n] for n in chosen},records
def evaluate(row,cs,gate):
    z=r.search(row.source,row.target,cs,gate);gold=set(r.gold[row.rid])
    return dict(PS=float(z['found']),ER=len(gold&set(z['edges']))/max(1,len(gold)),AH=float(str(row.answer) in z['nodes']))
def utility(results):return float(np.mean([.7*x['PS']+.3*x['ER'] for x in results]))
val=list(manifest[manifest.split=='val'].itertuples(index=False));grid=[]
for mu in protocol['selector_validation_grid']['mu']:
    for beta in protocol['selector_validation_grid']['beta']:
        out=[evaluate(row,select((row.task,row.rid),mu,beta)[0],.3) for row in val]
        grid.append(dict(mu=mu,beta=beta,utility=utility(out),**pd.DataFrame(out).mean().to_dict()))
gs=pd.DataFrame(grid).sort_values(['utility','mu','beta'],ascending=[False,True,True]);gs.to_csv(O/'selector_validation_grid.csv',index=False)
best=gs.iloc[0];mu,beta=float(best.mu),float(best.beta);print('Selected selector',mu,beta,flush=True)
selected={};trace=[]
for row in manifest.itertuples(index=False):
    key=(row.task,row.rid);selected[key],records=select(key,mu,beta)
    trace.extend(dict(split=row.split,**x) for x in records)
pd.DataFrame(trace).to_csv(O/'selection_trace.csv',index=False)
# Original gate estimator: fit only original training rows, then recompute features
# from each NEW selected set. Never reuse saved test-query gate predictions.
g={};exec(source('step_semantic_gate_diagnostics.py','\nrep={}'),g)
joblib.dump({k:g[k] for k in ['word','char','sc','clf','types']},O/'refitted_gate.joblib')
old=pd.read_csv(R/'data/processed/drugmechdb/semantic_gate_predictions.csv')
gate_error=float(np.max(np.abs(g['p']-old.p_semantic_gate.to_numpy())))
tt=[];nn=[];keys=[]
for row in manifest.itertuples(index=False):
    key=(row.task,row.rid);g['sets'][(row.task,row.rid,row.split,'Supplement')]=list(selected[key])
    t,n=g['feats'](SimpleNamespace(task=row.task,rid=row.rid,split=row.split,condition='Supplement'));tt.append(t);nn.append(n);keys.append(key)
xx=hstack([g['word'].transform(tt),g['char'].transform(tt),csr_matrix(g['sc'].transform(np.asarray(nn,np.float32)))],format='csr')
prob=dict(zip(keys,g['clf'].predict_proba(xx)[:,1]));grid=[]
for gmax in protocol['gate_grid']['gmax']:
    for gamma in protocol['gate_grid']['gamma']:
        out=[evaluate(row,selected[(row.task,row.rid)],gmax*prob[(row.task,row.rid)]**gamma) for row in val]
        grid.append(dict(gmax=gmax,gamma=gamma,utility=utility(out),**pd.DataFrame(out).mean().to_dict()))
gg=pd.DataFrame(grid).sort_values(['utility','gmax','gamma'],ascending=[False,True,True]);gg.to_csv(O/'gate_validation_grid.csv',index=False)
top=gg.iloc[0];gmax,gamma=float(top.gmax),float(top.gamma)
config={'mu':mu,'beta':beta,'gmax':gmax,'gamma':gamma,'gate_archived_score_max_abs_error':gate_error}
(O/'selected_config.json').write_text(json.dumps(config,indent=2));print(config,flush=True)
results=[]
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
for row in manifest.itertuples(index=False):
    key=(row.task,row.rid);nodes=pool[key]
    if nodes:
        docs=[str(row.question)]+[b['node_meta'][n]['name'] for n in nodes]
        try:
            xx=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=1).fit_transform(docs);ls=cosine_similarity(xx[0],xx[1:]).ravel()
        except ValueError:ls=np.zeros(len(nodes))
        lex=[n for _,n in sorted(zip(-ls,nodes))[:3]]
    else:lex=[]
    methods=[('Graph Only',{},0.),('Lexical K3 Fixed',{n:1. for n in lex},.3),('Reliability Top3 Fixed',select(key,0,0)[0],.3),('Greedy No Red Fixed',select(key,0,beta)[0],.3),('Greedy No Type Fixed',select(key,mu,0)[0],.3),('Greedy Fixed',selected[key],.3),('Full Supplement',selected[key],gmax*prob[key]**gamma)]
    for method,cs,gate in methods:
        results.append(dict(task=row.task,rid=row.rid,split=row.split,method=method,pool_size=len(nodes),selected_nodes=json.dumps(list(cs)),p_gate=prob[key],gate=gate,**evaluate(row,cs,gate)))
d=pd.DataFrame(results);d.to_csv(O/'per_query.csv',index=False)
s=d.groupby(['split','method'])[['PS','ER','AH','gate']].mean();s.to_csv(O/'summary.csv');print(s.to_string(),flush=True)
assert len(d)==len(manifest)*7
assert not d.duplicated(['task','rid','split','method']).any()
