"""Independent original-formula selection, scorer, retrieval and statistics replay."""
from pathlib import Path
import hashlib,json,math,sys,zipfile
import joblib,numpy as np,pandas as pd
from scipy.sparse import csr_matrix,hstack
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'audit_output/stage2_original_greedy_repair';R=ROOT/'package/iclr2027_review_package';P=ROOT/'audit_output/stage2_training_alignment_pilot';I=ROOT/'audit_output/experiment1_recovered_proposer';E=ROOT/'audit_output/new_candidate_evidence'
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
pr=json.loads((O/'protocol.json').read_text());assert json.loads((O/'completion.json').read_text())['complete']
for name,h in pr['frozen_inputs'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
a=pd.read_csv(P/'automatic_training_and_validation_candidates.csv',float_precision='round_trip');test=pd.read_csv(I/'candidates_scored.csv',float_precision='round_trip');c=pd.concat([a[a.split=='val'],test[test.split=='test']],ignore_index=True);groups={(t,i):g.sort_values(['pre','node'],ascending=[False,True]) for (t,i),g in c.groupby(['task','rid'])};man={(q.task,q.rid):q for q in r.manifest.itertuples(index=False)}
src=R/'code/original_recovered/current_dmdb/step_semantic_bridge_diagnostics.py';s=src.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(R/"data/processed/drugmechdb")!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')));b={};exec(compile(s,str(src),'exec'),b);base=joblib.load(P/'refitted_automatic_train_model.joblib');stats={};predictions=0
for C in [.1,1.,10.]:
    model=joblib.load(O/f'model_C{C:g}.joblib');params=base['clf'].get_params();params['C']=C;assert model['clf'].get_params()==params
    for name in ['word','char']:assert model[name].vocabulary_==base[name].vocabulary_ and np.array_equal(model[name].idf_,base[name].idf_)
    assert np.array_equal(model['sc'].mean_,base['sc'].mean_) and np.array_equal(model['sc'].scale_,base['sc'].scale_)
    if C==1.:assert np.array_equal(model['clf'].coef_,base['clf'].coef_) and np.array_equal(model['clf'].intercept_,base['clf'].intercept_)
    vv=pd.read_csv(O/f'val_scores_C{C:g}.csv',float_precision='round_trip')
    chosen=json.loads((O/'selected_configuration.json').read_text())
    if C==chosen['C']:vv=pd.concat([vv,pd.read_csv(O/'test_scores.csv',float_precision='round_trip')],ignore_index=True)
    for start in range(0,len(vv),512):
        batch=vv.iloc[start:start+512];docs=[];nums=[]
        for x in batch.itertuples(index=False):
            q=b['man'][(x.task,x.rid)];nm=b['node_meta'].get(x.node,{'name':x.node,'type':'Unknown'});docs.append(f"task {x.task} question {q['question']} bridge {nm['name']} bridge_type {nm['type']}");nums.append(b['numfeat'](x.task,x.rid,x.node))
        xx=hstack([model['word'].transform(docs),model['char'].transform(docs),csr_matrix(model['sc'].transform(np.asarray(nums,np.float32)))],format='csr');assert np.allclose(model['clf'].predict_proba(xx)[:,1],batch.confidence,rtol=0,atol=1e-13)
    stats[C]={(t,i):dict(zip(g.node,g.confidence)) for (t,i),g in vv.groupby(['task','rid'])};predictions+=len(vv)
print('All original-feature predictions verified',flush=True)
neighbors={n:set(r.G.predecessors(n))|set(r.G.successors(n)) for n in c.node.unique()};types={n:r.G.nodes[n].get('type','Unknown') for n in c.node.unique()}
def greedy(key,sc,mu,beta):
    chosen=[];left=set(groups.get(key,c.iloc[:0]).node)
    while left and len(chosen)<3:
        ranked=[]
        for n in left:
            red=max((len(neighbors[n].intersection(neighbors[h]))/max(1,len(neighbors[n].union(neighbors[h]))) for h in chosen),default=0.);bonus=int(types[n] not in {types[h] for h in chosen});ranked.append((-(sc[n]-mu*red+beta*bonus),n))
        n=min(ranked)[1];chosen.append(n);left.remove(n)
    return chosen
src=E/'candidate_generation/run_dmdb_proposal_samek.py';s=src.read_text().split('# Build proposal diagnostics first')[0].replace("ROOT=Path('/mnt/data/dmdb_samek')",f'ROOT=Path({str(O)!r})').replace("PATHS=ROOT/'indication_paths.json'",f'PATHS=Path({str(R/"data/raw/drugmechdb/indication_paths.json")!r})').replace("TEST_ROWS=ROOT/'dmdb_graph_only_rerun.csv'",f'TEST_ROWS=Path({str(E/"figure3/proposal_availability_by_query.csv")!r})').replace('OUTDIR.mkdir(exist_ok=True)','');p={};exec(compile(s,str(src),'exec'),p)
pathcount=0
def check_path(x,sc,gate):
    global pathcount
    q=man[(x.task,x.rid)];nodes=json.loads(x.selected_nodes);conf={n:(1. if getattr(x,'weighting','Learned')=='Equal' else sc[n]) for n in nodes};z=p['run_search'](q.source,q.target,conf,gate);gd=set(r.gold[q.rid]);er=len(set(z['edges'])&gd)/max(1,len(gd));assert z['nodes']==json.loads(x.nodes) and z['edges']==[tuple(e) for e in json.loads(x.edges)];assert np.allclose([z['found'],er,float(str(q.answer) in z['nodes']),.7*z['found']+.3*er],[x.PS,x.ER,x.AH,x.utility],atol=1e-14,rtol=0);assert z['visited_nodes']==x.visited_nodes and z['expanded_edges']==x.expanded_edges;pathcount+=1
gridrows=pd.read_csv(O/'validation_grid_per_query.csv',float_precision='round_trip')
for x in gridrows.itertuples(index=False):
    key=(x.task,x.rid);sc=stats[x.C].get(key,{});assert greedy(key,sc,x.mu,x.beta)==json.loads(x.selected_nodes);check_path(x,sc,.3)
grid=pd.read_csv(O/'validation_grid.csv',float_precision='round_trip');actual=gridrows.groupby(['C','mu','beta'])[['PS','ER','AH','utility']].mean().reset_index();joined=grid.merge(actual,on=['C','mu','beta'],suffixes=('_saved','_check'),validate='one_to_one')
for col in ['PS','ER','AH','utility']:assert np.allclose(joined[col+'_saved'],joined[col+'_check'],atol=1e-14,rtol=0)
winner=grid.sort_values(['tie','C_distance','mu','beta'],ascending=[False,True,True,True]).iloc[0];assert all(float(winner[k])==chosen[k] for k in ['C','mu','beta'])
lex=pd.read_csv(ROOT/'audit_output/experiment2_stage2_selection/candidate_scores.csv',float_precision='round_trip');lm={(x.task,x.rid,x.node):x.lexical_score for x in lex.itertuples(index=False)};d=pd.concat([pd.read_csv(O/'validation_controls.csv',float_precision='round_trip'),pd.read_csv(O/'test_per_query.csv',float_precision='round_trip')],ignore_index=True)
for x in d.itertuples(index=False):
    key=(x.task,x.rid);sc=stats[chosen['C']].get(key,{});g=groups.get(key,c.iloc[:0]);nodes=g.node.tolist()
    if x.method=='GraphOnly':expected=[]
    elif x.method=='Proposal':expected=nodes[:3]
    elif x.method=='Lexical':expected=sorted(nodes,key=lambda n:(-lm[(*key,n)],n))[:3]
    elif x.method=='Graph':expected=sorted(nodes,key=lambda n:(r.G.degree(n),n))[:3]
    elif x.method=='ConfidenceOnly':expected=sorted(nodes,key=lambda n:(-sc[n],n))[:3]
    else:expected=greedy(key,sc,0. if x.method=='NoRed' else chosen['mu'],0. if x.method=='NoType' else chosen['beta'])
    assert expected==json.loads(x.selected_nodes);check_path(x,sc,0. if x.method=='GraphOnly' else .3)
print('All greedy sets and independent paths verified',flush=True)
paired=pd.read_csv(O/'paired_cluster_bootstrap.csv',float_precision='round_trip')
for x in paired.itertuples(index=False):
    dd=d[(d.split==x.split)&(d.weighting==x.weighting)];primary=dd[dd.method=='Greedy'].set_index(['task','rid']);other=dd[dd.method==x.comparison.removeprefix('Greedy - ')].set_index(['task','rid']).reindex(primary.index);delta=primary[x.metric]-other[x.metric];cl=delta.groupby(level='rid').agg(['sum','size']).sort_index();ix=np.random.default_rng(20260914).integers(0,len(cl),size=(5000,len(cl)));bs=cl['sum'].to_numpy()[ix].sum(axis=1)/cl['size'].to_numpy()[ix].sum(axis=1);lo,hi=np.quantile(bs,[.025,.975]);assert np.allclose([delta.mean(),lo,hi],[x.delta,x.ci95_low,x.ci95_high],atol=1e-13,rtol=0)
count=0
with zipfile.ZipFile(ROOT/'iclr2027_review_package_v3.zip') as z:
    for info in z.infolist():
        if not info.is_dir():assert (ROOT/'package'/info.filename).read_bytes()==z.read(info.filename);count+=1
report={'passed':True,'original_feature_predictions_recomputed':predictions,'validation_grid_queries':len(gridrows),'control_queries':len(d),'paths_independently_replayed':pathcount,'statistics_recomputed':len(paired),'original_zip_files_identical':count,'original_formula_and_model_preserved':True,'selection_on_validation_only':True};(O/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2),flush=True)
