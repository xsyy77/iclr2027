"""Add prespecified GraphOnly control without touching selected configuration."""
from pathlib import Path
import json,sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'audit_output/stage2_original_greedy_repair';sys.path.insert(0,str(ROOT/'package/iclr2027_review_package/methods'));import dmdb_retrievers as r
assert json.loads((O/'completion.json').read_text())['complete'];allframes=[]
for split,name in [('val','validation_controls.csv'),('test','test_per_query.csv')]:
    d=pd.read_csv(O/name,float_precision='round_trip')
    if 'GraphOnly' not in set(d.method):
        rows=[]
        for q in r.manifest[r.manifest.split==split].itertuples(index=False):
            z=r.search(q.source,q.target,{},0.);gd=set(r.gold[q.rid]);ps=float(z['found']);er=len(set(z['edges'])&gd)/max(1,len(gd));pool=int(d[(d.task==q.task)&(d.rid==q.rid)].iloc[0].pool_size)
            for weighting in ['Equal','Learned']:rows.append(dict(split=split,task=q.task,rid=q.rid,method='GraphOnly',weighting=weighting,pool_size=pool,selected_nodes='[]',PS=ps,ER=er,AH=float(str(q.answer) in z['nodes']),utility=.7*ps+.3*er,nodes=json.dumps(z['nodes']),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges']))
        d=pd.concat([d,pd.DataFrame(rows)],ignore_index=True);d.to_csv(O/name,index=False)
    allframes.append(d)
pd.concat(allframes).groupby(['split','method','weighting'])[['PS','ER','AH','utility']].mean().to_csv(O/'summary.csv')
(O/'control_completion_note.json').write_text(json.dumps({'prespecified_graphonly_added':True,'selection_and_hyperparameters_unchanged':True,'baseline_gate':0.,'other_methods_gate':.3},indent=2),encoding='utf-8')
print('Prespecified GraphOnly control complete',flush=True)
