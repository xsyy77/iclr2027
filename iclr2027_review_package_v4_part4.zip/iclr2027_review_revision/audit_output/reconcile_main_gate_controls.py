"""kKLG-Q3/V6Sn-Q3: reconcile revised Table4 to actual Table1, using existing records.
No training, tuning, new controller or order selection. Optional executable replay provided.
"""
from pathlib import Path
import argparse,hashlib,json,math,sys
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'package/iclr2027_review_package';D=R/'data/processed/drugmechdb';O=ROOT/'audit_output/reconciled_gate_controls';O.mkdir(exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
parser=argparse.ArgumentParser();parser.add_argument('--replay-all',action='store_true');args=parser.parse_args()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):(O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
files=[ROOT/'audit_output/table1_gate_controls_per_query.csv',ROOT/'audit_output/table1_global_gate_validation.csv',D/'semantic_bridge_predictions.csv',D/'semantic_gate_predictions.csv',D/'final_continuous_validation_grid.csv',D/'final_continuous_test_detailed.csv',R/'methods/dmdb_retrievers.py',R/'code/original_recovered/current_dmdb/final_continuous_realgraph.py'];hashes={str(p.relative_to(ROOT)):sha(p) for p in files}
source=pd.read_csv(files[0],float_precision='round_trip');assert len(source)==504*248;assert not source.duplicated(['method','task','rid']).any();manifest=r.manifest;man={(q.task,q.rid):q for q in manifest.itertuples(index=False)};cand=pd.read_csv(D/'semantic_bridge_predictions.csv',float_precision='round_trip');gate=pd.read_csv(D/'semantic_gate_predictions.csv',float_precision='round_trip');confmap={key:g.groupby('node').pred_semantic_conf.max().to_dict() for key,g in cand[cand.condition=='Clean'].groupby(['task','rid','split'])};gp={(x.task,x.rid,x.split):x.p_semantic_gate for x in gate[gate.condition=='Clean'].itertuples(index=False)};qkeys=sorted((q.task,q.rid) for q in manifest[manifest.split=='test'].itertuples(index=False));vg=[.5*math.sqrt(gp[(q.task,q.rid,'val')]) for q in manifest[manifest.split=='val'].itertuples(index=False)];valmean=float(np.mean(vg));testg=np.array([.5*math.sqrt(gp[(*key,'test')]) for key in qkeys]);cv=pd.read_csv(files[1]);selected=cv.iloc[int(np.argmax(cv.utility))];globalg=float(selected.gate);fullgrid=pd.read_csv(D/'final_continuous_validation_grid.csv');winner=fullgrid.sort_values(['utility','path_success','edge_recall'],ascending=[False,False,False]).iloc[0];assert winner.gmax==.5 and winner.gamma==.5
meta_source=R/'code/original_recovered/current_dmdb/step_semantic_gate_diagnostics.py';s=meta_source.read_text().split('\ntexts=[]')[0].replace("BASE=Path('/mnt/data/dmdb_realgraph_experiment')",f'BASE=Path({str(D)!r})').replace("'/mnt/data/indication_paths.json'",repr(str(R/'data/raw/drugmechdb/indication_paths.json')));ns={};exec(compile(s,str(meta_source),'exec'),ns)
from types import SimpleNamespace
inputs=[]
for task,rid in qkeys:
    q=man[(task,rid)];conf=confmap[(task,rid,'test')];txt,nums=ns['feats'](SimpleNamespace(task=task,rid=rid,split='test',condition='Clean'));inputs.append(dict(task=task,rid=rid,source=q.source,target=q.target,question=q.question,selected_nodes=json.dumps(list(conf)),selected_confidences=json.dumps(conf),p_gate=gp[(task,rid,'test')],full_gate=.5*math.sqrt(gp[(task,rid,'test')]),gate_query_text=txt,gate_query_numeric=json.dumps(nums)))
inp=pd.DataFrame(inputs);inp.to_csv(O/'query_inputs.csv',index=False);saved=source[source.method=='Full'].set_index(['task','rid']).reindex(qkeys);assert np.allclose(saved.gate,testg,atol=1e-14,rtol=0)
for name,g in source.groupby('method',sort=False):
    gg=g.set_index(['task','rid']).reindex(qkeys)
    if name=='Full':expected=testg
    elif name=='Validation mean':expected=np.full(248,valmean)
    elif name=='Test mean descriptive':expected=np.full(248,testg.mean())
    elif name=='Validation best global':expected=np.full(248,globalg)
    else:expected=np.random.default_rng(20261108+int(name.split()[-1])).permutation(testg)
    assert np.allclose(expected,gg.gate,atol=1e-14,rtol=0),name
source.to_csv(O/'per_query_controls.csv.gz',index=False,compression='gzip');summary=source.groupby('method')[['PS','ER','AH','utility','gate']].mean();summary.to_csv(O/'all_control_summaries.csv');main=summary.loc[['Full','Validation mean','Validation best global','Test mean descriptive']].reset_index();sh=source[source.method.str.startswith('Shuffled ')];shmean=sh.groupby(['task','rid'])[['PS','ER','AH','utility','gate']].mean();shsummary=sh.groupby('method')[['PS','ER','AH','utility','gate']].mean();main=pd.concat([main,pd.DataFrame([dict(method='Shuffled Full (500-run mean)',**shsummary.mean().to_dict())])],ignore_index=True);main.to_csv(O/'revised_table4.csv',index=False)
paired=[];ids=sorted(saved.index.get_level_values('rid').unique());draw=np.random.default_rng(20260914).integers(0,len(ids),size=(5000,len(ids)))
for name in ['Validation mean','Validation best global','Test mean descriptive','Shuffled Full (per-query 500-run mean)']:
    other=shmean.reindex(saved.index) if name.startswith('Shuffled') else source[source.method==name].set_index(['task','rid']).reindex(saved.index)
    for metric in ['PS','ER','AH','utility']:
        delta=saved[metric]-other[metric];cl=delta.groupby(level='rid').agg(['sum','size']).reindex(ids);boot=cl['sum'].to_numpy()[draw].sum(axis=1)/cl['size'].to_numpy()[draw].sum(axis=1);lo,hi=np.quantile(boot,[.025,.975]);paired.append(dict(comparison='Full - '+name,metric=metric,delta=delta.mean(),ci95_low=lo,ci95_high=hi,rid_clusters=len(ids),query_cases=248))
pd.DataFrame(paired).to_csv(O/'paired_mechanism_cluster_CI.csv',index=False);random=[]
for metric in ['PS','ER','AH','utility']:random.append(dict(metric=metric,p_one_sided=(1+int((shsummary[metric]>=saved[metric].mean()-1e-12).sum()))/501,delta=float(saved[metric].mean()-shsummary[metric].mean())))
order=sorted(range(len(random)),key=lambda i:random[i]['p_one_sided']);prev=0.
for rank,i in enumerate(order):prev=max(prev,min(1.,(4-rank)*random[i]['p_one_sided']));random[i]['p_holm_4_metrics']=prev
pd.DataFrame(random).to_csv(O/'shuffle_randomization_tests.csv',index=False)
# Characterize EVERY beneficial/harmful case versus the validation-mean constant.
constant=source[source.method=='Validation mean'].set_index(['task','rid']).reindex(saved.index);case=saved[['PS','ER','AH','utility','gate']].join(constant[['PS','ER','AH','utility']],rsuffix='_constant').reset_index().merge(inp,on=['task','rid'],validate='one_to_one');case['utility_delta']=case.utility-case.utility_constant;case['status']=np.where(case.utility_delta>1e-12,'benefit',np.where(case.utility_delta< -1e-12,'harm','unchanged'));rawmeta={str(rec['graph']['_id']):rec['graph'] for rec in r.paths};case['drug']=case.rid.map(lambda i:rawmeta[i].get('drug',''));case['disease']=case.rid.map(lambda i:rawmeta[i].get('disease',''));case.to_csv(O/'all_query_effects_vs_validation_mean.csv',index=False);examples=case[case.status!='unchanged'].copy();pathrows=[]
for x in examples.itertuples(index=False):
    q=man[(x.task,x.rid)];conf=json.loads(x.selected_confidences)
    for method,g in [('Full',x.full_gate),('Validation mean',valmean)]:
        z=r.search(q.source,q.target,conf,g);pathrows.append(dict(task=x.task,rid=x.rid,method=method,gate=g,drug=x.drug,disease=x.disease,nodes=json.dumps(z['nodes']),node_names=json.dumps([r.G.nodes[n].get('name',n) for n in z['nodes']]),edges=json.dumps(z['edges']),visited_nodes=z['visited_nodes'],expanded_edges=z['expanded_edges']))
pd.DataFrame(pathrows).to_csv(O/'changed_case_paths.csv',index=False)
# Same Full as Table1, and explicit old-versus-revised comparison (never silently relabel old values).
archived=pd.read_csv(D/'final_continuous_test_detailed.csv');archived=archived[(archived.condition=='Clean')&(archived.method=='Full Continuous Gate')].set_index(['task','rid']).reindex(qkeys);assert np.allclose(saved[['PS','ER','AH','gate']],archived[['found','edge_recall','answer_hit','gate']].to_numpy(),atol=1e-14,rtol=0)
old=pd.read_csv(R/'paper_checks/data/stage3_controls_summary.csv');old.to_csv(O/'original_table4_summary_unchanged.csv',index=False)
config={'candidate_setting':'archived supplied reference-aligned Clean candidate sets, not automatic pipeline','candidate_scores':'frozen semantic_bridge_predictions.csv pred_semantic_conf, duplicate nodes max confidence as original code','gate_input_features':'original step_semantic_gate_diagnostics.py feats; query_inputs.csv stores exact query text/numeric inputs','controller':{'gmax':.5,'gamma':.5,'selection':'saved original42-combination validation grid, all five conditions; nearest .05 alpha-cache proxy in selection, continuous g at test as source implements','validation_mean':valmean,'test_mean':float(testg.mean()),'best_constant':globalg,'constant_selection':'original validation grid .00:.05:.50 utility; no test selection'},'search':{'beam':2,'hops':8,'node_budget':14,'edge_budget':20,'order':'unchanged original OUT'},'revised_table4_Full_identical_to_Table1':True,'old_Table4':{'ER':38.0534746568278,'mean_gate':.1091746267403836,'status':'preserved as archived original control output, NOT relabeled as verified main configuration','historical_generator_not_fully_verified':True},'scope':'corrected experimental alignment, not a changed gate/model; original table kept in correction record','source_hashes':hashes};save('configuration.json',config)
replayed=0
if args.replay_all:
    inmap={(x.task,x.rid):x for x in inp.itertuples(index=False)}
    for index,x in enumerate(source.itertuples(index=False)):
        q=man[(x.task,x.rid)];cf=json.loads(inmap[(x.task,x.rid)].selected_confidences);z=r.search(q.source,q.target,cf,x.gate);gd=set(r.gold[x.rid]);er=len(set(z['edges'])&gd)/max(1,len(gd));assert np.allclose([z['found'],er,float(str(q.answer) in z['nodes'])],[x.PS,x.ER,x.AH],atol=1e-14,rtol=0);assert z['visited_nodes']<=14 and z['expanded_edges']<=20;replayed+=1
        if (index+1)%25000==0:print(f'Existing main-control replay {index+1}/{len(source)}',flush=True)
    save('full_replay_verification.json',{'passed':True,'replayed_query_controls':replayed,'all_gates_verified_from_original_predictions_and_fixed_seeds':True,'same_Full_as_Table1':True,'new_training_or_parameter_tuning':False,'purpose':'verification of existing records, not new experiment selection'})
assert all(sha(ROOT/n)==h for n,h in hashes.items());save('assembly_verification.json',{'passed':True,'source_control_rows':len(source),'all_seeded_gate_assignments_verified':True,'same_Full_as_Table1':True,'historical_table4_retained':True,'input_hashes_unchanged':True,'query_effect_counts':{k:int(v) for k,v in case.status.value_counts().items()},'all_record_replay_count_this_call':replayed});print(main.to_string(index=False),flush=True);print(pd.DataFrame(random).to_string(index=False),flush=True);print(case.groupby('status').size().to_dict(),flush=True)
