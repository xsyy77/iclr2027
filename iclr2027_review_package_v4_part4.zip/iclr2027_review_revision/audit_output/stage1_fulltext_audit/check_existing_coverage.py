"""Audit existing candidate/label outputs against manuscript claims; no new retrieval."""
from pathlib import Path
import json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2];O=ROOT/'audit_output/stage1_fulltext_audit';R=ROOT/'package/iclr2027_review_package'
raw=json.loads((R/'data/raw/drugmechdb/indication_paths.json').read_text(encoding='utf-8'));types={}
for record in raw:
    for n in record['nodes']:types.setdefault(str(n['id']),n.get('label','Unknown'))
views={'Molecular':{'Protein','ChemicalSubstance','MolecularActivity','GeneFamily'},'Cellular':{'Cell','CellularComponent','MacromolecularComplex','GrossAnatomicalStructure'},'System':{'BiologicalProcess','Pathway','PhenotypicFeature','OrganismTaxon'}}
old=pd.read_csv(R/'data/processed/drugmechdb/bridge_marginal_training_samples.csv');old=old[(old.split=='test')&(old.condition=='Clean')].copy();old['view']=old.node.map(lambda n:next((v for v,t in views.items() if types.get(n) in t),'Other'))
auto=pd.read_csv(ROOT/'audit_output/experiment1_recovered_proposer/candidates_scored.csv');auto=auto[auto.split=='test'];labels=pd.read_csv(ROOT/'audit_output/aligned_weighting_evaluation/test_candidate_usefulness.csv');auto=auto.merge(labels[['task','rid','node','beneficial']],on=['task','rid','node'],validate='one_to_one');rows=[]
for protocol,frame in [('Archived Clean controlled partition',old),('Automatic manifest-endpoint proposal',auto)]:
    for view in ['Molecular','Cellular','System','Multi-view']:
        g=frame[frame.view.isin(views)] if view=='Multi-view' else frame[frame.view==view];covered=g[g.beneficial==1][['task','rid']].drop_duplicates();rows.append(dict(protocol=protocol,view=view,candidate_rows=len(g),queries=248,useful_query_count=len(covered),useful_query_coverage=len(covered)/248))
d=pd.DataFrame(rows);d.to_csv(O/'existing_useful_coverage_comparison.csv',index=False);automatic=d[d.protocol.str.startswith('Automatic')];assert int(automatic[automatic.view=='System'].iloc[0].useful_query_count)==100;assert int(automatic[automatic.view=='Multi-view'].iloc[0].useful_query_count)==152
verification={'read_only_existing_output_audit':True,'new_training_or_retrieval_runs':0,'automatic_strongest_single':{'view':'System','count':100,'denominator':248,'percent':10000/248},'automatic_union':{'count':152,'denominator':248,'percent':15200/248},'matches_manuscript_rounded_40_32_to_61_29':True,'clean_partition_is_different_protocol':True,'warning':'Counts support original coverage statement for automatic pools; do not assign them to archived Clean partition or infer historical execution identity. Graph remains transductive.'}
(O/'coverage_check.json').write_text(json.dumps(verification,indent=2),encoding='utf-8');print(d.to_string(index=False))
