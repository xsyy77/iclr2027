"""Check exported exact gate features against the released refit checkpoint.
Frozen archived predictions remain the primary replay inputs; retraining tolerance disclosed.
"""
from pathlib import Path
import hashlib,json,sys,math
import joblib,numpy as np,pandas as pd
from scipy.sparse import csr_matrix,hstack
ROOT=Path(__file__).resolve().parents[1];O=ROOT/'audit_output/reconciled_gate_controls';R=ROOT/'package/iclr2027_review_package';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'methods'));import dmdb_retrievers as r
q=pd.read_csv(O/'query_inputs.csv');m=joblib.load(ROOT/'audit_output/experiment1_recovered_proposer/gate_model.joblib');xx=hstack([m['word'].transform(q.gate_query_text),m['char'].transform(q.gate_query_text),csr_matrix(m['sc'].transform(np.asarray([json.loads(x) for x in q.gate_query_numeric],np.float32)))],format='csr');p=m['clf'].predict_proba(xx)[:,1];maxerror=float(np.max(np.abs(p-q.p_gate)));assert maxerror<1e-5,maxerror
paths=0
for x,pr in zip(q.itertuples(index=False),p):
    conf=json.loads(x.selected_confidences);a=r.search(x.source,x.target,conf,x.full_gate);b=r.search(x.source,x.target,conf,.5*math.sqrt(float(pr)));assert a==b,(x.task,x.rid);paths+=1
q['refit_p_gate']=p;q['probability_abs_error']=np.abs(p-q.p_gate);q.to_csv(O/'query_probability_refit_check.csv',index=False);proof={'passed':True,'query_feature_rows':len(q),'original_gate_numeric_training_sample_count':int(m['sc'].n_samples_seen_),'max_archived_vs_refit_p_absolute_difference':maxerror,'identical_clean_paths_with_archived_or_refit_gate':paths,'frozen_prediction_replay_uses_archived_values':True,'not_claiming_bit_identical_original_model_weights':True,'checkpoint_sha256':hashlib.sha256((ROOT/'audit_output/experiment1_recovered_proposer/gate_model.joblib').read_bytes()).hexdigest()};(O/'input_probability_verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(json.dumps(proof,indent=2))
