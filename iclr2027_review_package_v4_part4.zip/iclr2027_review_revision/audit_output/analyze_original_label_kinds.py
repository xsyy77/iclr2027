"""Existing-record decomposition of original usefulness labels, TRAIN/VAL only.
No fitting, search, tuning or new model adoption.
"""
from pathlib import Path
import json,pandas as pd
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'audit_output';O=A/'complete_original_contexts'
t=pd.read_csv(A/'stage2_training_alignment_pilot/automatic_training_and_validation_candidates.csv');t=t[t.split=='train'].copy();t['base_PS']=(t.base_utility>.5).astype(int)
t['positive_kind']='nonpositive';t.loc[t.beneficial==1,'positive_kind']='ER_only';t.loc[(t.beneficial==1)&(t.singleton_PS>t.base_PS),'positive_kind']='PS_gain'
t.groupby('positive_kind').agg(rows=('node','size'),mean_delta=('delta','mean'),median_delta=('delta','median')).to_csv(O/'train_positive_label_kinds.csv')
v=pd.read_csv(A/'original_validation_bottlenecks/validation_singleton_labels.csv');ctrl=pd.read_csv(A/'stage2_original_greedy_repair/validation_controls.csv');base=ctrl[(ctrl.method=='GraphOnly')&(ctrl.weighting=='Equal')][['task','rid','PS']].rename(columns={'PS':'base_PS'});v=v.merge(base,on=['task','rid'],validate='many_to_one')
v['positive_kind']='nonpositive';v.loc[v.beneficial==1,'positive_kind']='ER_only';v.loc[(v.beneficial==1)&(v.PS>v.base_PS),'positive_kind']='PS_gain'
v.groupby('positive_kind').agg(rows=('node','size'),mean_delta=('delta','mean'),median_delta=('delta','median')).to_csv(O/'validation_positive_label_kinds.csv')
rows=[]
for key,g in v.groupby(['task','rid']):
    ps=set(g[g.positive_kind=='PS_gain'].node);er=set(g[g.positive_kind=='ER_only'].node)
    for method,weight in [('Greedy','Learned'),('ConfidenceOnly','Learned'),('Proposal','Equal')]:
        x=ctrl[(ctrl.task==key[0])&(ctrl.rid==key[1])&(ctrl.method==method)&(ctrl.weighting==weight)].iloc[0];s=set(json.loads(x.selected_nodes));rows.append(dict(task=key[0],rid=key[1],method=method,pool_has_PS_gain=bool(ps),pool_has_ER_only=bool(er),selected_PS_gain=bool(ps&s),selected_ER_only=bool(er&s),final_PS=x.PS,final_ER=x.ER,final_utility=x.utility))
d=pd.DataFrame(rows);d.to_csv(O/'validation_positive_kind_selection_per_query.csv',index=False);d.groupby('method').agg(queries=('rid','size'),pool_has_PS_gain=('pool_has_PS_gain','sum'),pool_has_ER_only=('pool_has_ER_only','sum'),selected_PS_gain=('selected_PS_gain','sum'),selected_ER_only=('selected_ER_only','sum'),final_PS=('final_PS','mean'),final_ER=('final_ER','mean'),final_utility=('final_utility','mean')).to_csv(O/'validation_positive_kind_selection_summary.csv')
# Independently confirm label partition directly from utility arithmetic and stored outcomes.
assert (t[t.beneficial==1].delta>0).all()
assert ((t.base_utility<.31)|(t.base_utility>.69)).all()
assert (t[t.positive_kind=='PS_gain'].singleton_PS==1).all()
assert (t[t.positive_kind=='PS_gain'].base_PS==0).all()
assert (t[t.positive_kind=='ER_only'].singleton_PS==t[t.positive_kind=='ER_only'].base_PS).all()
assert len(d)==239*3
proof=dict(passed=True,TRAIN_singleton_positive_PS_gain=int((t.positive_kind=='PS_gain').sum()),TRAIN_singleton_positive_ER_only=int((t.positive_kind=='ER_only').sum()),validation_candidate_labels=len(v),validation_selection_records=len(d),no_new_search_fit_or_test=True,singleton_labels_not_guaranteed_set_utility=True,observational_decomposition_not_causal_proof=True)
(O/'label_kind_analysis_verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8');print(json.dumps(proof,indent=2))
