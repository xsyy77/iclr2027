# Anonymous review artifacts: confidence-gated mechanistic Bridge retrieval

This repository contains source, saved inputs and outputs, and numerical checks for the accompanying ICLR submission. It is an **audit-ready snapshot**, not a claim that every paper result can be rerun end to end without external resources. See `REPRODUCIBILITY_STATUS.md` before interpreting any result.

## Start here

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python scripts/check_project.py
python paper_checks/verify_bundle.py
python evaluation/evaluate_saved_results.py
```

`verify_bundle.py` checks 34 values behind the current DrugMechDB clean-condition table, Stage-II discrimination, utility-weight sensitivity, and Stage-III controls against included prediction and summary files. It is **result verification**, not fresh model training. `evaluate_saved_results.py` recomputes aggregates from saved detailed files; its 1,240-row DrugMechDB intervention is a different experimental condition from the 248-query clean-condition table. Do not combine those results.

## Where to look

| Area | Code | Data and outputs | Status |
|---|---|---|---|
| Graph-constrained retrieval, Bridge reliability, query gate | `methods/`, `code/original_recovered/current_dmdb/` | `data/raw/drugmechdb/`, `data/processed/drugmechdb/`, `results/dmdb/`, `checkpoints/` | Original source and saved inputs/outputs; historical absolute paths need configuration for a fresh run |
| Stage I/II/III controlled analyses | `code/original_recovered/section5/` | `results/section5/`, `paper_checks/data/` | Saved result checks included |
| EpiKG | `code/original_recovered/current_epikg/`, `methods/epikg_retrievers.py` | `data/raw/epikg/`, `data/processed/epikg/`, `results/epikg/` | Original source and saved inputs/outputs |
| Section 3 and historical ablations | `code/original_recovered/legacy/`, `supplementary_code/` | `results/historical/` | Historical provenance; do not equate these variants with the final pipeline |
| Coefficient sensitivity and figures | `paper_checks/parameter_sensitivity/`, `paper_checks/code/` | `paper_checks/data/` | Separate local checks and plotting scripts |
| CWQ target-agnostic transfer | `transfer/cwq/code/` | `transfer/cwq/results/` | Run source and saved results; external CWQ corpus not redistributed |
| BioHopR target-agnostic transfer | `transfer/biohopr/code/` | `transfer/biohopr/results/` | Run source and saved results; external BioHopR/PrimeKG data not redistributed |

`code/reconstructed_legacy/` contains compatibility reconstructions for missing historical scripts. These are explicitly **not** the original source. `audit/CODE_STATUS.csv` and `audit/MISSING_SOURCE_BUT_OUTPUTS_EXIST.md` detail provenance. `FILE_MANIFEST.csv` records checksums for the distributed files.

## Data and run order

The included DrugMechDB and EpiKG raw resources, fixed splits, manifests, prediction tables, and checkpoints are under `data/`. To inspect the original pipeline order, run `bash scripts/run_current_experiments.sh`; it performs structural/result checks and explains why the archived scripts still contain `/mnt/data/...` paths. `scripts/make_splits.py` can regenerate the split files from the packaged manifests. See `REPRODUCIBILITY_STATUS.md` for commands and limitations by experiment.

Transfer benchmarks require their original datasets. CWQ expects NSM/GraftNet-style `CWQ` files (`train_simple.json`, `dev_simple.json`, `test_simple.json`, `entities.txt`, `relations.txt`); run `python transfer/cwq/code/check_cwq.py PATH_TO_CWQ` before `run_cwq_ours.py`. BioHopR scripts expect `data/biohopr_raw/BioHopR.json` and `data/primekg.csv` in their working directory. Do not interpret the CWQ or BioHopR metrics as biomedical mechanistic-path results.

## Scope and anonymity

Large third-party benchmark corpora and third-party repositories are not included. The archive retains original experiment scripts with historical `/mnt/data` paths for provenance, but removes local user-home paths. It does not include API credentials or author-identifying manuscript files. Numerical checks can be run immediately; full benchmark reruns may require restoring external data or adapting the archived path configuration.
